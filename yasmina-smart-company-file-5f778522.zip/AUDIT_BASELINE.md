# Yasmina System — Baseline Audit Report (`AUDIT_BASELINE.md`)

**Date:** 2026-11-25  
**Branch:** `fix/audit-100`  
**Audit Standard:** Apple-Level Line-by-Line Engineering & Security Audit + Addy Osmani `agent-skills` Review  

---

## 1. Baseline Rubric Score: **38 / 100**

| Category | Max Points | Baseline Score | Rationale & Evidence |
| :--- | :---: | :---: | :--- |
| **Security** | 30 | **8 / 30** | Critical `canUsePreviewFallback` auth bypass in `rbac.ts` (#103) grants `SUPER_ADMIN` to unauthenticated requests; hardcoded JWT secrets (`yasmina_super_secret_jwt_key_2026`) (#11), admin password (`ChangeMe_Sanad2026!`) (#24, #104), and backup encryption key (#12); privilege escalation in `userRoutes.ts` (#46); cross-tenant IDOR across routes/services (#49, #50, #51, #107); path traversal / arbitrary file download in `companyRoutes.ts` (#105); stored XSS / content sniffing in document downloads (#55, #56); incomplete SSRF check (#30, #54); permissive CORS (`origin: true`), `sameSite: "none"` cookies without CSRF validation (#22), `20mb` global body limit (#27), unauthenticated `/api/whatsapp/*`, `/api/system/*`, `/api/requests/*` endpoints (#23, #28, #106). |
| **Correctness & Reliability** | 25 | **11 / 25** | 9 `tsc --noEmit` compile errors (#1–#7); missing `import path` in `companyRoutes.ts` causes `ReferenceError` (#9); `fetchMediaFromEvolution` return object treated as `Buffer` in `evolutionRoutes.ts` (#10); `taxId` overwritten with CR number (#8, #62); `crDocumentUrl` polluted by `/cr-download` relative URL on edit (#66); race condition in `REQ-YYYY-NNNN` generation (#19); unawaited async side-effects in `requestService.ts` (#13); WhatsApp duplicate message echo, zombie reconnect timers, and unbounded caches (#69, #77–#88); cron double-scheduling, silent error swallowing, and destructive `--clean --if-exists` prior to `pg_restore` (#70, #75, #94–#102). |
| **Code Quality & Architecture** | 20 | **8 / 20** | 11 backend files minified into single lines (#29); 12 files exceed 800 lines (up to 4,971 lines in `crExtractionService.ts`) (#37); no ESLint configuration (#38); pervasive `any` usage (#35) and `console.log`/`console.error` instead of Pino (#36); inconsistent error response shapes (#42) and raw `err.message` leaks (#53); `runMigrations()` called inside runtime `pool.query` error handlers (#59); hand-patched static bundle referenced in `index.html` with Python/JS binary bundle patch scripts (#33, #104). |
| **Testing & Verification** | 15 | **7 / 15** | `npm test` only runs 2 custom scripts out of 8 (`master_audit_verification.ts` and `expiry_monitoring_verification.ts`), and `[EXP-13]` fails (`unauth=200`) (#39, #61); no Vitest test runner; zero unit tests for auth lockout, refresh token rotation, RBAC hierarchy, SSRF, file download confinement, or backup round-trip. |
| **Operations, Build & Docs** | 10 | **4 / 10** | `npm run build` does not run `vite build` (#40); `index.html` points to pre-compiled `/assets/index-Dy4Gmkbw.js` instead of `/src/main.tsx` (#104); `npm audit --omit=dev` has 1 high vulnerability (`body-parser <1.20.9`) (#32); no `.github/workflows/ci.yml`; default AI Studio template `README.md` (#43); no `CHANGELOG.md` or `PRIVACY.md` (#45, #48). |
| **TOTAL** | **100** | **38 / 100** | **Fails 100/100 Gate — Proceeding to Phase 3 Remediation** |

---

## 2. Baseline Command Verification Outputs

### 2.1 `npx tsc --noEmit` (Exit Code: 2 — 9 Errors)
```text
server.ts(9,55): error TS2345: Argument of type 'number | undefined' is not assignable to parameter of type 'string'.
src/lib/api.ts(544,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/lib/api.ts(550,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/CompaniesPage.tsx(234,62): error TS2339: Property 'notifyError' does not exist on type '{ notifications: Notification[]; unreadCount: number; ... }'.
src/pages/CustomersPage.tsx(184,38): error TS2345: Argument of type 'string | undefined' is not assignable to parameter of type 'string'.
src/server/routes/aiRoutes.ts(1130,36): error TS2339: Property 'category' does not exist on type '{}'.
src/server/routes/customerRoutes.ts(229,11): error TS2769: No overload matches this call.
src/server/routes/customerRoutes.ts(238,24): error TS2339: Property 'id' does not exist on type 'never'.
src/server/routes/evolutionRoutes.ts(378,21): error TS2345: Argument of type '{ buffer: Buffer<ArrayBufferLike>; mimeType: string; } | null' is not assignable to parameter of type ' WithImplicitCoercion<ArrayBuffer | SharedArrayBuffer>'.
```

### 2.2 `npm run build` & `npx vite build`
```text
> yasmina-system@2.5.0 build
> esbuild src/server/serverEntry.ts --bundle --platform=node --packages=external --outfile=dist/server.js

  dist/server.js  881.3kb
```
- `npm run build` did not invoke `vite build` (#40).
- `npx vite build` only transformed 5 modules (`dist/index.html 5.20 kB`) because `index.html` references pre-built `/assets/index-Dy4Gmkbw.js` instead of `/src/main.tsx` (#104).

### 2.3 `npm audit --omit=dev` (6 Vulnerabilities: 1 High, 5 Moderate)
```text
body-parser <1.20.9 — Severity: high (GHSA-76c9-3jph-rj3q) via express@4.21.1
gaxios 7.0.0 - 7.1.3 — Severity: moderate (GHSA-p9pc-299p-vxgp) via @google-cloud/storage
glob 10.2.0 - 10.4.5 — Severity: moderate (GHSA-5j98-mcp5-4vw2) via rimraf
minimatch <3.1.3 || 9.0.0 - 9.0.6 — Severity: moderate via gaxios / glob
```

### 2.4 `npm test` (1 Failure in `expiry_monitoring_verification.ts`)
```text
master_audit_verification.ts: 14 passed, 0 failed
expiry_monitoring_verification.ts: 12 passed, 1 failed
  ❌ [EXP-13] Protected endpoint rejects unauthenticated requests and malformed inputs (unauth=200, badStatus=400, badSnooze=400)
```

---

## 3. Complete Inventory of Findings (108 Confirmed Findings)

### Part A — Initial Strict Audit Findings (#1–#45)
| # | Severity | File & Line | Description |
| :- | :--- | :--- | :--- |
| 1 | HIGH | `server.ts:9` | `parseInt(process.env.PORT, 10)` passes `number | undefined` to `parseInt`. |
| 2 | HIGH | `src/lib/api.ts:544,550` | `customerId: string | undefined` assigned to `Transaction.customerId: string` in `toFrontendTransaction`. |
| 3 | HIGH | `src/pages/CompaniesPage.tsx:234` | `notifyError` destructured from `useNotifications()`, which did not export `notifyError`. |
| 4 | HIGH | `src/pages/CustomersPage.tsx:184` | `c.companyId` (`string | undefined`) passed to `setSelectedCompanyForDetails(string)`. |
| 5 | HIGH | `src/server/routes/aiRoutes.ts:1130` | `const s = service[0] || {}` inferred as `{}`; accessing `s.category` fails TypeScript check. |
| 6 | HIGH | `src/server/routes/customerRoutes.ts:229,238` | `db.insert(customerDocuments).values({...})` passes nullable strings where Drizzle expects non-undefined types, causing `inserted` to be `never`. |
| 7 | HIGH | `src/pages/CustomerRequestsPage.tsx:157` | `result.transaction.id` and `result.transaction.number` accessed, whereas `convertToTransaction` returned `{ transactionId }`. |
| 8 | CRITICAL | `src/server/routes/companyRoutes.ts:151,180,224` | `taxId` overwritten with `normalizedCr` (`c.taxId || c.crNumber`), corrupting distinct CR vs Tax Card numbers. |
| 9 | CRITICAL | `src/server/routes/companyRoutes.ts:930` | `path.basename(fileUrl)` called without `import path from "path"`, throwing `ReferenceError: path is not defined`. |
| 10 | CRITICAL | `src/server/routes/evolutionRoutes.ts:378` | `fetchMediaFromEvolution` returns `{ buffer, mimeType } | null`, passed directly to `Buffer.from(mediaBuffer)`. |
| 11 | CRITICAL | `src/server/auth.ts:5-6` | Hardcoded fallback JWT secrets (`yasmina_super_secret_jwt_key_2026`, `yasmina_super_refresh_secret_2026`), and `verifyToken` accepts refresh tokens as access tokens. |
| 12 | CRITICAL | `src/server/services/backupService.ts:127-146` | Hardcoded fallback encryption key `yasmina-enterprise-secret-key-2026`, static salt `'yasmina-salt'`, and 12-byte GCM authTag on decrypt. |
| 13 | HIGH | `src/server/services/requestService.ts:174-205` | `db.insert(auditLogs)` and `db.insert(notifications)` inside `createCustomerFromRequest` are not awaited (`Promise` floating). |
| 14 | HIGH | `src/server/routes/companyRoutes.ts:29-78` | `GET /api/companies` loads all tenant rows + multi-MB base64 `crDocumentUrl` into RAM and paginates in JavaScript. |
| 15 | HIGH | `src/server/routes/authRoutes.ts:5-31` | Login lockout uses an in-memory `Map` keyed by `${ip}_${username}`, lost on restart and bypassable across proxies. |
| 16 | HIGH | `src/db/index.ts:93-404` | Ad-hoc `CREATE TABLE IF NOT EXISTS` and `ALTER TABLE` blocks wrapped in `try { ... } catch (_) {}` instead of Drizzle migrations + fail-fast startup. |
| 17 | HIGH | `src/server/routes/evolutionRoutes.ts:1` | `/test-incoming` is enabled in production and unauthenticated, allowing arbitrary WhatsApp message injection. |
| 18 | HIGH | `src/server/routes/transactionRoutes.ts:1`, `customerRoutes.ts:94` | Validation error logs dump full `req.body` (including PII and base64 files) to logs. |
| 19 | HIGH | `src/server/services/requestService.ts:62-75` | `generateRequestCode()` uses `SELECT count(*)` without locking or retry, racing under concurrent requests. |
| 20 | HIGH | `src/server/app.ts:1` | `app.use("/api/db/companies", companyRoutes)` and `app.use("/api/evolution", evolutionRoutes)` duplicate primary mounts while frontend calls both indiscriminately. |
| 21 | HIGH | `src/server/app.ts:1` | `cors({ origin: true, credentials: true })` reflects any origin with credentials enabled. |
| 22 | HIGH | `src/server/routes/authRoutes.ts:116-127` | Cookies set with `sameSite: "none"` without CSRF Origin validation. |
| 23 | HIGH | `src/server/app.ts:1`, `src/server/routes/systemRoutes.ts:14` | Three competing health routes (`/api/health`, `/api/system/health`, `/api/anydoc/info`) leaking unauthenticated DB stats, memory usage, and GCP project/region info. |
| 24 | CRITICAL | `src/db/users.ts:75-115`, `src/server/routes/authRoutes.ts:90-105` | Hardcoded default admin password `'ChangeMe_Sanad2026!'` seeded and auto-reset on login. |
| 25 | HIGH | `src/App.tsx:73-110` | `isAuthenticated` initialized solely from `localStorage.getItem('yasmina_user')` without verifying `/api/auth/session`. |
| 26 | HIGH | `src/server/app.ts:1` | Global `/api/` rate limiter (`max: 5000`) skips `/auth`, `/whatsapp`, and `/companies`. |
| 27 | HIGH | `src/server/app.ts:1` | Global `express.json({ limit: "20mb" })` allows 20 MB payloads on every unauthenticated endpoint. |
| 28 | CRITICAL | `src/server/routes/evolutionRoutes.ts:1-443` | All `/api/whatsapp/*` endpoints lack `requireAuth` and `requirePermission`. |
| 29 | HIGH | `src/server/routes/*.ts`, `src/server/app.ts`, `src/db/schema.ts` | 11 critical source files minified onto 1-2 lines. |
| 30 | HIGH | `src/server/routes/webhookRoutes.ts:22-35` | `isAllowedMediaHost` regex misses `172.16.0.0/12`, `169.254.169.254` metadata IP, IPv6 private ranges, and DNS rebinding. |
| 31 | MEDIUM | `src/db/index.ts:42-68`, `src/db/drizzle.config.ts:13` | `Pool` lacks `DATABASE_SSL` configuration and `drizzle.config.ts` hardcodes `ssl: false`. |
| 32 | HIGH | `package.json` | `npm audit --omit=dev` reports 1 high vulnerability (`body-parser <1.20.9`) and 5 moderate advisories. |
| 33 | HIGH | `package.json:11`, `scripts/patch-*.{js,py}` | `"postinstall": "node scripts/patch-whatsapp.js"` and binary bundle monkey-patching scripts in `scripts/`. |
| 34 | MEDIUM | `package.json:16-58` | Build/type packages (`@types/*`, `typescript`, `vite`, `@vitejs/plugin-react`, `@tailwindcss/vite`, `tailwindcss`, `autoprefixer`) placed in `dependencies`. |
| 35 | MEDIUM | `src/**/*.ts`, `src/**/*.tsx` | Pervasive `any` usage (`req: any`, `catch (error: any)`) and missing `Express.Request` augmentation. |
| 36 | MEDIUM | `src/server/**/*.ts` | `console.log`/`console.error` used across server files while `pino` in `package.json` is unused. |
| 37 | MEDIUM | `src/server/services/crExtractionService.ts`, etc. | 12 source files exceed 800 lines (up to 4,971 lines). |
| 38 | MEDIUM | Root directory | No ESLint configuration file or `"lint"` script in `package.json`. |
| 39 | HIGH | `package.json:10`, `tests/` | No Vitest runner; `npm test` only runs 2 of 8 test files. |
| 40 | HIGH | `package.json:8-9` | `npm run build` only bundles `dist/server.js` without building the Vite frontend; `start` script uses `tsx` instead of `node dist/server.js`. |
| 41 | MEDIUM | `vite.config.ts`, `src/App.tsx` | All 15 pages eagerly imported in `App.tsx`, producing a monolithic 1.54 MB JS bundle. |
| 42 | MEDIUM | `src/server/routes/*.ts`, `src/server/middleware/errorHandler.ts` | Three inconsistent error response shapes across routes. |
| 43 | LOW | `README.md`, `.env.example` | Default AI Studio placeholder `README.md` and incomplete `.env.example`. |
| 44 | MEDIUM | `src/pages/SettingsPage.tsx:197`, `WhatsAppPage.tsx:356` | Tenant settings stored only in browser `localStorage` and local JSON file instead of a tenant-scoped DB table via `GET/PUT /api/settings`. |
| 45 | LOW | `CHANGELOG.md` | No `CHANGELOG.md` documenting breaking API/cookie/CORS changes. |

### Part B — `agent-skills` Second-Pass Findings (#46–#61)
| # | Severity | File & Line | Description |
| :- | :--- | :--- | :--- |
| 46 | CRITICAL | `src/server/routes/userRoutes.ts:1` | Any `ADMIN` (`users:write`) can create or promote a user to `SUPER_ADMIN`, modify their own role, or overwrite any user's password without `oldPassword`. |
| 47 | HIGH | `src/server/routes/aiRoutes.ts:520`, `crExtractionService.ts:4714`, `requestService.ts:340`, `whatsappDocumentProcessor.ts:316` | Untrusted document/WhatsApp text interpolated directly into Gemini prompts without `<untrusted_input>` tagging or injection guards. |
| 48 | MEDIUM | `PRIVACY.md`, `src/server/routes/aiRoutes.ts` | PII and identity documents sent to external Gemini API without `PRIVACY.md`, consent config, or retention policy. |
| 49 | CRITICAL | `src/server/routes/*.ts`, `src/server/services/*.ts` | Pervasive `req.user?.tenantId \|\| 'default_tenant'` fallback across routes and services. |
| 50 | HIGH | `src/server/routes/evolutionRoutes.ts:357` | `GET /api/whatsapp/media/:messageId` does not verify `messageId` belongs to `req.user.tenantId`. |
| 51 | HIGH | `src/server/routes/transactionRoutes.ts`, `invoiceRoutes.ts`, `contractRoutes.ts`, `expenseRoutes.ts`, `cashRoutes.ts`, `employeeRoutes.ts`, `customerRoutes.ts` | Foreign keys (`branchId`, `companyId`, `customerId`, `serviceId`, `transactionId`, `invoiceId`, `cashSessionId`) accepted in `POST`/`PUT` without verifying tenant ownership. |
| 52 | HIGH | `src/server/routes/customerRoutes.ts`, `transactionRoutes.ts`, `invoiceRoutes.ts`, `employeeRoutes.ts`, `expenseRoutes.ts`, `serviceRoutes.ts`, `branchRoutes.ts`, `userRoutes.ts`, `cashRoutes.ts`, `contractRoutes.ts` | Full table scans (`SELECT *`) with in-memory filtering instead of SQL pagination and `WHERE` clauses. |
| 53 | MEDIUM | `src/server/middleware/errorHandler.ts:15`, `src/server/routes/*.ts` | Raw `err.message` returned to clients on 500 Internal Server Errors. |
| 54 | HIGH | `src/server/routes/webhookRoutes.ts:37-115` | `fetchMediaFromEvolution` passes `mediaUrl` to `fetch()` without DNS resolution pinning (DNS rebinding SSRF) or stream size limit, and inserts audit logs on invalid API keys (DB DoS). |
| 55 | HIGH | `src/server/routes/customerRoutes.ts:310-335` | `GET /api/customers/customer-documents/:id/download` uses `Content-Disposition: inline` with user-supplied `fileType` and lacks `X-Content-Type-Options: nosniff` (stored XSS vector). |
| 56 | MEDIUM | `src/server/routes/companyRoutes.ts:925`, `customerRoutes.ts:318` | Arabic filenames in `Content-Disposition` lack RFC 5987 `filename*=UTF-8''...` encoding. |
| 57 | HIGH | `src/server/services/backupService.ts:356,412` | `execAsync` interpolates `databaseUrl` and file paths into `/bin/sh` shell strings instead of using `execFile`/`spawn` with argument arrays and `PGPASSWORD` env. |
| 58 | MEDIUM | `src/server/app.ts:1` | `app.set("trust proxy", 1)` hardcoded instead of reading `TRUST_PROXY` from environment. |
| 59 | HIGH | `src/db/index.ts:81`, `contractRoutes.ts:1`, `transactionRoutes.ts:1`, `employeeRoutes.ts:1` | `pool.query` wrapper and route catch blocks call `runMigrations()` at runtime on SQL errors. |
| 60 | HIGH | `src/server/routes/authRoutes.ts:138-165` | `POST /api/auth/refresh` does not rotate refresh tokens or track active `jti` in DB to detect token reuse. |
| 61 | HIGH | `tests/expiry_monitoring_verification.ts:288` | `[EXP-13]` fails because `canUsePreviewFallback` in `rbac.ts` allows unauthenticated access (`unauth=200`). |

### Part C — WhatsApp CR-Registration End-to-End Trace Findings (#62–#65)
| # | Severity | File & Line | Description |
| :- | :--- | :--- | :--- |
| 62 | HIGH | `src/server/services/whatsappDocumentProcessor.ts:1244-1275` | Auto-save sets `taxId: crNumber` instead of keeping CR number in `crNumber`/`normalizedCrNumber` and Tax Card number in `taxCardNumber`/`taxId`. |
| 63 | HIGH | `src/server/services/whatsappDocumentProcessor.ts:998-1007` | Dedup queries `SELECT * FROM companies WHERE tenant_id = ...` loading all companies (and base64 blobs) into memory per WhatsApp image/PDF instead of indexed SQL lookup on `normalizedCrNumber`. |
| 64 | HIGH | `src/server/services/whatsappDocumentProcessor.ts:832-890,2316` | Full base64 data URL stored directly in `companies.crDocumentUrl` DB column and dumped into `data/last_extraction_debug.json`. |
| 65 | MEDIUM | `src/server/services/whatsappDocumentProcessor.ts:1543-1565` | Auto-reply sends extracted CR details over WhatsApp immediately without checking `tenantSettings.humanApprovalMode`. |

### Part D — Apple-Level Line-by-Line Deep-Dive Findings (#66–#102)
| # | Severity | File & Line | Description |
| :- | :--- | :--- | :--- |
| 66 | HIGH | `src/pages/CompaniesPage.tsx:266`, `src/server/routes/companyRoutes.ts:70,230` | Editing a company re-submits `/api/companies/:id/cr-download` as `crDocumentUrl`, overwriting the vault path in DB and breaking downloads. |
| 67 | HIGH | `src/server/services/crExtractionService.ts:4706-4755` | Gemini timeout timers created with `new Promise((_, reject) => setTimeout(...))` in `Promise.race` are not cleared in `finally`, and `ai` client is re-instantiated on every call. |
| 68 | MEDIUM | `src/server/services/crExtractionService.ts:390,4688` | `validateAndEnrichOmaniPhone` rejects valid 8-digit Omani landlines (`22xxxxxx`–`26xxxxxx`) and toll-free (`800xxxxx`) numbers; `hasReliableHeaderPageSignal` uses fragile `/1\s*\/\s*\d+/` regex. |
| 69 | HIGH | `src/server/services/whatsappDocumentProcessor.ts:35-46` | Module-level `processedMessageHashes` and `chatBatchQueues` `Map`s are not tenant-prefixed and grow unboundedly without TTL eviction. |
| 70 | HIGH | `src/server/services/expiryCronService.ts:95,935` | Cron runs with single `'default_tenant'` instead of iterating distinct tenants, and swallows individual notification errors silently. |
| 71 | MEDIUM | `src/server/routes/aiRoutes.ts:302-405` | Sequential awaited DB queries per customer/transaction/invoice inside loops (N+1 queries). |
| 72 | MEDIUM | `src/server/routes/aiRoutes.ts:1115-1155` | Multi-step transaction + invoice creation runs outside `db.transaction(async (tx) => ...)`. |
| 73 | MEDIUM | `src/server/routes/companyRoutes.ts:350-465` | `GET /api/companies/Signatories` and `GET /api/companies/:id/signatories` load all signatories across tenants into memory and filter in JS. |
| 74 | HIGH | `src/server/services/backupService.ts:620-695` | `restoreBackup` deletes existing local files or runs `pg_restore --clean --if-exists` before verifying archive decryption/extraction succeeds. |
| 75 | HIGH | `src/server/services/backupService.ts:1100-1165` | `initializeBackupJobs` and ` initializeExpiryCron` have no multi-instance lock (e.g. `pg_try_advisory_lock`) and swallow scheduler errors. |
| 76 | MEDIUM | `src/lib/api.ts:16,80` | `mockData.ts` imported unconditionally into production client bundle and seeded into `localStorage`. |
| 77 | HIGH | `src/server/services/whatsappService.ts:18-45` | `whatsappService` singleton state (`sock`, `messages`, `chats`, `authPath`) is single-tenant and uses module-global mutable state. |
| 78 | HIGH | `src/server/services/whatsappService.ts:878-908` | Outbound message echoed by Baileys `messages.upsert` before `sock.sendMessage` returns is duplicated if IDs differ or `upsert` fires first. |
| 79 | HIGH | `src/server/services/whatsappService.ts:310-395` | `connectToWhatsApp()` does not clear pending `reconnectTimeout` before opening a new socket, allowing duplicate Baileys sockets (`conflict / replaced` loop). |
| 80 | HIGH | `src/server/services/whatsappService.ts:1540-1615` | `downloadMedia` buffers full media into RAM (`Buffer.concat`) without checking `msg.message.*Message.fileLength` against a 15 MB cap first. |
| 81 | MEDIUM | `src/pages/WhatsAppPage.tsx:160-210` | `selectedChat` inside `useEffect` dependencies causes polling interval to tear down and recreate on every chat selection/message update. |
| 82 | MEDIUM | `src/pages/WhatsAppPage.tsx:245-315` | `handleSendMessage` appends optimistic message without a `clientMessageId`, causing duplicate bubbles when polling returns before `POST /api/whatsapp/send` resolves. |
| 83 | MEDIUM | `src/server/services/whatsappService.ts:510-585` | Corrupt `data/whatsapp_store.json` is overwritten with empty state instead of renaming to `.corrupt.<timestamp>.bak` and logging an error. |
| 84 | MEDIUM | `src/server/services/whatsappService.ts:1640-1710` | Media filenames stored in `data/whatsapp_media` use unsanitized message IDs without `path.basename` / traversal checks or disk cleanup. |
| 85 | MEDIUM | `src/server/services/whatsappService.ts:620-690` | Omani phone normalization strips leading `0` or prepends `968` inconsistently across 8-digit local numbers vs international numbers (`+20`, `+971`). |
| 86 | MEDIUM | `src/pages/WhatsAppPage.tsx:520-610` | Base64 media data URLs kept in React message list state without size limits, bloating browser memory on media-heavy chats. |
| 87 | HIGH | `src/server/services/whatsappDocumentProcessor.ts:140-210` | `chatBatchQueues` processes accumulated PDFs/images purely in memory; crash or restart loses queued attachments after Baileys ACK. |
| 88 | MEDIUM | `src/server/services/whatsappDocumentProcessor.ts:610-680` | `Promise.all` runs Gemini OCR across all pages/files in a batch concurrently without a concurrency limit (`p-limit(2)`), triggering 429 rate limits. |
| 89 | LOW | `src/pages/WhatsAppPage.tsx:480` | Message timestamps rendered with browser local timezone instead of consistent `Asia/Muscat` formatting. |
| 90 | MEDIUM | `src/server/services/crExtractionService.ts:4710`, `aiRoutes.ts:25` | Model name hardcoded in multiple places instead of reading `process.env.GEMINI_MODEL \|\| 'gemini-2.5-flash'` (or tenant setting). |
| 91 | MEDIUM | `src/pages/CompaniesPage.tsx:310-350` | `FileReader` in CR upload handler lacks `reader.onerror` and 10 MB file size check, leaving `isExtracting` stuck on `true` on failure. |
| 92 | LOW | `src/pages/CompaniesPage.tsx:420-480` | Rapid typing/filtering while triggering AI extraction can apply stale extraction results after modal close/reset if not guarded by an abort/request token. |
| 93 | MEDIUM | `src/App.tsx:285` | `App.tsx` stores `initialCompanyId` from expiry notifications in state, but renders `<CompaniesPage />` without passing `initialCompanyId` or `onClearInitialCompany`. |
| 94 | MEDIUM | `src/server/services/expiryCronService.ts:75-110` | `initializeExpiryCron()` registers a new `cron.schedule` task without stopping any existing task on hot reload. |
| 95 | MEDIUM | `src/server/services/expiryCronService.ts:120-210` | Cron date diffs use server local `new Date()` midnight instead of explicit `Asia/Muscat` (`UTC+04:00`) date calculation. |
| 96 | MEDIUM | `src/server/services/expiryCronService.ts:520-610` | Duplicate notification check queries `notifications` in a loop per item instead of batch-loading existing open notifications for the tenant. |
| 97 | MEDIUM | `src/server/services/expiryCronService.ts:150-190` | Expiry thresholds (`30` warning days, `7` urgent days) hardcoded instead of reading per-tenant configuration from `tenantSettings`. |
| 98 | MEDIUM | `src/server/services/expiryCronService.ts:640-710` | Outbound WhatsApp expiry reminders sent back-to-back in a loop without rate-limiting delay or recording failure status on the notification. |
| 99 | MEDIUM | `src/server/routes/systemRoutes.ts:14-58` | `/api/system/health` and `/api/system/backup-status` lack `requireAuth` and `requirePermission("system:manage")`. |
| 100 | HIGH | `src/server/services/backupService.ts:640-690` | `restoreDatabase` passes `--clean --if-exists` directly to `pg_restore` against the live DB before verifying restore viability in a transaction/pre-restore snapshot. |
| 101 | MEDIUM | `src/server/services/backupService.ts:280-360` | Backup archive creation buffers full `.tar.gz` and encrypted buffer in RAM (`fs.readFileSync`) instead of streaming with `pipeline(createReadStream, cipher, createWriteStream)` and calculating SHA-256 checksum. |
| 102 | MEDIUM | `src/server/services/backupService.ts:850-920` | Backup retention cleanup deletes local files by count/mtime without verifying at least one valid checksum-verified backup remains. |

### Part E — Newly Discovered Findings During Independent Full-Codebase Audit (#103–#108)
| # | Severity | File & Line | Description |
| :- | :--- | :--- | :--- |
| 103 | CRITICAL | `src/server/middleware/rbac.ts:19-80` | `canUsePreviewFallback` silently injects `req.user = { userId: 2, username: "admin", role: "SUPER_ADMIN", tenantId: "default_tenant" }` when auth tokens are missing or invalid on browser requests or `/api/companies`, `/api/whatsapp`, `/api/auth/change-*`. |
| 104 | CRITICAL | `index.html:15-58`, `public/assets/index-*.js`, `src/lib/api.ts:1749,1862`, `src/server/routes/authRoutes.ts:90-105` | `index.html` loads a static pre-built bundle (`/assets/index-Dy4Gmkbw.js`) and runs an inline auto-login script with hardcoded `'ChangeMe_Sanad2026!'`; `authRoutes.ts` contains a password self-heal backdoor that resets the admin DB password hash when `'ChangeMe_Sanad2026!'` or `'Admin@2026!'` is submitted. |
| 105 | HIGH | `src/server/routes/companyRoutes.ts:928`, `src/server/services/documentStorageService.ts:6` | `GET /api/companies/:id/cr-download` calls `res.download(fileUrl)` on any path stored in `company.crDocumentUrl` without confining it to the vault root directory (Arbitrary File Read), and `VAULT_ROOT_DIR` defaults to ephemeral `/tmp`. |
| 106 | HIGH | `src/server/routes/requestRoutes.ts:117,151`, `src/server/routes/evolutionRoutes.ts:357,412,423` | `POST /api/requests/simulate-inbound`, `POST /api/requests/analyze`, `GET /api/whatsapp/media/:messageId`, and `GET/POST /api/whatsapp/auto-reply` have no `requireAuth` or `requirePermission` middleware. |
| 107 | MEDIUM | `src/server/routes/notificationRoutes.ts:225`, `systemRoutes.ts:60`, `customerRoutes.ts:182`, `invoiceRoutes.ts:1`, `requestService.ts:80-290` | Missing `tenantId` filters in `GET /api/notifications/job-runs`, `GET /api/system/audit-logs`, `customerDocuments` lookup, `invoiceRoutes` payments/update queries, and `requestService.ts` queries. |
| 108 | MEDIUM | `src/pages/WhatsAppPage.tsx:341,361,369,396,423`, `src/pages/SettingsPage.tsx:66,199`, `src/lib/api/requests.ts:95,111,156,178` | Raw `fetch()` calls to `/api/whatsapp/*` and `/api/requests/*` omit `YasminaApi.getAuthHeaders()` and `credentials: 'include'`, which causes 401 failures once `canUsePreviewFallback` (#103) is removed. |
