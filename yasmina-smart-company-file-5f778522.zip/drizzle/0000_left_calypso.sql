CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"actor_id" text,
	"actor_name" text,
	"action" text NOT NULL,
	"resource" text NOT NULL,
	"resource_id" text,
	"details" text,
	"ip_address" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "branches" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"code" text NOT NULL,
	"name_ar" text NOT NULL,
	"name_en" text,
	"address" text,
	"phone" text,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text
);
--> statement-breakpoint
CREATE TABLE "cash_sessions" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"opened_by" integer NOT NULL,
	"closed_by" integer,
	"opening_balance_baisa" integer DEFAULT 0 NOT NULL,
	"closing_balance_baisa" integer DEFAULT 0,
	"expected_balance_baisa" integer DEFAULT 0,
	"variance_baisa" integer DEFAULT 0,
	"status" text DEFAULT 'OPEN' NOT NULL,
	"notes" text,
	"opened_at" timestamp DEFAULT now(),
	"closed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "commissions" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"employee_id" integer NOT NULL,
	"transaction_id" integer NOT NULL,
	"rate_pct" integer DEFAULT 0 NOT NULL,
	"amount_baisa" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'PENDING' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "companies" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"owner_customer_id" integer,
	"company_code" text NOT NULL,
	"name" text NOT NULL,
	"trade_name" text,
	"tax_id" text NOT NULL,
	"cr_expiry_date" text,
	"cr_issue_date" text,
	"license_number" text,
	"license_expiry_date" text,
	"sector" text,
	"activities" text,
	"status" text DEFAULT 'Active' NOT NULL,
	"city" text,
	"state_country" text DEFAULT 'سلطنة عُمان',
	"contact_phone" text,
	"contact_email" text,
	"capital_baisa" integer DEFAULT 20000000 NOT NULL,
	"legal_form" text DEFAULT 'شركة ذات مسؤولية محدودة (ش.م.م)',
	"revenue_monthly_baisa" integer DEFAULT 0 NOT NULL,
	"employees_count" integer DEFAULT 0 NOT NULL,
	"compliance_score" integer DEFAULT 100 NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text,
	CONSTRAINT "companies_company_code_unique" UNIQUE("company_code")
);
--> statement-breakpoint
CREATE TABLE "contracts" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"company_id" integer,
	"customer_id" integer,
	"title" text NOT NULL,
	"contract_type" text,
	"status" text DEFAULT 'Active' NOT NULL,
	"start_date" text,
	"end_date" text,
	"value_baisa" integer DEFAULT 0 NOT NULL,
	"file_url" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text
);
--> statement-breakpoint
CREATE TABLE "customer_documents" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"customer_id" integer NOT NULL,
	"doc_type" text NOT NULL,
	"doc_number" text,
	"issue_date" text,
	"expiry_date" text,
	"file_url" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text
);
--> statement-breakpoint
CREATE TABLE "customer_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"request_code" text NOT NULL,
	"customer_name" text NOT NULL,
	"customer_phone" text NOT NULL,
	"chat_id" text,
	"service_type" text DEFAULT 'عام' NOT NULL,
	"request_summary" text NOT NULL,
	"raw_message" text NOT NULL,
	"extracted_details" text,
	"ai_confidence" integer DEFAULT 95,
	"ai_reply" text,
	"status" text DEFAULT 'NEW' NOT NULL,
	"priority" text DEFAULT 'MEDIUM' NOT NULL,
	"assigned_to" text,
	"notes" text,
	"converted_transaction_id" integer,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	CONSTRAINT "customer_requests_request_code_unique" UNIQUE("request_code")
);
--> statement-breakpoint
CREATE TABLE "customers" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"customer_type" text DEFAULT 'INDIVIDUAL' NOT NULL,
	"civil_id" text,
	"passport_no" text,
	"nationality" text DEFAULT 'Omani' NOT NULL,
	"full_name_ar" text NOT NULL,
	"full_name_en" text,
	"phone" text NOT NULL,
	"whatsapp" text,
	"email" text,
	"address" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text
);
--> statement-breakpoint
CREATE TABLE "employees" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"company_id" integer,
	"employee_name" text NOT NULL,
	"civil_id" text,
	"labor_card_no" text,
	"residence_expiry" text,
	"passport_expiry" text,
	"passport_no" text,
	"nationality" text DEFAULT 'Omani' NOT NULL,
	"job_title" text,
	"salary_baisa" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text
);
--> statement-breakpoint
CREATE TABLE "expenses" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"cash_session_id" integer,
	"category" text NOT NULL,
	"description" text NOT NULL,
	"amount_baisa" integer NOT NULL,
	"created_by" integer,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "invoice_counters" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text NOT NULL,
	"year" integer NOT NULL,
	"last_sequence" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "uq_tenant_year_counter" UNIQUE("tenant_id","year")
);
--> statement-breakpoint
CREATE TABLE "invoices" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"invoice_number" text NOT NULL,
	"transaction_id" integer NOT NULL,
	"customer_id" integer NOT NULL,
	"gov_fee_baisa" integer DEFAULT 0 NOT NULL,
	"office_fee_baisa" integer DEFAULT 0 NOT NULL,
	"vat_baisa" integer DEFAULT 0 NOT NULL,
	"discount_baisa" integer DEFAULT 0 NOT NULL,
	"total_baisa" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'UNPAID' NOT NULL,
	"pdf_url" text,
	"issued_at" timestamp DEFAULT now(),
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	CONSTRAINT "invoices_invoice_number_unique" UNIQUE("invoice_number")
);
--> statement-breakpoint
CREATE TABLE "message_templates" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"content_ar" text NOT NULL,
	"content_en" text,
	"variables" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"type" text NOT NULL,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"recipient" text,
	"channel" text DEFAULT 'whatsapp',
	"status" text DEFAULT 'PENDING',
	"sent_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"transaction_id" integer NOT NULL,
	"invoice_id" integer,
	"method" text NOT NULL,
	"amount_baisa" integer NOT NULL,
	"received_by" integer,
	"cash_session_id" integer,
	"reference_no" text,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "services" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"code" text NOT NULL,
	"name_ar" text NOT NULL,
	"name_en" text,
	"authority" text NOT NULL,
	"gov_fee_baisa" integer DEFAULT 0 NOT NULL,
	"office_fee_baisa" integer DEFAULT 0 NOT NULL,
	"vat_applicable" boolean DEFAULT true NOT NULL,
	"required_documents" text,
	"sla_days" integer DEFAULT 1 NOT NULL,
	"needs_verification" boolean DEFAULT true NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text
);
--> statement-breakpoint
CREATE TABLE "transaction_documents" (
	"id" serial PRIMARY KEY NOT NULL,
	"transaction_id" integer NOT NULL,
	"title" text NOT NULL,
	"file_url" text,
	"doc_type" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "transaction_fees" (
	"id" serial PRIMARY KEY NOT NULL,
	"transaction_id" integer NOT NULL,
	"gov_fee_baisa" integer DEFAULT 0 NOT NULL,
	"office_fee_baisa" integer DEFAULT 0 NOT NULL,
	"discount_baisa" integer DEFAULT 0 NOT NULL,
	"vat_baisa" integer DEFAULT 0 NOT NULL,
	"total_baisa" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "transaction_fees_transaction_id_unique" UNIQUE("transaction_id")
);
--> statement-breakpoint
CREATE TABLE "transaction_steps" (
	"id" serial PRIMARY KEY NOT NULL,
	"transaction_id" integer NOT NULL,
	"step_name" text NOT NULL,
	"status" text NOT NULL,
	"notes" text,
	"user_id" integer,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"branch_id" integer,
	"number" text NOT NULL,
	"customer_id" integer NOT NULL,
	"company_id" integer,
	"service_id" integer NOT NULL,
	"status" text DEFAULT 'DRAFT' NOT NULL,
	"assigned_to" integer,
	"due_date" text,
	"gov_ref_no" text,
	"notes" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text,
	CONSTRAINT "transactions_number_unique" UNIQUE("number")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"uid" text NOT NULL,
	"email" text NOT NULL,
	"display_name" text,
	"role" text DEFAULT 'CLERK' NOT NULL,
	"password_hash" text,
	"salt" text,
	"permissions" text,
	"active" boolean DEFAULT true NOT NULL,
	"must_change_password" boolean DEFAULT false NOT NULL,
	"token_version" integer DEFAULT 1 NOT NULL,
	"failed_attempts" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"deleted_at" timestamp,
	"created_by" text,
	CONSTRAINT "users_uid_unique" UNIQUE("uid")
);
--> statement-breakpoint
CREATE TABLE "whatsapp_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"tenant_id" text DEFAULT 'default_tenant' NOT NULL,
	"instance_id" text,
	"chat_id" text,
	"phone" text NOT NULL,
	"direction" text NOT NULL,
	"message_text" text NOT NULL,
	"status" text DEFAULT 'DELIVERED',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "cash_sessions" ADD CONSTRAINT "cash_sessions_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cash_sessions" ADD CONSTRAINT "cash_sessions_opened_by_users_id_fk" FOREIGN KEY ("opened_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cash_sessions" ADD CONSTRAINT "cash_sessions_closed_by_users_id_fk" FOREIGN KEY ("closed_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commissions" ADD CONSTRAINT "commissions_employee_id_users_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commissions" ADD CONSTRAINT "commissions_transaction_id_transactions_id_fk" FOREIGN KEY ("transaction_id") REFERENCES "public"."transactions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "companies" ADD CONSTRAINT "companies_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "companies" ADD CONSTRAINT "companies_owner_customer_id_customers_id_fk" FOREIGN KEY ("owner_customer_id") REFERENCES "public"."customers"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contracts" ADD CONSTRAINT "contracts_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contracts" ADD CONSTRAINT "contracts_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contracts" ADD CONSTRAINT "contracts_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "customer_documents" ADD CONSTRAINT "customer_documents_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "customers" ADD CONSTRAINT "customers_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employees" ADD CONSTRAINT "employees_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employees" ADD CONSTRAINT "employees_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "expenses" ADD CONSTRAINT "expenses_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "expenses" ADD CONSTRAINT "expenses_cash_session_id_cash_sessions_id_fk" FOREIGN KEY ("cash_session_id") REFERENCES "public"."cash_sessions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "expenses" ADD CONSTRAINT "expenses_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_transaction_id_transactions_id_fk" FOREIGN KEY ("transaction_id") REFERENCES "public"."transactions"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_transaction_id_transactions_id_fk" FOREIGN KEY ("transaction_id") REFERENCES "public"."transactions"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_invoice_id_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."invoices"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_received_by_users_id_fk" FOREIGN KEY ("received_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_cash_session_id_cash_sessions_id_fk" FOREIGN KEY ("cash_session_id") REFERENCES "public"."cash_sessions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "services" ADD CONSTRAINT "services_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transaction_documents" ADD CONSTRAINT "transaction_documents_transaction_id_transactions_id_fk" FOREIGN KEY ("transaction_id") REFERENCES "public"."transactions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transaction_fees" ADD CONSTRAINT "transaction_fees_transaction_id_transactions_id_fk" FOREIGN KEY ("transaction_id") REFERENCES "public"."transactions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transaction_steps" ADD CONSTRAINT "transaction_steps_transaction_id_transactions_id_fk" FOREIGN KEY ("transaction_id") REFERENCES "public"."transactions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transaction_steps" ADD CONSTRAINT "transaction_steps_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_service_id_services_id_fk" FOREIGN KEY ("service_id") REFERENCES "public"."services"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_companies_tenant_status" ON "companies" USING btree ("tenant_id","status");--> statement-breakpoint
CREATE INDEX "idx_companies_cr_expiry" ON "companies" USING btree ("tenant_id","cr_expiry_date");--> statement-breakpoint
CREATE INDEX "idx_companies_license_expiry" ON "companies" USING btree ("tenant_id","license_expiry_date");--> statement-breakpoint
CREATE INDEX "idx_requests_tenant_status" ON "customer_requests" USING btree ("tenant_id","status");--> statement-breakpoint
CREATE INDEX "idx_requests_phone" ON "customer_requests" USING btree ("tenant_id","customer_phone");--> statement-breakpoint
CREATE INDEX "idx_customers_tenant_phone" ON "customers" USING btree ("tenant_id","phone");--> statement-breakpoint
CREATE INDEX "idx_customers_civil_id" ON "customers" USING btree ("tenant_id","civil_id");--> statement-breakpoint
CREATE INDEX "idx_employees_company" ON "employees" USING btree ("tenant_id","company_id");--> statement-breakpoint
CREATE INDEX "idx_employees_residence_expiry" ON "employees" USING btree ("tenant_id","residence_expiry");--> statement-breakpoint
CREATE INDEX "idx_invoices_tenant_status" ON "invoices" USING btree ("tenant_id","status");--> statement-breakpoint
CREATE INDEX "idx_invoices_customer" ON "invoices" USING btree ("tenant_id","customer_id");--> statement-breakpoint
CREATE INDEX "idx_transactions_tenant_status" ON "transactions" USING btree ("tenant_id","status");--> statement-breakpoint
CREATE INDEX "idx_transactions_customer" ON "transactions" USING btree ("tenant_id","customer_id");--> statement-breakpoint
CREATE INDEX "idx_users_tenant_role" ON "users" USING btree ("tenant_id","role");