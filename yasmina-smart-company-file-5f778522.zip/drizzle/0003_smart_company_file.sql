-- Smart Company File: document vault matching, people documents, reminder rules.
-- All changes are additive (nullable or defaulted) so existing rows survive.
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "doc_type_code" text;--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "match_lane" text;--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "match_score" integer;--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "match_confirmed_by" text;--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "match_confirmed_at" timestamp;--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "person_id" integer;--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "fields_json" text;--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_customer_docs_lane" ON "customer_documents" ("tenant_id", "match_lane");--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "client_reminders_enabled" boolean NOT NULL DEFAULT false;--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "client_reminder_consent_at" timestamp;--> statement-breakpoint
ALTER TABLE "tenant_settings" ADD COLUMN IF NOT EXISTS "auto_file_enabled" boolean NOT NULL DEFAULT false;--> statement-breakpoint
ALTER TABLE "tenant_settings" ADD COLUMN IF NOT EXISTS "auto_file_min_score" integer NOT NULL DEFAULT 90;--> statement-breakpoint
ALTER TABLE "tenant_settings" ADD COLUMN IF NOT EXISTS "reminder_staff_phones" text;--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "document_match_candidates" (
  "id" serial PRIMARY KEY,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "document_id" integer NOT NULL REFERENCES "customer_documents"("id") ON DELETE CASCADE,
  "company_id" integer NOT NULL,
  "score" integer NOT NULL,
  "reasons_json" text NOT NULL,
  "rank" integer NOT NULL,
  "created_at" timestamp DEFAULT now()
);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_doc_match_doc" ON "document_match_candidates" ("tenant_id", "document_id");--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "company_people" (
  "id" serial PRIMARY KEY,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "company_id" integer NOT NULL,
  "full_name" text NOT NULL,
  "role" text NOT NULL DEFAULT 'EMPLOYEE',
  "civil_number" text,
  "passport_number" text,
  "nationality" text,
  "created_at" timestamp DEFAULT now(),
  "deleted_at" timestamp
);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_company_people_company" ON "company_people" ("tenant_id", "company_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_company_people_civil" ON "company_people" ("tenant_id", "civil_number");--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "reminder_rules" (
  "id" serial PRIMARY KEY,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "doc_type_code" text NOT NULL,
  "offsets_days_json" text NOT NULL,
  "notify_staff" boolean NOT NULL DEFAULT true,
  "notify_client" boolean NOT NULL DEFAULT false,
  "active" boolean NOT NULL DEFAULT true,
  CONSTRAINT "uq_reminder_rules_tenant_type" UNIQUE ("tenant_id", "doc_type_code")
);--> statement-breakpoint
-- Backfill the canonical type code for existing documents.
UPDATE "customer_documents" SET "doc_type_code" = CASE lower("doc_type")
  WHEN 'commercial_registry' THEN 'CR' WHEN 'commercial_registration' THEN 'CR' WHEN 'cr' THEN 'CR'
  WHEN 'municipal_license' THEN 'MUNICIPAL_LICENSE' WHEN 'commercial_license' THEN 'COMMERCIAL_LICENSE'
  WHEN 'tax_certificate' THEN 'TAX_CARD' WHEN 'tax_card' THEN 'TAX_CARD' WHEN 'vat_certificate' THEN 'TAX_CARD'
  WHEN 'chamber_certificate' THEN 'CHAMBER_CERT' WHEN 'labor_certificate' THEN 'LABOR_LICENSE'
  WHEN 'labor_permit' THEN 'LABOR_LICENSE' WHEN 'employment_certificate' THEN 'OMANIZATION_CERT'
  WHEN 'lease_contract' THEN 'LEASE_CONTRACT' WHEN 'residence_card' THEN 'RESIDENCE_CARD'
  WHEN 'passport' THEN 'PASSPORT' WHEN 'civil_id' THEN 'CIVIL_ID' ELSE 'OTHER' END
WHERE "doc_type_code" IS NULL;
