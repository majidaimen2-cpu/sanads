-- 0001_audit_schema_sync.sql: Bring all schema additions into tracked Drizzle migrations
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "failed_attempts" integer NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "locked_until" timestamp;
--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "active_refresh_jti" text;
--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "must_change_password" boolean NOT NULL DEFAULT false;
--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "token_version" integer NOT NULL DEFAULT 1;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_users_tenant_role" ON "users" ("tenant_id", "role");
--> statement-breakpoint
ALTER TABLE "companies" ALTER COLUMN "tax_id" DROP NOT NULL;
--> statement-breakpoint
ALTER TABLE "companies" ALTER COLUMN "capital_baisa" SET DEFAULT 0;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "company_name_en" text;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "normalized_cr_number" text;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "name_discrepancy_flag" boolean NOT NULL DEFAULT false;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "name_discrepancy_details" text;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "tax_card_number" text;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "chamber_number" text;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "cr_document_url" text;
--> statement-breakpoint
ALTER TABLE "companies" ADD COLUMN IF NOT EXISTS "cr_document_name" text;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_companies_normalized_cr" ON "companies" ("tenant_id", "normalized_cr_number");
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "uq_companies_tenant_normalized_cr" ON "companies" ("tenant_id", "normalized_cr_number") WHERE "normalized_cr_number" IS NOT NULL AND "normalized_cr_number" <> '';
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "company_id" integer;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "raw_issue_date" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "raw_expiry_date" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "extraction_source" text DEFAULT 'MANUAL';
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "has_no_expiry" boolean NOT NULL DEFAULT false;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "expiry_status" text DEFAULT 'VALID';
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "needs_review" boolean NOT NULL DEFAULT false;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "original_file_name" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "mime_type" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "file_size_bytes" integer;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "sha256" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "storage_object_key" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "whatsapp_message_id" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "source_channel" text DEFAULT 'WEB';
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "sender_phone" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "sender_authorized" boolean DEFAULT true;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "extraction_confidence" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "processing_status" text DEFAULT 'COMPLETED';
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "version_number" integer NOT NULL DEFAULT 1;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "previous_version_id" integer;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "extracted_text" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "extracted_metadata_json" text;
--> statement-breakpoint
ALTER TABLE "customer_documents" ADD COLUMN IF NOT EXISTS "issuing_authority" text;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_customer_docs_company" ON "customer_documents" ("tenant_id", "company_id");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_customer_docs_sha256" ON "customer_documents" ("tenant_id", "sha256");
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "tenant_settings" (
  "tenant_id" text PRIMARY KEY,
  "ai_model" text NOT NULL DEFAULT 'gemini-2.5-flash',
  "auto_reply_enabled" boolean NOT NULL DEFAULT true,
  "human_approval_mode" boolean NOT NULL DEFAULT false,
  "ai_processing_consent" boolean NOT NULL DEFAULT true,
  "ai_processing_region" text NOT NULL DEFAULT 'global',
  "retention_days" integer NOT NULL DEFAULT 365,
  "warning_days" integer NOT NULL DEFAULT 30,
  "urgent_days" integer NOT NULL DEFAULT 7,
  "updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "request_counters" (
  "id" serial PRIMARY KEY,
  "tenant_id" text NOT NULL,
  "year" integer NOT NULL,
  "last_sequence" integer NOT NULL DEFAULT 0,
  CONSTRAINT "uq_tenant_year_request_counter" UNIQUE("tenant_id", "year")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "backup_history" (
  "id" serial PRIMARY KEY,
  "backup_id" text NOT NULL UNIQUE,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "schema_version" text NOT NULL DEFAULT '2.0.0',
  "app_version" text NOT NULL DEFAULT '1.0.0',
  "trigger_type" text NOT NULL DEFAULT 'MANUAL',
  "retention_tier" text NOT NULL DEFAULT 'DAILY',
  "local_status" text NOT NULL DEFAULT 'PENDING',
  "cloud_status" text NOT NULL DEFAULT 'PENDING',
  "restore_verify_status" text NOT NULL DEFAULT 'NOT_TESTED',
  "local_file_path" text,
  "cloud_object_uri" text,
  "file_size_bytes" integer NOT NULL DEFAULT 0,
  "encrypted_size_bytes" integer NOT NULL DEFAULT 0,
  "sha256_checksum" text NOT NULL,
  "encrypted_sha256" text,
  "encryption_algorithm" text NOT NULL DEFAULT 'AES-256-GCM',
  "encryption_key_id" text NOT NULL DEFAULT 'default-key-v1',
  "total_tables" integer NOT NULL DEFAULT 0,
  "total_records" integer NOT NULL DEFAULT 0,
  "coverage_report_json" text,
  "restore_report_json" text,
  "duration_ms" integer NOT NULL DEFAULT 0,
  "last_error" text,
  "actor_name" text DEFAULT 'System',
  "created_at" timestamp DEFAULT now(),
  "verified_at" timestamp
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "backup_sync_outbox" (
  "id" serial PRIMARY KEY,
  "job_id" text NOT NULL UNIQUE,
  "idempotency_key" text NOT NULL UNIQUE,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "operation_type" text NOT NULL,
  "entity_type" text NOT NULL,
  "entity_id" text NOT NULL,
  "payload_summary" text,
  "status" text NOT NULL DEFAULT 'PENDING',
  "local_backup_status" text NOT NULL DEFAULT 'PENDING',
  "cloud_backup_status" text NOT NULL DEFAULT 'PENDING',
  "backup_id" text,
  "retry_count" integer NOT NULL DEFAULT 0,
  "max_retries" integer NOT NULL DEFAULT 5,
  "next_retry_at" timestamp DEFAULT now(),
  "last_error" text,
  "created_at" timestamp DEFAULT now(),
  "updated_at" timestamp DEFAULT now(),
  "completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "verification_runs" (
  "id" serial PRIMARY KEY,
  "sha256" text NOT NULL,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "pass_a_json" text,
  "pass_b_json" text,
  "pass_c_json" text,
  "final_fields_json" text NOT NULL,
  "created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_verification_runs_sha256" ON "verification_runs" ("sha256");
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "expiry_job_runs" (
  "id" serial PRIMARY KEY,
  "run_id" text NOT NULL UNIQUE,
  "tenant_id" text NOT NULL DEFAULT 'ALL',
  "trigger_type" text NOT NULL DEFAULT 'CRON',
  "reference_date_muscat" text NOT NULL,
  "total_scanned" integer NOT NULL DEFAULT 0,
  "expired_count" integer NOT NULL DEFAULT 0,
  "expiring_today_count" integer NOT NULL DEFAULT 0,
  "expiring_7_days_count" integer NOT NULL DEFAULT 0,
  "expiring_30_days_count" integer NOT NULL DEFAULT 0,
  "valid_count" integer NOT NULL DEFAULT 0,
  "needs_review_count" integer NOT NULL DEFAULT 0,
  "no_expiry_count" integer NOT NULL DEFAULT 0,
  "notifications_created" integer NOT NULL DEFAULT 0,
  "notifications_skipped_duplicate" integer NOT NULL DEFAULT 0,
  "notifications_retried" integer NOT NULL DEFAULT 0,
  "notifications_failed" integer NOT NULL DEFAULT 0,
  "duration_ms" integer NOT NULL DEFAULT 0,
  "status" text NOT NULL DEFAULT 'COMPLETED',
  "error_details" text,
  "created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "whatsapp_processing_jobs" (
  "id" serial PRIMARY KEY,
  "job_id" text NOT NULL UNIQUE,
  "correlation_id" text NOT NULL,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "provider_message_id" text NOT NULL,
  "instance_id" text DEFAULT 'inst-main',
  "chat_id" text,
  "sender_phone" text NOT NULL,
  "sender_name" text,
  "sender_authorized" boolean NOT NULL DEFAULT false,
  "state" text NOT NULL DEFAULT 'RECEIVED',
  "state_history_json" text,
  "original_file_name" text,
  "mime_type" text,
  "file_size_bytes" integer,
  "file_sha256" text,
  "storage_object_key" text,
  "document_type" text,
  "extracted_cr_number" text,
  "normalized_cr_number" text,
  "extracted_company_name_ar" text,
  "extracted_company_name_en" text,
  "extraction_result_json" text,
  "extraction_confidence" text,
  "matched_company_id" integer,
  "company_match_resolution" text,
  "saved_document_id" integer,
  "locked_by_worker" text,
  "locked_at" timestamp,
  "retry_count" integer NOT NULL DEFAULT 0,
  "max_retries" integer NOT NULL DEFAULT 3,
  "last_attempt_at" timestamp,
  "next_retry_at" timestamp,
  "error_code" text,
  "error_message" text,
  "created_at" timestamp DEFAULT now(),
  "updated_at" timestamp DEFAULT now(),
  "completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "whatsapp_outbox" (
  "id" serial PRIMARY KEY,
  "outbox_id" text NOT NULL UNIQUE,
  "idempotency_key" text NOT NULL UNIQUE,
  "correlation_id" text NOT NULL,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "job_id" text,
  "provider_message_id" text,
  "recipient_phone" text NOT NULL,
  "recipient_jid" text NOT NULL DEFAULT '',
  "reply_category" text NOT NULL DEFAULT 'GENERAL',
  "message_text" text NOT NULL,
  "status" text NOT NULL DEFAULT 'PENDING',
  "delivery_attempts" integer NOT NULL DEFAULT 0,
  "sent_provider_msg_id" text,
  "last_error" text,
  "sent_at" timestamp,
  "created_at" timestamp DEFAULT now(),
  "updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "whatsapp_auth_sessions" (
  "id" serial PRIMARY KEY,
  "instance_id" text NOT NULL UNIQUE,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "phone_number" text,
  "profile_name" text,
  "auth_state_json" text NOT NULL,
  "updated_at" timestamp DEFAULT now(),
  "created_at" timestamp DEFAULT now()
);
