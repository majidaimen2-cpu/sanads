-- Brings a fresh database in sync with src/db/schema.ts (columns that 0000/0001 never created)
ALTER TABLE "employees" ADD COLUMN IF NOT EXISTS "license_number" text;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN IF NOT EXISTS "license_expiry_date" text;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN IF NOT EXISTS "license_file_url" text;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN IF NOT EXISTS "license_file_name" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "idempotency_key" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "company_id" integer;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "company_name" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "owner_name" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "document_id" integer;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "source_entity" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "source_id" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "doc_type" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "doc_number" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "expiry_date" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "days_remaining" integer;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "alert_stage" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "severity" text DEFAULT 'INFO';--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "is_read" boolean NOT NULL DEFAULT false;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "read_at" timestamp;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "read_by" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "target_roles" text DEFAULT 'SUPER_ADMIN,MANAGER,CLERK';--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "delivery_status" text DEFAULT 'DELIVERED';--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "retry_count" integer NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "last_error" text;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN IF NOT EXISTS "link" text;--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "notifications_idempotency_key_unique" ON "notifications" ("idempotency_key");--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "provider_message_id" text;--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "sender_name" text;--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "media_type" text;--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "media_mime_type" text;--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "media_sha256" text;--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "storage_object_key" text;--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "correlation_id" text;--> statement-breakpoint
ALTER TABLE "whatsapp_messages" ADD COLUMN IF NOT EXISTS "raw_payload_json" text;--> statement-breakpoint
-- customers.nationality is optional in code (WhatsApp auto-registration inserts NULL)
ALTER TABLE "customers" ALTER COLUMN "nationality" DROP NOT NULL;--> statement-breakpoint
-- customers.phone and employees.nationality are optional in schema.ts but were NOT NULL in the shipped migration
-- (company registration from a CR without an owner phone failed with a NOT NULL violation)
ALTER TABLE "customers" ALTER COLUMN "phone" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "employees" ALTER COLUMN "nationality" DROP NOT NULL;--> statement-breakpoint
-- Credit notes / refunds
CREATE TABLE IF NOT EXISTS "credit_notes" (
  "id" serial PRIMARY KEY,
  "tenant_id" text NOT NULL DEFAULT 'default_tenant',
  "credit_note_number" text NOT NULL UNIQUE,
  "invoice_id" integer NOT NULL REFERENCES "invoices"("id"),
  "transaction_id" integer NOT NULL REFERENCES "transactions"("id") ON DELETE RESTRICT,
  "customer_id" integer NOT NULL REFERENCES "customers"("id"),
  "amount_baisa" integer NOT NULL CHECK ("amount_baisa" > 0),
  "refund_method" text NOT NULL,
  "refund_payment_id" integer REFERENCES "payments"("id"),
  "reason" text NOT NULL,
  "created_by" integer REFERENCES "users"("id"),
  "created_at" timestamp DEFAULT now()
);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_credit_notes_invoice" ON "credit_notes" ("tenant_id", "invoice_id");--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "credit_note_counters" (
  "id" serial PRIMARY KEY,
  "tenant_id" text NOT NULL,
  "year" integer NOT NULL,
  "last_sequence" integer NOT NULL DEFAULT 0,
  CONSTRAINT "uq_tenant_year_cn_counter" UNIQUE ("tenant_id", "year")
);
