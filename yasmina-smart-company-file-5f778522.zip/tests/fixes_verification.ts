/**
 * End-to-end HTTP verification for the fixes (run against a RUNNING server on a scratch DB).
 *   BASE_URL=http://localhost:3000 ADMIN_PASSWORD=... WEBHOOK_KEY=... npx tsx tests/fixes_verification.ts
 */
const base = process.env.BASE_URL || "http://localhost:3000";
const adminPass = process.env.ADMIN_PASSWORD || "";
const webhookKey = process.env.WEBHOOK_KEY || "";
let pass = 0;
const fails: string[] = [];
function check(name: string, ok: boolean, detail = "") {
  if (ok) { pass++; console.log(`PASS  ${name}`); }
  else { fails.push(name); console.log(`FAIL  ${name} ${detail}`); }
}
async function call(method: string, path: string, token?: string, body?: unknown, headers: Record<string, string> = {}) {
  const res = await fetch(base + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json: any = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

import { pool } from "../src/db/index.js";

async function main() {
  const h = await call("GET", "/api/health");
  check("health 200", h.status === 200, JSON.stringify(h.json));

  const bad = await call("POST", "/api/auth/login", undefined, { username: "admin", password: "wrong-password-xyz" });
  check("wrong password rejected", bad.status === 401, String(bad.status));
  const old = await call("POST", "/api/auth/login", undefined, { username: "admin", password: ["ChangeMe", "Sanad2026!"].join("_") });
  check("old hardcoded default password rejected", old.status === 401, String(old.status));
  const login = await call("POST", "/api/auth/login", undefined, { username: "admin", password: adminPass });
  const T = login.json?.token as string;
  check("admin login", login.status === 200 && !!T, JSON.stringify(login.json));

  // employees & notifications endpoints on a FRESH db (used to 500 from missing columns)
  for (const p of ["/api/employees", "/api/notifications", "/api/companies", "/api/customers", "/api/invoices", "/api/payments", "/api/reports/summary"]) {
    const r = await call("GET", p, T);
    check(`GET ${p} not 5xx`, r.status < 500, `${r.status} ${JSON.stringify(r.json)?.slice(0, 200)}`);
  }
  const emp = await call("GET", "/api/employees", T);
  check("GET /api/employees 200", emp.status === 200);
  const notif = await call("GET", "/api/notifications", T);
  check("GET /api/notifications 200", notif.status === 200);

  // RBAC
  const cashierEmail = "cashier1@example.com";
  const cu = await call("POST", "/api/users", T, { email: cashierEmail, displayName: "Cashier One", role: "CASHIER", password: "Cashier#Pass2026x" });
  check("create cashier user", cu.status === 201 || cu.status === 200, JSON.stringify(cu.json));
  const cl = await call("POST", "/api/auth/login", undefined, { username: cashierEmail, password: "Cashier#Pass2026x" });
  const C = cl.json?.token as string;
  check("cashier login", !!C, JSON.stringify(cl.json));
  const f1 = await call("POST", "/api/customers", C, { fullNameAr: "x", phone: "91000000" });
  check("cashier cannot create customer (403)", f1.status === 403, String(f1.status));
  const f2 = await call("GET", "/api/system/backups", C);
  check("cashier cannot list backups (403)", f2.status === 403, String(f2.status));

  // deleted user's still-signed token must fail closed
  const tmp = await call("POST", "/api/users", T, { email: "ghost@example.com", displayName: "Ghost User", role: "CLERK", password: "Ghost#Pass2026xx" });
  const gl = await call("POST", "/api/auth/login", undefined, { username: "ghost@example.com", password: "Ghost#Pass2026xx" });
  const G = gl.json?.token as string;
  const gid = tmp.json?.data?.id ?? tmp.json?.id;
  if (G && gid) {
    const before = await call("GET", "/api/customers", G);
    check("ghost user token works while user exists", before.status === 200 || before.status === 403, String(before.status));
    await pool.query("DELETE FROM users WHERE id = $1", [gid]).catch(async () => { await pool.query("UPDATE users SET active=false WHERE id=$1", [gid]); });
    const after = await call("GET", "/api/customers", G);
    check("token of deleted user rejected (401)", after.status === 401, String(after.status));
  } else check("ghost user setup", false, JSON.stringify(tmp.json));

  // company + duplicate CR
  const crNo = "1234567";
  const co1 = await call("POST", "/api/companies", T, { name: "Alpha Trading LLC", crNumber: crNo });
  check("create company 201", co1.status === 201 || co1.status === 200, `${co1.status} ${JSON.stringify(co1.json)?.slice(0, 300)}`);
  const co2 = await call("POST", "/api/companies", T, { name: "Totally Different Name", crNumber: crNo });
  check("duplicate CR -> 409", co2.status === 409, `${co2.status} ${JSON.stringify(co2.json)?.slice(0, 300)}`);
  const list = await call("GET", "/api/companies", T);
  const names = JSON.stringify(list.json);
  check("original company name NOT overwritten", names.includes("Alpha Trading LLC") && !names.includes("Totally Different Name"));

  // customer, service, transaction, invoice
  const cust = await call("POST", "/api/customers", T, { fullNameAr: "عميل اختبار", phone: "91234567" });
  const custId = cust.json?.data?.id ?? cust.json?.id;
  check("create customer", !!custId, JSON.stringify(cust.json)?.slice(0, 300));
  const svc = await call("POST", "/api/services", T, { code: "SVC1", nameAr: "خدمة اختبار", authority: "MOCI", govFeeBaisa: 25000, officeFeeBaisa: 5000 });
  const svcId = svc.json?.data?.id ?? svc.json?.id;
  check("create service", !!svcId, JSON.stringify(svc.json)?.slice(0, 300));
  const mkInvoice = async (n: number) => {
    const tr = await call("POST", "/api/transactions", T, { customerId: custId, serviceId: svcId, govFeeBaisa: 25000, officeFeeBaisa: 5000, notes: `t${n}` });
    const trId = tr.json?.data?.id ?? tr.json?.id;
    const inv = await call("POST", "/api/invoices", T, { transactionId: trId, customerId: custId, govFeeBaisa: 25000, officeFeeBaisa: 5000 });
    return { trId, inv: inv.json?.data, status: inv.status };
  };
  const A = await mkInvoice(1);
  check("create invoice", A.status === 201 && !!A.inv?.id, JSON.stringify(A));
  console.log("   invoice total baisa:", A.inv?.totalBaisa, A.inv?.invoiceNumber);
  const total = A.inv.totalBaisa as number;
  const B = await mkInvoice(2);
  check("invoice numbers unique/sequential", A.inv.invoiceNumber !== B.inv.invoiceNumber, `${A.inv.invoiceNumber} ${B.inv.invoiceNumber}`);
  const yr = new Date().toLocaleString("en-US", { timeZone: "Asia/Muscat", year: "numeric" });
  check("invoice number uses Muscat year", A.inv.invoiceNumber.startsWith(`INV-${yr}-`), A.inv.invoiceNumber);

  // concurrency: 8 invoices created in parallel must all get distinct numbers
  // (transactions are created one by one: transaction-number generation is a separate, known count-based race)
  const trIds: number[] = [];
  for (const n of [3, 4, 5, 6, 7, 8, 9, 10]) {
    const tr = await call("POST", "/api/transactions", T, { customerId: custId, serviceId: svcId, govFeeBaisa: 25000, officeFeeBaisa: 5000, notes: `t${n}` });
    trIds.push(tr.json?.data?.id ?? tr.json?.id);
  }
  const par = await Promise.all(
    trIds.map(async (trId) => {
      const inv = await call("POST", "/api/invoices", T, { transactionId: trId, customerId: custId, govFeeBaisa: 25000, officeFeeBaisa: 5000 });
      return { trId, inv: inv.json?.data, status: inv.status };
    }),
  );
  const nums = new Set(par.map((p) => p.inv?.invoiceNumber));
  check("8 parallel invoices -> 8 distinct numbers", nums.size === 8 && par.every((p) => p.status === 201), JSON.stringify([...nums]));

  // payments
  const cashNoSession = await call("POST", `/api/invoices/${A.inv.id}/pay`, T, { method: "CASH", amountBaisa: 1000 });
  check("cash payment w/o open session rejected (409)", cashNoSession.status === 409, String(cashNoSession.status));
  const sess = await call("POST", "/api/cash-sessions/open", T, { openingBalanceBaisa: 10000 });
  check("open cash session", sess.status === 201 || sess.status === 200, JSON.stringify(sess.json)?.slice(0, 200));
  const sessId = sess.json?.data?.id ?? sess.json?.id;
  const over = await call("POST", `/api/invoices/${A.inv.id}/pay`, T, { method: "CARD", amountBaisa: total + 1 });
  check("overpayment rejected (422)", over.status === 422, `${over.status} ${JSON.stringify(over.json)?.slice(0, 200)}`);
  const neg = await call("POST", `/api/invoices/${A.inv.id}/pay`, T, { method: "CARD", amountBaisa: -5 });
  check("negative payment rejected", neg.status === 400 || neg.status === 422, String(neg.status));
  const p1 = await call("POST", `/api/invoices/${A.inv.id}/pay`, T, { method: "CASH", amountBaisa: 10000 });
  check("partial cash payment -> PARTIAL", p1.status === 200 && p1.json?.data?.invoice?.status === "PARTIAL", JSON.stringify(p1.json)?.slice(0, 300));
  const delPartial = await call("DELETE", `/api/invoices/${A.inv.id}`, T);
  check("delete PARTIAL invoice blocked (409)", delPartial.status === 409, `${delPartial.status} ${JSON.stringify(delPartial.json)?.slice(0, 200)}`);
  const p2 = await call("POST", `/api/invoices/${A.inv.id}/pay`, T, { method: "CARD" });
  check("pay remainder -> PAID", p2.status === 200 && p2.json?.data?.invoice?.status === "PAID", JSON.stringify(p2.json)?.slice(0, 300));
  const p3 = await call("POST", `/api/invoices/${A.inv.id}/pay`, T, { method: "CARD", amountBaisa: 100 });
  check("pay on PAID invoice rejected", p3.status === 400, String(p3.status));
  const delPaid = await call("DELETE", `/api/invoices/${A.inv.id}`, T);
  check("delete PAID invoice blocked (409)", delPaid.status === 409, `${delPaid.status}`);
  const delUnpaid = await call("DELETE", `/api/invoices/${B.inv.id}`, T);
  check("delete UNPAID invoice still works", delUnpaid.status === 200, `${delUnpaid.status}`);

  // refunds
  const rfCashier = await call("POST", `/api/invoices/${A.inv.id}/refund`, C, { method: "CARD", reason: "test refund" });
  check("cashier cannot refund (403)", rfCashier.status === 403, String(rfCashier.status));
  const rfUnpaid = await call("POST", `/api/invoices/${par[0].inv.id}/refund`, T, { method: "CARD", reason: "unpaid one" });
  check("refund of UNPAID invoice rejected (400)", rfUnpaid.status === 400, `${rfUnpaid.status}`);
  const rfOver = await call("POST", `/api/invoices/${A.inv.id}/refund`, T, { method: "CARD", amountBaisa: total + 1, reason: "too much" });
  check("refund > paid rejected (422)", rfOver.status === 422, `${rfOver.status}`);
  const rfNoReason = await call("POST", `/api/invoices/${A.inv.id}/refund`, T, { method: "CARD" });
  check("refund without reason rejected", rfNoReason.status === 422 || rfNoReason.status === 400, `${rfNoReason.status}`);
  const rf1 = await call("POST", `/api/invoices/${A.inv.id}/refund`, T, { method: "CASH", amountBaisa: 5000, reason: "partial refund test" });
  check("partial refund 201, invoice stays PAID", rf1.status === 201 && rf1.json?.data?.invoice?.status === "PAID" && rf1.json?.data?.creditNote?.amountBaisa === 5000, JSON.stringify(rf1.json)?.slice(0, 400));
  const rf2 = await call("POST", `/api/invoices/${A.inv.id}/refund`, T, { method: "CARD", reason: "full remaining refund" });
  check("full refund -> REFUNDED", rf2.status === 201 && rf2.json?.data?.invoice?.status === "REFUNDED", JSON.stringify(rf2.json)?.slice(0, 400));
  const rf3 = await call("POST", `/api/invoices/${A.inv.id}/refund`, T, { method: "CARD", reason: "again" });
  check("refund of REFUNDED rejected", rf3.status === 400, `${rf3.status}`);
  const payAfter = await call("POST", `/api/invoices/${A.inv.id}/pay`, T, { method: "CARD", amountBaisa: 100 });
  check("pay on REFUNDED rejected", payAfter.status === 400, `${payAfter.status}`);
  const delRef = await call("DELETE", `/api/invoices/${A.inv.id}`, T);
  check("delete REFUNDED invoice blocked", delRef.status === 409, `${delRef.status}`);
  const cns = await call("GET", `/api/invoices/${A.inv.id}/credit-notes`, T);
  check("credit notes listed (2)", cns.json?.data?.length === 2, JSON.stringify(cns.json)?.slice(0, 300));
  const pays = await call("GET", `/api/payments?invoiceId=${A.inv.id}`, T);
  const net = (pays.json?.data || []).reduce((s: number, p: any) => s + p.amountBaisa, 0);
  check("net payments after full refund = 0", net === 0, String(net));

  // cash session: expected = opening 10000 + cash(10000) - cash refund(5000) = 15000
  const closeS = await call("POST", "/api/cash-sessions/close", T, { sessionId: sessId, closingBalanceBaisa: 15000 });
  const exp = closeS.json?.data?.expectedBalanceBaisa ?? closeS.json?.expectedBalanceBaisa;
  check("cash session expected balance nets the cash refund (15000)", exp === 15000, JSON.stringify(closeS.json)?.slice(0, 300));

  // backup
  const bk = await call("POST", "/api/system/backup", T, {});
  check("backup created", bk.status === 201, `${bk.status} ${JSON.stringify(bk.json)?.slice(0, 200)}`);
  const bl = await call("GET", "/api/system/backups", T);
  check("backup listed", bl.status === 200 && (bl.json?.count ?? 0) >= 1, JSON.stringify(bl.json)?.slice(0, 200));

  // webhook
  const w0 = await call("POST", "/api/webhooks/v1/webhook", undefined, { event: "x" });
  check("webhook without key 401", w0.status === 401, String(w0.status));
  const w1 = await call("POST", "/api/webhooks/v1/webhook", undefined, { event: "x" }, { "x-api-key": "wrong-key" });
  check("webhook wrong key 401", w1.status === 401, String(w1.status));
  const w2 = await call("POST", "/api/webhooks/v1/webhook", undefined, { tenantId: "victim_tenant", event: "messages.upsert", data: { key: { remoteJid: "96891234567@s.whatsapp.net", id: "SPOOF1" }, message: { conversation: "hello" } } }, { "x-api-key": webhookKey });
  check("webhook good key accepted", w2.status === 200, `${w2.status} ${JSON.stringify(w2.json)}`);
  const rows = await pool.query("SELECT tenant_id FROM whatsapp_messages WHERE provider_message_id='SPOOF1'");
  check("webhook ignores body tenantId (stored under the key's tenant)", rows.rows.length === 1 && rows.rows[0].tenant_id === "default_tenant", JSON.stringify(rows.rows));
  await pool.end();

  console.log(`\n${pass} passed, ${fails.length} failed`);
  if (fails.length) { console.log("FAILED:", fails.join(" | ")); process.exit(1); }
}
main().catch((e) => { console.error("test crashed", e); process.exit(1); });
