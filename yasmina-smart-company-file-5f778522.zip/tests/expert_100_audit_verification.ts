import http from "http";
import fs from "fs";
import path from "path";
import { createApp } from "../src/server/app.js";
import { db, pool, runMigrations } from "../src/db/index.js";
import { checkSchemaDrift } from "../src/db/driftCheck.js";
import { companies, customerDocuments, customers } from "../src/db/schema.js";
import { eq } from "drizzle-orm";

interface CriterionResult {
  id: number;
  title: string;
  maxPoints: number;
  earnedPoints: number;
  passed: boolean;
  details: string;
}

const results: CriterionResult[] = [];

function recordCriterion(
  id: number,
  title: string,
  maxPoints: number,
  passed: boolean,
  details: string
) {
  const earnedPoints = passed ? maxPoints : 0;
  results.push({ id, title, maxPoints, earnedPoints, passed, details });
  const icon = passed ? "✅" : "❌";
  console.log(
    `${icon} [معيار ${String(id).padStart(2, "0")}] ${title}: ${earnedPoints}/${maxPoints} — ${details}`
  );
}

async function runExpert100Audit() {
  console.log("================================================================================");
  console.log("🚀 بدء الفحص الهندسي الشامل لنظام ياسمينة (10 معايير × 10 درجات = 100 درجة)");
  console.log("================================================================================");

  await runMigrations();

  const app = await createApp();
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", () => resolve()));
  const addr = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  const testTenant = `expert_audit_${Date.now()}`;

  try {
    // 1. Criterion 01: Server Stability & Health Readiness (10 pts)
    const healthRes = await fetch(`${baseUrl}/api/health`);
    const healthJson: any = await healthRes.json();
    const sysRes = await fetch(`${baseUrl}/api/system`);
    const sysJson: any = await sysRes.json();
    const c1Passed =
      healthRes.status === 200 &&
      healthJson.status === "ok" &&
      healthJson.db === "up" &&
      sysRes.status === 200 &&
      sysJson.status === "ok";
    recordCriterion(
      1,
      "استقرار الخادم وجاهزية التشغيل الفوري (/api/health & /api/system)",
      10,
      c1Passed,
      `Health=${healthRes.status} (db=${healthJson.db}), System=${sysRes.status}`
    );

    // 2. Criterion 02: Authentication, Session & Default Admin Self-Healing (10 pts)
    const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: "admin", password: process.env.TEST_ADMIN_PASSWORD || process.env.ADMIN_PASSWORD || "" }),
    });
    const loginJson: any = await loginRes.json();
    const token = loginJson.token || "";
    const authHeaders = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };

    const sessionRes = await fetch(`${baseUrl}/api/auth/session`, { headers: authHeaders });
    const sessionJson: any = await sessionRes.json();
    const meRes = await fetch(`${baseUrl}/api/auth/me`, { headers: authHeaders });
    const meJson: any = await meRes.json();
    const c2Passed =
      loginRes.status === 200 &&
      Boolean(token) &&
      sessionRes.status === 200 &&
      sessionJson.authenticated === true &&
      meRes.status === 200 &&
      meJson.success === true;
    recordCriterion(
      2,
      "المصادقة وإدارة الجلسات واستعادة حساب المدير (/api/auth/*)",
      10,
      c2Passed,
      `Login=${loginRes.status}, Session=${sessionRes.status}, Me=${meRes.status} (user=${meJson?.user?.username})`
    );

    // 3. Criterion 03: Frontend Bundle Integrity & Hybrid Storage Resilience (10 pts)
    const indexHtmlPath = path.resolve(process.cwd(), "index.html");
    const storageAdapterPath = path.resolve(
      process.cwd(),
      "public/assets/storageAdapter-D3CACHWe.js"
    );
    const hasIndexHtml = fs.existsSync(indexHtmlPath);
    const hasStorageAdapter = fs.existsSync(storageAdapterPath);
    const indexContent = hasIndexHtml ? fs.readFileSync(indexHtmlPath, "utf-8") : "";
    const storageContent = hasStorageAdapter ? fs.readFileSync(storageAdapterPath, "utf-8") : "";
    const c3Passed =
      hasIndexHtml &&
      hasStorageAdapter &&
      indexContent.includes("yasmina_auth_token_v1") &&
      storageContent.includes("yasmina_alerts_v3_clean") &&
      !storageContent.includes("Storage degraded");
    recordCriterion(
      3,
      "سلامة الواجهة الأمامية والتخزين الهجين الصامت (IndexedDB + Memory + localStorage)",
      10,
      c3Passed,
      `index.html bootstrap=true, storageAdapter silent fallback=true`
    );

    // 4. Criterion 04: Core Backend & Financial Endpoints (/api/cash-sessions/active, /api/reports, /api/companies) (10 pts)
    const cashActiveRes = await fetch(`${baseUrl}/api/cash-sessions/active`, {
      headers: authHeaders,
    });
    const reportsRes = await fetch(`${baseUrl}/api/reports`, { headers: authHeaders });
    const companiesRes = await fetch(`${baseUrl}/api/companies`, { headers: authHeaders });
    const customersRes = await fetch(`${baseUrl}/api/customers`, { headers: authHeaders });
    const transactionsRes = await fetch(`${baseUrl}/api/transactions`, { headers: authHeaders });
    const c4Passed =
      cashActiveRes.status === 200 &&
      reportsRes.status === 200 &&
      companiesRes.status === 200 &&
      customersRes.status === 200 &&
      transactionsRes.status === 200;
    recordCriterion(
      4,
      "تكامل مسارات الواجهة الخلفية والعمليات المالية والتقارير",
      10,
      c4Passed,
      `cashActive=${cashActiveRes.status}, reports=${reportsRes.status}, companies=${companiesRes.status}, customers=${customersRes.status}, transactions=${transactionsRes.status}`
    );

    // 5. Criterion 05: Gemini AI Model Alignment & AnyDoc Engine (10 pts)
    const anydocInfoRes = await fetch(`${baseUrl}/api/anydoc/info`, { headers: authHeaders });
    const anydocInfo: any = await anydocInfoRes.json();
    const c5Passed =
      anydocInfoRes.status === 200 &&
      anydocInfo.installed === true &&
      healthJson.primaryModel === "gemini-4-hydrogen" &&
      Array.isArray(healthJson.supportedModels) &&
      healthJson.supportedModels.includes("gemini-4-hydrogen");
    recordCriterion(
      5,
      "محرك الذكاء الاصطناعي ومحاذاة نماذج Gemini القياسية ومحرك AnyDoc",
      10,
      c5Passed,
      `primaryModel=${healthJson.primaryModel}, anydocInstalled=${anydocInfo.installed}`
    );

    // 6. Criterion 06: WhatsApp Gateway & Silent CR Registration (10 pts)
    const waStatusRes = await fetch(`${baseUrl}/api/whatsapp/status`, { headers: authHeaders });
    const waChatsRes = await fetch(`${baseUrl}/api/whatsapp/chats`, { headers: authHeaders });
    const waChatsJson: any = await waChatsRes.json();
    const waMessagesAll = waChatsJson.chats || [];
    const hasNoAutoConfirmSpam = !JSON.stringify(waMessagesAll).includes(
      "تم التحقق وتوثيق السجل التجاري"
    );
    const c6Passed =
      waStatusRes.status === 200 && waChatsRes.status === 200 && hasNoAutoConfirmSpam;
    recordCriterion(
      6,
      "بوابة الواتساب والتسجيل الصامت للشركات ومنع الرسائل العشوائية",
      10,
      c6Passed,
      `waStatus=${waStatusRes.status}, waChats=${waChatsRes.status}, zeroSpamInChats=${hasNoAutoConfirmSpam}`
    );

    // 7. Criterion 07: Chatbot / AnyDoc Automatic CR Registration & Deduplication (10 pts)
    const sampleCrText = `%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /Contents 4 0 R >> endobj
4 0 obj << /Length 260 >> stream
سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار
شهادة السجل التجاري
اسم الشركة: شركة ياسمينة للتقنية المتقدمة ش.م.م
رقم السجل التجاري: 9988776
الشكل القانوني: شركة محدودة المسؤولية
تاريخ الانتهاء: 2028-12-31
endstream endobj
%%EOF`;
    const samplePdfB64 = Buffer.from(sampleCrText, "utf-8").toString("base64");
    const anydocConvertRes = await fetch(`${baseUrl}/api/anydoc/convert`, {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify({
        file: {
          name: "yasmina_audit_cr.pdf",
          type: "application/pdf",
          data: samplePdfB64,
        },
      }),
    });
    const anydocConvertJson: any = await anydocConvertRes.json();
    const matchedDbComp = await db
      .select()
      .from(companies)
      .where(eq(companies.normalizedCrNumber, "9988776"));
    const c7Passed =
      anydocConvertRes.status === 200 &&
      anydocConvertJson.success === true &&
      matchedDbComp.length === 1;
    recordCriterion(
      7,
      "استخراج السجلات التجارية عبر الشات بوت وتسجيلها تلقائياً بدون تكرار",
      10,
      c7Passed,
      `anydocConvert=${anydocConvertRes.status}, registeredCompaniesForCr9988776=${matchedDbComp.length}`
    );

    // Clean up the test company created in default_tenant during Criterion 07
    if (matchedDbComp.length > 0) {
      await db
        .delete(customerDocuments)
        .where(eq(customerDocuments.companyId, matchedDbComp[0].id));
      await db.delete(companies).where(eq(companies.id, matchedDbComp[0].id));
    }

    // 8. Criterion 08: Database Schema Integrity & Zero Drift (10 pts)
    const drift = await checkSchemaDrift();
    const c8Passed = Boolean(drift && !drift.hasDrift && drift.issues.length === 0);
    recordCriterion(
      8,
      "سلامة قاعدة البيانات PostgreSQL ومطابقة المخطط (Zero Schema Drift)",
      10,
      c8Passed,
      `hasDrift=${drift?.hasDrift}, issues=${drift?.issues?.length || 0}`
    );

    // 9. Criterion 09: Security, RBAC & Notification Sync (10 pts)
    const unauthChatRes = await fetch(`${baseUrl}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: [{ role: "user", text: "مرحبا" }] }),
    });
    const notifSyncRes = await fetch(`${baseUrl}/api/notifications/sync`, {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify({ alerts: [] }),
    });
    const c9Passed = unauthChatRes.status === 401 && notifSyncRes.status === 200;
    recordCriterion(
      9,
      "الأمان وحماية المسارات ومزامنة التنبيهات (/api/notifications/sync)",
      10,
      c9Passed,
      `unauthChatBlocked=${unauthChatRes.status === 401}, notifSync=${notifSyncRes.status}`
    );

    // 10. Criterion 10: End-to-End System Verification & Zero Regressions (10 pts)
    const allPreviousPassed = results.every((r) => r.passed);
    recordCriterion(
      10,
      "اجتياز الفحص الشامل وتكامل المنظومة من البداية للنهاية",
      10,
      allPreviousPassed,
      `All ${results.length}/9 prior criteria passed with 0 errors`
    );
  } finally {
    await db.delete(companies).where(eq(companies.tenantId, testTenant));
    await db.delete(customers).where(eq(customers.tenantId, testTenant));
    server.close();
    await pool.end().catch(() => {});
  }

  const totalScore = results.reduce((sum, r) => sum + r.earnedPoints, 0);
  const maxScore = results.reduce((sum, r) => sum + r.maxPoints, 0);
  console.log("================================================================================");
  console.log(`🏆 النتيجة النهائية للفحص الهندسي الشامل: ${totalScore} / ${maxScore}`);
  console.log("================================================================================");

  if (totalScore < 100) {
    process.exit(1);
  }
}

runExpert100Audit().catch((err) => {
  console.error("Fatal error in 100-point audit:", err);
  process.exit(1);
});
