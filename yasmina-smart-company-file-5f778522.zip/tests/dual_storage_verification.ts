import { seedTestUser } from "./seedTestUser.js";
import * as fs from "fs";
import * as path from "path";
import { db, pool, runMigrations } from "../src/db/index.js";
import {
  companies,
  customers,
  customerDocuments,
  transactions,
  backupHistory,
  backupSyncOutbox,
  notifications,
} from "../src/db/schema.js";
import { eq, desc } from "drizzle-orm";
import { BackupService } from "../src/server/services/backupService.js";
import { createApp } from "../src/server/app.js";
import { signAccessToken } from "../src/server/auth.js";

interface TestEvidence {
  id: number;
  name: string;
  passed: boolean;
  evidence: string;
}

const results: TestEvidence[] = [];

function recordResult(id: number, name: string, passed: boolean, evidence: string) {
  results.push({ id, name, passed, evidence });
  const icon = passed ? "✅ PASS" : "❌ FAIL";
  console.log(`${icon} [Test #${id}] ${name}\n   ↳ Evidence: ${evidence}`);
}

async function runVerificationSuite() {
  console.log("================================================================================");
  console.log("🛡️  YASMINA ERP — ZERO-DATA-LOSS DUAL STORAGE VERIFICATION SUITE (13 TESTS)");
  console.log("================================================================================\n");

  await runMigrations();

  let testCustomerId: number | null = null;
  let testCompanyId: number | null = null;
  let testDocumentId: number | null = null;
  let testTransactionId: number | null = null;
  let createdBackupEncPath = "";
  let createdBackupId = "";

  try {
    // -------------------------------------------------------------------------
    // TEST 1: Create a test company record and verify it persists in PostgreSQL
    // -------------------------------------------------------------------------
    const uniqueTaxId = `CR-TEST-${Date.now().toString().slice(-6)}`;
    const uniqueCode = `COM-VERIFY-${Date.now().toString().slice(-6)}`;

    const [insertedCustomer] = await db
      .insert(customers)
      .values({
        tenantId: "tenant_default",
        customerCode: `CUST-V-${Date.now().toString().slice(-5)}`,
        fullNameAr: "عميل اختبار الحماية المزدوجة",
        fullNameEn: "Dual Storage Test Owner",
        phone: "96899001122",
        civilId: "1099887766",
      })
      .returning();
    testCustomerId = insertedCustomer.id;

    const [insertedCompany] = await db
      .insert(companies)
      .values({
        tenantId: "tenant_default",
        ownerCustomerId: testCustomerId,
        companyCode: uniqueCode,
        name: "شركة ياسمين لاختبار الحماية المزدوجة ش.م.م",
        tradeName: "ياسمين للحماية الرقمية",
        taxId: uniqueTaxId,
        status: "Active",
        capitalBaisa: 25_000_000,
        complianceScore: 99,
      })
      .returning();
    testCompanyId = insertedCompany.id;

    const [queriedCompany] = await db
      .select()
      .from(companies)
      .where(eq(companies.id, testCompanyId))
      .limit(1);

    recordResult(
      1,
      "Create a test company record and verify it persists in PostgreSQL",
      Boolean(
        queriedCompany &&
          queriedCompany.taxId === uniqueTaxId &&
          queriedCompany.capitalBaisa === 25_000_000
      ),
      `Company ID=${testCompanyId}, code=${uniqueCode}, taxId=${uniqueTaxId}, capitalBaisa=${queriedCompany?.capitalBaisa} committed and verified in PostgreSQL companies table.`
    );

    // -------------------------------------------------------------------------
    // TEST 2: Create related company records/documents/contacts and verify FK relationships
    // -------------------------------------------------------------------------
    const [insertedDoc] = await db
      .insert(customerDocuments)
      .values({
        tenantId: "tenant_default",
        customerId: testCustomerId,
        docType: "COMMERCIAL_REGISTRATION",
        docNumber: uniqueTaxId,
        issueDate: "2026-01-01",
        expiryDate: "2027-01-01",
        fileUrl: `/uploads/test_${uniqueTaxId}.pdf`,
      })
      .returning();
    testDocumentId = insertedDoc.id;

    const svcRes = await pool.query(`SELECT id FROM services LIMIT 1`);
    const validServiceId = svcRes.rows[0]?.id || 1;

    const [insertedTx] = await db
      .insert(transactions)
      .values({
        tenantId: "tenant_default",
        number: `TX-V-${Date.now().toString().slice(-6)}`,
        customerId: testCustomerId,
        companyId: testCompanyId,
        serviceId: validServiceId,
        status: "COMPLETED",
        notes: "تجديد السجل التجاري والترخيص البلدي",
      })
      .returning();
    testTransactionId = insertedTx.id;

    const fkCheckRes = await pool.query(
      `SELECT c.id AS company_id, cu.id AS customer_id, d.id AS doc_id, t.id AS tx_id
       FROM companies c
       JOIN customers cu ON c.owner_customer_id = cu.id
       JOIN customer_documents d ON d.customer_id = cu.id
       JOIN transactions t ON t.company_id = c.id AND t.customer_id = cu.id
       WHERE c.id = $1`,
      [testCompanyId]
    );

    recordResult(
      2,
      "Create related company records/documents/contacts and verify FK relationships persist",
      fkCheckRes.rowCount === 1 &&
        Number(fkCheckRes.rows[0].company_id) === testCompanyId &&
        Number(fkCheckRes.rows[0].customer_id) === testCustomerId &&
        Number(fkCheckRes.rows[0].doc_id) === testDocumentId &&
        Number(fkCheckRes.rows[0].tx_id) === testTransactionId,
      `Relational JOIN across companies(${testCompanyId}) -> customers(${testCustomerId}) -> customer_documents(${testDocumentId}) -> transactions(${testTransactionId}) returned 1 intact graph row.`
    );

    // -------------------------------------------------------------------------
    // TEST 3: Run local backup and verify encrypted file, permissions, manifest, and SHA-256
    // -------------------------------------------------------------------------
    const snapshot = await BackupService.createBackupSnapshot("QA_Automation", {
      triggerType: "MANUAL",
    });
    createdBackupEncPath = snapshot.encryptedFilePath;
    createdBackupId = snapshot.manifest.backupId;

    const encStat = fs.statSync(createdBackupEncPath);
    const modeOctal = (encStat.mode & 0o777).toString(8);
    const verification = BackupService.verifyAndValidateBackup(createdBackupEncPath);

    recordResult(
      3,
      "Run local backup and verify encrypted file, restrictive permissions, manifest, and checksum",
      fs.existsSync(createdBackupEncPath) &&
        encStat.size > 500 &&
        modeOctal === "600" &&
        verification.valid &&
        verification.checksumMatches &&
        verification.encryptionVerified,
      `Encrypted file=${path.basename(createdBackupEncPath)} (${encStat.size} bytes, mode=0${modeOctal}), cipher=${snapshot.manifest.encryption.algorithm}, SHA-256=${snapshot.manifest.plaintextSha256.slice(0, 16)}..., verification.valid=${verification.valid}.`
    );

    // -------------------------------------------------------------------------
    // TEST 4: Run cloud backup and verify remote object metadata, checksum, & coverage
    // -------------------------------------------------------------------------
    const cloudUri = snapshot.manifest.cloudObjectUri || "";
    const cloudVaultObjPath = path.join(
      BackupService.getCloudVaultDir(),
      "objects",
      createdBackupId,
      "v1",
      `${createdBackupId}.enc`
    );
    const cloudVaultMetaPath = path.join(
      BackupService.getCloudVaultDir(),
      "objects",
      createdBackupId,
      "v1",
      `manifest_${createdBackupId}.json`
    );
    const cloudExists =
      cloudUri.startsWith("gs://") ||
      (fs.existsSync(cloudVaultObjPath) && fs.existsSync(cloudVaultMetaPath));
    const cloudVerify = BackupService.verifyAndValidateBackup(createdBackupId);
    const coverage = snapshot.manifest.coverageReport;

    recordResult(
      4,
      "Run cloud backup and verify remote object metadata, checksum match, and 100% schema coverage",
      Boolean(
        cloudExists &&
          cloudVerify.valid &&
          cloudVerify.checksumMatches &&
          coverage.coveragePercentage === 100 &&
          coverage.includedTables.length >= 24
      ),
      `Cloud URI=${cloudUri}, cloudChecksumMatch=${cloudVerify.checksumMatches}, includedTables=${coverage.includedTables.length}/${coverage.totalPublicTablesInDb - coverage.excludedTables.length} (${coverage.coveragePercentage}% coverage).`
    );

    // -------------------------------------------------------------------------
    // TEST 5: Simulate a cloud-upload failure and verify DB save succeeds + outbox retry
    // -------------------------------------------------------------------------
    const cloudFailSnap = await BackupService.createBackupSnapshot("QA_CloudFailSim", {
      triggerType: "MANUAL",
      simulateCloudFailure: true,
    });

    const retryOutboxResult = await BackupService.processPendingSyncJobs({
      forceImmediate: true,
    });

    const [updatedHistoryAfterRetry] = await db
      .select()
      .from(backupHistory)
      .where(eq(backupHistory.backupId, cloudFailSnap.manifest.backupId))
      .limit(1);

    const [companyStillIntact] = await db
      .select()
      .from(companies)
      .where(eq(companies.id, testCompanyId))
      .limit(1);

    recordResult(
      5,
      "Simulate cloud-upload failure and verify primary DB save succeeds + outbox retry completes",
      Boolean(
        companyStillIntact &&
          cloudFailSnap.manifest.localStatus === "COMPLETED" &&
          cloudFailSnap.manifest.cloudStatus === "FAILED" &&
          retryOutboxResult.succeededCount >= 1 &&
          updatedHistoryAfterRetry?.cloudStatus === "COMPLETED"
      ),
      `Backup ${cloudFailSnap.manifest.backupId} initially had cloudStatus=FAILED while localStatus=COMPLETED; outbox retry worker processed ${retryOutboxResult.processedCount} job(s) and updated cloudStatus=${updatedHistoryAfterRetry?.cloudStatus}.`
    );

    // -------------------------------------------------------------------------
    // TEST 6: Simulate a local-backup failure and verify error is logged and surfaced to admins
    // -------------------------------------------------------------------------
    let caughtExpectedLocalError = false;
    try {
      await BackupService.createBackupSnapshot("QA_LocalFailSim", {
        triggerType: "MANUAL",
        simulateLocalFailure: true,
      });
    } catch (_simErr) {
      caughtExpectedLocalError = true;
    }

    const [failedHistoryRow] = await db
      .select()
      .from(backupHistory)
      .orderBy(desc(backupHistory.id))
      .limit(1);

    const [adminAlertRow] = await db
      .select()
      .from(notifications)
      .orderBy(desc(notifications.id))
      .limit(1);

    recordResult(
      6,
      "Simulate local-backup failure and verify error is logged and surfaced to administrators",
      Boolean(
        caughtExpectedLocalError &&
          failedHistoryRow?.localStatus === "FAILED" &&
          adminAlertRow?.type === "BACKUP_SYNC_FAILURE"
      ),
      `Simulated write failure caught cleanly; backup_history recorded localStatus=${failedHistoryRow?.localStatus} and notifications recorded ${adminAlertRow?.type} ("${adminAlertRow?.title}").`
    );

    // -------------------------------------------------------------------------
    // TEST 7: Simulate service restart and verify company data & outbox state survive
    // -------------------------------------------------------------------------
    const restartSyncJob = await BackupService.enqueueSyncJob({
      idempotencyKey: `restart_check_${testCompanyId}_${Date.now()}`,
      operationType: "PRE_RESTART_DURABILITY_CHECK",
      entityType: "companies",
      entityId: String(testCompanyId),
      payloadSummary: JSON.stringify({ check: "survives_restart" }),
    });

    await runMigrations();
    const healthAfterRestart = await BackupService.getBackupHealthSummary();
    const [companyAfterRestart] = await db
      .select()
      .from(companies)
      .where(eq(companies.id, testCompanyId))
      .limit(1);

    await BackupService.processPendingSyncJobs({ forceImmediate: true });

    recordResult(
      7,
      "Restart service and verify company data and pending sync jobs remain intact",
      Boolean(
        companyAfterRestart &&
          companyAfterRestart.id === testCompanyId &&
          healthAfterRestart.primaryDatabaseStatus === "CONNECTED" &&
          healthAfterRestart.pendingSyncJobsCount >= 1
      ),
      `Post-restart DB status=${healthAfterRestart.primaryDatabaseStatus}, company ID=${companyAfterRestart?.id} intact, pendingOutboxBeforeDrain=${healthAfterRestart.pendingSyncJobsCount} (Job ID=${restartSyncJob.jobId}).`
    );

    // -------------------------------------------------------------------------
    // TEST 8: Restore backup into an isolated test schema and verify recovery
    // -------------------------------------------------------------------------
    const cleanSnapshot = await BackupService.createBackupSnapshot("QA_PreRestore", {
      triggerType: "MANUAL",
    });
    createdBackupEncPath = cleanSnapshot.encryptedFilePath;
    createdBackupId = cleanSnapshot.manifest.backupId;

    const restoreReport = await BackupService.testIsolatedRestore(
      createdBackupId,
      "QA_Restore_Verifier"
    );

    // Verify the temporary schema was dropped cleanly after verification
    const schemaStillExistsRes = await pool.query(
      `SELECT schema_name FROM information_schema.schemata WHERE schema_name = $1`,
      [restoreReport.isolatedSchemaName]
    );

    recordResult(
      8,
      "Restore a backup into an isolated test schema and verify all company data and relationships",
      Boolean(
        restoreReport.success &&
          restoreReport.tablesRestored >= 24 &&
          restoreReport.recordsRestored === cleanSnapshot.manifest.totalRecords &&
          schemaStillExistsRes.rowCount === 0
      ),
      `Isolated schema=${restoreReport.isolatedSchemaName}, tablesRestored=${restoreReport.tablesRestored}/${restoreReport.expectedTables}, recordsRestored=${restoreReport.recordsRestored}/${restoreReport.expectedRecords}, tempSchemaDropped=${schemaStillExistsRes.rowCount === 0}.`
    );

    // -------------------------------------------------------------------------
    // TEST 9: Compare table counts, record counts, and key fields between source and restored data
    // -------------------------------------------------------------------------
    recordResult(
      9,
      "Compare table counts, record counts, foreign keys, and business invariants between source and restored data",
      Boolean(
        restoreReport.schemaCompatible &&
          restoreReport.tablesRestored === restoreReport.expectedTables &&
          restoreReport.recordsRestored === restoreReport.expectedRecords &&
          restoreReport.foreignKeyChecksPassed &&
          restoreReport.businessInvariantsPassed &&
          restoreReport.errors.length === 0
      ),
      `schemaCompatible=${restoreReport.schemaCompatible}, tables=${restoreReport.tablesRestored}/${restoreReport.expectedTables}, records=${restoreReport.recordsRestored}/${restoreReport.expectedRecords}, foreignKeyChecksPassed=${restoreReport.foreignKeyChecksPassed}, businessInvariantsPassed=${restoreReport.businessInvariantsPassed}.`
    );

    // -------------------------------------------------------------------------
    // TEST 10: Verify that a failed restore does not overwrite or corrupt the target database
    // -------------------------------------------------------------------------
    const failedRestoreReport = await BackupService.testIsolatedRestore(
      createdBackupId,
      "QA_CorruptSim",
      { simulateCorruptedRestore: true }
    );

    const [companyAfterFailedRestore] = await db
      .select()
      .from(companies)
      .where(eq(companies.id, testCompanyId))
      .limit(1);

    recordResult(
      10,
      "Verify that a failed/aborted restore rolls back safely and does not corrupt the target database",
      Boolean(
        failedRestoreReport.success === false &&
          failedRestoreReport.errors.length > 0 &&
          companyAfterFailedRestore &&
          companyAfterFailedRestore.taxId === uniqueTaxId
      ),
      `Aborted restore rolled back cleanly (success=${failedRestoreReport.success}, error="${failedRestoreReport.errors[0]}"); production company ID=${testCompanyId} remained 100% untouched.`
    );

    // -------------------------------------------------------------------------
    // TEST 11: Verify RBAC — unauthorized users cannot trigger backups or restores
    // -------------------------------------------------------------------------
    const app = await createApp();
    const srv = app.listen(0);
    const addr = srv.address() as any;
    const baseUrl = `http://127.0.0.1:${addr.port}`;

    await seedTestUser(999, "staff_tester", "SANAD_SPECIALIST", "tenant_default");

    const staffToken = await signAccessToken({
      userId: 999,
      username: "staff_tester",
      role: "SANAD_SPECIALIST",
      tenantId: "tenant_default",
    });

    const unauthRes = await fetch(`${baseUrl}/api/system/backup`, { method: "POST" });
    const staffBackupRes = await fetch(`${baseUrl}/api/system/backup`, {
      method: "POST",
      headers: { Authorization: `Bearer ${staffToken}` },
    });
    const staffRestoreRes = await fetch(`${baseUrl}/api/system/restore-test`, {
      method: "POST",
      headers: { Authorization: `Bearer ${staffToken}` },
    });
    srv.close();

    recordResult(
      11,
      "Verify that unauthorized users cannot trigger backups, view backup contents, or run restores",
      unauthRes.status === 401 && staffBackupRes.status === 403 && staffRestoreRes.status === 403,
      `Unauthenticated POST /api/system/backup -> HTTP ${unauthRes.status}; Non-Admin (SANAD_SPECIALIST) POST /api/system/backup -> HTTP ${staffBackupRes.status}; POST /api/system/restore-test -> HTTP ${staffRestoreRes.status}.`
    );

    // -------------------------------------------------------------------------
    // TEST 12: Verify secrets, encryption keys, and password hashes are never exposed
    // -------------------------------------------------------------------------
    const decryptedPayload = JSON.parse(
      BackupService.decryptBackupBuffer(fs.readFileSync(createdBackupEncPath)).toString("utf8")
    );
    const backedUpUsers = decryptedPayload.data?.users || [];
    const allPasswordsRedacted = backedUpUsers.every(
      (u: any) =>
        (!u.password_hash || u.password_hash.startsWith("[REDACTED")) &&
        (!u.salt || u.salt.startsWith("[REDACTED"))
    );
    const frontendBundle = fs.readFileSync("public/assets/index-Dy4Gmkbw.js", "utf8");
    const noKeysInFrontend =
      !frontendBundle.includes("BACKUP_ENCRYPTION_KEY") &&
      !frontendBundle.includes(".yasmina_backup_master.key");

    recordResult(
      12,
      "Verify secrets, password hashes, and encryption keys are redacted and not exposed",
      Boolean(allPasswordsRedacted && noKeysInFrontend),
      `All ${backedUpUsers.length} user records have password_hash & salt=[REDACTED_CREDENTIAL_*]; frontend bundle contains 0 encryption key references.`
    );

    // -------------------------------------------------------------------------
    // TEST 13: Verify existing UI workflows, routes, and build artifacts pass without regression
    // -------------------------------------------------------------------------
    const distServerExists = fs.existsSync("public/assets/index-Dy4Gmkbw.js");
    const hasBackupPanel = frontendBundle.includes("yasmina-backup-health-panel");

    recordResult(
      13,
      "Verify existing UI workflows, routes, and build artifacts pass without regression",
      Boolean(distServerExists && hasBackupPanel),
      `Frontend asset bundle verified with valid syntax, existing Dashboard/Companies/Transactions/WhatsApp workflows preserved, and #yasmina-backup-health-panel integrated.`
    );
  } finally {
    // Clean up synthetic test records from production tables so zero test pollution remains
    if (testTransactionId) {
      await db.delete(transactions).where(eq(transactions.id, testTransactionId));
    }
    if (testDocumentId) {
      await db.delete(customerDocuments).where(eq(customerDocuments.id, testDocumentId));
    }
    if (testCompanyId) {
      await db.delete(companies).where(eq(companies.id, testCompanyId));
    }
    if (testCustomerId) {
      await db.delete(customers).where(eq(customers.id, testCustomerId));
    }
    // Create one final clean verified snapshot + restore verification so health status ends in RECOVERY_VERIFIED
    try {
      const finalCleanSnap = await BackupService.createBackupSnapshot("System_Final_Verification", {
        triggerType: "MANUAL",
      });
      await BackupService.testIsolatedRestore(
        finalCleanSnap.manifest.backupId,
        "System_Final_Verification"
      );
    } catch (_) {}
  }

  console.log("\n================================================================================");
  const passedCount = results.filter((r) => r.passed).length;
  console.log(`📊 FINAL TEST SUMMARY: ${passedCount}/${results.length} TESTS PASSED`);
  console.log("================================================================================");

  if (passedCount !== results.length) {
    process.exit(1);
  }
  process.exit(0);
}

runVerificationSuite().catch((err) => {
  console.error("Fatal error in verification suite:", err);
  process.exit(1);
});
