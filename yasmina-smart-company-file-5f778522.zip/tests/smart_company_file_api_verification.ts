/**
 * HTTP-level verification of the Smart Company File API. Needs a running server (BASE_URL, default http://localhost:3055)
 * on the same DATABASE_URL. Run: npx tsx tests/smart_company_file_api_verification.ts
 */
import assert from "node:assert/strict";
import { db, pool, closePool } from "../src/db/index.js";
import { companies, whatsappOutbox } from "../src/db/schema.js";
import { eq, and } from "drizzle-orm";
import { signAccessToken } from "../src/server/auth.js";
import { seedTestUser } from "./seedTestUser.js";
import { processIncomingWhatsAppMediaMessage } from "../src/server/services/whatsappDocumentProcessor.js";

const BASE = process.env.BASE_URL || "http://localhost:3055";
const A = `api_alpha_${Date.now()}`;
const B = `api_beta_${Date.now()}`;
let passed = 0, failed = 0;
async function t(name: string, fn: () => Promise<void>) {
  try { await fn(); passed++; console.log(`✅ PASS ${name}`); } catch (e) { failed++; console.log(`❌ FAIL ${name}: ${(e as Error).message}`); }
}
function pdf(lines: string[]): Buffer {
  const body = lines.join("\n");
  return Buffer.from(`%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /Resources << >> /MediaBox [0 0 595 842] /Contents 4 0 R >>\nendobj\n4 0 obj\n<< /Length ${Buffer.byteLength(body) + 40} >>\nstream\nBT\n(${body.replace(/[()\\]/g, " ")}) Tj\nET\nendstream\nendobj\nxref\n0 5\n0000000000 65535 f \ntrailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n250\n%%EOF`, "utf8");
}
async function call(token: string | null, method: string, path: string, body?: unknown) {
  const res = await fetch(BASE + path, { method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
  let json: any = null; try { json = await res.json(); } catch { /* none */ }
  return { status: res.status, json };
}
const roles = ["SUPER_ADMIN", "MANAGER", "CLERK", "VIEWER", "ACCOUNTANT", "CASHIER"] as const;
const tok: Record<string, string> = {};

async function main() {
  let uid = 7100 + Math.floor(Math.random() * 800) * 10;
  for (const r of roles) {
    await seedTestUser(uid, `api_${r.toLowerCase()}_${uid}`, r, A);
    tok[r] = await signAccessToken({ userId: uid, username: `api_${r.toLowerCase()}_${uid}`, role: r, tenantId: A, tokenVersion: 1 } as any);
    uid++;
  }
  await seedTestUser(uid, `api_beta_${uid}`, "SUPER_ADMIN", B);
  const betaTok = await signAccessToken({ userId: uid, username: `api_beta_${uid}`, role: "SUPER_ADMIN", tenantId: B, tokenVersion: 1 } as any);

  const [co] = await db.insert(companies).values({ tenantId: A, name: "شركة النور للتجارة ش.م.م", normalizedCrNumber: "1111" + (uid % 1000), companyCode: "API-" + uid, contactPhone: "96890000001" } as any).returning();
  const [coB] = await db.insert(companies).values({ tenantId: B, name: "Beta Co", normalizedCrNumber: "7777" + (uid % 1000), companyCode: "APIB-" + uid } as any).returning();
  const residence = (civil: string, exp: string) => ["شرطة عمان السلطانية", "بطاقة إقامة", "الاسم: AHMED KHAN", `الرقم المدني: ${civil}`, "جهة العمل: شركة النور للتجارة ش.م.م", "تاريخ الإصدار: 2024-01-10", `تاريخ الانتهاء: ${exp}`];

  let docId = 0;
  await t("API-01 unauthenticated => 401", async () => { assert.equal((await call(null, "GET", "/api/vault/inbox")).status, 401); });
  await t("API-02 WhatsApp-inbound doc appears in the inbox via API (full ID for SUPER_ADMIN, masked for CLERK)", async () => {
    const r = await processIncomingWhatsAppMediaMessage({ tenantId: A, providerMessageId: "api_wa_" + uid, senderPhone: "+96890000001", fileName: "id.pdf", declaredMimeType: "application/pdf", mediaBuffer: pdf(residence("55667788", "2026-12-30")) } as any);
    assert.equal(r.matchLane, "CONFIRM");
    docId = r.savedDocumentId!;
    const admin = await call(tok.SUPER_ADMIN, "GET", "/api/vault/inbox");
    assert.equal(admin.status, 200);
    assert.ok(admin.json.data.some((d: any) => d.id === docId));
    assert.ok(JSON.stringify(admin.json).includes("55667788"));
    const clerk = await call(tok.CLERK, "GET", "/api/vault/inbox");
    assert.equal(clerk.status, 200);
    assert.ok(!JSON.stringify(clerk.json).includes("55667788"), "CLERK must see masked ID");
  });
  await t("API-03 role matrix: confirm-match allowed for SUPER_ADMIN/MANAGER/CLERK, denied for VIEWER/CASHIER (no state change)", async () => {
    const viewer = await call(tok.VIEWER, "POST", `/api/vault/documents/${docId}/confirm-match`, { companyId: co.id });
    assert.equal(viewer.status, 403);
    const cashier = await call(tok.CASHIER, "POST", `/api/vault/documents/${docId}/confirm-match`, { companyId: co.id });
    assert.equal(cashier.status, 403);
    const bad = await call(tok.CLERK, "POST", `/api/vault/documents/${docId}/confirm-match`, { companyId: "x" });
    assert.ok([400, 422].includes(bad.status), "invalid body => " + bad.status);
  });
  await t("API-04 tenant isolation: other tenant cannot confirm or read, cannot target a foreign company", async () => {
    assert.ok([403, 404].includes((await call(betaTok, "POST", `/api/vault/documents/${docId}/confirm-match`, { companyId: coB.id })).status));
    const foreign = await call(tok.SUPER_ADMIN, "POST", `/api/vault/documents/${docId}/confirm-match`, { companyId: coB.id });
    assert.ok([403, 404, 422].includes(foreign.status), "foreign company => " + foreign.status);
    const still = await call(tok.SUPER_ADMIN, "GET", "/api/vault/inbox");
    assert.ok(still.json.data.some((d: any) => d.id === docId), "document must remain unfiled");
    assert.ok([403, 404, 422].includes((await call(betaTok, "GET", `/api/vault/companies/${co.id}/documents`)).status));
  });
  await t("API-05 confirm to company, then it shows in the company vault and leaves the inbox", async () => {
    const ok = await call(tok.MANAGER, "POST", `/api/vault/documents/${docId}/confirm-match`, { companyId: co.id });
    assert.equal(ok.status, 200, JSON.stringify(ok.json));
    const vault = await call(tok.VIEWER, "GET", `/api/vault/companies/${co.id}/documents`);
    assert.equal(vault.status, 200);
    assert.ok(JSON.stringify(vault.json).includes(String(docId)));
    const inbox = await call(tok.SUPER_ADMIN, "GET", "/api/vault/inbox");
    assert.ok(!inbox.json.data.some((d: any) => d.id === docId));
  });
  await t("API-06 manual vault upload (WEB) files straight to the company", async () => {
    const data = pdf(["عقد إيجار", "المؤجر: سالم الحارثي", "المستأجر: شركة النور للتجارة ش.م.م", "تاريخ بداية العقد: 2025-03-01", "تاريخ نهاية العقد: 2026-12-28", "الإيجار السنوي: 3600"]).toString("base64");
    const up = await call(tok.CLERK, "POST", `/api/vault/companies/${co.id}/documents`, { fileName: "lease.pdf", mimeType: "application/pdf", data });
    assert.equal(up.status, 201, JSON.stringify(up.json));
    assert.equal(up.json.data.companyId, co.id);
    assert.equal((await call(tok.VIEWER, "POST", `/api/vault/companies/${co.id}/documents`, { fileName: "l.pdf", mimeType: "application/pdf", data })).status, 403);
  });
  await t("API-07 chat upload goes through the same pipeline and appears in the inbox", async () => {
    const data = pdf(residence("99001122", "2027-05-05")).toString("base64");
    const r = await call(tok.CLERK, "POST", "/api/chat", { messages: [{ role: "user", text: "ارفع الوثيقة", attachment: { name: "idcard.pdf", mimeType: "application/pdf", data } }] });
    assert.equal(r.status, 200, JSON.stringify(r.json));
    assert.ok(typeof r.json.text === "string" && r.json.text.length > 5);
    const inbox = await call(tok.SUPER_ADMIN, "GET", "/api/vault/inbox");
    assert.ok(inbox.json.data.some((d: any) => d.channel === "CHAT" || d.sourceChannel === "CHAT" || JSON.stringify(d).includes("CHAT")), "chat doc visible in inbox");
  });
  await t("API-08 expiring board lists docs within window", async () => {
    const r = await call(tok.VIEWER, "GET", "/api/vault/expiring?days=400");
    assert.equal(r.status, 200);
    assert.ok(r.json.count >= 1);
  });
  await t("API-09 reminder rules: SUPER_ADMIN only; invalid body => 4xx", async () => {
    assert.equal((await call(tok.MANAGER, "GET", "/api/vault/reminder-rules")).status, 403);
    assert.equal((await call(tok.SUPER_ADMIN, "GET", "/api/vault/reminder-rules")).status, 200);
    const bad = await call(tok.SUPER_ADMIN, "PUT", "/api/vault/reminder-rules", { rules: [{ docTypeCode: "NOPE", offsetsDays: [1] }] });
    assert.ok([400, 422].includes(bad.status));
    const ok = await call(tok.SUPER_ADMIN, "PUT", "/api/vault/reminder-rules", { settings: { reminderStaffPhones: "96891110000", autoFileEnabled: false } });
    assert.equal(ok.status, 200, JSON.stringify(ok.json));
  });
  await t("API-10 reminder cycle queues a staff reminder into whatsapp_outbox (idempotent)", async () => {
    const run1 = await call(tok.SUPER_ADMIN, "POST", "/api/vault/reminders/run", { referenceDate: "2026-12-20" });
    assert.equal(run1.status, 200, JSON.stringify(run1.json));
    const rows = await db.select().from(whatsappOutbox).where(and(eq(whatsappOutbox.tenantId, A), eq(whatsappOutbox.replyCategory, "EXPIRY_REMINDER_STAFF")));
    assert.ok(rows.length >= 1, "reminder row queued");
    const n = rows.length;
    await call(tok.SUPER_ADMIN, "POST", "/api/vault/reminders/run", { referenceDate: "2026-12-20" });
    const rows2 = await db.select().from(whatsappOutbox).where(and(eq(whatsappOutbox.tenantId, A), eq(whatsappOutbox.replyCategory, "EXPIRY_REMINDER_STAFF")));
    assert.equal(rows2.length, n, "rerun must not duplicate");
    assert.equal((await call(tok.CLERK, "POST", "/api/vault/reminders/run", {})).status, 403);
  });
  await t("API-11 client reminders toggle needs companies:update", async () => {
    assert.equal((await call(tok.VIEWER, "PATCH", `/api/vault/companies/${co.id}/reminders`, { enabled: true, consentGiven: true })).status, 403);
    const ok = await call(tok.MANAGER, "PATCH", `/api/vault/companies/${co.id}/reminders`, { enabled: true, consentGiven: true });
    assert.equal(ok.status, 200, JSON.stringify(ok.json));
    const noConsent = await call(tok.MANAGER, "PATCH", `/api/vault/companies/${co.id}/reminders`, { enabled: true, consentGiven: false });
    assert.ok([200, 400, 422].includes(noConsent.status));
  });

  console.log(`\nAPI: ${passed} passed, ${failed} failed`);
  await closePool();
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error("Fatal", e); process.exit(1); });
