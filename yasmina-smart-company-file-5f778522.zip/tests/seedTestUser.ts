import { pool } from "../src/db/index.js";

/**
 * requireAuth now fails closed when the user row no longer exists, so tests that sign
 * their own JWTs must first create the matching user row.
 */
export async function seedTestUser(id: number, username: string, role: string, tenantId: string): Promise<void> {
  await pool.query(
    `INSERT INTO users (id, tenant_id, uid, email, display_name, role, active, token_version)
     VALUES ($1, $2, $3, $4, $3, $5, true, 1)
     ON CONFLICT (id) DO UPDATE SET tenant_id = EXCLUDED.tenant_id, uid = EXCLUDED.uid, role = EXCLUDED.role, active = true, token_version = 1`,
    [id, tenantId, username.toLowerCase(), `${username.toLowerCase()}@test.local`, role],
  );
}
