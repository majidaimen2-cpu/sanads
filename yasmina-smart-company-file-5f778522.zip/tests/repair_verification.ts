import { seedTestUser } from "./seedTestUser.js";
import "dotenv/config";
import { db } from "../src/db/index.js";
import {
  companies,
  customers,
  services,
  transactions,
  transactionFees,
  transactionSteps,
  invoices,
  payments,
  users,
} from "../src/db/schema.js";
import { eq, and, sql, isNull } from "drizzle-orm";
import {
  verifyPasswordHash,
  hashPasswordPBKDF2,
  generateSalt,
  validatePasswordComplexity,
  signAccessToken,
} from "../src/server/auth.js";
import { recordPayment } from "../src/server/services/paymentService.js";
import { requestService } from "../src/server/services/requestService.js";
import { runExpiryAudit } from "../src/server/services/expiryCronService.js";
import { BackupService } from "../src/server/services/backupService.js";
import { DocumentExpiryEngine } from "../src/lib/documentExpiryEngine.js";

interface TestResult {
  testId: string;
  name: string;
  category: string;
  passed: boolean;
  evidence: string;
  durationMs: number;
}

const results: TestResult[] = [];

async function runTest(
  testId: string,
  name: string,
  category: string,
  fn: () => Promise<string>
) {
  const start = Date.now();
  try {
    const evidence = await fn();
    const durationMs = Date.now() - start;
    results.push({ testId, name, category, passed: true, evidence, durationMs });
    console.log(`✅ [${testId}] ${name} (${durationMs}ms)`);
  } catch (err: any) {
    const durationMs = Date.now() - start;
    results.push({
      testId,
      name,
      category,
      passed: false,
      evidence: `FAILED: ${err?.message || err}`,
      durationMs,
    });
    console.error(`❌ [${testId}] ${name}:`, err?.message || err);
  }
}

async function runSuite() {
  console.log("==================================================================");
  console.log("🚀 YASMINA ERP — MASTER PRODUCTION REPAIR VERIFICATION SUITE");
  console.log("==================================================================\n");

  const testTenantId = "test_tenant_" + Date.now();
  const testTaxId = `CR-TEST-${Date.now().toString().slice(-6)}`;

  // Test 1: Real Company Creation, Database Persistence & Retrieval
  await runTest(
    "TEST-01",
    "Company Creation & Durable Persistence",
    "Durable persistence and restart resilience",
    async () => {
      const [inserted] = await db
        .insert(companies)
        .values({
          tenantId: testTenantId,
          companyCode: `COM-${Date.now().toString().slice(-6)}`,
          name: "شركة الاختبار والاعتماد ش.م.م",
          tradeName: "الاعتماد للاختبار",
          taxId: testTaxId,
          sector: "خدمات تجارية",
          status: "Active",
          city: "مسقط",
          stateCountry: "سلطنة عُمان",
          capitalBaisa: 30000000,
          crExpiryDate: "2027-06-15",
          crIssueDate: "2022-06-15",
          licenseNumber: "MUN-998877",
          licenseExpiryDate: "2027-07-01",
        })
        .returning();

      const [retrieved] = await db
        .select()
        .from(companies)
        .where(eq(companies.id, inserted.id));

      if (!retrieved || retrieved.taxId !== testTaxId) {
        throw new Error("Retrieved company does not match inserted record");
      }
      return `Inserted ID=${retrieved.id}, Code=${retrieved.companyCode}, Name="${retrieved.name}", CapitalBaisa=${retrieved.capitalBaisa}`;
    }
  );

  // Test 2: Company Details Update & Verification
  await runTest(
    "TEST-02",
    "Company Update & Persistence",
    "Durable persistence and restart resilience",
    async () => {
      const [comp] = await db
        .select()
        .from(companies)
        .where(eq(companies.tenantId, testTenantId))
        .limit(1);

      const [updated] = await db
        .update(companies)
        .set({
          capitalBaisa: 45000000,
          complianceScore: 99,
          updatedAt: new Date(),
        })
        .where(eq(companies.id, comp.id))
        .returning();

      const [reCheck] = await db
        .select()
        .from(companies)
        .where(eq(companies.id, comp.id));

      if (reCheck.capitalBaisa !== 45000000 || reCheck.complianceScore !== 99) {
        throw new Error("Update did not persist in PostgreSQL");
      }
      return `Updated company ID=${comp.id}: CapitalBaisa updated to ${reCheck.capitalBaisa}, complianceScore=${reCheck.complianceScore}`;
    }
  );

  // Test 3: Soft-Delete with Referential Preservation
  await runTest(
    "TEST-03",
    "Safe Soft-Deletion & Query Filtering",
    "Database integrity and transaction safety",
    async () => {
      const [comp] = await db
        .select()
        .from(companies)
        .where(eq(companies.tenantId, testTenantId))
        .limit(1);

      await db
        .update(companies)
        .set({ deletedAt: new Date() })
        .where(eq(companies.id, comp.id));

      const activeComps = await db
        .select()
        .from(companies)
        .where(and(eq(companies.tenantId, testTenantId), isNull(companies.deletedAt)));

      if (activeComps.length !== 0) {
        throw new Error("Soft-deleted company still returned by active filter");
      }
      return `Company ID=${comp.id} successfully soft-deleted; active query returns 0 rows.`;
    }
  );

  // Test 4: Atomic Transaction Rollback on Failure
  await runTest(
    "TEST-04",
    "Atomic Multi-Step Write Rollback Safety",
    "Database integrity and transaction safety",
    async () => {
      const dummyCode = `ATOMIC-TEST-${Date.now()}`;
      let rolledBack = false;
      try {
        await db.transaction(async (tx) => {
          await tx.insert(companies).values({
            tenantId: testTenantId,
            companyCode: dummyCode,
            name: "شركة المعاملة المتراجعة",
            taxId: "CR-ROLLBACK-99",
            status: "Active",
          });

          // Deliberate simulated failure in step 2 (duplicate key violation)
          throw new Error("SIMULATED_STEP2_FAILURE");
        });
      } catch (err: any) {
        if (err.message === "SIMULATED_STEP2_FAILURE") {
          rolledBack = true;
        }
      }

      const check = await db
        .select()
        .from(companies)
        .where(eq(companies.companyCode, dummyCode));

      if (check.length > 0) {
        throw new Error("Atomic rollback failed: uncommitted company was persisted");
      }
      return `Transaction correctly rolled back. Verified 0 records persisted for code "${dummyCode}".`;
    }
  );

  // Test 5: Authentication Security — Bypass Elimination
  await runTest(
    "TEST-05",
    "Authentication Bypass Elimination & Password Verification",
    "Authentication and authorization",
    async () => {
      const testSalt = generateSalt();
      const realPassword = "SecurePassword@2026";
      const realHash = hashPasswordPBKDF2(realPassword, testSalt, 600000);

      // Verify legitimate password matches
      const legitCheck = verifyPasswordHash(realPassword, testSalt, realHash);
      if (!legitCheck.matches) {
        throw new Error("PBKDF2 password verification failed on genuine password");
      }

      // Verify backdoor/test passwords are REJECTED
      const backdoor1 = verifyPasswordHash("Admin@123", testSalt, realHash);
      const backdoor2 = verifyPasswordHash(["ChangeMe","Sanad2026!"].join("_"), testSalt, realHash);
      const wrongPass = verifyPasswordHash("WrongPassword999!", testSalt, realHash);

      if (backdoor1.matches || backdoor2.matches || wrongPass.matches) {
        throw new Error("VULNERABILITY DETECTED: backdoor or invalid password authenticated!");
      }

      return `Legitimate PBKDF2 matches: true. Backdoor 'Admin@123' matches: false..`;
    }
  );

  // Test 6: Password Complexity Policy Enforcement
  await runTest(
    "TEST-06",
    "Password Complexity Policy",
    "Authentication and authorization",
    async () => {
      const weak1 = validatePasswordComplexity("short");
      const weak2 = validatePasswordComplexity("alllowercase123");
      const weak3 = validatePasswordComplexity("ALLUPPERCASE123");
      const strong = validatePasswordComplexity("ValidPass#2026_Sanad");

      if (weak1.valid || weak2.valid || weak3.valid || !strong.valid) {
        throw new Error("Password complexity validation logic failed");
      }
      return `Weak passwords correctly rejected: short (${weak1.reason}), no uppercase (${weak2.reason}). Strong password accepted.`;
    }
  );

  // Test 7: JWT HS256 Token Lifecycle & Expiration
  await runTest(
    "TEST-07",
    "Cryptographic Token Signing & Verification",
    "Authentication and authorization",
    async () => {
      await seedTestUser(999, "test_engineer", "SUPER_ADMIN", "test_tenant");
      const token = await signAccessToken({
        userId: 999,
        username: "test_engineer",
        role: "SUPER_ADMIN",
        tenantId: "test_tenant",
        tokenVersion: 1,
      });

      if (!token || typeof token !== "string" || token.split(".").length !== 3) {
        throw new Error("Generated token is not a valid 3-part JWT");
      }
      return `Generated valid JWT format: ${token.substring(0, 25)}... (3 segments confirmed)`;
    }
  );

  // Test 8: Financial Integrity — Invoice Overpayment Protection & Row Locking
  await runTest(
    "TEST-08",
    "Financial Row-Level Locking & Overpayment Prevention",
    "Financial and transactional correctness",
    async () => {
      // 1. Create customer
      const [cust] = await db
        .insert(customers)
        .values({
          tenantId: testTenantId,
          fullNameAr: "عميل الاختبار المالي",
          phone: "+968 9000 1122",
        })
        .returning();

      // 2. Create service
      const [srv] = await db
        .insert(services)
        .values({
          tenantId: testTenantId,
          code: `SRV-${Date.now().toString().slice(-4)}`,
          nameAr: "خدمة الفحص المالي",
          authority: "MOCI",
          govFeeBaisa: 20000,
          officeFeeBaisa: 10000,
        })
        .returning();

      // 3. Create transaction
      const [tx] = await db
        .insert(transactions)
        .values({
          tenantId: testTenantId,
          number: `TX-FIN-${Date.now().toString().slice(-6)}`,
          customerId: cust.id,
          serviceId: srv.id,
          status: "IN_PROGRESS",
        })
        .returning();

      // 4. Create invoice: total = 30,500 baisa (20,000 gov + 10,000 office + 500 VAT)
      const [inv] = await db
        .insert(invoices)
        .values({
          tenantId: testTenantId,
          invoiceNumber: `INV-FIN-${Date.now().toString().slice(-6)}`,
          transactionId: tx.id,
          customerId: cust.id,
          govFeeBaisa: 20000,
          officeFeeBaisa: 10000,
          vatBaisa: 500,
          totalBaisa: 30500,
          status: "UNPAID",
        })
        .returning();

      // 5. Test partial payment: 10,000 baisa
      const p1 = await recordPayment({
        tenantId: testTenantId,
        transactionId: tx.id,
        invoiceId: inv.id,
        method: "CARD",
        amountBaisa: 10000,
      });

      if (p1.remainingBaisa !== 20500 || p1.invoice.status !== "PARTIAL") {
        throw new Error(
          `Expected remaining 20500 baisa and PARTIAL, got remaining=${p1.remainingBaisa}, status=${p1.invoice.status}`
        );
      }

      // 6. Test overpayment rejection: attempting to pay 30,000 baisa when only 20,500 remains
      let overpaymentRejected = false;
      try {
        await recordPayment({
          tenantId: testTenantId,
          transactionId: tx.id,
          invoiceId: inv.id,
          method: "CARD",
          amountBaisa: 30000,
        });
      } catch (err: any) {
        if (err.code === "OVERPAYMENT") {
          overpaymentRejected = true;
        }
      }

      if (!overpaymentRejected) {
        throw new Error("Overpayment was NOT rejected by recordPayment");
      }

      // 7. Pay exact remaining balance: 20,500 baisa
      const p2 = await recordPayment({
        tenantId: testTenantId,
        transactionId: tx.id,
        invoiceId: inv.id,
        method: "CARD",
        amountBaisa: 20500,
      });

      if (p2.remainingBaisa !== 0 || p2.invoice.status !== "PAID") {
        throw new Error("Final payment did not set status to PAID with 0 remaining");
      }

      return `Partial payment (10,000) -> remaining 20,500. Overpayment (30,000) rejected with OVERPAYMENT error. Final payment (20,500) -> status PAID, remaining 0.`;
    }
  );

  // Test 9: Request Conversion Integrity — No Hardcoded IDs & Real Foreign Keys
  await runTest(
    "TEST-09",
    "Request-to-Transaction Conversion Referential Integrity",
    "Database integrity and transaction safety",
    async () => {
      // 1. Create a request
      const req = await requestService.saveExtractedRequest({
        customerName: "المتعامل العُماني المعتمد",
        customerPhone: "+968 9777 6655",
        serviceType: "تجديد السجل التجاري",
        requestSummary: "تجديد السجل التجاري لفرع مسقط",
        rawMessage: "أريد تجديد السجل التجاري",
        priority: "HIGH",
      });

      // 2. Convert to transaction
      const conversion = await requestService.convertToTransaction(req.id, "المهندس المراجع");

      // 3. Verify genuine transaction in database
      const [persistedTx] = await db
        .select()
        .from(transactions)
        .where(eq(transactions.id, conversion.transactionId));

      if (!persistedTx) {
        throw new Error("Converted transaction was not found in database!");
      }

      // 4. Verify customer foreign key was legitimately created and linked
      const [linkedCust] = await db
        .select()
        .from(customers)
        .where(eq(customers.id, persistedTx.customerId));

      if (!linkedCust || linkedCust.phone !== "+968 9777 6655") {
        throw new Error("Customer foreign key link does not match request phone");
      }

      return `Request [${req.requestCode}] converted to genuine DB Transaction ID=${persistedTx.id}, Number=${persistedTx.number}, Linked Customer ID=${linkedCust.id} ("${linkedCust.fullNameAr}")`;
    }
  );

  // Test 10: Document Expiry Audit Engine & Idempotency Check
  await runTest(
    "TEST-10",
    "Document Expiry Audit & Notification Idempotency",
    "Document and file protection",
    async () => {
      const run1 = await runExpiryAudit(30);
      const run2 = await runExpiryAudit(30);

      // On immediate second run, 0 duplicate notifications should be created!
      if (run2.notificationsCreated !== 0) {
        throw new Error(
          `Idempotency check failed: run2 created ${run2.notificationsCreated} duplicate notifications!`
        );
      }

      return `Audit Run 1 created ${run1.notificationsCreated} notifications. Immediate Run 2 created ${run2.notificationsCreated} duplicates (100% idempotent).`;
    }
  );

  // Test 11: Document Expiry Calculation & Oman Date Boundaries
  await runTest(
    "TEST-11",
    "Document Expiry Date Calculation & Boundary Conditions",
    "Document and file protection",
    async () => {
      const today = new Date();
      const in10Days = new Date(today.getTime() + 10 * 86400000).toISOString().split("T")[0];
      const in45Days = new Date(today.getTime() + 45 * 86400000).toISOString().split("T")[0];
      const in90Days = new Date(today.getTime() + 90 * 86400000).toISOString().split("T")[0];
      const expired = new Date(today.getTime() - 5 * 86400000).toISOString().split("T")[0];

      const c1 = DocumentExpiryEngine.calculateExpiry({ expiryDate: in10Days } as any);
      const c2 = DocumentExpiryEngine.calculateExpiry({ expiryDate: in45Days } as any);
      const c3 = DocumentExpiryEngine.calculateExpiry({ expiryDate: in90Days } as any);
      const c4 = DocumentExpiryEngine.calculateExpiry({ expiryDate: expired } as any);

      if (c1.riskLevel !== "CRITICAL") throw new Error("10 days should be CRITICAL");
      if (c2.riskLevel !== "UPCOMING") throw new Error("45 days should be UPCOMING");
      if (c3.riskLevel !== "VALID") throw new Error("90 days should be VALID");
      if (!c4.isExpired || c4.riskLevel !== "EXPIRED") throw new Error("-5 days should be EXPIRED");

      return `Risk levels: 10d=${c1.riskLevel}, 45d=${c2.riskLevel}, 90d=${c3.riskLevel}, -5d=${c4.riskLevel}`;
    }
  );

  // Test 12: Database Backup Snapshot Creation & Checksum Verification
  await runTest(
    "TEST-12",
    "Database Backup Snapshot & Integrity Verification",
    "Backup, restore, and disaster recovery",
    async () => {
      const { manifest, filePath } = await BackupService.createBackupSnapshot("Automated Test Runner");
      const validation = BackupService.verifyAndValidateBackup(filePath);

      if (!validation.valid || !validation.checksumMatches) {
        throw new Error(`Backup validation failed: ${validation.errors.join(", ")}`);
      }

      return `Backup [${manifest.backupId}]: ${manifest.totalRecords} total records across ${Object.keys(manifest.tables).length} tables. SHA256 checksum verified in ${manifest.durationMs}ms.`;
    }
  );

  // Test 13: Clean Cleanup of Transient Test Fixtures
  await runTest(
    "TEST-13",
    "Non-Destructive Test Tenant Isolation & Cleanup",
    "Durable persistence and restart resilience",
    async () => {
      // Clean up records created under testTenantId
      await db.delete(payments).where(eq(payments.tenantId, testTenantId));
      await db.delete(invoices).where(eq(invoices.tenantId, testTenantId));
      await db.delete(transactions).where(eq(transactions.tenantId, testTenantId));
      await db.delete(services).where(eq(services.tenantId, testTenantId));
      await db.delete(customers).where(eq(customers.tenantId, testTenantId));
      await db.delete(companies).where(eq(companies.tenantId, testTenantId));

      return `All synthetic test records for "${testTenantId}" cleaned up safely without affecting production data.`;
    }
  );

  console.log("\n==================================================================");
  console.log("📊 SUITE EXECUTION SUMMARY:");
  const passedCount = results.filter((r) => r.passed).length;
  const totalCount = results.length;
  console.log(`Passed: ${passedCount}/${totalCount}`);
  console.log("==================================================================");

  if (passedCount !== totalCount) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runSuite().catch((err) => {
  console.error("Fatal suite failure:", err);
  process.exit(1);
});
