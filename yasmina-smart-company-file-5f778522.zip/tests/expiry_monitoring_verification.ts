import { seedTestUser } from "./seedTestUser.js";
import http from "http";
import { createApp } from "../src/server/app.js";
import { db, pool, runMigrations } from "../src/db/index.js";
import {
  companies,
  customers,
  customerDocuments,
  employees,
  contracts,
  notifications,
  expiryJobRuns,
  auditLogs,
} from "../src/db/schema.js";
import { eq, inArray } from "drizzle-orm";
import {
  classifyDocumentExpiry,
  discoverAllMonitoredDocuments,
  runExpiryAudit,
} from "../src/server/services/expiryCronService.js";
import { signAccessToken } from "../src/server/auth.js";

interface TestResult {
  id: string;
  name: string;
  passed: boolean;
  details: string;
}

const results: TestResult[] = [];

function recordTest(id: string, name: string, passed: boolean, details: string) {
  results.push({ id, name, passed, details });
  const icon = passed ? "✅ PASS" : "❌ FAIL";
  console.log(`${icon} [${id}] ${name} — ${details}`);
}

function addDays(baseIsoDate: string, daysOffset: number): string {
  const [y, m, d] = baseIsoDate.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + daysOffset));
  return dt.toISOString().slice(0, 10);
}

async function main() {
  console.log("================================================================================");
  console.log("🚀 STARTING AUTOMATIC DOCUMENT EXPIRY MONITORING & NOTIFICATIONS VERIFICATION");
  console.log("================================================================================");

  await runMigrations();

  // Deterministic reference date in Asia/Muscat
  const REF_DATE = "2026-06-01";
  const suffix = Date.now().toString().slice(-6);
  const TENANT_A = `tenant_exp_a_${suffix}`;
  const TENANT_B = `tenant_exp_b_${suffix}`;

  // Spin up ephemeral Express server with full app & RBAC
  const app = await createApp();
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", () => resolve()));
  const address = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${address.port}`;

  await seedTestUser(9001, `admin_a_${suffix}`, "SUPER_ADMIN", TENANT_A);

  const tokenAdminA = await signAccessToken({
    userId: 9001,
    username: `admin_a_${suffix}`,
    role: "SUPER_ADMIN",
    tenantId: TENANT_A,
    tokenVersion: 1,
  });

  await seedTestUser(9002, `clerk_b_${suffix}`, "CLERK", TENANT_B);

  const tokenClerkB = await signAccessToken({
    userId: 9002,
    username: `clerk_b_${suffix}`,
    role: "CLERK",
    tenantId: TENANT_B,
    tokenVersion: 1,
  });

  await seedTestUser(9003, `viewer_a_${suffix}`, "VIEWER", TENANT_A);

  const tokenViewerA = await signAccessToken({
    userId: 9003,
    username: `viewer_a_${suffix}`,
    role: "VIEWER",
    tenantId: TENANT_A,
    tokenVersion: 1,
  });

  await seedTestUser(9004, `cashier_a_${suffix}`, "CASHIER", TENANT_A);

  const tokenCashierA = await signAccessToken({
    userId: 9004,
    username: `cashier_a_${suffix}`,
    role: "CASHIER",
    tenantId: TENANT_A,
    tokenVersion: 1,
  });

  try {
    // Create base customer and company for TENANT_A
    const [custA] = await db
      .insert(customers)
      .values({
        tenantId: TENANT_A,
        customerType: "CORPORATE",
        fullNameAr: "سالم بن حمد الشكيلي",
        phone: "+96891112222",
      })
      .returning();

    const [compA] = await db
      .insert(companies)
      .values({
        tenantId: TENANT_A,
        ownerCustomerId: custA.id,
        companyCode: `EXP-COMP-A-${suffix}`,
        name: "شركة الأفق العُمانية للتجارة ش.م.م",
        tradeName: "الأفق العُمانية",
        taxId: `9910${suffix}`,
        crIssueDate: "2024-06-01",
        crExpiryDate: addDays(REF_DATE, 90), // Case 1: +90 days (VALID)
        capitalBaisa: 25000000,
        legalForm: "شركة ذات مسؤولية محدودة",
        status: "Active",
      })
      .returning();

    // ------------------------------------------------------------------------
    // TEST 1: Document expiring in +90 days -> VALID ("سارية") & NO notification
    // ------------------------------------------------------------------------
    const c90 = classifyDocumentExpiry({
      expiryDate: addDays(REF_DATE, 90),
      hasNoExpiry: false,
      referenceDate: REF_DATE,
    });
    const auditAfter90 = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    recordTest(
      "EXP-01",
      "وثيقة تنتهي بعد 90 يومًا تصنف سارية ولا تولد إشعار انتهاء",
      c90.status === "VALID" &&
        c90.statusAr === "سارية" &&
        c90.daysRemaining === 90 &&
        auditAfter90.notificationsCreated === 0,
      `status=${c90.status} (${c90.statusAr}), daysRemaining=${c90.daysRemaining}, notificationsCreated=${auditAfter90.notificationsCreated}`
    );

    // ------------------------------------------------------------------------
    // TEST 2: Document expiring in +30 days -> EXPIRING_30 ("قربت تنتهي") + 1 notification
    // ------------------------------------------------------------------------
    const [doc30] = await db
      .insert(customerDocuments)
      .values({
        tenantId: TENANT_A,
        customerId: custA.id,
        companyId: compA.id,
        docType: "TAX_CARD",
        docNumber: `TAX-30-${suffix}`,
        issueDate: "2025-06-01",
        expiryDate: addDays(REF_DATE, 30),
        rawExpiryDate: addDays(REF_DATE, 30),
        extractionSource: "MANUAL",
        hasNoExpiry: false,
      })
      .returning();

    const audit30 = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const notifs30 = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `TAX-30-${suffix}`));

    recordTest(
      "EXP-02",
      "وثيقة تنتهي بعد 30 يومًا تصنف قربت تنتهي وتولد إشعارًا واحدًا",
      audit30.expiring30DaysCount === 1 &&
        notifs30.length === 1 &&
        notifs30[0].alertStage === "EXPIRING_30" &&
        notifs30[0].daysRemaining === 30,
      `alertStage=${notifs30[0]?.alertStage}, daysRemaining=${notifs30[0]?.daysRemaining}, count=${notifs30.length}`
    );

    // ------------------------------------------------------------------------
    // TEST 3: Document expiring in +7 days -> EXPIRING_7 ("تنتهي قريبًا جدًا") + urgent alert
    // ------------------------------------------------------------------------
    await db.insert(customerDocuments).values({
      tenantId: TENANT_A,
      customerId: custA.id,
      companyId: compA.id,
      docType: "MUNICIPAL_LICENSE",
      docNumber: `MUN-7-${suffix}`,
      issueDate: "2025-06-08",
      expiryDate: addDays(REF_DATE, 7),
      rawExpiryDate: addDays(REF_DATE, 7),
      extractionSource: "MANUAL",
      hasNoExpiry: false,
    });

    await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const notifs7 = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `MUN-7-${suffix}`));

    recordTest(
      "EXP-03",
      "وثيقة تنتهي بعد 7 أيام تصنف تنتهي قريبًا جدًا وتولد إشعارًا عاجلًا",
      notifs7.length === 1 &&
        notifs7[0].alertStage === "EXPIRING_7" &&
        notifs7[0].severity === "HIGH" &&
        notifs7[0].daysRemaining === 7,
      `alertStage=${notifs7[0]?.alertStage}, severity=${notifs7[0]?.severity}, daysRemaining=${notifs7[0]?.daysRemaining}`
    );

    // ------------------------------------------------------------------------
    // TEST 4: Document expiring TODAY (0 days) -> EXPIRING_TODAY ("تنتهي اليوم"), NOT expired yet
    // ------------------------------------------------------------------------
    await db.insert(customerDocuments).values({
      tenantId: TENANT_A,
      customerId: custA.id,
      companyId: compA.id,
      docType: "LABOR_PERMIT",
      docNumber: `LAB-0-${suffix}`,
      issueDate: "2025-06-01",
      expiryDate: REF_DATE,
      rawExpiryDate: REF_DATE,
      extractionSource: "MANUAL",
      hasNoExpiry: false,
    });

    const cToday = classifyDocumentExpiry({
      expiryDate: REF_DATE,
      hasNoExpiry: false,
      referenceDate: REF_DATE,
    });

    await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const notifsToday = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `LAB-0-${suffix}`));

    recordTest(
      "EXP-04",
      "وثيقة تنتهي اليوم تصنف تنتهي اليوم (وليست منتهية قبل نهاية اليوم) وتولد إشعارًا فوريًا",
      cToday.status === "EXPIRING_TODAY" &&
        cToday.statusAr === "تنتهي اليوم" &&
        cToday.daysRemaining === 0 &&
        notifsToday.length === 1 &&
        notifsToday[0].alertStage === "EXPIRING_TODAY",
      `status=${cToday.status} (${cToday.statusAr}), daysRemaining=${cToday.daysRemaining}, notifType=${notifsToday[0]?.type}`
    );

    // ------------------------------------------------------------------------
    // TEST 5: Document expired YESTERDAY (-1 day) -> EXPIRED ("منتهية") + CRITICAL alert
    // ------------------------------------------------------------------------
    await db.insert(employees).values({
      tenantId: TENANT_A,
      companyId: compA.id,
      employeeName: "راشد بن سعيد البلوشي",
      civilId: `RES-YEST-${suffix}`,
      residenceExpiry: addDays(REF_DATE, -1),
      nationality: "Omani",
    });

    await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const notifsYesterday = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `RES-YEST-${suffix}`));

    recordTest(
      "EXP-05",
      "وثيقة انتهت أمس (-1 يوم) تصنف منتهية وتولد إشعار انتهاء حرج",
      notifsYesterday.length === 1 &&
        notifsYesterday[0].alertStage === "EXPIRED" &&
        notifsYesterday[0].severity === "CRITICAL" &&
        notifsYesterday[0].daysRemaining === -1,
      `alertStage=${notifsYesterday[0]?.alertStage}, daysRemaining=${notifsYesterday[0]?.daysRemaining}`
    );

    // ------------------------------------------------------------------------
    // TEST 6: Document expired 60 days ago (-60 days) -> EXPIRED & ranked #1 highest priority
    // ------------------------------------------------------------------------
    const [contract60] = await db
      .insert(contracts)
      .values({
        tenantId: TENANT_A,
        companyId: compA.id,
        customerId: custA.id,
        title: "عقد إيجار المقر الرئيسي",
        contractType: "LEASE",
        status: "Active",
        startDate: "2025-04-02",
        endDate: addDays(REF_DATE, -60),
        valueBaisa: 5000000,
      })
      .returning();

    await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const allDiscoveredA = await discoverAllMonitoredDocuments(TENANT_A, {
      referenceDate: REF_DATE,
    });

    const topPriorityItem = allDiscoveredA[0];
    recordTest(
      "EXP-06",
      "وثيقة انتهت منذ 60 يومًا تصنف منتهية وتتصدر قائمة الأولويات القصوى",
      topPriorityItem.sourceEntity === "contracts" &&
        topPriorityItem.sourceId === String(contract60.id) &&
        topPriorityItem.status === "EXPIRED" &&
        topPriorityItem.daysRemaining === -60 &&
        topPriorityItem.priorityRank === 1,
      `topItem=${topPriorityItem.docTypeAr} (${topPriorityItem.docNumber}), daysRemaining=${topPriorityItem.daysRemaining}, rank=${topPriorityItem.priorityRank}`
    );

    // ------------------------------------------------------------------------
    // TEST 7: Document with hasNoExpiry = true -> NO_EXPIRY & generates ZERO alerts
    // ------------------------------------------------------------------------
    await db.insert(customerDocuments).values({
      tenantId: TENANT_A,
      customerId: custA.id,
      companyId: compA.id,
      docType: "FOUNDATION_CONTRACT",
      docNumber: `PERM-DOC-${suffix}`,
      issueDate: "2020-01-15",
      expiryDate: null,
      hasNoExpiry: true,
      extractionSource: "MANUAL",
    });

    await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const notifsPerm = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `PERM-DOC-${suffix}`));

    const cPerm = classifyDocumentExpiry({
      expiryDate: null,
      hasNoExpiry: true,
      referenceDate: REF_DATE,
    });

    recordTest(
      "EXP-07",
      "وثيقة بلا تاريخ انتهاء (hasNoExpiry=true) لا تولد إشعار انتهاء خاطئ",
      cPerm.status === "NO_EXPIRY" &&
        cPerm.needsReview === false &&
        notifsPerm.length === 0,
      `status=${cPerm.status} (${cPerm.statusAr}), notificationsGenerated=${notifsPerm.length}`
    );

    // ------------------------------------------------------------------------
    // TEST 8: Document with invalid or missing expiry date -> NEEDS_REVIEW without fabricating date
    // ------------------------------------------------------------------------
    const [invalidDoc] = await db
      .insert(customerDocuments)
      .values({
        tenantId: TENANT_A,
        customerId: custA.id,
        companyId: compA.id,
        docType: "CHAMBER_CERTIFICATE",
        docNumber: `INV-DATE-${suffix}`,
        issueDate: "2025-01-01",
        expiryDate: null,
        rawExpiryDate: "2026-02-31", // Impossible calendar date (Feb 31)
        hasNoExpiry: false,
        extractionSource: "OCR",
      })
      .returning();

    const cInvalid = classifyDocumentExpiry({
      expiryDate: "2026-02-31",
      hasNoExpiry: false,
      referenceDate: REF_DATE,
    });

    await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const [reloadedInvalidDoc] = await db
      .select()
      .from(customerDocuments)
      .where(eq(customerDocuments.id, invalidDoc.id));

    const notifsInvalid = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `INV-DATE-${suffix}`));

    recordTest(
      "EXP-08",
      "وثيقة بتاريخ غير صالح أو ناقص تصنف تحتاج إلى مراجعة (NEEDS_REVIEW) دون اختلاق تاريخ",
      cInvalid.status === "NEEDS_REVIEW" &&
        cInvalid.needsReview === true &&
        cInvalid.normalizedExpiryDate === null &&
        reloadedInvalidDoc.expiryDate === null &&
        reloadedInvalidDoc.needsReview === true &&
        notifsInvalid.length === 1 &&
        notifsInvalid[0].alertStage === "NEEDS_REVIEW",
      `status=${cInvalid.status}, dbExpiryDate=${reloadedInvalidDoc.expiryDate}, needsReview=${reloadedInvalidDoc.needsReview}, alertStage=${notifsInvalid[0]?.alertStage}`
    );

    // ------------------------------------------------------------------------
    // TEST 9: Manual expiry date update -> immediately updates status, creates new stage notification, and logs in audit_logs
    // ------------------------------------------------------------------------
    const manualUpdateRes = await fetch(
      `${baseUrl}/api/notifications/documents/customer_documents/${invalidDoc.id}/expiry`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${tokenAdminA}`,
        },
        body: JSON.stringify({
          expiryDate: addDays(REF_DATE, 5), // Now expires in 5 days (EXPIRING_7)
          hasNoExpiry: false,
          referenceDate: REF_DATE,
        }),
      }
    );
    const manualUpdateBody = await manualUpdateRes.json();

    const auditLogRows = await db
      .select()
      .from(auditLogs)
      .where(eq(auditLogs.resourceId, String(invalidDoc.id)));

    const notifsAfterManualUpdate = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `INV-DATE-${suffix}`));

    const hasExpiring7Alert = notifsAfterManualUpdate.some((n) => n.alertStage === "EXPIRING_7");
    const hasAuditRecord = auditLogRows.some((a) => a.action === "UPDATE_DOCUMENT_EXPIRY");

    recordTest(
      "EXP-09",
      "تعديل تاريخ انتهاء وثيقة يحدث الحالة والإشعارات فورًا ويسجل العملية في سجل التدقيق (audit_logs)",
      manualUpdateRes.status === 200 &&
        manualUpdateBody.classification?.status === "EXPIRING_7" &&
        hasExpiring7Alert &&
        hasAuditRecord,
      `newStatus=${manualUpdateBody.classification?.status}, hasExpiring7Alert=${hasExpiring7Alert}, auditLogged=${hasAuditRecord}`
    );

    // ------------------------------------------------------------------------
    // TEST 10: Repeated cron runs idempotency & stage escalation across days
    // ------------------------------------------------------------------------
    const repeatRun1 = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "CRON",
    });
    const repeatRun2 = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "CRON",
    });
    const repeatNextDaySameStage = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: addDays(REF_DATE, 1), // doc30 is now 29 days remaining (still EXPIRING_30)
      triggerType: "CRON",
    });

    const notifsDoc30StillSameStage = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `TAX-30-${suffix}`));

    // Now advance clock so doc30 has 6 days remaining (transitions from EXPIRING_30 -> EXPIRING_7)
    const escalateRun = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: addDays(REF_DATE, 24), // 30 - 24 = 6 days remaining -> EXPIRING_7
      triggerType: "CRON",
    });

    const notifsDoc30AfterEscalation = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `TAX-30-${suffix}`));

    recordTest(
      "EXP-10",
      "تشغيل الوظيفة المجدولة عدة مرات لا يكرر إشعار نفس المرحلة، وينشئ إشعارًا جديدًا عند الانتقال لمرحلة أشد خطورة",
      repeatRun1.notificationsCreated === 0 &&
        repeatRun2.notificationsCreated === 0 &&
        repeatRun2.notificationsDeduplicated > 0 &&
        notifsDoc30StillSameStage.length === 1 &&
        escalateRun.notificationsCreated >= 1 &&
        notifsDoc30AfterEscalation.length === 2,
      `repeatRun1Created=${repeatRun1.notificationsCreated}, repeatRun2Created=${repeatRun2.notificationsCreated}, deduplicated=${repeatRun2.notificationsDeduplicated}, stagesForDoc30=${notifsDoc30AfterEscalation.map((n) => n.alertStage).join(" -> ")}`
    );

    // ------------------------------------------------------------------------
    // TEST 11: Multi-tenant isolation, Chatbot immediate expired CR upload, and Mark-as-Read
    // ------------------------------------------------------------------------
    // Upload an already-expired CR via Chatbot endpoint (/api/cr/confirm-register) for TENANT_B
    const confirmExpiredCrRes = await fetch(`${baseUrl}/api/cr/confirm-register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${tokenClerkB}`,
      },
      body: JSON.stringify({
        action: "CREATE_NEW",
        companyNameAr: "شركة مسقط للحلول الرقمية ش.م.م",
        crNumber: `8844${suffix}`,
        legalForm: "شركة ذات مسؤولية محدودة",
        capitalOmr: 15000,
        issueDate: "2020-01-01",
        expiryDate: "2025-01-01", // Already expired!
        city: "مسقط",
        ownerOrManagerName: "خالد بن محمد العامري",
      }),
    });
    const confirmExpiredCrBody = await confirmExpiredCrRes.json();

    // Fetch notifications as TENANT_B Clerk
    const getNotifsBRes = await fetch(`${baseUrl}/api/notifications`, {
      headers: { Authorization: `Bearer ${tokenClerkB}` },
    });
    const getNotifsBBody = await getNotifsBRes.json();

    // Ensure TENANT_B only sees TENANT_B notifications and NOT TENANT_A notifications
    const tenantBAllBelongToB =
      Array.isArray(getNotifsBBody.data) &&
      getNotifsBBody.data.length === 1 &&
      getNotifsBBody.data.every(
        (n: any) => n.tenantId === TENANT_B && String(n.docNumber).includes(`8844${suffix}`)
      );

    // Mark the notification as read
    const notifBId = getNotifsBBody.data[0]?.id;
    const markReadRes = await fetch(`${baseUrl}/api/notifications/${notifBId}/read`, {
      method: "PUT",
      headers: { Authorization: `Bearer ${tokenClerkB}` },
    });
    const getNotifsBAfterRead = await (
      await fetch(`${baseUrl}/api/notifications`, {
        headers: { Authorization: `Bearer ${tokenClerkB}` },
      })
    ).json();

    recordTest(
      "EXP-11",
      "عزل بيانات الشركات والمستخدمين، وتوليد إشعار فوري عند رفع سجل منتهٍ من الشات بوت، وتحديث عداد غير المقروءة عند القراءة",
      confirmExpiredCrRes.status === 201 &&
        confirmExpiredCrBody.expiryEvaluation?.status === "EXPIRED" &&
        tenantBAllBelongToB &&
        getNotifsBBody.unreadCount === 1 &&
        markReadRes.status === 200 &&
        getNotifsBAfterRead.unreadCount === 0,
      `chatbotCrStatus=${confirmExpiredCrBody.expiryEvaluation?.status}, tenantBIsolated=${tenantBAllBelongToB}, unreadBefore=${getNotifsBBody.unreadCount}, unreadAfter=${getNotifsBAfterRead.unreadCount}`
    );

    // ------------------------------------------------------------------------
    // TEST 12: Delivery failure recording & automatic retry on subsequent run
    // ------------------------------------------------------------------------
    await db.insert(customerDocuments).values({
      tenantId: TENANT_A,
      customerId: custA.id,
      companyId: compA.id,
      docType: "PASSPORT",
      docNumber: `FAIL-RETRY-${suffix}`,
      issueDate: "2021-01-01",
      expiryDate: addDays(REF_DATE, -10),
      rawExpiryDate: addDays(REF_DATE, -10),
      hasNoExpiry: false,
      extractionSource: "MANUAL",
    });

    const failRun = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
      simulateDeliveryFailureForDocNumber: `FAIL-RETRY-${suffix}`,
    });

    const [failedNotifBeforeRetry] = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `FAIL-RETRY-${suffix}`));

    // Next audit run automatically retries failed notifications
    const recoveryRun = await runExpiryAudit({
      tenantId: TENANT_A,
      referenceDate: REF_DATE,
      triggerType: "TEST",
    });

    const [recoveredNotif] = await db
      .select()
      .from(notifications)
      .where(eq(notifications.docNumber, `FAIL-RETRY-${suffix}`));

    recordTest(
      "EXP-12",
      "تسجيل فشل تسليم الإشعار وإعادة المحاولة تلقائيًا في التشغيل التالي دون فقدان الإشعار",
      failRun.failedDeliveries === 1 &&
        failedNotifBeforeRetry?.deliveryStatus === "FAILED" &&
        recoveryRun.retriedDeliveries >= 1 &&
        recoveredNotif?.deliveryStatus === "DELIVERED" &&
        recoveredNotif?.retryCount === 1,
      `initialStatus=${failedNotifBeforeRetry?.deliveryStatus}, retriedCount=${recoveryRun.retriedDeliveries}, finalStatus=${recoveredNotif?.deliveryStatus}, retryCount=${recoveredNotif?.retryCount}`
    );

    // ------------------------------------------------------------------------
    // TEST 13: Unauthorized users (VIEWER, CASHIER, unauthenticated) blocked from notifications & expiry updates
    // ------------------------------------------------------------------------
    const unauthNotifRes = await fetch(`${baseUrl}/api/notifications`);
    const viewerNotifRes = await fetch(`${baseUrl}/api/notifications`, {
      headers: { Authorization: `Bearer ${tokenViewerA}` },
    });
    const cashierNotifRes = await fetch(`${baseUrl}/api/notifications`, {
      headers: { Authorization: `Bearer ${tokenCashierA}` },
    });
    const viewerModifyExpiryRes = await fetch(
      `${baseUrl}/api/notifications/documents/customer_documents/${doc30.id}/expiry`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${tokenViewerA}`,
        },
        body: JSON.stringify({ expiryDate: "2028-01-01" }),
      }
    );

    recordTest(
      "EXP-13",
      "منع المستخدمين غير المخولين (VIEWER / CASHIER / بدون تسجيل دخول) من الوصول للإشعارات أو تعديل تواريخ الوثائق",
      unauthNotifRes.status === 401 &&
        viewerNotifRes.status === 403 &&
        cashierNotifRes.status === 403 &&
        viewerModifyExpiryRes.status === 403,
      `unauth=${unauthNotifRes.status}, viewerRead=${viewerNotifRes.status}, cashierRead=${cashierNotifRes.status}, viewerUpdateExpiry=${viewerModifyExpiryRes.status}`
    );
  } finally {
    // Clean up all test rows created in TENANT_A and TENANT_B (except append-only audit_logs)
    const testTenants = [TENANT_A, TENANT_B];
    await db.delete(notifications).where(inArray(notifications.tenantId, testTenants));
    await db.delete(expiryJobRuns).where(inArray(expiryJobRuns.tenantId, testTenants));
    await db.delete(contracts).where(inArray(contracts.tenantId, testTenants));
    await db.delete(employees).where(inArray(employees.tenantId, testTenants));
    await db.delete(customerDocuments).where(inArray(customerDocuments.tenantId, testTenants));
    await db.delete(companies).where(inArray(companies.tenantId, testTenants));
    await db.delete(customers).where(inArray(customers.tenantId, testTenants));

    server.close();
    await pool.end();
  }

  console.log("================================================================================");
  const passedCount = results.filter((r) => r.passed).length;
  console.log(`📊 EXPIRY MONITORING VERIFICATION SUMMARY: ${passedCount}/${results.length} PASSED`);
  console.log("================================================================================");

  if (passedCount !== results.length) {
    process.exit(1);
  }
}

main().catch((err) => {
  console.error("Fatal error in expiry_monitoring_verification:", err);
  process.exit(1);
});
