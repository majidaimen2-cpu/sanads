/**
 * WhatsApp Gateway QR Code Production-Grade Verification Suite
 * Covers all 10 Mandatory Automated Test Cases required by Mission Specification:
 *  1. Connection initialization
 *  2. Real provider QR event handling
 *  3. QR delivery to frontend API
 *  4. QR rendering and decoding
 *  5. QR replacement when new event arrives
 *  6. Stale QR rejection
 *  7. Successful connection-state transitions
 *  8. Disconnect and reconnect behavior
 *  9. Concurrent connection requests
 * 10. Session persistence and restoration across restarts
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import path from "path";
import QRCode from "qrcode";
import {
  whatsAppService,
  isValidBaileysQrPayload,
  type WhatsAppConnectionState,
} from "../src/server/services/whatsappService.js";
import { db } from "../src/db/index.js";
import { whatsappAuthSessions } from "../src/db/schema.js";
import { eq, and } from "drizzle-orm";

interface TestReport {
  id: string;
  name: string;
  passed: boolean;
  details: string;
}

const testResults: TestReport[] = [];

function record(id: string, name: string, passed: boolean, details: string) {
  testResults.push({ id, name, passed, details });
  console.log(`[TEST] ${passed ? "✅ PASS" : "❌ FAIL"} - ${id}: ${name}`);
  if (details) console.log(`       Details: ${details}`);
}

async function runVerification() {
  console.log("\n=======================================================");
  console.log("🚀 STARTING WHATSAPP GATEWAY QR 10-STAGE AUTOMATED AUDIT");
  console.log("=======================================================\n");

  // -------------------------------------------------------------------------
  // TEST 1: Connection initialization
  // Verify clean state initialization, attempt ID generation, and state transitions
  // -------------------------------------------------------------------------
  try {
    await whatsAppService.logout();
    const stateBefore = whatsAppService.getState();
    assert.equal(stateBefore.status, "disconnected");
    assert.equal(stateBefore.connectionState, "DISCONNECTED");
    assert.equal(stateBefore.qrCodeDataUrl, null);

    const initPromise = whatsAppService.startSession(true);
    const stateDuring = whatsAppService.getState();
    assert.ok(
      stateDuring.connectionState === "INITIALIZING" ||
        stateDuring.connectionState === "QR_READY" ||
        stateDuring.status === "connecting"
    );
    assert.ok(stateDuring.connectionAttemptId.startsWith("wa_attempt_"));

    await initPromise;
    record(
      "TEST-01",
      "Connection Initialization",
      true,
      `State transitioned cleanly. AttemptId: ${whatsAppService.state.connectionAttemptId}`
    );
  } catch (err: any) {
    record("TEST-01", "Connection Initialization", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 2: Real Provider QR Event Handling
  // Validate format check, ref/key string length, and rejection of malformed payloads
  // -------------------------------------------------------------------------
  try {
    const validQrString =
      "2@ABCDEF1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,wXyZ1234567890abcdefghijklmnopqrstuvwxyz=,1234567890abcdefghijklmnopqrstuvwxyz=";
    const malformedHttpUrl = "https://example.com/fake-qr";
    const tooShortQr = "short";

    assert.equal(isValidBaileysQrPayload(validQrString), true);
    assert.equal(isValidBaileysQrPayload(malformedHttpUrl), false);
    assert.equal(isValidBaileysQrPayload(tooShortQr), false);
    assert.equal(isValidBaileysQrPayload(null), false);

    // Feed valid payload through handleConnectionUpdate
    const attemptId = whatsAppService.state.connectionAttemptId;
    await whatsAppService.handleConnectionUpdate({ qr: validQrString }, attemptId);

    const stateAfter = whatsAppService.getState();
    assert.equal(stateAfter.connectionState, "QR_READY");
    assert.equal(stateAfter.rawQr, validQrString);
    assert.ok(stateAfter.qrCodeDataUrl?.startsWith("data:image/png;base64,"));
    assert.ok(stateAfter.qrSequence > 0);

    record(
      "TEST-02",
      "Real Provider QR Event Handling",
      true,
      `Valid Baileys payload accepted, malformed payloads rejected. Seq: #${stateAfter.qrSequence}`
    );
  } catch (err: any) {
    record("TEST-02", "Real Provider QR Event Handling", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 3: QR Delivery to Frontend API
  // Verify waitForQrCode resolves with fresh payload, sequence, and expiry metadata
  // -------------------------------------------------------------------------
  try {
    const qrResult = await whatsAppService.waitForQrCode(5000, false);
    assert.ok(qrResult.qrCodeDataUrl?.startsWith("data:image/png;base64,"));
    assert.equal(qrResult.connectionState, "QR_READY");
    assert.ok(qrResult.qrSequence >= 1);
    assert.ok(qrResult.qrGeneratedAt > 0);

    record(
      "TEST-03",
      "QR Delivery to Frontend API",
      true,
      `waitForQrCode returned valid data URL (${qrResult.qrCodeDataUrl?.length} chars) with timestamp and sequence`
    );
  } catch (err: any) {
    record("TEST-03", "QR Delivery to Frontend API", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 4: QR Rendering & Decoding Verification
  // Verify data URL is a valid, high-contrast scannable PNG image with correct dimensions
  // -------------------------------------------------------------------------
  try {
    const dataUrl = whatsAppService.state.qrCodeDataUrl!;
    assert.ok(dataUrl.startsWith("data:image/png;base64,"));
    const base64Part = dataUrl.replace("data:image/png;base64,", "");
    const imgBuffer = Buffer.from(base64Part, "base64");

    // PNG header check (89 50 4E 47 0D 0A 1A 0A)
    assert.equal(imgBuffer[0], 0x89);
    assert.equal(imgBuffer[1], 0x50);
    assert.equal(imgBuffer[2], 0x4e);
    assert.equal(imgBuffer[3], 0x47);
    assert.ok(imgBuffer.length > 1000, "Image buffer should be > 1KB for scannable QR");

    record(
      "TEST-04",
      "QR Rendering & PNG Binary Validity",
      true,
      `Decoded PNG buffer size: ${imgBuffer.length} bytes, verified valid PNG 8-byte signature`
    );
  } catch (err: any) {
    record("TEST-04", "QR Rendering & PNG Binary Validity", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 5: QR Replacement When New Event Arrives
  // Verify that when provider rotates QR code, new QR atomically replaces older one
  // -------------------------------------------------------------------------
  try {
    const attemptId = whatsAppService.state.connectionAttemptId;
    const initialSeq = whatsAppService.state.qrSequence;
    const rotatedQrString =
      "2@ROTATED_SECOND_KEY_9876543210zyxwvutsrqponmlkjihgfedcba0987654321,aBcDeF=,rotated=";

    await whatsAppService.handleConnectionUpdate({ qr: rotatedQrString }, attemptId);

    const rotatedState = whatsAppService.getState();
    assert.equal(rotatedState.rawQr, rotatedQrString);
    assert.equal(rotatedState.qrSequence, initialSeq + 1);
    assert.ok(rotatedState.qrCodeDataUrl);

    record(
      "TEST-05",
      "QR Replacement on Provider Rotation",
      true,
      `Rotated QR replaced old QR atomically. Sequence increased from #${initialSeq} to #${rotatedState.qrSequence}`
    );
  } catch (err: any) {
    record("TEST-05", "QR Replacement on Provider Rotation", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 6: Stale QR Rejection
  // Verify events from old attempt IDs or superseded socket generations are ignored
  // -------------------------------------------------------------------------
  try {
    const staleAttemptId = "wa_attempt_old_superseded_999";
    const currentAttemptId = whatsAppService.state.connectionAttemptId;
    const staleQr = "2@STALE_ATTEMPT_IGNORED_9999999999999999999999999999999999999999999999=";

    const seqBefore = whatsAppService.state.qrSequence;
    await whatsAppService.handleConnectionUpdate({ qr: staleQr }, staleAttemptId);

    const stateAfterStale = whatsAppService.getState();
    assert.equal(stateAfterStale.qrSequence, seqBefore);
    assert.notEqual(stateAfterStale.rawQr, staleQr);
    assert.equal(stateAfterStale.connectionAttemptId, currentAttemptId);

    record(
      "TEST-06",
      "Stale QR & Superseded Event Rejection",
      true,
      `Event from outdated attempt ${staleAttemptId} was safely ignored without polluting active state`
    );
  } catch (err: any) {
    record("TEST-06", "Stale QR & Superseded Event Rejection", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 7: Successful Connection-State Transitions
  // Verify transition from QR_READY to AUTHENTICATING and CONNECTED
  // and ensure QR is cleared immediately upon authentication
  // -------------------------------------------------------------------------
  try {
    const attemptId = whatsAppService.state.connectionAttemptId;
    // Simulate connection = 'open' event
    await whatsAppService.handleConnectionUpdate({ connection: "open" }, attemptId);

    const connState = whatsAppService.getState();
    assert.equal(connState.connectionState, "CONNECTED");
    assert.equal(connState.status, "connected");
    assert.equal(connState.qrCodeDataUrl, null, "QR data URL must be cleared upon connection");
    assert.equal(connState.rawQr, null, "Raw QR must be cleared upon connection");
    assert.ok(connState.phoneNumber, "Phone number must be set upon connection");

    record(
      "TEST-07",
      "Successful Connection-State Transitions & QR Clearance",
      true,
      `State: ${connState.connectionState}, Status: ${connState.status}, Phone: ${connState.phoneNumber}, QR cleared: true`
    );
  } catch (err: any) {
    record("TEST-07", "Successful Connection-State Transitions & QR Clearance", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 8: Disconnect & Reconnect Behavior
  // Verify handling of restartRequired (code 515) and loggedOut (code 401)
  // -------------------------------------------------------------------------
  try {
    const attemptId = whatsAppService.state.connectionAttemptId;

    // Simulate restartRequired (515) during pairing handshake
    await whatsAppService.handleConnectionUpdate(
      { connection: "close", lastDisconnect: { error: { statusCode: 515 } } as any },
      attemptId
    );
    assert.equal(whatsAppService.state.connectionState, "AUTHENTICATING");
    assert.equal(whatsAppService.state.qrCodeDataUrl, null);

    // Simulate loggedOut (401)
    await whatsAppService.handleConnectionUpdate(
      { connection: "close", lastDisconnect: { error: { statusCode: 401 } } as any },
      attemptId
    );
    assert.equal(whatsAppService.state.connectionState, "DISCONNECTED");
    assert.equal(whatsAppService.state.status, "disconnected");
    assert.equal(whatsAppService.state.qrCodeDataUrl, null);

    record(
      "TEST-08",
      "Disconnect & Reconnect Lifecycle Behavior",
      true,
      `Code 515 triggered AUTHENTICATING, Code 401 triggered clean DISCONNECTED with wiped QR`
    );
  } catch (err: any) {
    record("TEST-08", "Disconnect & Reconnect Lifecycle Behavior", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 9: Concurrent Connection Requests Single-Flight Lock
  // Verify multiple simultaneous calls join the same in-flight session and return identical attempt IDs
  // -------------------------------------------------------------------------
  try {
    await whatsAppService.logout();

    const [res1, res2, res3] = await Promise.all([
      whatsAppService.startSession(false),
      whatsAppService.startSession(false),
      whatsAppService.startSession(false),
    ]);

    assert.equal(res1.connectionAttemptId, res2.connectionAttemptId);
    assert.equal(res2.connectionAttemptId, res3.connectionAttemptId);

    record(
      "TEST-09",
      "Concurrent Connection Requests Lock",
      true,
      `All 3 parallel startSession requests joined the single-flight promise. Unified attemptId: ${res1.connectionAttemptId}`
    );
  } catch (err: any) {
    record("TEST-09", "Concurrent Connection Requests Lock", false, err.message);
  }

  // -------------------------------------------------------------------------
  // TEST 10: Session Persistence & Restoration Across Container Restarts
  // Verify PostgreSQL syncAuthToDatabase and restoreAuthFromDatabase
  // -------------------------------------------------------------------------
  try {
    const authDir = path.join(process.cwd(), "data", "whatsapp_auth");
    if (!fs.existsSync(authDir)) fs.mkdirSync(authDir, { recursive: true });

    // Seed dummy creds file to test DB persistence
    const testCreds = {
      me: { id: "96891234567:1@s.whatsapp.net", name: "مكتب سند للخدمات الذكية" },
      account: { details: "verified_test_session" },
    };
    fs.writeFileSync(path.join(authDir, "creds.json"), JSON.stringify(testCreds), "utf-8");

    // Sync to PostgreSQL
    const synced = await whatsAppService.syncAuthToDatabase();
    assert.equal(synced, true);

    // Verify row exists in DB
    const rows = await db
      .select()
      .from(whatsappAuthSessions)
      .where(
        and(
          eq(whatsappAuthSessions.tenantId, "default_tenant"),
          eq(whatsappAuthSessions.instanceId, "inst-main")
        )
      )
      .limit(1);
    assert.ok(rows.length > 0);
    assert.equal(rows[0].instanceId, "inst-main");

    // Wipe local creds file to simulate container restart / ephemeral disk wipe
    fs.unlinkSync(path.join(authDir, "creds.json"));
    assert.equal(fs.existsSync(path.join(authDir, "creds.json")), false);

    // Restore from PostgreSQL
    const restored = await whatsAppService.restoreAuthFromDatabase();
    assert.equal(restored, true);
    assert.equal(fs.existsSync(path.join(authDir, "creds.json")), true);

    const restoredContent = JSON.parse(fs.readFileSync(path.join(authDir, "creds.json"), "utf-8"));
    assert.equal(restoredContent.me.name, "مكتب سند للخدمات الذكية");

    record(
      "TEST-10",
      "Session Persistence & Database Restoration Across Restarts",
      true,
      `Auth credentials persisted to PostgreSQL and successfully restored after simulating disk wipe`
    );

    // Clean up test credentials so server returns to clean unauthenticated pairing state
    await whatsAppService.clearAuthFiles();
  } catch (err: any) {
    record("TEST-10", "Session Persistence & Database Restoration Across Restarts", false, err.message);
    await whatsAppService.clearAuthFiles().catch(() => {});
  }

  // -------------------------------------------------------------------------
  // SUMMARY
  // -------------------------------------------------------------------------
  const total = testResults.length;
  const passed = testResults.filter((r) => r.passed).length;
  console.log("\n=======================================================");
  console.log(`📋 AUDIT SUMMARY: ${passed}/${total} TESTS PASSED`);
  console.log("=======================================================\n");

  if (passed !== total) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runVerification().catch((err) => {
  console.error("FATAL ERROR running verification suite:", err);
  process.exit(1);
});
