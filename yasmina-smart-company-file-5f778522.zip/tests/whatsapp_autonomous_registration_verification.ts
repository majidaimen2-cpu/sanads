import assert from "node:assert/strict";
import fs from "node:fs";
import crypto from "node:crypto";
import { and, eq, isNull } from "drizzle-orm";
import { db, pool, runMigrations, closePool } from "../src/db/index.js";
import {
  companies,
  customers,
  customerDocuments,
  whatsappMessages,
  whatsappProcessingJobs,
  whatsappOutbox,
  auditLogs,
  tenantSettings,
} from "../src/db/schema.js";
import { normalizeCrNumber } from "../src/server/services/crExtractionService.js";
import {
  processIncomingWhatsAppMediaMessage,
  recoverInterruptedWhatsAppJobs,
  classifyDocumentByContent,
} from "../src/server/services/whatsappDocumentProcessor.js";
import {
  validateDocumentBuffer,
  readStoredDocumentBuffer,
  resolveVaultPath,
} from "../src/server/services/documentStorageService.js";

const TEST_TENANT = "test_tenant_wa_autonomous";

/**
 * Helper to build a valid PDF buffer containing embedded UTF-8 Arabic/English text.
 */
function buildSyntheticPdfBuffer(contentLines: string[], extraSalt = ""): Buffer {
  const bodyText = contentLines.join("\n");
  const pdfContent = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /Resources << >> /MediaBox [0 0 595 842] /Contents 4 0 R >>
endobj
4 0 obj
<< /Length ${Buffer.byteLength(bodyText, "utf8") + 40} >>
stream
BT
(${bodyText.replace(/[()\\]/g, " ")}) Tj
ET
${extraSalt}
endstream
endobj
xref
0 5
0000000000 65535 f 
trailer
<< /Size 5 /Root 1 0 R >>
startxref
250
%%EOF`;
  return Buffer.from(pdfContent, "utf8");
}

/**
 * Helper to build a valid PNG image buffer with embedded UTF-8 text chunk for deterministic OCR/text extraction.
 */
function buildSyntheticPngBuffer(contentLines: string[]): Buffer {
  const pngHeader = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const textPayload = Buffer.from("\n" + contentLines.join("\n") + "\n", "utf8");
  return Buffer.concat([pngHeader, Buffer.alloc(16, 0), textPayload]);
}

async function cleanupTestTenantData() {
  await db.delete(whatsappOutbox).where(eq(whatsappOutbox.tenantId, TEST_TENANT));
  await db.delete(whatsappProcessingJobs).where(eq(whatsappProcessingJobs.tenantId, TEST_TENANT));
  await db.delete(whatsappMessages).where(eq(whatsappMessages.tenantId, TEST_TENANT));
  await db.delete(customerDocuments).where(eq(customerDocuments.tenantId, TEST_TENANT));
  await db.delete(companies).where(eq(companies.tenantId, TEST_TENANT));
  await db.delete(customers).where(eq(customers.tenantId, TEST_TENANT));
}

interface TestResult {
  id: number;
  name: string;
  category: "COMPANY_IDENTIFICATION" | "DOCUMENT_CLASSIFICATION" | "INFRASTRUCTURE_SECURITY";
  passed: boolean;
  details: string;
}

const results: TestResult[] = [];

async function runTest(
  id: number,
  category: TestResult["category"],
  name: string,
  fn: () => Promise<string>
) {
  try {
    const details = await fn();
    results.push({ id, name, category, passed: true, details });
    console.log(`✅ [TEST ${String(id).padStart(2, "0")}] PASS — ${name}: ${details}`);
  } catch (err: any) {
    const msg = err?.stack || err?.message || String(err);
    results.push({ id, name, category, passed: false, details: msg });
    console.error(`❌ [TEST ${String(id).padStart(2, "0")}] FAIL — ${name}: ${err?.message || err}`);
    throw err;
  }
}

async function main() {
  console.log("================================================================================");
  console.log("🚀 STARTING 30 MANDATORY WHATSAPP AUTONOMOUS REGISTRATION & DEDUPLICATION TESTS");
  console.log("================================================================================");

  await runMigrations();
  await cleanupTestTenantData();

  try {
    // =========================================================================
    // PART 1: COMPANY IDENTIFICATION & DEDUPLICATION TESTS (1–10)
    // =========================================================================

    let company1Id = 0;
    let doc1Id = 0;
    const cr1Pdf = buildSyntheticPdfBuffer([
      "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
      "شهادة السجل التجاري",
      "رقم السجل التجاري: 7100100",
      "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
      "الاسم التجاري: النهضة اللوجستية",
      "الشكل القانوني: شركة محدودة المسؤولية",
      "تاريخ الإصدار: 2024-01-15",
      "تاريخ الانتهاء: 2027-01-15",
      "رأس المال: 50000 ر.ع",
    ]);

    // Test 1 — New Company CR
    await runTest(1, "COMPANY_IDENTIFICATION", "New Company CR creates 1 company, 1 doc, 1 reply", async () => {
      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_01",
        senderPhone: "+96891112222",
        senderName: "أحمد الرواحي",
        fileName: "cr_7100100.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: cr1Pdf,
      });

      assert.equal(res.ok, true);
      assert.equal(res.state, "COMPLETED");
      assert.equal(res.isNewCompany, true);
      assert.equal(res.companyResolution, "CREATED_NEW_COMPANY");
      assert.equal(res.normalizedCrNumber, "7100100");
      assert.ok(res.companyId, "Expected companyId to be returned");
      assert.ok(res.savedDocumentId, "Expected savedDocumentId to be returned");
      assert.ok(res.replyMessageText.includes("تم استلام السجل التجاري وتسجيل الشركة بنجاح."));

      company1Id = res.companyId!;
      doc1Id = res.savedDocumentId!;

      const dbCompanies = await db
        .select()
        .from(companies)
        .where(and(eq(companies.tenantId, TEST_TENANT), eq(companies.normalizedCrNumber, "7100100")));
      assert.equal(dbCompanies.length, 1, "Must create exactly 1 company row");

      const stored = readStoredDocumentBuffer(
        (await db.select().from(customerDocuments).where(eq(customerDocuments.id, doc1Id)))[0].storageObjectKey,
        null
      );
      assert.ok(stored && stored.buffer.length === cr1Pdf.length, "Stored binary must match original PDF");

      return `Created companyId=${company1Id}, docId=${doc1Id}, CR=7100100`;
    });

    // Test 2 — Existing Company CR
    await runTest(2, "COMPANY_IDENTIFICATION", "Existing Company CR reuses existing company and never duplicates", async () => {
      const cr1SecondPagePdf = buildSyntheticPdfBuffer(
        [
          "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
          "شهادة السجل التجاري",
          "رقم السجل التجاري: 7100100",
          "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
          "تاريخ الإصدار: 2024-01-15",
          "تاريخ الانتهاء: 2027-01-15",
        ],
        "second-submission-different-bytes"
      );

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_02",
        senderPhone: "+96891112222",
        fileName: "cr_7100100_copy.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: cr1SecondPagePdf,
      });

      assert.equal(res.ok, true);
      assert.equal(res.isNewCompany, false);
      assert.equal(res.companyId, company1Id, "Must reuse existing companyId");
      assert.equal(res.companyResolution, "MATCHED_EXISTING_COMPANY");

      const dbCompanies = await db
        .select()
        .from(companies)
        .where(and(eq(companies.tenantId, TEST_TENANT), eq(companies.normalizedCrNumber, "7100100")));
      assert.equal(dbCompanies.length, 1, "Still exactly 1 company row in DB");

      return `Reused companyId=${res.companyId}, total companies for CR 7100100 = ${dbCompanies.length}`;
    });

    // Test 3 — Formatting Variations of CR Number
    await runTest(3, "COMPANY_IDENTIFICATION", "Formatting variations of CR number normalize to identical value", async () => {
      const variants = [
        "7100100",
        "CR-7100100",
        "C.R. No: 7100100",
        "710-010-0",
        "٧١٠٠١٠٠",
        "7100100 / 01",
        "س.ت: ٧١٠٠١٠٠",
      ];
      for (const v of variants) {
        const norm = normalizeCrNumber(v);
        assert.equal(norm, "7100100", `Variant "${v}" normalized to "${norm}" instead of "7100100"`);
      }

      const arabicDigitCrPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: CR - ٧١٠٠١٠٠ / 01",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "تاريخ الانتهاء: 2027-01-15",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_03",
        senderPhone: "+96891112222",
        fileName: "cr_arabic_digits.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: arabicDigitCrPdf,
      });

      assert.equal(res.companyId, company1Id, "Formatted Arabic CR must match company1Id");
      return `All ${variants.length} CR formatting variants matched companyId=${company1Id}`;
    });

    // Test 4 — Same CR from Different WhatsApp Number
    await runTest(4, "COMPANY_IDENTIFICATION", "Same CR from different WhatsApp phone matches existing company and flags senderAuthorized=false", async () => {
      const thirdPartyCrPdf = buildSyntheticPdfBuffer(
        [
          "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
          "شهادة السجل التجاري",
          "رقم السجل التجاري: 7100100",
          "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
          "تاريخ الانتهاء: 2027-01-15",
        ],
        "from-different-phone-number"
      );

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_04",
        senderPhone: "+96899998888", // Different phone number!
        senderName: "مندوب خارجي",
        fileName: "cr_from_other_phone.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: thirdPartyCrPdf,
      });

      assert.equal(res.companyId, company1Id, "Must reuse existing companyId");
      assert.equal(res.isNewCompany, false);
      assert.equal(res.senderAuthorized, false, "Different phone must be marked senderAuthorized=false");

      const [compAfter] = await db.select().from(companies).where(eq(companies.id, company1Id));
      assert.equal(compAfter.contactPhone, "96891112222", "Official contactPhone must not be overwritten by unauthorized sender");

      return `Matched companyId=${company1Id}, senderAuthorized=${res.senderAuthorized}, officialPhone=${compAfter.contactPhone}`;
    });

    // Test 5 — Identical CR File Sent Twice (SHA-256 Deduplication)
    await runTest(5, "COMPANY_IDENTIFICATION", "Identical CR file sent again (same SHA-256) skips duplicate document creation", async () => {
      const docsBefore = await db
        .select()
        .from(customerDocuments)
        .where(and(eq(customerDocuments.tenantId, TEST_TENANT), eq(customerDocuments.companyId, company1Id)));

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_05", // New message ID, identical file bytes (cr1Pdf)
        senderPhone: "+96891112222",
        fileName: "cr_7100100_resend.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: cr1Pdf,
      });

      const docsAfter = await db
        .select()
        .from(customerDocuments)
        .where(and(eq(customerDocuments.tenantId, TEST_TENANT), eq(customerDocuments.companyId, company1Id)));

      assert.equal(res.companyId, company1Id);
      assert.equal(res.isDuplicateFile, true);
      assert.equal(res.companyResolution, "DUPLICATE_FILE_SKIPPED");
      assert.equal(docsAfter.length, docsBefore.length, "Must NOT insert a duplicate customer_documents row");
      assert.ok(res.replyMessageText.includes("تم استلام هذه الوثيقة مسبقاً وهي محفوظة بالفعل في ملف الشركة"));

      return `Duplicate SHA-256 detected; document count remained ${docsAfter.length}`;
    });

    // Test 6 — Renewed CR Document for Existing Company
    await runTest(6, "COMPANY_IDENTIFICATION", "Renewed CR document increments versionNumber, preserves history, and updates expiryDate", async () => {
      const renewedCrPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "تاريخ الإصدار: 2026-01-15",
        "تاريخ الانتهاء: 2029-01-15",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_06",
        senderPhone: "+96891112222",
        fileName: "cr_7100100_renewed_2029.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: renewedCrPdf,
      });

      assert.equal(res.companyId, company1Id);
      assert.ok((res.versionNumber || 0) > 1, "Expected versionNumber > 1");

      const [compAfter] = await db.select().from(companies).where(eq(companies.id, company1Id));
      assert.equal(compAfter.crExpiryDate, "2029-01-15", "Company crExpiryDate must update to renewed date");

      const [newDocRow] = await db
        .select()
        .from(customerDocuments)
        .where(eq(customerDocuments.id, res.savedDocumentId!));
      assert.ok(newDocRow.previousVersionId, "New version must reference previousVersionId");

      return `Saved versionNumber=${res.versionNumber}, previousVersionId=${newDocRow.previousVersionId}, newExpiry=${compAfter.crExpiryDate}`;
    });

    // Test 7 — Similar Company Names with Different CR Numbers (Case F)
    await runTest(7, "COMPANY_IDENTIFICATION", "Similar company names with different CR numbers remain separate companies", async () => {
      const simPdfA = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7200111",
        "اسم الشركة: شركة الخليج المتحد للتجارة والمقاولات ش.م.م",
        "تاريخ الانتهاء: 2028-05-01",
      ]);
      const simPdfB = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7200222",
        "اسم الشركة: شركة الخليج المتحد للتجارة والمقاولات ش.م.م",
        "تاريخ الانتهاء: 2028-05-01",
      ]);

      const resA = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_07_a",
        senderPhone: "+96892221111",
        fileName: "gulf_7200111.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: simPdfA,
      });
      const resB = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_07_b",
        senderPhone: "+96892221111",
        fileName: "gulf_7200222.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: simPdfB,
      });

      assert.notEqual(resA.companyId, resB.companyId, "Different CR numbers must NEVER be merged into one company");
      assert.equal(resA.isNewCompany, true);
      assert.equal(resB.isNewCompany, true);

      return `Distinct CRs (7200111 -> id=${resA.companyId}, 7200222 -> id=${resB.companyId}) kept separate`;
    });

    // Test 8 — Existing CR with Different Company Name (Case G)
    await runTest(8, "COMPANY_IDENTIFICATION", "Existing CR with different company name reuses company, preserves official name, and sets nameDiscrepancyFlag", async () => {
      const mismatchedNamePdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: مؤسسة مسقط الذهبية للاستيراد والتصدير",
        "تاريخ الانتهاء: 2028-09-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_08",
        senderPhone: "+96891112222",
        fileName: "cr_7100100_different_name.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: mismatchedNamePdf,
      });

      assert.equal(res.companyId, company1Id, "Must reuse company1Id");
      assert.equal(res.isNewCompany, false);
      assert.equal(res.nameDiscrepancyFlag, true, "Must set nameDiscrepancyFlag=true");

      const [compAfter] = await db.select().from(companies).where(eq(companies.id, company1Id));
      assert.equal(
        compAfter.name,
        "شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "Official company name must be preserved until discrepancy is resolved"
      );
      assert.equal(compAfter.nameDiscrepancyFlag, true);
      assert.ok(compAfter.nameDiscrepancyDetails?.includes("مؤسسة مسقط الذهبية"));

      return `Preserved official name "${compAfter.name}", flagged discrepancy`;
    });

    // Test 9 — Missing or Unreadable CR Number (Case E)
    await runTest(9, "COMPANY_IDENTIFICATION", "Missing or unreadable CR number never creates a company and routes to NEEDS_REVIEW", async () => {
      const blurryPdf = buildSyntheticPdfBuffer([
        "وثيقة غير واضحة المعالم",
        "اسم الشركة: شركة غير مكتملة البيانات",
        "ملاحظة: رقم السجل التجاري غير مقروء بالماسح الضوئي",
      ]);

      const companiesCountBefore = (
        await db.select().from(companies).where(eq(companies.tenantId, TEST_TENANT))
      ).length;

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_09",
        senderPhone: "+96893334444",
        fileName: "unreadable_cr.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: blurryPdf,
      });

      const companiesCountAfter = (
        await db.select().from(companies).where(eq(companies.tenantId, TEST_TENANT))
      ).length;

      assert.equal(res.state, "NEEDS_REVIEW");
      assert.equal(res.companyId, null, "Must not create a company");
      assert.equal(companiesCountAfter, companiesCountBefore, "Total companies must not increase");
      assert.ok(res.savedDocumentId, "Original file must still be preserved for human review");
      assert.ok(res.replyMessageText.includes("تم تحويل الوثيقة للمراجعة اليدوية"));

      return `Routed to state=${res.state}, savedDocumentId=${res.savedDocumentId}, companiesCreated=0`;
    });

    // Test 10 — Simultaneous Duplicate CR Submissions (Case H Concurrency)
    await runTest(10, "COMPANY_IDENTIFICATION", "Simultaneous messages with same new CR number create only ONE company", async () => {
      const concurrentPdf1 = buildSyntheticPdfBuffer(
        [
          "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
          "شهادة السجل التجاري",
          "رقم السجل التجاري: 7555999",
          "اسم الشركة: شركة صحار للطاقة المتجددة ش.م.م",
          "تاريخ الانتهاء: 2028-12-31",
        ],
        "worker-1-payload"
      );
      const concurrentPdf2 = buildSyntheticPdfBuffer(
        [
          "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
          "شهادة السجل التجاري",
          "رقم السجل التجاري: CR-7555999",
          "اسم الشركة: شركة صحار للطاقة المتجددة ش.م.م",
          "تاريخ الانتهاء: 2028-12-31",
        ],
        "worker-2-payload"
      );

      const [res1, res2] = await Promise.all([
        processIncomingWhatsAppMediaMessage({
          tenantId: TEST_TENANT,
          providerMessageId: "msg_test_10_w1",
          senderPhone: "+96894445555",
          fileName: "sohar_w1.pdf",
          declaredMimeType: "application/pdf",
          mediaBuffer: concurrentPdf1,
        }),
        processIncomingWhatsAppMediaMessage({
          tenantId: TEST_TENANT,
          providerMessageId: "msg_test_10_w2",
          senderPhone: "+96894445555",
          fileName: "sohar_w2.pdf",
          declaredMimeType: "application/pdf",
          mediaBuffer: concurrentPdf2,
        }),
      ]);

      assert.equal(res1.ok, true);
      assert.equal(res2.ok, true);
      assert.equal(res1.companyId, res2.companyId, "Both concurrent workers must resolve to the exact same companyId");

      const rows = await db
        .select()
        .from(companies)
        .where(and(eq(companies.tenantId, TEST_TENANT), eq(companies.normalizedCrNumber, "7555999")));
      assert.equal(rows.length, 1, "Database must contain strictly 1 company for CR 7555999");

      return `Concurrent workers resolved to single companyId=${res1.companyId} (DB count=${rows.length})`;
    });

    // =========================================================================
    // PART 2: DOCUMENT CLASSIFICATION & ROUTING TESTS (11–20)
    // =========================================================================

    // Test 11 — PDF Commercial Registration
    await runTest(11, "DOCUMENT_CLASSIFICATION", "PDF Commercial Registration extracted, classified, and stored", async () => {
      const pdfCr = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "مستخرج السجل التجاري",
        "رقم السجل التجاري: 7600111",
        "اسم الشركة: شركة صلالة للشحن البحري ش.م.م",
        "الشكل القانوني: شركة محدودة المسؤولية",
        "تاريخ الإصدار: 2024-03-01",
        "تاريخ الانتهاء: 2027-03-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_11",
        senderPhone: "+96895551111",
        fileName: "salalah_shipping_cr.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: pdfCr,
      });

      assert.equal(res.documentType, "commercial_registry");
      assert.equal(res.normalizedCrNumber, "7600111");
      assert.equal(res.isNewCompany, true);
      return `Classified as ${res.documentType}, companyId=${res.companyId}`;
    });

    // Test 12 — Image Commercial Registration (JPG/PNG)
    await runTest(12, "DOCUMENT_CLASSIFICATION", "Image Commercial Registration (PNG) processed and matched", async () => {
      const pngCr = buildSyntheticPngBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7600222",
        "اسم الشركة: شركة نزوى للصناعات الغذائية ش.م.م",
        "تاريخ الانتهاء: 2028-04-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_12",
        senderPhone: "+96895552222",
        fileName: "nizwa_cr_scan.png",
        declaredMimeType: "image/png",
        mediaBuffer: pngCr,
      });

      assert.equal(res.documentType, "commercial_registry");
      assert.equal(res.normalizedCrNumber, "7600222");
      assert.equal(res.isNewCompany, true);
      return `PNG Image CR processed -> companyId=${res.companyId}, docId=${res.savedDocumentId}`;
    });

    // Test 13 — Municipal License
    await runTest(13, "DOCUMENT_CLASSIFICATION", "Municipal License attached to matching company without duplicating company", async () => {
      // Smart company file: auto-filing is OFF by default (documents go to the confirm inbox).
      // This legacy scenario (known sender + printed CR) validates the AUTO lane, so enable it for this tenant.
      await db
        .insert(tenantSettings)
        .values({ tenantId: TEST_TENANT, autoFileEnabled: true })
        .onConflictDoUpdate({ target: tenantSettings.tenantId, set: { autoFileEnabled: true } });
      const muniPdf = buildSyntheticPdfBuffer([
        "بلدية مسقط - سلطنة عمان",
        "ترخيص بلدي لمزاولة نشاط تجاري",
        "رقم الترخيص: MUN-2026-9981",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "تاريخ الإصدار: 2025-01-01",
        "تاريخ الانتهاء: 2027-01-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_13",
        senderPhone: "+96891112222",
        fileName: "municipal_license.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: muniPdf,
      });

      assert.equal(res.documentType, "municipal_license");
      assert.equal(res.companyId, company1Id);
      assert.equal(res.isNewCompany, false);
      assert.ok(res.replyMessageText.includes("الترخيص البلدي"));
      return `Classified as ${res.documentType}, attached to companyId=${res.companyId}`;
    });

    // Test 14 — Tax Certificate
    await runTest(14, "DOCUMENT_CLASSIFICATION", "Tax Certificate attached to matching company and classified as tax_certificate", async () => {
      const taxCertPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - جهاز الضرائب",
        "شهادة التسجيل في ضريبة القيمة المضافة - الشهادة الضريبية",
        "رقم الشهادة: VAT-OM-7100100",
        "رقم البطاقة الضريبية: 88001122",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "تاريخ الانتهاء: 2028-06-30",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_14",
        senderPhone: "+96891112222",
        fileName: "tax_certificate.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: taxCertPdf,
      });

      assert.equal(res.documentType, "tax_certificate");
      assert.equal(res.companyId, company1Id);
      assert.ok(res.replyMessageText.includes("الشهادة الضريبية"));
      return `Classified as ${res.documentType}, attached to companyId=${res.companyId}`;
    });

    // Test 15 — Chamber Certificate
    await runTest(15, "DOCUMENT_CLASSIFICATION", "Chamber of Commerce Certificate attached to matching company", async () => {
      const chamberPdf = buildSyntheticPdfBuffer([
        "غرفة تجارة وصناعة عمان",
        "شهادة انتساب الغرفة",
        "رقم انتساب الغرفة: OCC-554433",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "تاريخ الانتهاء: 2027-12-31",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_15",
        senderPhone: "+96891112222",
        fileName: "chamber_certificate.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: chamberPdf,
      });

      assert.equal(res.documentType, "chamber_certificate");
      assert.equal(res.companyId, company1Id);
      assert.ok(res.replyMessageText.includes("شهادة انتساب الغرفة"));
      return `Classified as ${res.documentType}, attached to companyId=${res.companyId}`;
    });

    // Test 16 — Labor Certificate
    await runTest(16, "DOCUMENT_CLASSIFICATION", "Labor License / Card attached to matching company", async () => {
      const laborPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة العمل",
        "ترخيص استقدام قوى عاملة غير عمانية - بطاقة عمل",
        "رقم الترخيص: LAB-2026-771",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "تاريخ الانتهاء: 2027-08-15",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_16",
        senderPhone: "+96891112222",
        fileName: "labor_license.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: laborPdf,
      });

      assert.equal(res.documentType, "labor_certificate");
      assert.equal(res.companyId, company1Id);
      return `Classified as ${res.documentType}, attached to companyId=${res.companyId}`;
    });

    // Test 17 — Employment / Omanization Certificate
    await runTest(17, "DOCUMENT_CLASSIFICATION", "Employment / Omanization Certificate distinguished from Labor License", async () => {
      const omanizationPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة العمل",
        "شهادة نسب التعمين - Omanization Certificate",
        "رقم الشهادة: OMZ-2026-309",
        "نسبة التعمين المحققة: 42%",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "تاريخ الانتهاء: 2027-05-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_17",
        senderPhone: "+96891112222",
        fileName: "omanization_certificate.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: omanizationPdf,
      });

      assert.equal(res.documentType, "employment_certificate");
      assert.notEqual(res.documentType, "labor_certificate");
      assert.equal(res.companyId, company1Id);
      return `Classified strictly as ${res.documentType}, attached to companyId=${res.companyId}`;
    });

    // Test 18 — Contract Document
    await runTest(18, "DOCUMENT_CLASSIFICATION", "Contract Document classified as contract and attached to company", async () => {
      const contractPdf = buildSyntheticPdfBuffer([
        "عقد إيجار محل تجاري موثق",
        "الطرف الأول: شركة العقارات الحديثة",
        "الطرف الثاني: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "رقم السجل التجاري: 7100100",
        "رقم العقد: CNT-2026-500",
        "تاريخ الإصدار: 2025-02-01",
        "تاريخ الانتهاء: 2028-02-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_18",
        senderPhone: "+96891112222",
        fileName: "lease_contract.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: contractPdf,
      });

      // Smart company file: a lease is now its own type (lease_contract) instead of the generic "contract".
      assert.equal(res.documentType, "lease_contract");
      assert.equal(res.companyId, company1Id);
      return `Classified as ${res.documentType}, attached to companyId=${res.companyId}`;
    });

    // Test 19 — Unclassified / Other Document
    await runTest(19, "DOCUMENT_CLASSIFICATION", "Unclassified document stored safely as 'other' without forcing wrong type", async () => {
      const otherPdf = buildSyntheticPdfBuffer([
        "مذكرة داخلية بشأن جدول تسليم البضائع في الميناء",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
      ]);

      // Note: Even if filename claims "tax_certificate.pdf", content classification must prevail!
      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_19",
        senderPhone: "+96891112222",
        fileName: "tax_certificate_misleading_name.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: otherPdf,
      });

      assert.equal(res.documentType, "other");
      assert.equal(res.companyId, company1Id);
      return `Classified by content as "${res.documentType}" despite misleading filename`;
    });

    // Test 20 — Tax Invoice vs Tax Certificate Distinction
    await runTest(20, "DOCUMENT_CLASSIFICATION", "Tax Invoice classified as tax_invoice and never misclassified as tax_certificate", async () => {
      const taxInvoicePdf = buildSyntheticPdfBuffer([
        "فاتورة ضريبية - Tax Invoice",
        "رقم الفاتورة: INV-2026-00412",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
        "المبلغ الإجمالي شامل الضريبة: 1,050.000 ر.ع",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_20",
        senderPhone: "+96891112222",
        fileName: "vat_document.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: taxInvoicePdf,
      });

      assert.equal(res.documentType, "tax_invoice");
      assert.notEqual(res.documentType, "tax_certificate");
      assert.equal(res.companyId, company1Id);
      return `Tax Invoice classified strictly as ${res.documentType}`;
    });

    // =========================================================================
    // PART 3: INFRASTRUCTURE & SECURITY TESTS (21–30)
    // =========================================================================

    // Test 21 — Duplicate Webhook Delivery
    await runTest(21, "INFRASTRUCTURE_SECURITY", "Duplicate webhook delivery with same providerMessageId is idempotent and sends only 1 reply", async () => {
      const replayRes = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_01", // Same providerMessageId as Test 1!
        senderPhone: "+96891112222",
        fileName: "cr_7100100.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: cr1Pdf,
      });

      assert.equal(replayRes.deduplicatedReplay, true);
      assert.equal(replayRes.companyId, company1Id);

      const outboxRows = await db
        .select()
        .from(whatsappOutbox)
        .where(
          and(
            eq(whatsappOutbox.tenantId, TEST_TENANT),
            eq(whatsappOutbox.providerMessageId, "msg_test_01")
          )
        );
      assert.equal(outboxRows.length, 1, "Must have strictly 1 outbox reply row for msg_test_01");

      return `Duplicate webhook deduplicated (deduplicatedReplay=true, outboxRows=${outboxRows.length})`;
    });

    // Test 22 — Corrupted File
    await runTest(22, "INFRASTRUCTURE_SECURITY", "Corrupted/truncated PDF rejected safely with Arabic error reply", async () => {
      const corruptedPdf = Buffer.from("%PDF-1.4\ncorrupted_truncated_bytes_without_eof", "utf8");

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_22",
        senderPhone: "+96896667777",
        fileName: "broken.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: corruptedPdf,
      });

      assert.equal(res.ok, false);
      assert.equal(res.state, "REJECTED");
      assert.equal(res.companyId, null);
      assert.ok(res.replyMessageText.includes("تعذر قراءة الملف المرسل"));

      return `Rejected with errorCode=${res.errorCode}, state=${res.state}`;
    });

    // Test 23 — Unsupported or Malicious Executable File
    await runTest(23, "INFRASTRUCTURE_SECURITY", "Executable/malicious file (.exe / MZ magic bytes) blocked immediately", async () => {
      const exeBuffer = Buffer.from("MZ\x90\x00\x03\x00\x00\x00\x04\x00\x00\x00\xFF\xFF", "binary");

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_23",
        senderPhone: "+96896667777",
        fileName: "invoice.exe",
        declaredMimeType: "application/octet-stream",
        mediaBuffer: exeBuffer,
      });

      assert.equal(res.ok, false);
      assert.equal(res.state, "REJECTED");
      assert.equal(res.companyId, null);

      return `Malicious file blocked with errorCode=${res.errorCode}`;
    });

    // Test 24 — Filename Path Traversal Attempt
    await runTest(24, "INFRASTRUCTURE_SECURITY", "Filename path traversal (../../etc/passwd.pdf) neutralized and stored safely inside Vault", async () => {
      const traversalPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7100100",
        "اسم الشركة: شركة النهضة العمانية للخدمات اللوجستية ش.م.م",
      ], "path-traversal-test-salt");

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_24",
        senderPhone: "+96891112222",
        fileName: "../../../../etc/passwd.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: traversalPdf,
      });

      assert.equal(res.ok, true);
      const [docRow] = await db
        .select()
        .from(customerDocuments)
        .where(eq(customerDocuments.id, res.savedDocumentId!));

      assert.ok(!docRow.storageObjectKey?.includes(".."), "storageObjectKey must never contain '..'");
      assert.ok(!docRow.originalFileName?.includes("/"), "originalFileName must have slashes stripped");
      const resolvedPath = resolveVaultPath(docRow.storageObjectKey!);
      assert.ok(fs.existsSync(resolvedPath), "File exists inside safe vault directory");

      return `Sanitized originalFileName="${docRow.originalFileName}", storageKey="${docRow.storageObjectKey}"`;
    });

    // Test 25 — Invalid Chronological Dates
    await runTest(25, "INFRASTRUCTURE_SECURITY", "Expiry date earlier than issue date is flagged for review and not accepted as valid date", async () => {
      const invertedDatesPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7700555",
        "اسم الشركة: شركة البريمي للتجارة ش.م.م",
        "تاريخ الإصدار: 2026-08-01",
        "تاريخ الانتهاء: 2024-01-01", // Earlier than issueDate!
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_25",
        senderPhone: "+96897778888",
        fileName: "inverted_dates_cr.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: invertedDatesPdf,
      });

      assert.equal(res.state, "NEEDS_REVIEW", "Chronological date error must set job state to NEEDS_REVIEW");
      const [docRow] = await db
        .select()
        .from(customerDocuments)
        .where(eq(customerDocuments.id, res.savedDocumentId!));
      assert.equal(docRow.needsReview, true, "Document needsReview must be true");

      return `Flagged chronological date error -> state=${res.state}, doc.needsReview=${docRow.needsReview}`;
    });

    // Test 26 — Expired Document
    await runTest(26, "INFRASTRUCTURE_SECURITY", "Expired CR document marks company status as Expired and document expiryStatus as EXPIRED", async () => {
      const expiredPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7800666",
        "اسم الشركة: شركة صور للملاحة ش.م.م",
        "تاريخ الإصدار: 2019-01-01",
        "تاريخ الانتهاء: 2022-01-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_26",
        senderPhone: "+96898889999",
        fileName: "expired_cr.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: expiredPdf,
      });

      const [compRow] = await db.select().from(companies).where(eq(companies.id, res.companyId!));
      const [docRow] = await db
        .select()
        .from(customerDocuments)
        .where(eq(customerDocuments.id, res.savedDocumentId!));

      assert.equal(compRow.status, "Expired");
      assert.equal(docRow.expiryStatus, "EXPIRED");

      return `Company status="${compRow.status}", document expiryStatus="${docRow.expiryStatus}"`;
    });

    // Test 27 — Storage / Media Download Failure Simulation
    await runTest(27, "INFRASTRUCTURE_SECURITY", "Media download/storage failure transitions job to RETRY_PENDING and sends NO false success message", async () => {
      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_27",
        senderPhone: "+96891112222",
        fileName: "network_fail.pdf",
        declaredMimeType: "application/pdf",
        mediaDownloadFn: async () => {
          throw new Error("Simulated network timeout during media download");
        },
      });

      assert.equal(res.ok, false);
      assert.equal(res.state, "RETRY_PENDING");
      assert.equal(res.outboxId, null, "Must NOT queue any success reply on storage/download failure");

      const outboxRows = await db
        .select()
        .from(whatsappOutbox)
        .where(
          and(
            eq(whatsappOutbox.tenantId, TEST_TENANT),
            eq(whatsappOutbox.providerMessageId, "msg_test_27")
          )
        );
      assert.equal(outboxRows.length, 0, "Zero outbox messages for failed download");

      return `Transitioned to state=${res.state}, outboxRows=${outboxRows.length}`;
    });

    // Test 28 — Database Rollback & Unique Constraint Enforcement Test
    await runTest(28, "INFRASTRUCTURE_SECURITY", "PostgreSQL unique index uq_companies_tenant_normalized_cr blocks direct duplicate insert and rolls back cleanly", async () => {
      let constraintTriggered = false;
      try {
        await db.transaction(async (tx) => {
          await tx.insert(companies).values({
            tenantId: TEST_TENANT,
            companyCode: `CR-7100100-DUP-ATTEMPT`,
            name: "شركة مكررة غير مسموح بها",
            taxId: "7100100",
            normalizedCrNumber: "7100100", // Already exists in TEST_TENANT!
          });
        });
      } catch (err: any) {
        constraintTriggered = true;
      }

      assert.equal(
        constraintTriggered,
        true,
        "PostgreSQL unique index uq_companies_tenant_normalized_cr must reject duplicate normalized_cr_number"
      );

      const dbCompanies = await db
        .select()
        .from(companies)
        .where(and(eq(companies.tenantId, TEST_TENANT), eq(companies.normalizedCrNumber, "7100100")));
      assert.equal(dbCompanies.length, 1, "Still strictly 1 company after rollback");

      return `Database unique constraint uq_companies_tenant_normalized_cr enforced; duplicate insert rolled back`;
    });

    // Test 29 — Worker Crash Recovery
    await runTest(29, "INFRASTRUCTURE_SECURITY", "Interrupted job with stale lock recovers to RETRY_PENDING and completes cleanly without duplication", async () => {
      const crashPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7900777",
        "اسم الشركة: شركة عبري للخدمات الهندسية ش.م.م",
        "تاريخ الانتهاء: 2028-10-10",
      ]);

      // Simulate a worker that crashed mid-EXTRACTION 5 minutes ago
      const staleTime = new Date(Date.now() - 5 * 60_000);
      await db.insert(whatsappProcessingJobs).values({
        jobId: "wajob_crash_sim_29",
        correlationId: "corr_crash_sim_29",
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_29",
        senderPhone: "96890001111",
        state: "EXTRACTING",
        lockedByWorker: "worker_crashed_999",
        lockedAt: staleTime,
      });

      const recovery = await recoverInterruptedWhatsAppJobs(TEST_TENANT);
      assert.ok(
        recovery.recoveredIds.includes("wajob_crash_sim_29"),
        "Stale job must be recovered by recoverInterruptedWhatsAppJobs"
      );

      // Now retry processing the recovered job
      const retryRes = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_29",
        senderPhone: "+96890001111",
        fileName: "ibri_engineering_cr.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: crashPdf,
      });

      assert.equal(retryRes.ok, true);
      assert.equal(retryRes.state, "COMPLETED");
      assert.equal(retryRes.normalizedCrNumber, "7900777");

      return `Recovered stale job wajob_crash_sim_29 and completed registration (companyId=${retryRes.companyId})`;
    });

    // Test 30 — End-to-End Persistence Verification Across Pool Re-Read
    await runTest(30, "INFRASTRUCTURE_SECURITY", "All companies, document versions, vault files, jobs, and outbox replies persist in PostgreSQL and disk vault", async () => {
      const allTestCompanies = await db
        .select()
        .from(companies)
        .where(eq(companies.tenantId, TEST_TENANT));
      const allTestDocs = await db
        .select()
        .from(customerDocuments)
        .where(eq(customerDocuments.tenantId, TEST_TENANT));
      const allTestJobs = await db
        .select()
        .from(whatsappProcessingJobs)
        .where(eq(whatsappProcessingJobs.tenantId, TEST_TENANT));
      const allTestOutbox = await db
        .select()
        .from(whatsappOutbox)
        .where(eq(whatsappOutbox.tenantId, TEST_TENANT));

      assert.ok(allTestCompanies.length >= 6, `Expected >= 6 distinct test companies, found ${allTestCompanies.length}`);
      assert.ok(allTestDocs.length >= 15, `Expected >= 15 stored documents, found ${allTestDocs.length}`);
      assert.ok(allTestJobs.length >= 25, `Expected >= 25 tracked processing jobs, found ${allTestJobs.length}`);
      assert.ok(allTestOutbox.length >= 20, `Expected >= 20 outbox replies, found ${allTestOutbox.length}`);

      // Verify zero duplicate normalized_cr_number across the entire database (including production!)
      const dupQuery = await pool.query(`
        SELECT tenant_id, normalized_cr_number, COUNT(*)::int AS cnt
        FROM companies
        WHERE deleted_at IS NULL
          AND normalized_cr_number IS NOT NULL
          AND normalized_cr_number <> ''
        GROUP BY tenant_id, normalized_cr_number
        HAVING COUNT(*) > 1
      `);
      assert.equal(dupQuery.rows.length, 0, "Zero duplicate normalized CR numbers across all tenants");

      // Verify every stored test document exists on disk and matches its SHA-256 checksum
      for (const doc of allTestDocs) {
        assert.ok(doc.storageObjectKey, `Doc ${doc.id} missing storageObjectKey`);
        const readBack = readStoredDocumentBuffer(doc.storageObjectKey, null);
        assert.ok(readBack, `Doc ${doc.id} binary missing from vault`);
        const actualHash = crypto.createHash("sha256").update(readBack.buffer).digest("hex");
        assert.equal(actualHash, doc.sha256, `Doc ${doc.id} SHA-256 mismatch`);
      }

      return `Verified ${allTestCompanies.length} companies, ${allTestDocs.length} vault-verified docs, ${allTestJobs.length} jobs, ${allTestOutbox.length} outbox replies, 0 duplicate CRs`;
    });

    // Test 31 — License without CR number matched by Company Name & sent from unknown phone updates company fields directly
    await runTest(31, "DOCUMENT_CLASSIFICATION", "Municipal License without CR number matched by Company Name from any sender phone updates licenseNumber & licenseExpiryDate directly", async () => {
      const muniByNameOnlyPdf = buildSyntheticPdfBuffer([
        "بلدية مسقط - سلطنة عمان",
        "ترخيص بلدي",
        "رقم الترخيص: MUN-NAME-2026-777",
        "اسم المرخص له: النهضة العمانية للخدمات اللوجستية",
        "تاريخ الإصدار: 2026-01-01",
        "تاريخ انتهاء الترخيص: 2028-12-31",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_31_name_match",
        senderPhone: "+96897001234", // New/unregistered sender phone!
        fileName: "muni_by_name_only.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: muniByNameOnlyPdf,
      });

      // Smart company file: a name-only match is never auto-filed. The document waits in the confirm inbox
      // with the company as top candidate, and the company record is NOT modified until a human confirms.
      assert.equal(res.ok, true);
      assert.equal(res.documentType, "municipal_license");
      assert.equal(res.companyId ?? null, null, "Name-only match must not be filed automatically");
      assert.equal(res.matchLane, "CONFIRM");
      const [heldDoc] = await db.select().from(customerDocuments).where(eq(customerDocuments.id, res.savedDocumentId!));
      assert.equal(heldDoc.matchLane, "CONFIRM");
      assert.equal(heldDoc.companyId, null);
      const [untouched] = await db.select().from(companies).where(eq(companies.id, company1Id));
      assert.notEqual(untouched.licenseNumber, "MUN-NAME-2026-777", "Company must not be updated before confirmation");

      return `Name-only match held in confirm inbox (lane=${res.matchLane}), company untouched`;
    });

    // Test 32 — License without CR number and without company name matched by Sender Phone
    await runTest(32, "DOCUMENT_CLASSIFICATION", "Tax Certificate without CR or company name matched by registered Sender Phone updates taxCardNumber", async () => {
      const taxByPhoneOnlyPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - جهاز الضرائب",
        "شهادة التسجيل في ضريبة القيمة المضافة - الشهادة الضريبية",
        "رقم البطاقة الضريبية: TAX-PHONE-990011",
        "تاريخ الإصدار: 2026-02-01",
        "تاريخ الانتهاء: 2029-02-01",
      ]);

      const res = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_32_phone_match",
        senderPhone: "+96891112222", // Registered phone for company1Id
        fileName: "tax_by_phone_only.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: taxByPhoneOnlyPdf,
      });

      // Smart company file: a phone-only match is never auto-filed either. It goes to the confirm inbox.
      assert.equal(res.ok, true);
      assert.equal(res.documentType, "tax_certificate");
      assert.equal(res.companyId ?? null, null, "Phone-only match must not be filed automatically");
      assert.equal(res.matchLane, "CONFIRM");
      const [untouched] = await db.select().from(companies).where(eq(companies.id, company1Id));
      assert.notEqual(untouched.taxCardNumber, "TAX-PHONE-990011", "Company must not be updated before confirmation");

      return `Phone-only match held in confirm inbox (lane=${res.matchLane}), company untouched`;
    });

    // Test 33 — Unregistered Company License held in Review Queue, then Auto-Linked when CR arrives
    await runTest(33, "COMPANY_IDENTIFICATION", "Unregistered company licenses held in NEEDS_REVIEW and automatically linked & applied when CR is later registered", async () => {
      const pendingMuniPdf = buildSyntheticPdfBuffer([
        "بلدية مسقط - سلطنة عمان",
        "ترخيص بلدي",
        "رقم الترخيص: MUN-PENDING-2026-505",
        "رقم السجل التجاري: 7998877",
        "اسم الشركة: شركة مسقط للابتكار الرقمي ش.م.م",
        "تاريخ الإصدار: 2026-01-10",
        "تاريخ الانتهاء: 2028-01-10",
      ]);

      const pendingChamberPdf = buildSyntheticPdfBuffer([
        "غرفة تجارة وصناعة عمان",
        "شهادة انتساب الغرفة",
        "رقم انتساب الغرفة: OCCI-PENDING-808",
        "اسم العضو: مسقط للابتكار الرقمي",
        "تاريخ الإصدار: 2026-01-15",
        "تاريخ الانتهاء: 2028-01-15",
      ]);

      // Step 1: Send Municipal License & Chamber Certificate BEFORE the company is registered
      const muniRes = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_33_pending_muni",
        senderPhone: "+96896005555",
        fileName: "pending_muni_7998877.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: pendingMuniPdf,
      });

      const chamberRes = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_33_pending_chamber",
        senderPhone: "+96896005555",
        fileName: "pending_chamber.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: pendingChamberPdf,
      });

      assert.equal(muniRes.state, "NEEDS_REVIEW", "License for unregistered company must be held in NEEDS_REVIEW");
      assert.equal(muniRes.companyId, null, "Must not create a company from a license");
      assert.equal(chamberRes.state, "NEEDS_REVIEW");
      assert.equal(chamberRes.companyId, null);

      // Step 2: Now send the Commercial Registration for CR 7998877 ("شركة مسقط للابتكار الرقمي ش.م.م")
      const newCompanyCrPdf = buildSyntheticPdfBuffer([
        "سلطنة عمان - وزارة التجارة والصناعة وترويج الاستثمار",
        "شهادة السجل التجاري",
        "رقم السجل التجاري: 7998877",
        "اسم الشركة: شركة مسقط للابتكار الرقمي ش.م.م",
        "الشكل القانوني: شركة محدودة المسؤولية",
        "تاريخ الإصدار: 2026-01-01",
        "تاريخ الانتهاء: 2029-01-01",
      ]);

      const crRes = await processIncomingWhatsAppMediaMessage({
        tenantId: TEST_TENANT,
        providerMessageId: "msg_test_33_cr_arrival",
        senderPhone: "+96896009999",
        fileName: "cr_7998877.pdf",
        declaredMimeType: "application/pdf",
        mediaBuffer: newCompanyCrPdf,
      });

      assert.equal(crRes.ok, true);
      assert.equal(crRes.isNewCompany, true);
      assert.ok(crRes.companyId, "New company must be registered from CR");

      // Step 3: Verify that BOTH pending licenses were automatically linked to crRes.companyId and their fields applied!
      const [linkedMuniDoc] = await db
        .select()
        .from(customerDocuments)
        .where(eq(customerDocuments.id, muniRes.savedDocumentId!));
      const [linkedChamberDoc] = await db
        .select()
        .from(customerDocuments)
        .where(eq(customerDocuments.id, chamberRes.savedDocumentId!));

      assert.equal(linkedMuniDoc.companyId, crRes.companyId, "Pending Municipal License (matched by CR) must be auto-linked to the new company");
      assert.equal(linkedMuniDoc.processingStatus, "COMPLETED");
      assert.equal(linkedMuniDoc.needsReview, false);

      // Smart company file: a pending document that only matches by name is no longer linked silently.
      // It stays in the confirm inbox until a human confirms it.
      assert.equal(linkedChamberDoc.companyId, null, "Name-only pending Chamber Certificate must stay unlinked (confirm inbox)");

      const [newCompRow] = await db
        .select()
        .from(companies)
        .where(eq(companies.id, crRes.companyId!));
      assert.equal(newCompRow.licenseNumber, "MUN-PENDING-2026-505", "Company licenseNumber auto-populated from linked pending license");
      assert.equal(newCompRow.licenseExpiryDate, "2028-01-10", "Company licenseExpiryDate auto-populated from linked pending license");
      assert.notEqual(newCompRow.chamberNumber, "OCCI-PENDING-808", "Chamber number must not be applied before confirmation");

      return `Auto-linked pending docs [${muniRes.savedDocumentId}, ${chamberRes.savedDocumentId}] -> companyId=${crRes.companyId} (license=${newCompRow.licenseNumber}, chamber=${newCompRow.chamberNumber})`;
    });

    console.log("================================================================================");
    console.log(`🎉 ALL ${results.length}/33 MANDATORY TESTS PASSED (100% PASS RATE)`);
    console.log("================================================================================");
  } finally {
    await cleanupTestTenantData();
    await closePool();
  }
}

main().catch((err) => {
  console.error("Fatal verification error:", err);
  process.exit(1);
});
