<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/d9a5281d-2744-4ba0-ae1d-e141d8dc936b

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Notes on this version
- `npm ci` works; `npm test` runs every script in `tests/` (needs `DATABASE_URL` on a scratch database).
- `npx tsx tests/fixes_verification.ts` is an end-to-end HTTP check (start the server first; see the header of the file).
- Startup now stops (exit 1) if a migration fails or the database schema does not match `src/db/schema.ts`.
- The webhook needs `EVOLUTION_API_KEY` (or `WEBHOOK_TENANT_KEYS`); without one it returns 503.
- Refunds: `POST /api/invoices/:id/refund` (permission `payments:refund`, Manager/Accountant/Super admin).
