import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const distServer = path.resolve(__dirname, "dist/server.js");

if (process.env.NODE_ENV === "production" && fs.existsSync(distServer)) {
  await import("./dist/server.js");
} else {
  await import("./src/server/serverEntry.js");
}
