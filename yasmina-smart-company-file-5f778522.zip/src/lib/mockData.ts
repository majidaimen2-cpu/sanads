import {
  Company,
  WhatsAppInstance,
  WhatsAppChat,
  ChatMessage,
  CrewAgent,
  AgentTask,
  Employee,
  Contract,
  Transaction,
  Customer,
  ServiceItem,
  SystemAlert,
  UserUser,
  SystemMetrics
} from '../types';

export const INITIAL_COMPANIES: Company[] = [];

export const INITIAL_INSTANCES: WhatsAppInstance[] = [
  {
    id: 'inst-main',
    name: 'بوابة سند الرئيسية (WhatsApp Gateway)',
    phoneNumber: '+968 9123 4567',
    profileName: 'مكتب سند للخدمات الحكومية',
    status: 'connected',
  },
];

export const INITIAL_CHATS: WhatsAppChat[] = [
  {
    id: 'chat-1',
    name: 'سالم بن عبد الله البوسعيدي',
    phone: '+968 9123 4567',
    unreadCount: 0,
    lastMessage: 'تم استلام كشف الحساب وتجديد السجل التجاري بنجاح، شكراً لكم.',
    lastMessageTime: '10:15 AM',
  },
];

export const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  'chat-1': [
    {
      id: 'm-1',
      chatId: 'chat-1',
      senderName: 'سالم بن عبد الله البوسعيدي',
      senderNumber: '+968 9123 4567',
      fromMe: false,
      text: 'السلام عليكم ورحمة الله، أريد متابعة السجل التجاري لشركة الأفق.',
      timestamp: '10:10 AM',
      status: 'read',
    },
  ],
};

export const INITIAL_AGENTS: CrewAgent[] = [
  {
    id: 'ag-01',
    name: 'وكيل السجلات والتراخيص (CR Sentinel)',
    role: 'مدقق السجلات التجارية والتراخيص البلدية',
    goal: 'متابعة صلاحيات السجلات والاشتراكات والتنبيه قبل الانتهاء',
    backstory: 'وكيل ذكي مخصص لمنظومة استثمر بسهولة ومطابقة نسب التعمين بوزارة العمل.',
    status: 'idle',
  },
];

export const INITIAL_TASKS: AgentTask[] = [];

export const INITIAL_EMPLOYEES: Employee[] = [];
export const INITIAL_CONTRACTS: Contract[] = [];
export const INITIAL_TRANSACTIONS: Transaction[] = [];
export const INITIAL_CUSTOMERS: Customer[] = [];
export const INITIAL_SERVICES: ServiceItem[] = [];

export const INITIAL_ALERTS: SystemAlert[] = [];

export const INITIAL_USERS: UserUser[] = [
  {
    id: '2',
    username: 'admin',
    displayName: 'مدير النظام المعتمد',
    email: 'admin@yasminasanad.om',
    role: 'SUPER_ADMIN',
    active: true,
  },
];

export const INITIAL_METRICS: SystemMetrics = {
  totalCompanies: 0,
  totalTransactions: 0,
  totalRevenueOMR: 0,
  activeContracts: 0,
  systemUptime: '100%',
};
