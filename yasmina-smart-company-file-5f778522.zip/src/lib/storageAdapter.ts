const DB_NAME = 'yasmina_system_storage_v2';
const STORE_NAME = 'key_value_store';

class SafeIndexedDBStore {
  private dbPromise: Promise<IDBDatabase | null> | null = null;
  private idbDisabled = false;

  getDB(): Promise<IDBDatabase | null> {
    if (this.idbDisabled) return Promise.resolve(null);
    if (!this.dbPromise) {
      this.dbPromise = new Promise((resolve) => {
        try {
          if (typeof window === 'undefined' || !window.indexedDB) {
            this.idbDisabled = true;
            return resolve(null);
          }
          const req = window.indexedDB.open(DB_NAME, 1);
          req.onupgradeneeded = (ev: any) => {
            try {
              const db = ev.target?.result as IDBDatabase | undefined;
              if (db && !db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
              }
            } catch {}
          };
          req.onsuccess = () => {
            const db = req.result;
            if (!db || !db.objectStoreNames.contains(STORE_NAME)) {
              this.idbDisabled = true;
              return resolve(null);
            }
            db.onversionchange = () => {
              try {
                db.close();
              } catch {}
              this.dbPromise = null;
            };
            db.onclose = () => {
              this.dbPromise = null;
            };
            resolve(db);
          };
          req.onerror = () => {
            this.idbDisabled = true;
            this.dbPromise = null;
            resolve(null);
          };
          req.onblocked = () => {
            this.idbDisabled = true;
            this.dbPromise = null;
            resolve(null);
          };
        } catch {
          this.idbDisabled = true;
          this.dbPromise = null;
          resolve(null);
        }
      });
    }
    return this.dbPromise;
  }

  async get<T>(key: string): Promise<T | null> {
    try {
      const db = await this.getDB();
      if (!db) return null;
      return await new Promise<T | null>((resolve) => {
        try {
          const tx = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(key);
          tx.onsuccess = () => resolve((tx.result as T) ?? null);
          tx.onerror = () => resolve(null);
        } catch {
          this.dbPromise = null;
          resolve(null);
        }
      });
    } catch {
      return null;
    }
  }

  async set<T>(key: string, val: T): Promise<boolean> {
    try {
      const db = await this.getDB();
      if (!db) return false;
      return await new Promise<boolean>((resolve) => {
        try {
          const tx = db.transaction(STORE_NAME, 'readwrite').objectStore(STORE_NAME).put(val, key);
          tx.onsuccess = () => resolve(true);
          tx.onerror = () => resolve(false);
        } catch {
          this.dbPromise = null;
          resolve(false);
        }
      });
    } catch {
      return false;
    }
  }

  async remove(key: string): Promise<boolean> {
    try {
      const db = await this.getDB();
      if (!db) return false;
      return await new Promise<boolean>((resolve) => {
        try {
          const tx = db.transaction(STORE_NAME, 'readwrite').objectStore(STORE_NAME).delete(key);
          tx.onsuccess = () => resolve(true);
          tx.onerror = () => resolve(false);
        } catch {
          this.dbPromise = null;
          resolve(false);
        }
      });
    } catch {
      return false;
    }
  }

  async hydrateMap(targetMap: Map<string, any>): Promise<boolean> {
    try {
      const db = await this.getDB();
      if (!db) return false;
      return await new Promise<boolean>((resolve) => {
        try {
          const req = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).openCursor();
          req.onsuccess = (ev: any) => {
            try {
              const cursor = ev.target?.result;
              if (cursor) {
                if (
                  typeof cursor.key === 'string' &&
                  !cursor.key.startsWith('doc_raw_file_') &&
                  !targetMap.has(cursor.key)
                ) {
                  targetMap.set(cursor.key, cursor.value);
                }
                cursor.continue();
              } else {
                resolve(true);
              }
            } catch {
              resolve(false);
            }
          };
          req.onerror = () => resolve(false);
        } catch {
          this.dbPromise = null;
          resolve(false);
        }
      });
    } catch {
      return false;
    }
  }
}

const idbStore = new SafeIndexedDBStore();
const memoryCache = new Map<string, any>();
let syncChannel: BroadcastChannel | null = null;

if (typeof window !== 'undefined') {
  idbStore
    .hydrateMap(memoryCache)
    .then((hydrated) => {
      if (hydrated) {
        window.dispatchEvent(new CustomEvent('yasmina_company_updated'));
        window.dispatchEvent(new CustomEvent('yasmina_document_updated'));
      }
    })
    .catch(() => {});

  if ('BroadcastChannel' in window) {
    try {
      syncChannel = new BroadcastChannel('atend_storage_sync_channel');
      syncChannel.onmessage = (ev) => {
        if (ev.data?.type === 'SET' && ev.data?.key) {
          memoryCache.set(ev.data.key, ev.data.value);
        } else if (ev.data?.type === 'REMOVE' && ev.data?.key) {
          memoryCache.delete(ev.data.key);
        }
      };
    } catch {}
  }
}

export const AtendStorage = {
  getItemSync<T>(key: string, defaultVal: T): T {
    if (memoryCache.has(key)) return memoryCache.get(key) as T;
    try {
      if (typeof localStorage === 'undefined') return defaultVal;
      const item = localStorage.getItem(key);
      if (!item) return defaultVal;
      const parsed = JSON.parse(item) as T;
      memoryCache.set(key, parsed);
      return parsed;
    } catch {
      return defaultVal;
    }
  },
  async getItem<T>(key: string, defaultVal: T): Promise<T> {
    const idbVal = await idbStore.get<T>(key);
    if (idbVal !== null) {
      memoryCache.set(key, idbVal);
      return idbVal;
    }
    return this.getItemSync(key, defaultVal);
  },
  async getItemAsync<T>(key: string, defaultVal: T): Promise<T> {
    return this.getItem(key, defaultVal);
  },
  async setItem<T>(key: string, val: T): Promise<void> {
    memoryCache.set(key, val);
    if (syncChannel && !key.startsWith('doc_raw_file_')) {
      try {
        syncChannel.postMessage({ type: 'SET', key, value: val });
      } catch {}
    }
    try {
      await idbStore.set(key, val);
    } catch {}
    try {
      if (typeof localStorage !== 'undefined' && !key.startsWith('doc_raw_file_')) {
        let lightPayload: any = val;
        if (key === 'yasmina_alerts_v3_clean' && Array.isArray(lightPayload) && lightPayload.length > 150) {
          lightPayload = lightPayload.slice(0, 150);
        }
        localStorage.setItem(key, JSON.stringify(lightPayload));
      }
    } catch {}
  },
  async removeItem(key: string): Promise<void> {
    memoryCache.delete(key);
    if (syncChannel) {
      try {
        syncChannel.postMessage({ type: 'REMOVE', key });
      } catch {}
    }
    await idbStore.remove(key);
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(key);
      }
    } catch {}
  },
};
