import {
  Company,
  CompanyDocument,
  DocumentExpiryAuditConfig,
  DocumentLifecycleStatus,
  DocumentRenewalRequest,
} from "../types";

export interface DocumentExpiryItem {
  id: string;
  entityType: "COMPANY" | "EMPLOYEE" | "CUSTOMER_DOCUMENT" | "CONTRACT";
  entityId: number;
  entityName: string;
  docType:
    | "CR"
    | "COMMERCIAL_LICENSE"
    | "TAX_CARD"
    | "CHAMBER_CERT"
    | "RESIDENCE_CARD"
    | "PASSPORT"
    | "WORK_PERMIT"
    | "LEASE_CONTRACT"
    | "OTHER";
  docTypeAr: string;
  docNumber: string;
  expiryDate: string; // YYYY-MM-DD
  daysRemaining: number;
  status:
    | "EXPIRED"
    | "CRITICAL"
    | "WARNING"
    | "SAFE"
    | "EXPIRING_TODAY"
    | "NEEDS_REVIEW"
    | "NO_EXPIRY";
  statusAr: string;
  urgencyScore: number; // 0 to 100
  recommendedActionAr: string;
}

export interface DocumentExpiryCalculation {
  hasValidDate: boolean;
  expiryDateStr: string | null;
  daysRemaining: number | null;
  isExpired: boolean;
  riskLevel: "VALID" | "UPCOMING" | "URGENT" | "CRITICAL" | "EXPIRED" | "NEEDS_REVIEW";
  lifecycleStatus: DocumentLifecycleStatus;
}

export interface DocumentAuditScanItem {
  document: CompanyDocument;
  company: Company | null;
  calculation: DocumentExpiryCalculation;
  companyPhone: string | null;
  phoneSource: string;
  hasPhone: boolean;
  previousNotifications: any[];
  requiresNotification: boolean;
  eligibleNotificationType: any;
  skipReason?: string;
  renewalRequest: DocumentRenewalRequest | null;
}

export interface DocumentAuditRunReport {
  id: string;
  startedAt: string;
  completedAt: string;
  totalCompaniesScanned: number;
  totalDocumentsScanned: number;
  validDocuments: number;
  expiringSoon: number;
  critical: number;
  expired: number;
  missingExpiryDates: number;
  notificationsSent: number;
  notificationsSkipped: number;
  notificationsFailed: number;
  renewalRequestsActive: number;
  items: DocumentAuditScanItem[];
  crewAILogs: string[];
}

export const DEFAULT_AUDIT_CONFIG: DocumentExpiryAuditConfig & {
  autonomousEnabled?: boolean;
  whatsappEnabled?: boolean;
  defaultLanguage?: "ar" | "en";
} = {
  warningDays: 60,
  criticalDays: 14,
  autonomousEnabled: true,
  whatsappEnabled: true,
  defaultLanguage: "ar",
};

export class DocumentExpiryEngine {
  static getMuscatTodayString(referenceDate?: string | Date): string {
    if (typeof referenceDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(referenceDate.trim())) {
      return referenceDate.trim();
    }
    const d = referenceDate ? new Date(referenceDate) : new Date();
    if (isNaN(d.getTime())) {
      return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Muscat" });
    }
    return d.toLocaleDateString("en-CA", { timeZone: "Asia/Muscat" });
  }

  static calculateExpiry(
    doc: Partial<CompanyDocument>,
    config: Partial<DocumentExpiryAuditConfig> = DEFAULT_AUDIT_CONFIG,
    referenceDate?: string
  ): DocumentExpiryCalculation {
    const raw = doc.expiryDate ? String(doc.expiryDate).trim() : "";
    if (!raw || !/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
      return {
        hasValidDate: false,
        expiryDateStr: null,
        daysRemaining: null,
        isExpired: false,
        riskLevel: "NEEDS_REVIEW",
        lifecycleStatus: "EXPIRING_SOON",
      };
    }

    const todayStr = this.getMuscatTodayString(referenceDate);
    const [ty, tm, td] = todayStr.split("-").map(Number);
    const [ey, em, ed] = raw.split("-").map(Number);

    const todayUtc = Date.UTC(ty, tm - 1, td);
    const expUtc = Date.UTC(ey, em - 1, ed);
    const daysRemaining = Math.round((expUtc - todayUtc) / (1000 * 60 * 60 * 24));

    const warningDays = config.warningDays ?? 60;
    const criticalDays = config.criticalDays ?? 14;

    if (daysRemaining < 0) {
      return {
        hasValidDate: true,
        expiryDateStr: raw,
        daysRemaining,
        isExpired: true,
        riskLevel: "EXPIRED",
        lifecycleStatus: "EXPIRED",
      };
    }

    if (daysRemaining <= criticalDays) {
      return {
        hasValidDate: true,
        expiryDateStr: raw,
        daysRemaining,
        isExpired: false,
        riskLevel: "CRITICAL",
        lifecycleStatus: "CRITICAL",
      };
    }

    if (daysRemaining <= warningDays) {
      return {
        hasValidDate: true,
        expiryDateStr: raw,
        daysRemaining,
        isExpired: false,
        riskLevel: "UPCOMING",
        lifecycleStatus: "EXPIRING_SOON",
      };
    }

    return {
      hasValidDate: true,
      expiryDateStr: raw,
      daysRemaining,
      isExpired: false,
      riskLevel: "VALID",
      lifecycleStatus: "ACTIVE",
    };
  }

  static makeIdempotencyKey(docId: string, notificationType: string, expiryDateStr: string): string {
    return `notif:${docId}:${notificationType}:${expiryDateStr}`;
  }

  static getEligibleNotificationType(
    calc: DocumentExpiryCalculation,
    _config?: Partial<DocumentExpiryAuditConfig>
  ): string | null {
    if (!calc.hasValidDate || calc.daysRemaining === null) return "NEEDS_REVIEW";
    if (calc.daysRemaining < 0) return "EXPIRED";
    if (calc.daysRemaining === 0) return "EXPIRING_TODAY";
    if (calc.daysRemaining <= 7) return "EXPIRING_7_DAYS";
    if (calc.daysRemaining <= 30) return "EXPIRING_30_DAYS";
    return null;
  }

  static generateRenewalMessage(params: {
    companyName: string;
    documentTitle: string;
    expiryDateStr: string;
    daysRemaining: number | null;
    isExpired: boolean;
    language?: string;
  }): string {
    if (params.isExpired) {
      return `تنبيه هام من مكتب سند: انتهت صلاحية الوثيقة "${params.documentTitle}" الخاصة بشركة ${params.companyName} بتاريخ ${params.expiryDateStr}. للبدء في التجديد الفوري يرجى الرد بكلمة: تجديد`;
    }
    if (params.daysRemaining === 0) {
      return `تنبيه عاجل من مكتب سند: تنتهي اليوم صلاحية الوثيقة "${params.documentTitle}" الخاصة بشركة ${params.companyName} (${params.expiryDateStr}). للتجديد يرجى الرد بكلمة: تجديد`;
    }
    return `تذكير من مكتب سند: تقترب نهاية صلاحية الوثيقة "${params.documentTitle}" الخاصة بشركة ${params.companyName} بتاريخ ${params.expiryDateStr} (متبقي ${params.daysRemaining} يوم). للتجديد يرجى الرد بكلمة: تجديد`;
  }

  static parseCustomerResponse(text: string): {
    intent: "RENEWAL_REQUESTED" | "NO_RENEWAL" | "INFO_REQUEST" | "UNCLEAR";
    explanation: string;
  } {
    const clean = (text || "").trim().toLowerCase();
    if (/تجديد|جدد|نعم|موافق|renew|yes/.test(clean)) {
      return { intent: "RENEWAL_REQUESTED", explanation: "العميل طلب التجديد صراحة" };
    }
    if (/لا|إلغاء|الغاء|تأجيل|no|cancel/.test(clean)) {
      return { intent: "NO_RENEWAL", explanation: "العميل اعتذر عن التجديد حالياً" };
    }
    if (/كم|رسوم|سعر|متطلبات|تفاصيل|price|cost|info/.test(clean)) {
      return { intent: "INFO_REQUEST", explanation: "العميل يستفسر عن الرسوم أو المتطلبات" };
    }
    return { intent: "UNCLEAR", explanation: "رسالة عامة" };
  }
}

export function evaluateDocumentExpiry(
  items: Omit<
    DocumentExpiryItem,
    "daysRemaining" | "status" | "statusAr" | "urgencyScore" | "recommendedActionAr"
  >[],
  referenceDateStr?: string
): DocumentExpiryItem[] {
  const todayStr = DocumentExpiryEngine.getMuscatTodayString(referenceDateStr);
  const [ty, tm, td] = todayStr.split("-").map(Number);
  const todayUtc = Date.UTC(ty, tm - 1, td);

  return items
    .map((item) => {
      if (!item.expiryDate || !/^\d{4}-\d{2}-\d{2}$/.test(item.expiryDate)) {
        return {
          ...item,
          daysRemaining: 0,
          status: "NEEDS_REVIEW" as const,
          statusAr: "تحتاج إلى مراجعة",
          urgencyScore: 70,
          recommendedActionAr: `يرجى التحقق من تاريخ انتهاء ${item.docTypeAr} (${item.docNumber}) وتحديثه يدوياً`,
        };
      }

      const [ey, em, ed] = item.expiryDate.split("-").map(Number);
      const expUtc = Date.UTC(ey, em - 1, ed);
      const daysRemaining = Math.round((expUtc - todayUtc) / (1000 * 60 * 60 * 24));

      let status: DocumentExpiryItem["status"] = "SAFE";
      let statusAr = "سارية";
      let urgencyScore = 10;
      let recommendedActionAr = "لا يوجد إجراء مطلوب حالياً";

      if (daysRemaining < 0) {
        status = "EXPIRED";
        statusAr = `منتهية منذ ${Math.abs(daysRemaining)} يوم`;
        urgencyScore = 100;
        recommendedActionAr = `إيقاف المعاملات فوراً وتجديد ${item.docTypeAr} لتجنب الغرامات القانونية`;
      } else if (daysRemaining === 0) {
        status = "EXPIRING_TODAY";
        statusAr = "تنتهي اليوم";
        urgencyScore = 95;
        recommendedActionAr = `تنتهي اليوم صلاحية ${item.docTypeAr} — يرجى التجديد الفوري`;
      } else if (daysRemaining <= 7) {
        status = "CRITICAL";
        statusAr = `تنتهي قريبًا جدًا (${daysRemaining} يوم)`;
        urgencyScore = 90;
        recommendedActionAr = `التواصل العاجل مع المعني لتجديد ${item.docTypeAr} قبل انتهاء المهلة`;
      } else if (daysRemaining <= 30) {
        status = "WARNING";
        statusAr = `قربت تنتهي (${daysRemaining} يوم)`;
        urgencyScore = 60;
        recommendedActionAr = `إرسال تنبيه تذكيري وتجهيز مستندات تجديد ${item.docTypeAr}`;
      }

      return {
        ...item,
        daysRemaining,
        status,
        statusAr,
        urgencyScore,
        recommendedActionAr,
      };
    })
    .sort((a, b) => a.daysRemaining - b.daysRemaining);
}
