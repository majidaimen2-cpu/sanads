/**
 * Single source of truth for document type codes used by the Smart Company File feature
 * (processor, matching, vault API, expiry reminders, UI). Do not create a second list.
 */
export const DOC_TYPE_CODES = [
  "CR",
  "MUNICIPAL_LICENSE",
  "COMMERCIAL_LICENSE",
  "TAX_CARD",
  "CHAMBER_CERT",
  "LABOR_LICENSE",
  "OMANIZATION_CERT",
  "LEASE_CONTRACT",
  "RESIDENCE_CARD",
  "PASSPORT",
  "CIVIL_ID",
  "LABOR_CARD",
  "OTHER",
] as const;

export type DocTypeCode = (typeof DOC_TYPE_CODES)[number];

export interface DocTypeInfo {
  code: DocTypeCode;
  labelAr: string;
  labelEn: string;
  hasExpiry: boolean;
  isPersonDocument: boolean;
  /** Days before expiry at which a reminder is sent. 0 = on the expiry day. */
  defaultReminderOffsets: number[];
}

export const DOC_TYPES: Record<DocTypeCode, DocTypeInfo> = {
  CR: { code: "CR", labelAr: "السجل التجاري", labelEn: "Commercial Registration", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [60, 30, 7, 0] },
  MUNICIPAL_LICENSE: { code: "MUNICIPAL_LICENSE", labelAr: "الترخيص البلدي", labelEn: "Municipal License", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [60, 30, 7, 0] },
  COMMERCIAL_LICENSE: { code: "COMMERCIAL_LICENSE", labelAr: "الترخيص التجاري", labelEn: "Commercial License", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [60, 30, 7, 0] },
  TAX_CARD: { code: "TAX_CARD", labelAr: "البطاقة الضريبية", labelEn: "Tax Card", hasExpiry: false, isPersonDocument: false, defaultReminderOffsets: [30, 0] },
  CHAMBER_CERT: { code: "CHAMBER_CERT", labelAr: "شهادة انتساب الغرفة", labelEn: "Chamber Certificate", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [60, 30, 7, 0] },
  LABOR_LICENSE: { code: "LABOR_LICENSE", labelAr: "ترخيص العمل", labelEn: "Labor License", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [90, 30, 7, 0] },
  OMANIZATION_CERT: { code: "OMANIZATION_CERT", labelAr: "شهادة التعمين", labelEn: "Omanization Certificate", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [60, 30, 0] },
  LEASE_CONTRACT: { code: "LEASE_CONTRACT", labelAr: "عقد الإيجار", labelEn: "Lease Contract", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [60, 30, 0] },
  RESIDENCE_CARD: { code: "RESIDENCE_CARD", labelAr: "بطاقة الإقامة", labelEn: "Residence Card", hasExpiry: true, isPersonDocument: true, defaultReminderOffsets: [90, 30, 7, 0] },
  PASSPORT: { code: "PASSPORT", labelAr: "جواز السفر", labelEn: "Passport", hasExpiry: true, isPersonDocument: true, defaultReminderOffsets: [180, 60, 0] },
  CIVIL_ID: { code: "CIVIL_ID", labelAr: "بطاقة الهوية", labelEn: "Civil ID", hasExpiry: true, isPersonDocument: true, defaultReminderOffsets: [90, 30, 0] },
  LABOR_CARD: { code: "LABOR_CARD", labelAr: "بطاقة العمل", labelEn: "Labor Card", hasExpiry: true, isPersonDocument: true, defaultReminderOffsets: [90, 30, 7, 0] },
  OTHER: { code: "OTHER", labelAr: "وثيقة إضافية", labelEn: "Other document", hasExpiry: true, isPersonDocument: false, defaultReminderOffsets: [30, 0] },
};

/** After the expiry date: every 7 days, at most 4 times, then stop (dashboard alert stays). */
export const AFTER_EXPIRY_REPEAT_DAYS = 7;
export const AFTER_EXPIRY_MAX_REMINDERS = 4;

/** Legacy lower-case processor types (CanonicalDocumentType) and free-text docType values to canonical codes. */
const LEGACY_TO_CODE: Record<string, DocTypeCode> = {
  commercial_registry: "CR",
  commercial_registration: "CR",
  cr: "CR",
  municipal_license: "MUNICIPAL_LICENSE",
  commercial_license: "COMMERCIAL_LICENSE",
  tax_certificate: "TAX_CARD",
  tax_card: "TAX_CARD",
  vat_certificate: "TAX_CARD",
  chamber_certificate: "CHAMBER_CERT",
  chamber_cert: "CHAMBER_CERT",
  labor_certificate: "LABOR_LICENSE",
  labor_license: "LABOR_LICENSE",
  labor_permit: "LABOR_LICENSE",
  employment_certificate: "OMANIZATION_CERT",
  omanization_cert: "OMANIZATION_CERT",
  lease_contract: "LEASE_CONTRACT",
  residence_card: "RESIDENCE_CARD",
  passport: "PASSPORT",
  civil_id: "CIVIL_ID",
  labor_card: "LABOR_CARD",
};

export function toDocTypeCode(raw: string | null | undefined): DocTypeCode {
  if (!raw) return "OTHER";
  const key = raw.trim().toLowerCase().replace(/\s+/g, "_");
  if (LEGACY_TO_CODE[key]) return LEGACY_TO_CODE[key];
  const upper = key.toUpperCase();
  if ((DOC_TYPE_CODES as readonly string[]).includes(upper)) return upper as DocTypeCode;
  return "OTHER";
}

export function hasExpiry(code: DocTypeCode): boolean {
  return DOC_TYPES[code].hasExpiry;
}
export function isPersonDocument(code: DocTypeCode): boolean {
  return DOC_TYPES[code].isPersonDocument;
}
export function docTypeLabelAr(code: DocTypeCode): string {
  return DOC_TYPES[code].labelAr;
}
