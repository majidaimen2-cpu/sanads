export function normalizeArabicText(text?: string | null): string {
  if (!text) return "";
  return text
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآ]/g, "\u0627")
    .replace(/ة/g, "\u0647")
    .replace(/ى/g, "\u064A")
    .toLowerCase()
    .trim();
}

export function matchesArabicText(target?: string | null, query?: string | null): boolean {
  if (!query) return true;
  if (!target) return false;
  const normalizedTarget = normalizeArabicText(target);
  const normalizedQuery = normalizeArabicText(query);
  return normalizedTarget.includes(normalizedQuery);
}

