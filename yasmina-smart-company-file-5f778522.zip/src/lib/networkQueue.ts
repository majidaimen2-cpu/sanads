export const networkQueue = {
  add: async <T>(fn: () => Promise<T>): Promise<T> => {
    return fn();
  },
  size: 0,
  pending: 0,
};
