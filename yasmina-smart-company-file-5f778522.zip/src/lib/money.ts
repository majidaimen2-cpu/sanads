export function toBaisa(omrAmount: number | string | null | undefined): number {
  if (omrAmount === null || omrAmount === undefined) return 0;
  const num = typeof omrAmount === "string" ? parseFloat(omrAmount) : omrAmount;
  if (isNaN(num)) return 0;
  return Math.round(num * 1000);
}

export function toOMR(baisaAmount: number | null | undefined): number {
  if (!baisaAmount || isNaN(baisaAmount)) return 0;
  return baisaAmount / 1000;
}

export const baisaToOmr = toOMR;

export function formatOMR(
  baisaAmount: number | null | undefined,
  includeCurrency = true,
  lang: "ar" | "en" = "ar"
): string {
  const omr = toOMR(baisaAmount);
  const formatted = omr.toFixed(3);
  if (!includeCurrency) return formatted;
  return lang === "ar" ? `${formatted} ر.ع.` : `${formatted} OMR`;
}

export function calculateVatBaisa(officeFeeBaisa: number | null | undefined, vatRatePct = 5): number {
  if (!officeFeeBaisa || officeFeeBaisa <= 0) return 0;
  return Math.round((officeFeeBaisa * vatRatePct) / 100);
}

export function calculateTransactionTotal(params: {
  govFeeBaisa?: number | null;
  officeFeeBaisa?: number | null;
  discountBaisa?: number | null;
  vatRatePct?: number;
}) {
  const govFeeBaisa = params.govFeeBaisa || 0;
  const officeFeeBaisa = params.officeFeeBaisa || 0;
  const discountBaisa = params.discountBaisa || 0;
  const netOfficeFeeBaisa = Math.max(0, officeFeeBaisa - discountBaisa);
  const vatRatePct = params.vatRatePct ?? 5;
  const vatBaisa = calculateVatBaisa(netOfficeFeeBaisa, vatRatePct);
  const totalBaisa = govFeeBaisa + netOfficeFeeBaisa + vatBaisa;
  return {
    govFeeBaisa,
    officeFeeBaisa,
    discountBaisa,
    netOfficeFeeBaisa,
    vatBaisa,
    totalBaisa,
  };
}

