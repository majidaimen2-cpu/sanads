import { CustomerRequest, RequestPriority, RequestStatus } from '../../types';

// Mock initial data in case server API is offline or during initial state
const initialRequests: CustomerRequest[] = [
  {
    id: 'req-001',
    customerPhone: '+96891234567',
    customerName: 'سالم بن عبد الله البوسعيدي',
    serviceCategory: 'السجل التجاري (إستثمر سهولة)',
    serviceSubType: 'تجديد السجل التجاري وإضافة أنشطة',
    extractedIntent: 'الزبون يرغب في تجديد السجل التجاري رقم 1029384 مع إضافة نشاط مقاولات البناء والتعديل السريع للأنشطة',
    status: 'pending',
    priority: 'high',
    requirementChecklist: [
      'نسخة البطاقة الشخصية للنائب/المالك',
      'تحديث بيانات عقد الإيجار بلديتي',
      'شهادة انتساب غرفة تجارة وصناعة عمان',
      'ترخيص النشاط التجاري السابق'
    ],
    notes: 'الزبون مستعجل ويرغب بإنهاء الخدمة خلال اليوم قبل انتهاء مهلة التجديد بدون غرامة',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    fullRawConversation: [
      { role: 'customer', text: 'السلام عليكم ورحمة الله، أخي أريد تجديد السجل التجاري مالي وتعديل أنشطة', timestamp: '10:15 AM' },
      { role: 'assistant', text: 'وعليكم السلام ورحمة الله وبركاته أهلاً بك في مكتب سند للخدمات الذكية. يسعدنا مساعدتك بالتأكيد. هل السجل قائم وتود إضافة نشاط مع تجديده؟', timestamp: '10:15 AM' },
      { role: 'customer', text: 'نعم السجل رقم 1029384، أريد أضيف نشاط مقاولات البناء وأجدده قبل السبت', timestamp: '10:17 AM' }
    ]
  },
  {
    id: 'req-002',
    customerPhone: '+96898765432',
    customerName: 'خالد بن أحمد المعمري',
    serviceCategory: 'وزارة العمل (تأشيرات وترخيص عمال)',
    serviceSubType: 'طلب ترخيص استقدام قوى عاملة وافدة',
    extractedIntent: 'استخراج 3 مأذونيات لعمال بناء وإعداد ملف عقود العمل الإلكترونية عبر بوابة وزارة العمل',
    status: 'in_progress',
    priority: 'high',
    requirementChecklist: [
      'شهادة إثبات نسبة التعمين للشركة',
      'كشف حساب بنكي للمؤسسة لآخر 3 أشهر',
      'عقد المشروع الحاضر للشركة'
    ],
    notes: 'تم فحص نسبة التعمين وهي مكتملة 100% بنجاح',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 1).toISOString(),
    fullRawConversation: [
      { role: 'customer', text: 'مساء الخير، كم تكلفة استخراج مأذونيات عمال بناء3؟', timestamp: '08:30 AM' },
      { role: 'assistant', text: 'أهلاً بك أستاذ خالد. استخراج مأذونية العمل يستلزم مطابقة السجل وتوفر نسبة التعمين. نسعد بتقديم الخدمة لك فور إرسال الأوراق.', timestamp: '08:31 AM' }
    ]
  },
  {
    id: 'req-003',
    customerPhone: '+96895551234',
    customerName: 'مريم بنت راشد الحوسنية',
    serviceCategory: 'بلديات وتراخيص بلديتي',
    serviceSubType: 'اصدار ترخيص بلدي جديد وتدقيق اللوحة',
    extractedIntent: 'الزبونة تطلب إصدار ترخيص بلدي لمحل تجميل جديد في مسقط مع التدقيق على اللوحة التجارية',
    status: 'pending',
    priority: 'medium',
    requirementChecklist: [
      'عقد إيجار موثق من البلدية',
      'صورة اللوحة الإعلانية بالمقاييس',
      'موافقة الدفاع المدني للموقع'
    ],
    notes: 'تم إرسال نموذج الأوراق المطلوبة للزبونة على الواتساب',
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    fullRawConversation: [
      { role: 'customer', text: 'هلا اختي أريد اطلع ترخيص بلدية لمشروعي الجديد صالون تجميل في الموالح', timestamp: '01:00 PM' }
    ]
  },
  {
    id: 'req-004',
    customerPhone: '+96894443322',
    customerName: 'شركة النور للمقاولات والتجارة',
    serviceCategory: 'جهاز الضرائب العماني',
    serviceSubType: 'تقديم إقرار ضريبة القيمة المضافة VAT',
    extractedIntent: 'تقديم الإقرار الضريبي للربع الثالث لعام 2026 وحساب الفواتير الضريبية المدخلة والمخرجة',
    status: 'converted',
    priority: 'low',
    requirementChecklist: [
      'ملف الفواتير الضريبية والمبيعات',
      'بيانات الرقم الضريبي الموحد VAT ID'
    ],
    notes: 'تم تحويل الطلب لمعاملة رسمية برقم TXN-2026-88',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 18).toISOString()
  }
];

let memoryRequests: CustomerRequest[] = [...initialRequests];

export async function fetchCustomerRequests(): Promise<CustomerRequest[]> {
  try {
    const res = await fetch('/api/requests');
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.requests) && data.requests.length > 0) {
        memoryRequests = data.requests;
        return memoryRequests;
      }
    }
  } catch (err) {
    console.warn('API fetch error, using client state:', err);
  }
  return memoryRequests;
}

export async function updateRequestStatus(id: string, status: RequestStatus): Promise<CustomerRequest | null> {
  try {
    const res = await fetch(`/api/requests/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.request) {
        const idx = memoryRequests.findIndex(r => r.id === id);
        if (idx !== -1) memoryRequests[idx] = data.request;
        return data.request;
      }
    }
  } catch (err) {
    console.warn('API update status fallback:', err);
  }

  // Client fallback
  const item = memoryRequests.find(r => r.id === id);
  if (item) {
    item.status = status;
    item.updatedAt = new Date().toISOString();
    return { ...item };
  }
  return null;
}

export async function createCustomerRequest(req: Partial<CustomerRequest>): Promise<CustomerRequest> {
  const newReq: CustomerRequest = {
    id: `req-${Date.now()}`,
    customerPhone: req.customerPhone || '+96890000000',
    customerName: req.customerName || 'زبون جديد',
    serviceCategory: req.serviceCategory || 'خدمات سند العامة',
    serviceSubType: req.serviceSubType || 'استفسار عام',
    extractedIntent: req.extractedIntent || 'استفسار زبون محول من الواتساب',
    status: req.status || 'pending',
    priority: req.priority || 'medium',
    requirementChecklist: req.requirementChecklist || ['البطاقة الشخصية'],
    notes: req.notes || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    fullRawConversation: req.fullRawConversation || []
  };

  try {
    const res = await fetch('/api/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newReq)
    });
    if (res.ok) {
      const data = await res.json();
      if (data.request) {
        memoryRequests.unshift(data.request);
        return data.request;
      }
    }
  } catch (err) {
    console.warn('API create fallback:', err);
  }

  memoryRequests.unshift(newReq);
  return newReq;
}

export async function analyzeCustomerMessageWithAI(message: string, customerPhone: string = '+96891234567'): Promise<{ responseText: string; extractedRequest: CustomerRequest }> {
  try {
    const res = await fetch('/api/requests/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, phone: customerPhone })
    });

    if (res.ok) {
      const data = await res.json();
      if (data.extractedRequest) {
        memoryRequests.unshift(data.extractedRequest);
        return {
          responseText: data.reply || 'تم استلام طلبكم ونحن بمعالجته فوراً.',
          extractedRequest: data.extractedRequest
        };
      }
    }
  } catch (err) {
    console.warn('API AI analyze fallback:', err);
  }

  // Client AI fallback simulation
  const mockExtracted: CustomerRequest = {
    id: `req-${Date.now()}`,
    customerPhone,
    customerName: 'زبون واتساب',
    serviceCategory: message.includes('سجل') ? 'السجل التجاري (إستثمر سهولة)' : message.includes('عمل') ? 'وزارة العمل' : 'خدمات سند الذكية',
    serviceSubType: 'استفسار مستخرج بواسطة Gemini AI 3.8',
    extractedIntent: `تحليل الذكاء الاصطناعي: ${message}`,
    status: 'pending',
    priority: message.includes('مستعجل') || message.includes('اليوم') ? 'high' : 'medium',
    requirementChecklist: [
      'نسخة من البطاقة الشخصية العمانية',
      'بيانات السجل التجاري إن وجد',
      'إثبات الترخيص والمقر'
    ],
    notes: 'تم استخراجه وتصنيفه تلقائياً بواسطة الموديل الذكي',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    fullRawConversation: [{ role: 'customer', text: message, timestamp: new Date().toLocaleTimeString('ar-OM') }]
  };

  memoryRequests.unshift(mockExtracted);

  return {
    responseText: `أهلاً وسهلاً بك في مكتب سند للخدمات الحكومية الذكية! 🌿\n\nلقد قمت بفهم طلبك بخصوص "${mockExtracted.serviceCategory}". تم تسجيل طلبك وتجهيز قائمة بالمستندات المطلوبة للبدء فوراً. هل أوراقك جاهزة؟`,
    extractedRequest: mockExtracted
  };
}
