export class ApiError extends Error {
  status: number;
  code: string;
  details?: any;

  constructor(status: number, code: string, message: string, details?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export async function apiFetch<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = typeof window !== 'undefined'
    ? (localStorage.getItem('yasmina_auth_token_v1') ||
       localStorage.getItem('yasmina_auth_token') ||
       localStorage.getItem('yasmine_auth_token') ||
       localStorage.getItem('token'))
    : null;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    credentials: 'same-origin',
    ...options,
    headers,
  });

  const body = await res.json().catch(() => ({}));

  if (!res.ok) {
    const errorObj = body.error || {};
    const code = errorObj.code || (res.status === 401 ? 'UNAUTHORIZED' : res.status === 403 ? 'FORBIDDEN' : 'SERVER_ERROR');
    const message = errorObj.message || body.message || `Request failed with status ${res.status}`;
    
    if (res.status === 401 && typeof window !== 'undefined') {
      // Clear expired auth session tokens
      localStorage.removeItem('yasmina_auth_token_v1');
      localStorage.removeItem('yasmina_auth_token');
      localStorage.removeItem('yasmine_auth_token');
      localStorage.removeItem('yasmina_user_v1');
    }

    throw new ApiError(res.status, code, message, errorObj.details);
  }

  return body as T;
}
