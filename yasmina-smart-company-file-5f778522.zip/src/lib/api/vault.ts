import { apiFetch } from './client';

/** Client for the Smart Company File API (/api/vault). All calls are tenant-scoped on the server. */
export interface VaultCandidate {
  companyId: number;
  companyName: string;
  score: number;
  hardAnchor?: boolean;
  reasons: { code: string; points: number; detail: string }[];
  laneReason?: string | null;
}

export interface VaultDocument {
  id: number;
  companyId: number | null;
  companyName: string | null;
  docTypeCode: string;
  labelAr: string;
  labelEn: string;
  isPersonDocument: boolean;
  docNumber: string | null;
  issueDate: string | null;
  expiryDate: string | null;
  hasNoExpiry: boolean;
  expiryStatus: string | null;
  needsReview: boolean;
  matchLane: 'AUTO' | 'CONFIRM' | 'UNMATCHED' | 'MANUAL' | null;
  matchScore: number | null;
  versionNumber: number;
  extractionConfidence?: number | null;
  originalFileName: string | null;
  sourceChannel: string | null;
  senderPhone: string | null;
  createdAt: string;
  fields: Record<string, unknown> | null;
  downloadUrl: string;
  candidates?: VaultCandidate[];
}

export interface ReminderRule {
  docTypeCode: string;
  labelAr: string;
  offsetsDays: number[];
  notifyStaff: boolean;
  notifyClient: boolean;
  active: boolean;
  isDefault: boolean;
}

export interface ReminderSettings {
  autoFileEnabled: boolean;
  autoFileMinScore: number;
  reminderStaffPhones: string;
}

const json = (body: unknown): RequestInit => ({ body: JSON.stringify(body) });

export const vaultApi = {
  inbox: () => apiFetch<{ data: VaultDocument[]; count: number }>('/api/vault/inbox'),
  companyDocuments: (companyId: number) =>
    apiFetch<{ data: VaultDocument[] }>(`/api/vault/companies/${companyId}/documents`),
  expiring: (days = 60) => apiFetch<{ data: VaultDocument[]; count: number }>(`/api/vault/expiring?days=${days}`),
  confirm: (docId: number, companyId: number) =>
    apiFetch(`/api/vault/documents/${docId}/confirm-match`, { method: 'POST', ...json({ companyId }) }),
  move: (docId: number, companyId: number) =>
    apiFetch(`/api/vault/documents/${docId}/move`, { method: 'POST', ...json({ companyId }) }),
  reject: (docId: number, reason?: string) =>
    apiFetch(`/api/vault/documents/${docId}/reject`, { method: 'POST', ...json({ reason }) }),
  updateFields: (docId: number, edit: Record<string, unknown>) =>
    apiFetch(`/api/vault/documents/${docId}/fields`, { method: 'PATCH', ...json(edit) }),
  upload: (companyId: number, fileName: string, mimeType: string, base64: string) =>
    apiFetch(`/api/vault/companies/${companyId}/documents`, {
      method: 'POST',
      ...json({ fileName, mimeType, data: base64 }),
    }),
  getRules: () => apiFetch<{ data: { rules: ReminderRule[]; settings: ReminderSettings } }>('/api/vault/reminder-rules'),
  saveRules: (body: { rules?: Partial<ReminderRule>[]; settings?: Partial<ReminderSettings> }) =>
    apiFetch('/api/vault/reminder-rules', { method: 'PUT', ...json(body) }),
  setClientReminders: (companyId: number, enabled: boolean, consentGiven: boolean) =>
    apiFetch(`/api/vault/companies/${companyId}/reminders`, { method: 'PATCH', ...json({ enabled, consentGiven }) }),
};

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).replace(/^data:[^;]+;base64,/, ''));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
