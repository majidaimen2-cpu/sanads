import "dotenv/config";
import { getTableConfig } from "drizzle-orm/pg-core";
import { createPool } from "./index.js";
import * as schema from "./schema.js";

export async function checkSchemaDrift() {
  const issues: string[] = [];
  const pool = createPool();
  try {
    const res = await pool.query(`
      SELECT table_name, column_name, data_type, is_nullable
      FROM information_schema.columns
      WHERE table_schema = 'public'
    `);
    const dbColumnMap = new Map<string, Set<string>>();
    const dbNullable = new Map<string, boolean>();
    for (const row of res.rows) {
      if (!dbColumnMap.has(row.table_name)) {
        dbColumnMap.set(row.table_name, new Set());
      }
      dbColumnMap.get(row.table_name)!.add(row.column_name);
      dbNullable.set(`${row.table_name}.${row.column_name}`, row.is_nullable === "YES");
    }
    for (const [key, val] of Object.entries(schema)) {
      const anyVal = val as any;
      if (!anyVal || typeof anyVal !== "object" || !anyVal[Symbol.for("drizzle:Name")]) {
        continue;
      }
      try {
        const config = getTableConfig(anyVal);
        const tableName = config.name;
        const dbCols = dbColumnMap.get(tableName);
        if (!dbCols) {
          issues.push(`Missing table in DB: "${tableName}" (defined in schema.${key})`);
          continue;
        }
        for (const col of config.columns) {
          if (!dbCols.has(col.name)) {
            issues.push(`Missing column in DB table "${tableName}": "${col.name}"`);
            continue;
          }
          // Nullability must match too: a NOT NULL column in the DB that the code treats as
          // optional makes inserts fail at runtime.
          const dbIsNullable = dbNullable.get(`${tableName}.${col.name}`);
          if (dbIsNullable !== undefined && dbIsNullable === col.notNull && !col.primary) {
            issues.push(
              `Nullability mismatch in "${tableName}"."${col.name}": schema.ts says ${col.notNull ? "NOT NULL" : "nullable"}, DB says ${dbIsNullable ? "nullable" : "NOT NULL"}`
            );
          }
        }
      } catch {}
    }
  } catch (err: any) {
    issues.push(`Failed to query information_schema: ${err?.message || err}`);
  }
  return { hasDrift: issues.length > 0, issues };
}

const isMain =
  process.argv[1]?.endsWith("driftCheck.ts") || process.argv[1]?.endsWith("driftCheck.js");
if (isMain) {
  checkSchemaDrift()
    .then(({ hasDrift, issues }) => {
      if (hasDrift) {
        console.error("❌ Schema drift detected between schema.ts and database:");
        issues.forEach((issue) => console.error(`  - ${issue}`));
        process.exit(1);
      } else {
        console.log("✅ Database schema matches PostgreSQL information_schema with 0 drift.");
        process.exit(0);
      }
    })
    .catch((err) => {
      console.error("Fatal error during drift check:", err);
      process.exit(1);
    });
}
