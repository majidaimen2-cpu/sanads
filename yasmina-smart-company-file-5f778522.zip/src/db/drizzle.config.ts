import { defineConfig } from "drizzle-kit";

const sslEnabled = process.env.DATABASE_SSL === "true";

export default defineConfig({
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dialect: "postgresql",
  dbCredentials: {
    host: process.env.SQL_HOST || "/app/cloudsql/gen-lang-client-0876184485:europe-west2:ai-studio-d9a5281d",
    user: process.env.SQL_ADMIN_USER || process.env.SQL_USER || "ai_studio_admin",
    password: process.env.SQL_ADMIN_PASSWORD || process.env.SQL_PASSWORD || "",
    database: process.env.SQL_DB_NAME || "cloud_sql_development_database",
    port: parseInt(process.env.SQL_PORT || "5432", 10),
    ssl: sslEnabled ? { rejectUnauthorized: true } : false,
  },
});
