import { drizzle } from "drizzle-orm/node-postgres";
import { Pool, type PoolConfig } from "pg";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import * as schema from "./schema.js";
import { logger } from "../server/logger.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface GlobalWithPgPool {
  _postgresPool?: Pool & { _hasRetryWrapper?: boolean };
}

const g = globalThis as unknown as GlobalWithPgPool;

interface DbErrorLike {
  code?: string;
  message?: string;
  cause?: {
    code?: string;
    message?: string;
  };
}

const isTransientDbError = (err: unknown): boolean => {
  if (!err || typeof err !== "object") return false;
  const dbErr = err as DbErrorLike;
  const code = String(dbErr.code || dbErr.cause?.code || "");
  const msg = String(dbErr.message || dbErr.cause?.message || "");
  return (
    code === "57P01" ||
    code === "57P02" ||
    code === "57P03" ||
    code === "08000" ||
    code === "08003" ||
    code === "08006" ||
    code === "08001" ||
    code === "08004" ||
    code === "53300" ||
    msg.includes("Connection terminated") ||
    msg.includes("ECONNRESET") ||
    msg.includes("ETIMEDOUT") ||
    msg.includes("EPIPE") ||
    msg.includes("ECONNREFUSED") ||
    msg.includes("Client has encountered a connection error") ||
    msg.includes("terminating connection") ||
    msg.includes("timeout expired") ||
    msg.includes("Connection ended unexpectedly")
  );
};

const createPool = (): Pool => {
  if (!g._postgresPool) {
    const connectionString = process.env.DATABASE_URL;
    const sslEnabled = process.env.DATABASE_SSL === "true";
    const poolConfig: PoolConfig = {
      max: 10,
      connectionTimeoutMillis: 15000,
      idleTimeoutMillis: 30000,
      keepAlive: true,
      keepAliveInitialDelayMillis: 10000,
      ssl: sslEnabled ? { rejectUnauthorized: true } : false,
    };

    const isLocalPlaceholder =
      connectionString &&
      connectionString.includes("postgres:password@localhost:5432") &&
      Boolean(process.env.SQL_HOST);

    const rawPool =
      connectionString && !isLocalPlaceholder
        ? new Pool({
            connectionString,
            ...poolConfig,
          })
        : new Pool({
            host: process.env.SQL_HOST,
            user: process.env.SQL_ADMIN_USER || process.env.SQL_USER,
            password: process.env.SQL_ADMIN_PASSWORD || process.env.SQL_PASSWORD,
            database: process.env.SQL_DB_NAME || "cloud_sql_development_database",
            port: parseInt(process.env.SQL_PORT || "5432", 10),
            ...poolConfig,
          });

    rawPool.on("error", (err: Error) => {
      if (isTransientDbError(err)) {
        logger.debug({ err: err.message }, "PostgreSQL idle client connection closed by remote host");
        return;
      }
      logger.warn({ err: err.message }, "PostgreSQL pool client warning");
    });

    g._postgresPool = rawPool;
  }

  const activePool = g._postgresPool;
  if (activePool && !activePool._hasRetryWrapper) {
    const originalQuery = activePool.query.bind(activePool) as (...args: unknown[]) => Promise<unknown>;
    (activePool as unknown as { query: (...args: unknown[]) => Promise<unknown> }).query = async (
      ...args: unknown[]
    ) => {
      if (args.length > 0 && typeof args[args.length - 1] === "function") {
        return originalQuery(...args);
      }
      // Only auto-retry read-only statements. Retrying an INSERT/UPDATE/DELETE after a dropped
      // connection could apply it twice (the first attempt may have committed).
      const firstQueryArg = args[0];
      const queryText =
        typeof firstQueryArg === "string"
          ? firstQueryArg
          : typeof (firstQueryArg as { text?: unknown } | undefined)?.text === "string"
            ? String((firstQueryArg as { text: string }).text)
            : "";
      const isReadOnlyQuery =
        /^\s*(SELECT|SHOW|EXPLAIN)\b/i.test(queryText) ||
        (/^\s*WITH\b/i.test(queryText) &&
          !/\b(INSERT|UPDATE|DELETE|MERGE)\b/i.test(queryText));
      const maxAttempts = isReadOnlyQuery ? 3 : 1;
      let lastErr: unknown;
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          const firstArg = args[0];
          const callArgs =
            args.length > 0 &&
            typeof firstArg === "object" &&
            firstArg !== null &&
            !Array.isArray(firstArg) &&
            firstArg.constructor === Object
              ? [{ ...(firstArg as Record<string, unknown>) }, ...args.slice(1)]
              : args;
          return await originalQuery(...callArgs);
        } catch (err: unknown) {
          lastErr = err;
          if (attempt < maxAttempts && isTransientDbError(err)) {
            await new Promise((r) => setTimeout(r, attempt * 150));
            continue;
          }
          throw err;
        }
      }
      throw lastErr;
    };
    activePool._hasRetryWrapper = true;
  }

  return g._postgresPool;
};

const pool = createPool();
const db = drizzle(pool, { schema });

let migrationsPromise: Promise<void> | null = null;

async function runMigrations(): Promise<void> {
  if (migrationsPromise) {
    return migrationsPromise;
  }
  migrationsPromise = executeMigrationsInternal().finally(() => {
    migrationsPromise = null;
  });
  return migrationsPromise;
}

async function executeMigrationsInternal(): Promise<void> {
  if (!process.env.DATABASE_URL && !process.env.SQL_HOST) {
    logger.info("Neither DATABASE_URL nor SQL_HOST configured. Skipping database migrations.");
    return;
  }

  const migrationsFolder = path.resolve(__dirname, "../../drizzle");
  if (!fs.existsSync(migrationsFolder)) {
    throw new Error(`Migrations folder not found at ${migrationsFolder}`);
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS "__drizzle_migrations_applied" (
      "id" serial PRIMARY KEY,
      "filename" text NOT NULL UNIQUE,
      "applied_at" timestamp NOT NULL DEFAULT now()
    );
  `);

  const appliedRes = await pool.query<{ filename: string }>(
    `SELECT "filename" FROM "__drizzle_migrations_applied"`
  );
  const appliedFiles = new Set(appliedRes.rows.map((r) => r.filename));

  const sqlFiles = fs
    .readdirSync(migrationsFolder)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  for (const file of sqlFiles) {
    if (appliedFiles.has(file)) {
      continue;
    }

    const filePath = path.join(migrationsFolder, file);
    const rawSql = fs.readFileSync(filePath, "utf-8");
    const statements = rawSql
      .split("--> statement-breakpoint")
      .map((s) => s.trim())
      .filter(Boolean);

    for (const stmt of statements) {
      const safeStmt = /^CREATE TABLE (?!IF NOT EXISTS)/i.test(stmt)
        ? stmt.replace(/^CREATE TABLE /i, "CREATE TABLE IF NOT EXISTS ")
        : stmt;
      try {
        await pool.query(safeStmt);
      } catch (stmtErr: unknown) {
        const msg = stmtErr instanceof Error ? stmtErr.message : String(stmtErr);
        const code = (stmtErr as DbErrorLike)?.code || "";
        // Allow idempotent re-application on pre-existing tables/columns/constraints
        if (
          code === "42P07" || // duplicate_table
          code === "42701" || // duplicate_column
          code === "42710" || // duplicate_object
          msg.includes("already exists")
        ) {
          continue;
        }
        logger.error({ err: stmtErr, file, statement: safeStmt }, "Database migration statement failed");
        throw stmtErr;
      }
    }

    await pool.query(
      `INSERT INTO "__drizzle_migrations_applied" ("filename") VALUES ($1) ON CONFLICT ("filename") DO NOTHING`,
      [file]
    );
  }

  logger.info("Database migrations verified and in sync.");
}

async function closePool(): Promise<void> {
  if (g._postgresPool) {
    try {
      await g._postgresPool.end();
    } catch (err: unknown) {
      logger.warn({ err }, "Error closing PostgreSQL pool");
    }
    g._postgresPool = undefined;
  }
}

export { createPool, closePool, pool, db, runMigrations };
