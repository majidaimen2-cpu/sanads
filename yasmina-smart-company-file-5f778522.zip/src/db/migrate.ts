import "dotenv/config";
import { runMigrations, closePool } from "./index.js";
import { logger } from "../server/logger.js";

async function main(): Promise<void> {
  try {
    await runMigrations();
    logger.info("Migration runner completed successfully.");
  } catch (err: unknown) {
    logger.fatal({ err }, "Migration runner failed.");
    process.exitCode = 1;
  } finally {
    await closePool();
  }
}

void main();
