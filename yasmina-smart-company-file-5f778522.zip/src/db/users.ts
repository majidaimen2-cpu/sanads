import { db } from "./index.js";
import { users, companies, auditLogs } from "./schema.js";
import { eq, desc, and, or } from "drizzle-orm";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { logger } from "../server/logger.js";

function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 600000, 64, "sha512").toString("hex");
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString("hex");
}

async function findUserForAuth(identifier: string, tenantId?: string) {
  try {
    const clean = identifier.trim().toLowerCase();
    const identityFilter = or(
      eq(users.email, clean),
      eq(users.uid, clean),
      eq(users.displayName, identifier.trim())
    );
    const whereClause = tenantId
      ? and(eq(users.tenantId, tenantId), identityFilter)
      : identityFilter;

    const rows = await db.select().from(users).where(whereClause).limit(1);
    return rows[0] || null;
  } catch (error) {
    logger.warn({ err: error }, "findUserForAuth db error");
    return null;
  }
}

async function seedInitialAdminIfNone() {
  const adminUsername = (process.env.ADMIN_USERNAME || "admin").trim().toLowerCase();
  const envPassword = process.env.ADMIN_PASSWORD?.trim();

  try {
    const existing = await db
      .select()
      .from(users)
      .where(
        or(
          eq(users.uid, adminUsername),
          eq(users.email, `${adminUsername}@yasminasanad.om`)
        )
      )
      .limit(1);

    if (existing.length === 0) {
      let effectivePassword = envPassword;
      let mustChangePassword = false;

      if (!effectivePassword) {
        if (process.env.NODE_ENV === "production") {
          throw new Error(
            "CRITICAL SECURITY ERROR: ADMIN_PASSWORD environment variable is required to seed the initial admin account in production."
          );
        }
        effectivePassword = `Sanad_${crypto.randomBytes(16).toString("base64url")}9A!`;
        mustChangePassword = true;
        const dataDir = path.resolve(process.cwd(), "data");
        fs.mkdirSync(dataDir, { recursive: true });
        const bootstrapFile = path.join(dataDir, ".initial_admin_bootstrap");
        fs.writeFileSync(
          bootstrapFile,
          `ADMIN_USERNAME=${adminUsername}\nADMIN_PASSWORD=${effectivePassword}\n`,
          { mode: 0o600 }
        );
        logger.info(
          { adminUsername, bootstrapFile },
          "Seeded initial admin account with generated one-time bootstrap password file (mode 0600)."
        );
      }

      const salt = generateSalt();
      const passwordHash = hashPassword(effectivePassword, salt);
      await db.insert(users).values({
        uid: adminUsername,
        email: `${adminUsername}@yasminasanad.om`,
        displayName: "Yasmina Master Admin",
        role: "SUPER_ADMIN",
        passwordHash,
        salt,
        permissions: JSON.stringify(["*"]),
        tenantId: "default_tenant",
        active: true,
        mustChangePassword,
      });
      logger.info({ adminUsername }, "Seeded initial admin account into PostgreSQL.");
    } else if (envPassword && existing[0]) {
      // Ensure existing admin account matches explicit ADMIN_PASSWORD from environment if configured
      const existingAdmin = existing[0];
      if (!existingAdmin.passwordHash || !existingAdmin.salt) {
        const salt = generateSalt();
        const passwordHash = hashPassword(envPassword, salt);
        await db
          .update(users)
          .set({ passwordHash, salt, active: true })
          .where(eq(users.id, existingAdmin.id));
      }
    }

    const firstAdmin = await db
      .select()
      .from(users)
      .where(eq(users.uid, adminUsername))
      .limit(1);
    return firstAdmin[0] || null;
  } catch (error) {
    logger.warn({ err: error }, "seedInitialAdminIfNone notice");
    return null;
  }
}

async function updateUserPassword(userId: number, newPassword: string) {
  try {
    const salt = generateSalt();
    const passwordHash = hashPassword(newPassword, salt);
    const result = await db
      .update(users)
      .set({
        passwordHash,
        salt,
        mustChangePassword: false,
        activeRefreshJti: null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return result[0];
  } catch (error) {
    logger.error({ err: error }, "updateUserPassword error");
    throw error;
  }
}

async function getOrCreateUser(uid: string, email: string, displayName?: string) {
  try {
    const result = await db
      .insert(users)
      .values({ uid, email, displayName: displayName || "" })
      .onConflictDoUpdate({
        target: users.uid,
        set: { email, displayName: displayName || "" },
      })
      .returning();
    return result[0];
  } catch (error) {
    logger.error({ err: error }, "Database query failed in getOrCreateUser");
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}

async function getCompaniesFromDb(tenantId: string) {
  try {
    return await db.select().from(companies).where(eq(companies.tenantId, tenantId));
  } catch (error) {
    logger.error({ err: error }, "Database query failed in getCompaniesFromDb");
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}

interface CompanyUpsertInput {
  tenantId: string;
  companyCode: string;
  name: string;
  tradeName?: string;
  taxId?: string | null;
  sector?: string;
  status?: string;
  city?: string;
  stateCountry?: string;
  contactPhone?: string;
  contactEmail?: string;
  complianceScore?: number;
  revenueMonthly?: number;
  employeesCount?: number;
  crExpiryDate?: string;
  crIssueDate?: string;
  licenseExpiryDate?: string;
  licenseNumber?: string;
}

async function upsertCompanyToDb(company: CompanyUpsertInput) {
  try {
    const tenant = company.tenantId;
    const revenueBaisa = company.revenueMonthly
      ? Math.round(company.revenueMonthly * 1000)
      : 0;
    const result = await db
      .insert(companies)
      .values({
        companyCode: company.companyCode,
        name: company.name,
        tradeName: company.tradeName || "",
        taxId: company.taxId ?? null,
        sector: company.sector || "",
        status: company.status || "Active",
        city: company.city || "",
        stateCountry: company.stateCountry || "",
        contactPhone: company.contactPhone || "",
        contactEmail: company.contactEmail || "",
        complianceScore: company.complianceScore ?? 100,
        revenueMonthlyBaisa: revenueBaisa,
        employeesCount: company.employeesCount ?? 0,
        crExpiryDate: company.crExpiryDate || "",
        crIssueDate: company.crIssueDate || "",
        licenseExpiryDate: company.licenseExpiryDate || "",
        licenseNumber: company.licenseNumber || "",
        tenantId: tenant,
      })
      .onConflictDoUpdate({
        target: companies.companyCode,
        set: {
          name: company.name,
          tradeName: company.tradeName || "",
          taxId: company.taxId ?? null,
          sector: company.sector || "",
          status: company.status || "Active",
          city: company.city || "",
          stateCountry: company.stateCountry || "",
          contactPhone: company.contactPhone || "",
          contactEmail: company.contactEmail || "",
          complianceScore: company.complianceScore ?? 100,
          revenueMonthlyBaisa: revenueBaisa,
          employeesCount: company.employeesCount ?? 0,
          crExpiryDate: company.crExpiryDate || "",
          crIssueDate: company.crIssueDate || "",
          licenseExpiryDate: company.licenseExpiryDate || "",
          licenseNumber: company.licenseNumber || "",
          tenantId: tenant,
        },
      })
      .returning();
    return result[0];
  } catch (error) {
    logger.error({ err: error }, "Database query failed in upsertCompanyToDb");
    throw new Error("Database query failed in upsertCompanyToDb.", { cause: error });
  }
}

async function deleteCompanyFromDb(identifier: string, tenantId: string) {
  return await db
    .delete(companies)
    .where(
      and(
        eq(companies.tenantId, tenantId),
        or(eq(companies.companyCode, identifier), eq(companies.taxId, identifier))
      )
    )
    .returning();
}

async function insertAuditLog(log: {
  tenantId?: string;
  actorId?: string;
  actorName?: string;
  action: string;
  resource: string;
  resourceId?: string;
  details?: string;
  ipAddress?: string;
}) {
  const result = await db
    .insert(auditLogs)
    .values({
      tenantId: log.tenantId || "default_tenant",
      actorId: log.actorId || "system",
      actorName: log.actorName || "System Admin",
      action: log.action,
      resource: log.resource,
      resourceId: log.resourceId || "",
      details: log.details || "",
      ipAddress: log.ipAddress || "127.0.0.1",
    })
    .returning();
  return result[0];
}

async function getAuditLogs(tenantId: string, limitCount = 50) {
  return await db
    .select()
    .from(auditLogs)
    .where(eq(auditLogs.tenantId, tenantId))
    .orderBy(desc(auditLogs.createdAt))
    .limit(limitCount);
}

export {
  deleteCompanyFromDb,
  findUserForAuth,
  generateSalt,
  getAuditLogs,
  getCompaniesFromDb,
  getOrCreateUser,
  hashPassword,
  insertAuditLog,
  seedInitialAdminIfNone,
  updateUserPassword,
  upsertCompanyToDb,
};
