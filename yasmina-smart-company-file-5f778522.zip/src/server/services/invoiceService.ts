import { eq, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  invoices,
  transactionFees,
} from "../../db/schema.js";
import { calculateTransactionTotal } from "../../lib/money.js";

type DbExecutor = Pick<typeof db, "execute">;

/** Current calendar year in the Asia/Muscat timezone (UTC+4, no DST). */
export function getMuscatYear(date: Date = new Date()): number {
  return Number(
    new Intl.DateTimeFormat("en-US", {
      timeZone: "Asia/Muscat",
      year: "numeric",
    }).format(date),
  );
}

async function nextSequence(
  executor: DbExecutor,
  table: "invoice_counters" | "credit_note_counters",
  tenantId: string,
  year: number,
): Promise<number> {
  // Single atomic upsert: the row lock taken by ON CONFLICT DO UPDATE serialises
  // concurrent callers for the same tenant/year, so two requests can never get the same number.
  const result = await executor.execute(sql`
    INSERT INTO ${sql.raw(`"${table}"`)} (tenant_id, year, last_sequence)
    VALUES (${tenantId}, ${year}, 1)
    ON CONFLICT (tenant_id, year)
    DO UPDATE SET last_sequence = ${sql.raw(`"${table}"`)}.last_sequence + 1
    RETURNING last_sequence;
  `);
  const rows = (result as unknown as { rows?: Array<{ last_sequence?: number | string }> }).rows;
  const seq = Number(rows?.[0]?.last_sequence);
  if (!Number.isInteger(seq) || seq < 1) {
    throw new Error(`Failed to allocate next ${table} sequence`);
  }
  return seq;
}

/**
 * Per-tenant, race-safe invoice number. Pass the surrounding transaction as `executor`
 * so a rolled-back invoice does not burn a number.
 */
export async function getNextInvoiceNumber(
  tenantId: string,
  executor: DbExecutor = db,
): Promise<string> {
  const year = getMuscatYear();
  const seq = await nextSequence(executor, "invoice_counters", tenantId, year);
  return `INV-${year}-${String(seq).padStart(6, "0")}`;
}

export async function getNextCreditNoteNumber(
  tenantId: string,
  executor: DbExecutor = db,
): Promise<string> {
  const year = getMuscatYear();
  const seq = await nextSequence(executor, "credit_note_counters", tenantId, year);
  return `CN-${year}-${String(seq).padStart(6, "0")}`;
}

export async function createInvoiceForTransaction(params: {
  tenantId: string;
  branchId?: number | null;
  transactionId: number;
  customerId: number;
  govFeeBaisa?: number;
  officeFeeBaisa?: number;
  discountBaisa?: number;
  pdfUrl?: string;
}) {
  const { tenantId, branchId, transactionId, customerId } = params;
  const [feeRow] = await db
    .select()
    .from(transactionFees)
    .where(eq(transactionFees.transactionId, transactionId))
    .limit(1);
  const govFee = params.govFeeBaisa ?? (feeRow?.govFeeBaisa || 0);
  const officeFee = params.officeFeeBaisa ?? (feeRow?.officeFeeBaisa || 0);
  const discount = params.discountBaisa ?? (feeRow?.discountBaisa || 0);
  const calculated = calculateTransactionTotal({
    govFeeBaisa: govFee,
    officeFeeBaisa: officeFee,
    discountBaisa: discount,
  });
  return await db.transaction(async (tx) => {
  const invoiceNumber = await getNextInvoiceNumber(tenantId, tx);
  const [newInvoice] = await tx
    .insert(invoices)
    .values({
      tenantId,
      branchId: branchId ?? null,
      invoiceNumber,
      transactionId,
      customerId,
      govFeeBaisa: calculated.govFeeBaisa,
      officeFeeBaisa: calculated.officeFeeBaisa,
      discountBaisa: calculated.discountBaisa,
      vatBaisa: calculated.vatBaisa,
      totalBaisa: calculated.totalBaisa,
      status: "UNPAID",
      pdfUrl: params.pdfUrl,
    })
    .returning();
  return newInvoice;
  });
}
