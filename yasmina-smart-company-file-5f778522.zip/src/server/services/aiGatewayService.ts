/**
 * AI Service Gateway (Legacy wrapper - reverted to direct Google Gemini API SDK)
 */

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "model";
  content: string;
}

export interface AiGatewayOptions {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  jsonMode?: boolean;
  systemPrompt?: string;
}

export class AiGatewayService {
  public static getApiKey(): string {
    return "";
  }

  public static getBaseUrl(): string {
    return "";
  }

  public static hasActiveApiKey(): boolean {
    return false;
  }

  public static getPrimaryModel(): string {
    return process.env.GEMINI_MODEL || "gemini-4-hydrogen";
  }

  public static async generateCompletion(
    _messages: ChatMessage[],
    _options: AiGatewayOptions = {}
  ): Promise<string | null> {
    return null;
  }

  public static async streamCompletion(
    _messages: ChatMessage[],
    _onChunk: (chunk: string) => void,
    _options: AiGatewayOptions = {}
  ): Promise<boolean> {
    return false;
  }
}
