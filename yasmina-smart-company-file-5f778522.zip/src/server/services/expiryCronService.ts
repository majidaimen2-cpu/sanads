import cron, { type ScheduledTask } from "node-cron";
import { eq, and, isNotNull } from "drizzle-orm";
import { db, pool } from "../../db/index.js";
import {
  companies,
  customerDocuments,
  employees,
  contracts,
  notifications,
  expiryJobRuns,
  auditLogs,
} from "../../db/schema.js";
import { normalizeAndValidateDate } from "./crExtractionService.js";
import {
  resolveDocTypeAr,
  normalizeDocTypeCode,
  getMuscatTodayString,
  classifyDocumentExpiry,
  discoverAllMonitoredDocuments,
  buildNotificationCopy,
  type ExpiryStatusCode,
  type AlertSeverity,
  type ExpiryClassificationResult,
  type MonitoredDocumentItem,
  type ExpiryAuditOptions,
  type ExpiryAuditRunResult,
} from "./expiryClassification.js";
import { logger } from "../logger.js";

export {
  resolveDocTypeAr,
  normalizeDocTypeCode,
  getMuscatTodayString,
  classifyDocumentExpiry,
  discoverAllMonitoredDocuments,
  buildNotificationCopy,
  type ExpiryStatusCode,
  type AlertSeverity,
  type ExpiryClassificationResult,
  type MonitoredDocumentItem,
  type ExpiryAuditOptions,
  type ExpiryAuditRunResult,
};

export async function retryFailedNotifications(
  tenantId?: string,
): Promise<number> {
  const query = tenantId
    ? `
      UPDATE "notifications"
      SET "delivery_status" = 'DELIVERED',
          "retry_count" = "retry_count" + 1,
          "last_error" = NULL
      WHERE "delivery_status" = 'FAILED'
        AND "retry_count" < 5
        AND "tenant_id" = $1
      RETURNING "id"
    `
    : `
      UPDATE "notifications"
      SET "delivery_status" = 'DELIVERED',
          "retry_count" = "retry_count" + 1,
          "last_error" = NULL
      WHERE "delivery_status" = 'FAILED'
        AND "retry_count" < 5
      RETURNING "id"
    `;
  const res = await pool.query(query, tenantId ? [tenantId] : []);
  return res.rowCount || 0;
}

export async function runExpiryAudit(
  options?: ExpiryAuditOptions,
): Promise<ExpiryAuditRunResult> {
  const startTime = Date.now();
  const referenceDate = getMuscatTodayString(options?.referenceDate);
  const triggerType = options?.triggerType || "CRON";
  const tenantFilter = options?.tenantId;
  const runId = `exp-run-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  let lockAcquired = false;
  const lockId = 88442211;

  try {
    if (triggerType === "CRON") {
      const lockRes = await pool.query(
        "SELECT pg_try_advisory_lock($1) AS locked",
        [lockId],
      );
      lockAcquired = Boolean(lockRes.rows[0]?.locked);
      if (!lockAcquired) {
        return {
          runId,
          referenceDate,
          totalScanned: 0,
          expiredCount: 0,
          expiringTodayCount: 0,
          expiring7DaysCount: 0,
          expiring30DaysCount: 0,
          expiringSoonCount: 0,
          needsReviewCount: 0,
          validCount: 0,
          noExpiryCount: 0,
          notificationsCreated: 0,
          notificationsDeduplicated: 0,
          failedDeliveries: 0,
          retriedDeliveries: 0,
          durationMs: Date.now() - startTime,
        };
      }
    }

    const retriedDeliveries = await retryFailedNotifications(tenantFilter);

    const discovered = await discoverAllMonitoredDocuments(tenantFilter, {
      referenceDate,
      warningDays: options?.warningDays,
      urgentDays: options?.urgentDays,
    });

    // Batch-preload existing idempotency keys to avoid N+1 per-item notification checks (#96)
    const existingKeysRows = tenantFilter
      ? await db
          .select({ idempotencyKey: notifications.idempotencyKey })
          .from(notifications)
          .where(
            and(
              eq(notifications.tenantId, tenantFilter),
              isNotNull(notifications.idempotencyKey),
            ),
          )
      : await db
          .select({ idempotencyKey: notifications.idempotencyKey })
          .from(notifications)
          .where(isNotNull(notifications.idempotencyKey));

    const existingIdempotencyKeys = new Set<string>();
    for (const r of existingKeysRows) {
      if (r.idempotencyKey) {
        existingIdempotencyKeys.add(r.idempotencyKey);
      }
    }

    let expiredCount = 0;
    let expiringTodayCount = 0;
    let expiring7DaysCount = 0;
    let expiring30DaysCount = 0;
    let needsReviewCount = 0;
    let validCount = 0;
    let noExpiryCount = 0;
    let notificationsCreated = 0;
    let notificationsDeduplicated = 0;
    let failedDeliveries = 0;

    const actionableStages: ExpiryStatusCode[] = [
      "EXPIRED",
      "EXPIRING_TODAY",
      "EXPIRING_7",
      "EXPIRING_30",
      "NEEDS_REVIEW",
    ];

    for (const item of discovered) {
      if (item.status === "EXPIRED") expiredCount++;
      else if (item.status === "EXPIRING_TODAY") expiringTodayCount++;
      else if (item.status === "EXPIRING_7") expiring7DaysCount++;
      else if (item.status === "EXPIRING_30") expiring30DaysCount++;
      else if (item.status === "NEEDS_REVIEW") needsReviewCount++;
      else if (item.status === "VALID") validCount++;
      else if (item.status === "NO_EXPIRY") noExpiryCount++;

      try {
        if (item.documentId) {
          await pool.query(
            `UPDATE "customer_documents"
             SET "expiry_status" = $1,
                 "needs_review" = $2,
                 "expiry_date" = COALESCE($3, "expiry_date")
             WHERE "id" = $4 AND "tenant_id" = $5`,
            [
              item.status,
              item.needsReview,
              item.expiryDate,
              item.documentId,
              item.tenantId,
            ],
          );
        }

        if (!actionableStages.includes(item.status)) {
          continue;
        }

        const idempotencyKey = `notif:${item.tenantId}:${item.sourceEntity}:${item.sourceId}:${item.docTypeCode}:${item.alertStage}:${item.expiryDate || "MISSING"}`;

        if (existingIdempotencyKeys.has(idempotencyKey)) {
          notificationsDeduplicated++;
          continue;
        }

        const copy = buildNotificationCopy(item);

        const shouldSimulateFailure =
          Boolean(options?.simulateDeliveryFailureForDocNumber) &&
          item.docNumber === options?.simulateDeliveryFailureForDocNumber;

        const deliveryStatus = shouldSimulateFailure ? "FAILED" : "DELIVERED";
        const lastError = shouldSimulateFailure
          ? "SIMULATED_TRANSIENT_DELIVERY_FAILURE"
          : null;

        const insertRes = await pool.query(
          `INSERT INTO "notifications" (
            "tenant_id",
            "company_id",
            "company_name",
            "owner_name",
            "document_id",
            "source_entity",
            "source_id",
            "doc_type",
            "doc_number",
            "expiry_date",
            "days_remaining",
            "alert_stage",
            "title",
            "message",
            "type",
            "severity",
            "is_read",
            "status",
            "delivery_status",
            "retry_count",
            "last_error",
            "idempotency_key",
            "link"
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12,
            $13, $14, $15, $16, false, 'UNREAD', $17, 0, $18, $19, $20
          )
          ON CONFLICT ("idempotency_key") DO NOTHING
          RETURNING "id"`,
          [
            item.tenantId,
            item.companyId,
            item.companyName,
            item.ownerName,
            item.documentId,
            item.sourceEntity,
            item.sourceId,
            item.docTypeCode,
            item.docNumber,
            item.expiryDate,
            item.daysRemaining,
            item.alertStage,
            copy.title,
            copy.message,
            copy.type,
            item.severity,
            deliveryStatus,
            lastError,
            idempotencyKey,
            item.link,
          ],
        );

        if ((insertRes.rowCount || 0) > 0) {
          existingIdempotencyKeys.add(idempotencyKey);
          notificationsCreated++;
          if (shouldSimulateFailure) {
            failedDeliveries++;
          }
        } else {
          existingIdempotencyKeys.add(idempotencyKey);
          notificationsDeduplicated++;
        }
      } catch (itemErr) {
        failedDeliveries++;
        logger.error(
          { err: itemErr, itemKey: item.key, tenantId: item.tenantId },
          "Expiry audit item processing error",
        );
      }
    }

    const durationMs = Date.now() - startTime;
    const expiringSoonCount = expiring7DaysCount + expiring30DaysCount;

    await db.insert(expiryJobRuns).values({
      runId,
      tenantId: tenantFilter || "ALL",
      triggerType,
      referenceDateMuscat: referenceDate,
      status: "COMPLETED",
      totalScanned: discovered.length,
      expiredCount,
      expiringTodayCount,
      expiring7DaysCount,
      expiring30DaysCount,
      validCount,
      needsReviewCount,
      noExpiryCount,
      notificationsCreated,
      notificationsSkippedDuplicate: notificationsDeduplicated,
      notificationsRetried: retriedDeliveries,
      notificationsFailed: failedDeliveries,
      durationMs,
    });

    return {
      runId,
      referenceDate,
      totalScanned: discovered.length,
      expiredCount,
      expiringTodayCount,
      expiring7DaysCount,
      expiring30DaysCount,
      expiringSoonCount,
      needsReviewCount,
      validCount,
      noExpiryCount,
      notificationsCreated,
      notificationsDeduplicated,
      failedDeliveries,
      retriedDeliveries,
      durationMs,
    };
  } catch (error) {
    const durationMs = Date.now() - startTime;
    const errMsg = error instanceof Error ? error.message : String(error);
    logger.error({ err: error }, "Error during expiry audit");
    try {
      await db.insert(expiryJobRuns).values({
        runId,
        tenantId: tenantFilter || "ALL",
        triggerType,
        referenceDateMuscat: referenceDate,
        status: "FAILED",
        durationMs,
        errorDetails: errMsg,
      });
    } catch {
      // Ignore secondary logging error
    }
    throw error;
  } finally {
    if (lockAcquired) {
      try {
        await pool.query("SELECT pg_advisory_unlock($1)", [lockId]);
      } catch {
        // Ignore unlock error
      }
    }
  }
}

export async function updateMonitoredDocumentExpiry(params: {
  tenantId: string;
  sourceEntity: "companies" | "customer_documents" | "employees" | "contracts";
  sourceId: string;
  expiryDate?: string | null;
  hasNoExpiry?: boolean;
  actorId?: string;
  actorName: string;
  ipAddress?: string;
  referenceDate?: string | Date;
}): Promise<{
  updated: boolean;
  normalizedExpiryDate: string | null;
  classification: ExpiryClassificationResult;
  auditResult: ExpiryAuditRunResult;
}> {
  const {
    tenantId,
    sourceEntity,
    sourceId,
    hasNoExpiry,
    actorId,
    actorName,
    ipAddress,
    referenceDate,
  } = params;
  const rawDate =
    params.expiryDate !== undefined ? String(params.expiryDate || "").trim() : "";

  let normalizedDate: string | null = null;
  if (!hasNoExpiry && rawDate) {
    normalizedDate = normalizeAndValidateDate(rawDate);
    if (!normalizedDate) {
      throw new Error(
        "تاريخ الانتهاء المدخل غير صالح في التقويم. يرجى إدخال تاريخ صحيح بصيغة YYYY-MM-DD.",
      );
    }
  }

  let previousValue: Record<string, unknown> | null = null;

  if (sourceEntity === "companies") {
    const isLicense = sourceId.endsWith(":LICENSE");
    const compId = parseInt(sourceId.split(":")[0], 10);
    const [existing] = await db
      .select({
        id: companies.id,
        crExpiryDate: companies.crExpiryDate,
        licenseExpiryDate: companies.licenseExpiryDate,
      })
      .from(companies)
      .where(and(eq(companies.id, compId), eq(companies.tenantId, tenantId)));

    if (!existing) {
      throw new Error("الشركة غير موجودة أو لا تملك صلاحية تعديلها.");
    }

    if (isLicense) {
      previousValue = { licenseExpiryDate: existing.licenseExpiryDate };
      await db
        .update(companies)
        .set({ licenseExpiryDate: normalizedDate, updatedAt: new Date() })
        .where(and(eq(companies.id, compId), eq(companies.tenantId, tenantId)));
    } else {
      previousValue = { crExpiryDate: existing.crExpiryDate };
      await db
        .update(companies)
        .set({ crExpiryDate: normalizedDate, updatedAt: new Date() })
        .where(and(eq(companies.id, compId), eq(companies.tenantId, tenantId)));

      await pool.query(
        `UPDATE "customer_documents"
         SET "expiry_date" = $1,
             "raw_expiry_date" = $2,
             "has_no_expiry" = $3,
             "updated_at" = NOW()
         WHERE "company_id" = $4 AND "tenant_id" = $5
           AND ("doc_type" = 'CR' OR "doc_type" = 'COMMERCIAL_REGISTRATION' OR "doc_type" = 'السجل التجاري')`,
        [
          normalizedDate,
          rawDate || null,
          Boolean(hasNoExpiry),
          compId,
          tenantId,
        ],
      );
    }
  } else if (sourceEntity === "customer_documents") {
    const docId = parseInt(sourceId, 10);
    const [existing] = await db
      .select()
      .from(customerDocuments)
      .where(
        and(
          eq(customerDocuments.id, docId),
          eq(customerDocuments.tenantId, tenantId),
        ),
      );

    if (!existing) {
      throw new Error("الوثيقة غير موجودة أو لا تملك صلاحية تعديلها.");
    }

    previousValue = {
      expiryDate: existing.expiryDate,
      rawExpiryDate: existing.rawExpiryDate,
      hasNoExpiry: existing.hasNoExpiry,
    };

    const classification = classifyDocumentExpiry({
      expiryDate: normalizedDate,
      hasNoExpiry: Boolean(hasNoExpiry),
      referenceDate,
    });

    await db
      .update(customerDocuments)
      .set({
        expiryDate: normalizedDate,
        rawExpiryDate: rawDate || null,
        hasNoExpiry: Boolean(hasNoExpiry),
        expiryStatus: classification.status,
        needsReview: classification.needsReview,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(customerDocuments.id, docId),
          eq(customerDocuments.tenantId, tenantId),
        ),
      );

    if (
      existing.companyId &&
      normalizeDocTypeCode(existing.docType) === "CR"
    ) {
      await db
        .update(companies)
        .set({ crExpiryDate: normalizedDate, updatedAt: new Date() })
        .where(
          and(
            eq(companies.id, existing.companyId),
            eq(companies.tenantId, tenantId),
          ),
        );
    }
  } else if (sourceEntity === "employees") {
    const [empIdStr, subType] = sourceId.split(":");
    const empId = parseInt(empIdStr, 10);
    const [existing] = await db
      .select()
      .from(employees)
      .where(and(eq(employees.id, empId), eq(employees.tenantId, tenantId)));

    if (!existing) {
      throw new Error("سجل الموظف غير موجود.");
    }

    if (subType === "PASSPORT") {
      previousValue = { passportExpiry: existing.passportExpiry };
      await db
        .update(employees)
        .set({ passportExpiry: normalizedDate, updatedAt: new Date() })
        .where(and(eq(employees.id, empId), eq(employees.tenantId, tenantId)));
    } else {
      previousValue = { residenceExpiry: existing.residenceExpiry };
      await db
        .update(employees)
        .set({ residenceExpiry: normalizedDate, updatedAt: new Date() })
        .where(and(eq(employees.id, empId), eq(employees.tenantId, tenantId)));
    }
  } else if (sourceEntity === "contracts") {
    const contractId = parseInt(sourceId, 10);
    const [existing] = await db
      .select()
      .from(contracts)
      .where(
        and(eq(contracts.id, contractId), eq(contracts.tenantId, tenantId)),
      );

    if (!existing) {
      throw new Error("العقد غير موجود.");
    }

    previousValue = { endDate: existing.endDate };
    await db
      .update(contracts)
      .set({
        endDate: normalizedDate || existing.endDate,
        updatedAt: new Date(),
      })
      .where(
        and(eq(contracts.id, contractId), eq(contracts.tenantId, tenantId)),
      );
  }

  const classification = classifyDocumentExpiry({
    expiryDate: normalizedDate,
    hasNoExpiry: Boolean(hasNoExpiry),
    referenceDate,
  });

  await db.insert(auditLogs).values({
    tenantId,
    actorId: actorId || null,
    actorName: actorName || "System",
    action: "UPDATE_DOCUMENT_EXPIRY",
    resource: sourceEntity,
    resourceId: sourceId,
    details: JSON.stringify({
      previousValue,
      newValue: {
        expiryDate: normalizedDate,
        hasNoExpiry: Boolean(hasNoExpiry),
        status: classification.status,
      },
    }),
    ipAddress: ipAddress || "127.0.0.1",
  });

  const auditResult = await runExpiryAudit({
    tenantId,
    referenceDate,
    triggerType: "DATE_UPDATE",
  });

  return {
    updated: true,
    normalizedExpiryDate: normalizedDate,
    classification,
    auditResult,
  };
}

let scheduledTask: ScheduledTask | null = null;

export function startExpiryCron() {
  if (scheduledTask) {
    try {
      scheduledTask.stop();
    } catch {
      // Ignore stop error
    }
    scheduledTask = null;
  }

  scheduledTask = cron.schedule(
    "0 8 * * *",
    async () => {
      try {
        await runExpiryAudit({ triggerType: "CRON" });
      } catch (err) {
        logger.error({ err }, "[ExpiryCron] Scheduled run failed");
      }
    },
    {
      timezone: "Asia/Muscat",
    },
  );

  setTimeout(() => {
    runExpiryAudit({ triggerType: "CRON" }).catch((err) => {
      logger.warn({ err }, "[ExpiryCron] Initial startup check warning");
    });
  }, 5000);

  logger.info(
    "[ExpiryCron] Scheduled daily document expiry audit at 08:00 AM (Asia/Muscat).",
  );
}

export const initExpiryCron = startExpiryCron;
