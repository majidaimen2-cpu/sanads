import { eq, and, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { cashSessions, payments, expenses } from "../../db/schema.js";

interface HttpError extends Error {
  status?: number;
  code?: string;
  details?: unknown;
}

export async function openCashSession(params: {
  tenantId: string;
  branchId?: number | null;
  userId?: number | null;
  openingBalanceBaisa: number;
  notes?: string;
}) {
  const { tenantId, branchId, userId, openingBalanceBaisa, notes } = params;
  if (userId) {
    const [existingOpen] = await db
      .select()
      .from(cashSessions)
      .where(
        and(
          eq(cashSessions.tenantId, tenantId),
          eq(cashSessions.openedBy, userId),
          eq(cashSessions.status, "OPEN"),
        ),
      )
      .limit(1);
    if (existingOpen) {
      const error: HttpError = new Error(
        "يوجد بالفعل صندوق كاش مفتوح لهذا المستخدم",
      );
      error.status = 409;
      error.code = "SESSION_ALREADY_OPEN";
      error.details = { existingSessionId: existingOpen.id };
      throw error;
    }
  }
  const [session] = await db
    .insert(cashSessions)
    .values({
      tenantId,
      branchId: branchId ?? null,
      openedBy: userId || 1,
      openingBalanceBaisa,
      status: "OPEN",
      notes,
    })
    .returning();
  return session;
}

export async function closeCashSession(params: {
  tenantId: string;
  sessionId: number;
  userId?: number | null;
  closingBalanceBaisa: number;
  notes?: string;
}) {
  const { tenantId, sessionId, userId, closingBalanceBaisa, notes } = params;
  const [session] = await db
    .select()
    .from(cashSessions)
    .where(
      and(
        eq(cashSessions.id, sessionId),
        eq(cashSessions.tenantId, tenantId),
      ),
    )
    .limit(1);
  if (!session) {
    const error: HttpError = new Error("جلسة الصندوق غير موجودة");
    error.status = 404;
    error.code = "NOT_FOUND";
    throw error;
  }
  if (session.status === "CLOSED") {
    const error: HttpError = new Error("جلسة الصندوق مغلقة بالفعل");
    error.status = 400;
    error.code = "SESSION_ALREADY_CLOSED";
    throw error;
  }
  const cashPayments = await db
    .select({ total: sql`coalesce(sum(${payments.amountBaisa}), 0)` })
    .from(payments)
    .where(
      and(
        eq(payments.cashSessionId, sessionId),
        eq(payments.tenantId, tenantId),
        eq(payments.method, "CASH"),
      ),
    );
  const totalCashInBaisa = Number(cashPayments[0]?.total ?? 0);
  const sessionExpenses = await db
    .select({ total: sql`coalesce(sum(${expenses.amountBaisa}), 0)` })
    .from(expenses)
    .where(
      and(
        eq(expenses.cashSessionId, sessionId),
        eq(expenses.tenantId, tenantId),
      ),
    );
  const totalExpensesBaisa = Number(sessionExpenses[0]?.total ?? 0);
  const expectedBalanceBaisa =
    session.openingBalanceBaisa + totalCashInBaisa - totalExpensesBaisa;
  const varianceBaisa = closingBalanceBaisa - expectedBalanceBaisa;
  const combinedNotes = [session.notes, notes].filter(Boolean).join(" | ");
  const [updatedSession] = await db
    .update(cashSessions)
    .set({
      status: "CLOSED",
      closedBy: userId ?? null,
      closingBalanceBaisa,
      expectedBalanceBaisa,
      varianceBaisa,
      notes: combinedNotes,
      closedAt: new Date(),
    })
    .where(
      and(
        eq(cashSessions.id, sessionId),
        eq(cashSessions.tenantId, tenantId),
      ),
    )
    .returning();
  return { ...updatedSession, totalCashInBaisa, totalExpensesBaisa };
}
