import { eq, and, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  transactions,
  transactionSteps,
  notifications,
  customers,
} from "../../db/schema.js";

interface HttpError extends Error {
  status?: number;
  code?: string;
}

export async function generateTransactionNumber(
  tenantId: string,
): Promise<string> {
  const year = new Date().getFullYear();
  const countResult = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(transactions)
    .where(
      and(
        eq(transactions.tenantId, tenantId),
        sql`created_at >= ${new Date(year, 0, 1)}`,
      ),
    );
  const nextNum = Number(countResult[0]?.count ?? 0) + 1;
  return `YAS-${year}-${String(nextNum).padStart(6, "0")}`;
}

export async function appendTransactionStep(params: {
  tenantId: string;
  transactionId: number;
  stepName: string;
  status: string;
  notes?: string;
  userId?: number | null;
  /** Pass the surrounding DB transaction so the step commits or rolls back with the caller. */
  executor?: Pick<typeof db, "select" | "insert" | "update">;
}) {
  const { tenantId, transactionId, stepName, status, notes, userId } = params;
  const d = params.executor ?? db;
  const [tx] = await d
    .select()
    .from(transactions)
    .where(
      and(
        eq(transactions.id, transactionId),
        eq(transactions.tenantId, tenantId),
      ),
    )
    .limit(1);
  if (!tx) {
    const error: HttpError = new Error("المعاملة غير موجودة");
    error.status = 404;
    error.code = "NOT_FOUND";
    throw error;
  }
  const [step] = await d
    .insert(transactionSteps)
    .values({
      transactionId,
      stepName,
      status,
      notes,
      userId: userId ?? null,
    })
    .returning();
  const [updatedTx] = await d
    .update(transactions)
    .set({ status, updatedAt: new Date() })
    .where(
      and(
        eq(transactions.id, transactionId),
        eq(transactions.tenantId, tenantId),
      ),
    )
    .returning();
  const [customer] = await d
    .select()
    .from(customers)
    .where(
      and(eq(customers.id, tx.customerId), eq(customers.tenantId, tenantId)),
    )
    .limit(1);
  if (customer && customer.phone) {
    await d.insert(notifications).values({
      tenantId,
      type: "TRANSACTION_STATUS_UPDATE",
      title: `تحديث حالة المعاملة: ${tx.number}`,
      message: `تم تحديث حالة معاملتكم (${tx.number}) إلى: ${status} - ${stepName}`,
      recipient: customer.phone,
      channel: "whatsapp",
      status: "PENDING",
    });
  }
  return { transaction: updatedTx, step };
}
