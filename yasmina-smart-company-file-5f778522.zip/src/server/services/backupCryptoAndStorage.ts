import fs from "fs";
import path from "path";
import crypto from "crypto";
import { Transform } from "stream";
import { pipeline } from "stream/promises";
import { GoogleAuth } from "google-auth-library";

export const SCHEMA_VERSION = "2.1.0";
export const APP_VERSION = "1.0.0";
export const ENCRYPTION_MAGIC = Buffer.from("YASBKP02", "ascii"); // 8 bytes
export const ADVISORY_LOCK_KEY = 88442211;
export const GCM_AUTH_TAG_LENGTH = 16;

export const EXCLUDED_SYSTEM_TABLES: Record<string, string> = {
  backup_history:
    "System backup telemetry table managed outside snapshot payload to avoid recursive self-nesting.",
  backup_sync_outbox:
    "Transactional outbox queue table tracking in-flight replication jobs; transient state is managed by the sync worker.",
  __drizzle_migrations:
    "ORM schema migration journal captured separately in manifest schemaVersion metadata.",
  __drizzle_migrations_applied:
    "Applied SQL migration ledger tracked by migration runner.",
};

export type ProtectionState =
  | "DATABASE_SAVE_SUCCESSFUL"
  | "LOCAL_BACKUP_SUCCESSFUL"
  | "CLOUD_BACKUP_SUCCESSFUL"
  | "BACKUP_PENDING"
  | "BACKUP_FAILED"
  | "RECOVERY_VERIFIED";

export interface BackupCoverageReport {
  schemaVersion: string;
  inspectedAt: string;
  totalPublicTablesInDb: number;
  includedTables: string[];
  excludedTables: Array<{
    tableName: string;
    reason: string;
    isSafeExclusion: boolean;
  }>;
  tableRecordCounts: Record<string, number>;
  tableChecksums: Record<string, string>;
  protectedFiles: Array<{
    relativePath: string;
    sizeBytes: number;
    sha256: string;
  }>;
  coveragePercentage: number;
}

export interface DatabaseBackupManifest {
  backupId: string;
  createdAt: string;
  schemaVersion: string;
  appVersion: string;
  databaseEngine: string;
  pgSnapshotId: string;
  triggerType: "MANUAL" | "SCHEDULED" | "OUTBOX_SYNC" | "PRE_RESTORE_SAFETY";
  retentionTier: "DAILY" | "WEEKLY" | "MONTHLY";
  encryption: {
    enabled: boolean;
    algorithm: "AES-256-GCM";
    keyId: string;
    encryptedSha256: string;
    encryptedSizeBytes: number;
  };
  plaintextSha256: string;
  plaintextSizeBytes: number;
  tables: Record<string, number>;
  totalTables: number;
  totalRecords: number;
  coverageReport: BackupCoverageReport;
  localStatus: "COMPLETED" | "FAILED" | "PENDING";
  cloudStatus: "COMPLETED" | "FAILED" | "PENDING";
  restoreVerifyStatus: "RECOVERY_VERIFIED" | "FAILED" | "NOT_TESTED";
  localFilePath: string;
  cloudObjectUri: string | null;
  durationMs: number;
  protectionState: ProtectionState;
}

export interface RestoreVerificationReport {
  backupId: string;
  verifiedAt: string;
  isolatedSchemaName: string;
  success: boolean;
  sourceUsed: "LOCAL_PRIMARY" | "CLOUD_FAILOVER";
  checksumVerified: boolean;
  decryptionVerified: boolean;
  schemaCompatible: boolean;
  tablesRestored: number;
  expectedTables: number;
  recordsRestored: number;
  expectedRecords: number;
  tableComparison: Record<
    string,
    { expected: number; restored: number; matches: boolean }
  >;
  foreignKeyChecksPassed: boolean;
  businessInvariantsPassed: boolean;
  durationMs: number;
  errors: string[];
}

export interface StorageEnvironmentReport {
  localBackupDir: string;
  isEphemeralContainerDisk: boolean;
  filesystemType: string;
  durabilityWarning: string | null;
  cloudProvider:
    | "GOOGLE_CLOUD_STORAGE"
    | "CUSTOM_OBJECT_ENDPOINT"
    | "INDEPENDENT_LOCAL_CLOUD_VAULT";
  cloudBucketConfigured: boolean;
  cloudDestinationLabel: string;
  encryptionKeySource: "ENV_BACKUP_ENCRYPTION_KEY";
}

export function getLocalBackupDir(): string {
  return (
    process.env.LOCAL_BACKUP_DIR?.trim() ||
    path.join(process.cwd(), "data", "backups")
  );
}

export function getCloudVaultDir(): string {
  return (
    process.env.CLOUD_VAULT_DIR?.trim() ||
    path.join(process.cwd(), "data", "cloud_vault")
  );
}

export function validateSafeIdentifier(id: string): string {
  const clean = path.basename(String(id || "").trim());
  if (
    !clean ||
    clean !== id ||
    clean.includes("..") ||
    clean.includes("/") ||
    clean.includes("\\") ||
    !/^[a-zA-Z0-9._-]+$/.test(clean)
  ) {
    throw new Error(
      "Invalid or unsafe backup identifier blocked against path traversal",
    );
  }
  return clean;
}

export function redactSensitiveError(err: unknown): string {
  const msg =
    err instanceof Error ? err.message : String(err || "Unknown error");
  return msg
    .replace(/postgres(?:ql)?:\/\/[^\s"']+/gi, "postgresql://[REDACTED]")
    .replace(/Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi, "Bearer [REDACTED]")
    .replace(
      /(password|secret|token|key)\s*[:=]\s*[^\s,;]+/gi,
      "$1=[REDACTED]",
    )
    .slice(0, 450);
}

export function detectStorageEnvironment(): StorageEnvironmentReport {
  const localDir = getLocalBackupDir();
  let fstype = "unknown";
  let isEphemeral = Boolean(process.env.K_SERVICE);

  try {
    if (fs.existsSync("/proc/mounts")) {
      const mounts = fs.readFileSync("/proc/mounts", "utf-8").split("\n");
      let bestMatchLen = -1;
      for (const line of mounts) {
        const parts = line.split(" ");
        if (parts.length >= 3) {
          const mountPoint = parts[1];
          const type = parts[2];
          if (
            localDir.startsWith(mountPoint) &&
            mountPoint.length > bestMatchLen
          ) {
            bestMatchLen = mountPoint.length;
            fstype = type;
          }
        }
      }
    }
  } catch {
    // Ignore /proc/mounts read errors on non-Linux hosts
  }

  if (fstype === "overlay" || fstype === "tmpfs") {
    isEphemeral = true;
  } else if (process.env.LOCAL_BACKUP_PERSISTENT_VOLUME === "true") {
    isEphemeral = false;
  }

  const gcsBucket = process.env.CLOUD_BACKUP_BUCKET?.trim();
  const customEndpoint = process.env.CLOUD_BACKUP_ENDPOINT?.trim();

  let cloudProvider: StorageEnvironmentReport["cloudProvider"] =
    "INDEPENDENT_LOCAL_CLOUD_VAULT";
  let cloudDestinationLabel = `Independent Object Vault (${getCloudVaultDir()})`;
  let cloudBucketConfigured = false;

  if (gcsBucket) {
    cloudProvider = "GOOGLE_CLOUD_STORAGE";
    cloudDestinationLabel = `gs://${gcsBucket}/${process.env.CLOUD_BACKUP_PREFIX || "yasmina-backups"}`;
    cloudBucketConfigured = true;
  } else if (customEndpoint) {
    cloudProvider = "CUSTOM_OBJECT_ENDPOINT";
    cloudDestinationLabel = customEndpoint;
    cloudBucketConfigured = true;
  }

  const durabilityWarning = isEphemeral
    ? "Local directory resides on container overlay filesystem (ephemeral across container replacements). Mount a persistent volume at LOCAL_BACKUP_DIR and configure CLOUD_BACKUP_BUCKET for cross-instance durability."
    : null;

  return {
    localBackupDir: localDir,
    isEphemeralContainerDisk: isEphemeral,
    filesystemType: fstype,
    durabilityWarning,
    cloudProvider,
    cloudBucketConfigured,
    cloudDestinationLabel,
    encryptionKeySource: "ENV_BACKUP_ENCRYPTION_KEY",
  };
}

/**
 * Requires BACKUP_ENCRYPTION_KEY environment variable (>= 32 chars).
 * Fails closed without falling back to hardcoded strings or world-accessible /tmp files (#12).
 */
export function getMasterEncryptionSecret(): { secret: Buffer; keyId: string } {
  const envKey = process.env.BACKUP_ENCRYPTION_KEY?.trim();
  if (!envKey || envKey.length < 32) {
    throw new Error(
      "CRITICAL: BACKUP_ENCRYPTION_KEY environment variable is required and must be at least 32 characters long.",
    );
  }
  return {
    secret: crypto.createHash("sha256").update(envKey).digest(),
    keyId: process.env.BACKUP_ENCRYPTION_KEY_ID || "env-master-key-v1",
  };
}

export function encryptBackupBuffer(plainBuffer: Buffer): {
  encryptedBuffer: Buffer;
  keyId: string;
  encryptedSha256: string;
} {
  const { secret, keyId } = getMasterEncryptionSecret();
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const derivedKey = crypto.scryptSync(secret, salt, 32);

  const cipher = crypto.createCipheriv("aes-256-gcm", derivedKey, iv, {
    authTagLength: GCM_AUTH_TAG_LENGTH,
  });
  const ciphertext = Buffer.concat([
    cipher.update(plainBuffer),
    cipher.final(),
  ]);
  const authTag = cipher.getAuthTag();
  if (authTag.length !== GCM_AUTH_TAG_LENGTH) {
    throw new Error("Invalid AES-256-GCM authentication tag length");
  }

  const encryptedBuffer = Buffer.concat([
    ENCRYPTION_MAGIC, // 8 bytes
    salt, // 16 bytes
    iv, // 12 bytes
    authTag, // 16 bytes
    ciphertext,
  ]);

  const encryptedSha256 = crypto
    .createHash("sha256")
    .update(encryptedBuffer)
    .digest("hex");

  return { encryptedBuffer, keyId, encryptedSha256 };
}

export function decryptBackupBuffer(encryptedBuffer: Buffer): Buffer {
  if (encryptedBuffer.length < 52) {
    throw new Error(
      "Encrypted backup buffer is truncated or invalid (< 52 bytes)",
    );
  }
  const magic = encryptedBuffer.subarray(0, 8);
  if (!magic.equals(ENCRYPTION_MAGIC)) {
    throw new Error("Invalid backup encryption magic header");
  }

  const salt = encryptedBuffer.subarray(8, 24);
  const iv = encryptedBuffer.subarray(24, 36);
  const authTag = encryptedBuffer.subarray(36, 52);
  if (authTag.length !== GCM_AUTH_TAG_LENGTH) {
    throw new Error("Invalid AES-256-GCM authTag length in backup header");
  }
  const ciphertext = encryptedBuffer.subarray(52);

  const { secret } = getMasterEncryptionSecret();
  const derivedKey = crypto.scryptSync(secret, salt, 32);

  const decipher = crypto.createDecipheriv("aes-256-gcm", derivedKey, iv, {
    authTagLength: GCM_AUTH_TAG_LENGTH,
  });
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

/**
 * Streaming file encryption using Node stream pipeline (#101).
 * Writes [MAGIC(8)][SALT(16)][IV(12)][ PLACEHOLDER_TAG(16) ][CIPHERTEXT...], then patches the 16-byte GCM authTag at offset 36.
 */
export async function encryptBackupStream(
  inputFilePath: string,
  outputFilePath: string,
): Promise<{ keyId: string; encryptedSha256: string; encryptedSizeBytes: number }> {
  const { secret, keyId } = getMasterEncryptionSecret();
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const derivedKey = crypto.scryptSync(secret, salt, 32);

  const dir = path.dirname(outputFilePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  }

  const tempPath = `${outputFilePath}.tmp.${process.pid}.${Date.now()}`;
  const headerPlaceholder = Buffer.concat([
    ENCRYPTION_MAGIC,
    salt,
    iv,
    Buffer.alloc(GCM_AUTH_TAG_LENGTH, 0),
  ]);
  fs.writeFileSync(tempPath, headerPlaceholder, { mode: 0o600 });

  const cipher = crypto.createCipheriv("aes-256-gcm", derivedKey, iv, {
    authTagLength: GCM_AUTH_TAG_LENGTH,
  });
  const readStream = fs.createReadStream(inputFilePath);
  const writeStream = fs.createWriteStream(tempPath, {
    flags: "a",
    mode: 0o600,
  });

  await pipeline(readStream, cipher, writeStream);

  const authTag = cipher.getAuthTag();
  const fd = fs.openSync(tempPath, "r+");
  try {
    fs.writeSync(fd, authTag, 0, GCM_AUTH_TAG_LENGTH, 36);
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }

  const hash = crypto.createHash("sha256");
  let encryptedSizeBytes = 0;
  await pipeline(
    fs.createReadStream(tempPath),
    new Transform({
      transform(chunk: Buffer, _enc, cb) {
        encryptedSizeBytes += chunk.length;
        hash.update(chunk);
        cb();
      },
    }),
  );

  fs.renameSync(tempPath, outputFilePath);
  return {
    keyId,
    encryptedSha256: hash.digest("hex"),
    encryptedSizeBytes,
  };
}

export function writeFileAtomically(
  targetPath: string,
  contentBuffer: Buffer,
): void {
  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  }

  const tempPath = `${targetPath}.tmp.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString("hex")}`;
  const expectedSha = crypto
    .createHash("sha256")
    .update(contentBuffer)
    .digest("hex");

  let fd: number | null = null;
  try {
    fd = fs.openSync(tempPath, "w", 0o600);
    fs.writeFileSync(fd, contentBuffer);
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = null;

    const writtenBuf = fs.readFileSync(tempPath);
    const writtenSha = crypto
      .createHash("sha256")
      .update(writtenBuf)
      .digest("hex");
    if (
      writtenBuf.length !== contentBuffer.length ||
      writtenSha !== expectedSha
    ) {
      throw new Error(
        "Atomic write verification failed: written checksum mismatch",
      );
    }

    fs.renameSync(tempPath, targetPath);
    try {
      fs.chmodSync(targetPath, 0o600);
    } catch {
      // Ignore chmod error on non-POSIX filesystems
    }
  } catch (err) {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch {
        // Ignore close error
      }
    }
    if (fs.existsSync(tempPath)) {
      try {
        fs.unlinkSync(tempPath);
      } catch {
        // Ignore unlink error
      }
    }
    throw err;
  }
}

export function collectProtectedFiles(): {
  filesMeta: Array<{ relativePath: string; sizeBytes: number; sha256: string }>;
  filesPayload: Record<string, string>;
} {
  const filesMeta: Array<{
    relativePath: string;
    sizeBytes: number;
    sha256: string;
  }> = [];
  const filesPayload: Record<string, string> = {};

  const candidateFiles = [
    "data/whatsapp_chats.json",
    "data/whatsapp_messages.json",
    "data/customer_requests.json",
  ];

  const uploadsDir = path.join(process.cwd(), "data", "uploads");
  if (fs.existsSync(uploadsDir)) {
    try {
      for (const entry of fs.readdirSync(uploadsDir)) {
        const full = path.join(uploadsDir, entry);
        if (fs.statSync(full).isFile()) {
          candidateFiles.push(path.join("data", "uploads", entry));
        }
      }
    } catch {
      // Ignore directory read error
    }
  }

  for (const relPath of candidateFiles) {
    const absPath = path.join(process.cwd(), relPath);
    if (fs.existsSync(absPath)) {
      try {
        const buf = fs.readFileSync(absPath);
        const sha256 = crypto.createHash("sha256").update(buf).digest("hex");
        filesMeta.push({
          relativePath: relPath,
          sizeBytes: buf.length,
          sha256,
        });
        filesPayload[relPath] = buf.toString("base64");
      } catch {
        // Ignore unreadable file
      }
    }
  }

  return { filesMeta, filesPayload };
}

export async function uploadToCloudStorage(
  backupId: string,
  encryptedBuffer: Buffer,
  manifest: Pick<DatabaseBackupManifest, "backupId"> &
    Partial<DatabaseBackupManifest>,
  options?: { simulateCloudFailure?: boolean },
): Promise<{ cloudUri: string; verifiedSize: number; verifiedSha256: string }> {
  if (options?.simulateCloudFailure) {
    throw new Error(
      "SIMULATED_CLOUD_UPLOAD_FAILURE: Cloud storage destination unreachable",
    );
  }

  const expectedSha = crypto
    .createHash("sha256")
    .update(encryptedBuffer)
    .digest("hex");
  const gcsBucket = process.env.CLOUD_BACKUP_BUCKET?.trim();
  const gcsPrefix = (
    process.env.CLOUD_BACKUP_PREFIX || "yasmina-backups"
  ).replace(/^\/+|\/+$/g, "");

  const vaultDir = getCloudVaultDir();
  const objectDir = path.join(vaultDir, "objects", backupId, "v1");
  const objectFilePath = path.join(objectDir, `${backupId}.enc`);
  const objectManifestPath = path.join(objectDir, `manifest_${backupId}.json`);
  const objectLockPath = path.join(objectDir, `${backupId}.lock.json`);

  writeFileAtomically(objectFilePath, encryptedBuffer);
  writeFileAtomically(
    objectManifestPath,
    Buffer.from(JSON.stringify(manifest, null, 2), "utf-8"),
  );
  writeFileAtomically(
    objectLockPath,
    Buffer.from(
      JSON.stringify(
        {
          backupId,
          versionId: "v1",
          retentionLockedUntil: new Date(
            Date.now() + 90 * 24 * 3600 * 1000,
          ).toISOString(),
          sha256: expectedSha,
          sizeBytes: encryptedBuffer.length,
        },
        null,
        2,
      ),
      "utf-8",
    ),
  );

  const verifiedBuf = fs.readFileSync(objectFilePath);
  const verifiedSha = crypto
    .createHash("sha256")
    .update(verifiedBuf)
    .digest("hex");
  if (
    verifiedBuf.length !== encryptedBuffer.length ||
    verifiedSha !== expectedSha
  ) {
    throw new Error(
      "Cloud vault object verification failed: checksum mismatch after upload",
    );
  }

  if (gcsBucket) {
    const auth = new GoogleAuth({
      scopes: ["https://www.googleapis.com/auth/devstorage.read_write"],
    });
    const client = await auth.getClient();
    const accessTokenRes = await client.getAccessToken();
    const token = accessTokenRes.token;
    if (!token) {
      throw new Error("Unable to acquire Google Cloud Storage OAuth token");
    }

    const objectName = encodeURIComponent(
      `${gcsPrefix}/${backupId}/${backupId}.enc`,
    );
    const uploadUrl = `https://storage.googleapis.com/upload/storage/v1/b/${encodeURIComponent(gcsBucket)}/o?uploadType=media&name=${objectName}`;
    const resp = await fetch(uploadUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/octet-stream",
        "Content-Length": String(encryptedBuffer.length),
      },
      body: new Uint8Array(encryptedBuffer),
    });

    if (!resp.ok) {
      const errBody = await resp.text().catch(() => "");
      throw new Error(
        `GCS upload failed with status ${resp.status}: ${errBody.slice(0, 200)}`,
      );
    }

    const gcsMeta = (await resp.json()) as { size?: string | number };
    if (Number(gcsMeta.size) !== encryptedBuffer.length) {
      throw new Error(
        `GCS uploaded size mismatch: expected ${encryptedBuffer.length}, got ${gcsMeta.size}`,
      );
    }

    return {
      cloudUri: `gs://${gcsBucket}/${gcsPrefix}/${backupId}/${backupId}.enc`,
      verifiedSize: encryptedBuffer.length,
      verifiedSha256: expectedSha,
    };
  }

  return {
    cloudUri: `vault://${objectFilePath}`,
    verifiedSize: verifiedBuf.length,
    verifiedSha256: verifiedSha,
  };
}
