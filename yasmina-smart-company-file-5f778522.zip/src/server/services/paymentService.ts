import { eq, and, sql, isNull, ne } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  transactions,
  invoices,
  payments,
  cashSessions,
  creditNotes,
} from "../../db/schema.js";
import { appendTransactionStep } from "./transactionService.js";

interface HttpError extends Error {
  status?: number;
  code?: string;
  details?: unknown;
}

function createHttpError(
  message: string,
  status: number,
  code: string,
  details?: unknown,
): HttpError {
  const err: HttpError = new Error(message);
  err.status = status;
  err.code = code;
  if (details !== undefined) err.details = details;
  return err;
}

export async function recordPayment(params: {
  tenantId: string;
  userId?: number;
  transactionId: number;
  invoiceId?: number | null;
  method: "CASH" | "CARD" | "BANK" | "TRANSFER";
  amountBaisa?: number;
  referenceNo?: string | null;
  notes?: string | null;
}): Promise<{
  payment: typeof payments.$inferSelect;
  invoice: typeof invoices.$inferSelect;
  remainingBaisa: number;
}> {
  const {
    tenantId,
    userId,
    transactionId,
    invoiceId,
    method,
    amountBaisa,
    referenceNo,
    notes,
  } = params;

  return await db.transaction(async (tx) => {
    const [targetTx] = await tx
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.id, transactionId),
          eq(transactions.tenantId, tenantId),
        ),
      )
      .limit(1);

    if (!targetTx) {
      throw createHttpError(
        "المعاملة غير موجودة",
        404,
        "TRANSACTION_NOT_FOUND",
      );
    }

    let targetInvoice: typeof invoices.$inferSelect | null = null;
    if (invoiceId) {
      const [inv] = await tx
        .select()
        .from(invoices)
        .where(
          and(eq(invoices.id, invoiceId), eq(invoices.tenantId, tenantId)),
        )
        .for("update")
        .limit(1);

      if (!inv) {
        throw createHttpError("الفاتورة غير موجودة", 404, "INVOICE_NOT_FOUND");
      }
      if (inv.transactionId !== transactionId) {
        throw createHttpError(
          "الفاتورة لا تنتمي لهذه المعاملة",
          422,
          "INVOICE_TRANSACTION_MISMATCH",
        );
      }
      targetInvoice = inv;
    } else {
      const [inv] = await tx
        .select()
        .from(invoices)
        .where(
          and(
            eq(invoices.transactionId, transactionId),
            eq(invoices.tenantId, tenantId),
            isNull(invoices.deletedAt),
            ne(invoices.status, "CANCELLED"),
          ),
        )
        .for("update")
        .limit(1);

      targetInvoice = inv || null;
    }

    if (!targetInvoice) {
      throw createHttpError(
        "لا توجد فاتورة صادرة لهذه المعاملة",
        404,
        "INVOICE_NOT_FOUND",
      );
    }

    const totalBaisa = targetInvoice.totalBaisa;

    const existingPayments = await tx
      .select({ total: sql<string>`coalesce(sum(${payments.amountBaisa}), 0)` })
      .from(payments)
      .where(
        and(
          eq(payments.invoiceId, targetInvoice.id),
          eq(payments.tenantId, tenantId),
        ),
      );

    // Payments include negative refund rows, so this is the NET amount paid.
    const currentPaidBaisa = Number(existingPayments[0]?.total ?? 0);

    const creditedRows = await tx
      .select({ total: sql<string>`coalesce(sum(${creditNotes.amountBaisa}), 0)` })
      .from(creditNotes)
      .where(
        and(
          eq(creditNotes.invoiceId, targetInvoice.id),
          eq(creditNotes.tenantId, tenantId),
        ),
      );
    const creditedBaisa = Number(creditedRows[0]?.total ?? 0);
    if (targetInvoice.status === "REFUNDED" || creditedBaisa >= totalBaisa) {
      throw createHttpError(
        "الفاتورة مستردة بالكامل بإشعار دائن ولا يمكن الدفع عليها",
        400,
        "INVOICE_REFUNDED",
      );
    }
    const dueBaisa = totalBaisa - creditedBaisa;
    const remainingBaisa = dueBaisa - currentPaidBaisa;

    if (remainingBaisa <= 0 || targetInvoice.status === "PAID") {
      throw createHttpError(
        "الفاتورة مدفوعة بالكامل مسبقاً",
        400,
        "ALREADY_PAID",
      );
    }

    const payAmount =
      amountBaisa !== undefined && amountBaisa !== null
        ? amountBaisa
        : remainingBaisa;

    if (payAmount <= 0) {
      throw createHttpError(
        "مبلغ الدفع يجب أن يكون أكبر من صفر",
        422,
        "INVALID_AMOUNT",
      );
    }

    if (payAmount > remainingBaisa) {
      throw createHttpError(
        `المبلغ المدفوع أكبر من المتبقي على الفاتورة (${remainingBaisa} بيسة)`,
        422,
        "OVERPAYMENT",
        { remainingBaisa },
      );
    }

    let activeCashSessionId: number | null = null;
    if (method === "CASH") {
      const [userSession] = await tx
        .select()
        .from(cashSessions)
        .where(
          and(
            eq(cashSessions.tenantId, tenantId),
            eq(cashSessions.openedBy, userId || 0),
            eq(cashSessions.status, "OPEN"),
          ),
        )
        .limit(1);

      if (!userSession) {
        throw createHttpError(
          "لا توجد جلسة صندوق كاش مفتوحة للمستخدم الحالي",
          409,
          "NO_OPEN_CASH_SESSION",
        );
      }
      activeCashSessionId = userSession.id;
    }

    const [insertedPayment] = await tx
      .insert(payments)
      .values({
        tenantId,
        branchId: targetInvoice.branchId,
        transactionId: targetInvoice.transactionId,
        invoiceId: targetInvoice.id,
        method,
        amountBaisa: payAmount,
        receivedBy: userId,
        cashSessionId: activeCashSessionId,
        referenceNo: referenceNo || null,
        notes: notes || null,
      })
      .returning();

    const newPaidBaisa = currentPaidBaisa + payAmount;
    const newStatus = newPaidBaisa >= dueBaisa ? "PAID" : "PARTIAL";

    const [updatedInvoice] = await tx
      .update(invoices)
      .set({ status: newStatus, updatedAt: new Date() })
      .where(
        and(
          eq(invoices.id, targetInvoice.id),
          eq(invoices.tenantId, tenantId),
        ),
      )
      .returning();

    if (newStatus === "PAID") {
      await appendTransactionStep({
        tenantId,
        transactionId: targetInvoice.transactionId,
        stepName: "سداد الفاتورة بالكامل",
        status: "COMPLETED",
        notes: `تم سداد الفاتورة رقم ${targetInvoice.invoiceNumber} بالكامل بقيمة ${newPaidBaisa} بيسة`,
        userId,
        executor: tx,
      });
    }

    return {
      payment: insertedPayment,
      invoice: updatedInvoice,
      remainingBaisa: Math.max(0, dueBaisa - newPaidBaisa),
    };
  });
}
