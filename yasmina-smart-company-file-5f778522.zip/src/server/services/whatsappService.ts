import * as baileysModule from "@whiskeysockets/baileys";
import pino from "pino";
import QRCode from "qrcode";
import path from "path";
import fs from "fs";
import { eq, and } from "drizzle-orm";
import { db } from "../../db/index.js";
import { whatsappAuthSessions } from "../../db/schema.js";
import { processIncomingWhatsAppMediaMessage } from "./whatsappDocumentProcessor.js";
import {
  AUTH_DIR,
  CHATS_FILE,
  MESSAGES_FILE,
  SETTINGS_FILE,
  MEDIA_INDEX_FILE,
  MEDIA_DIR,
  DEFAULT_INSTANCE_ID,
  QR_FRESHNESS_TTL_MS,
  isValidBaileysQrPayload,
  loadJsonFileSafe,
  writeJsonFileAtomically,
  resolveConfinedMediaPath,
  normalizeWhatsAppPhone,
  isAutoConfirmationMessageText,
  syncAuthDirToPostgres,
  restoreAuthDirFromPostgres,
  ensureCustomerRegisteredInDb,
  type WhatsAppConnectionState,
  type DiagnosticLogEntry,
  type ChatItem,
  type MessageItem,
  type GatewayState,
  type QrWaitResult,
  type MediaIndexEntry,
} from "./whatsappTypesAndStorage.js";
import {
  appendMessageWithCap,
  saveMediaForMessageInStore,
  getMediaForMessageFromStore,
  upsertChatFromJidInStore,
  markChatAsReadInStore,
  processRawBaileysMessage,
  sendManualWhatsAppMessage,
  type RawBaileysMessage,
  type WhatsAppPipelineContext,
} from "./whatsappMessagePipeline.js";
import { logger } from "../logger.js";

const {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
} = baileysModule;

type WASocket = import("@whiskeysockets/baileys").WASocket;
type ConnectionState = import("@whiskeysockets/baileys").ConnectionState;

const baileysExports = baileysModule as unknown as {
  makeWASocket?: typeof import("@whiskeysockets/baileys").default;
  default?:
    | typeof import("@whiskeysockets/baileys").default
    | {
        default?: typeof import("@whiskeysockets/baileys").default;
        makeWASocket?: typeof import("@whiskeysockets/baileys").default;
        fetchLatestWaWebVersion?: (
          options: Record<string, unknown>,
        ) => Promise<{ version?: [number, number, number] }>;
      };
  fetchLatestWaWebVersion?: (
    options: Record<string, unknown>,
  ) => Promise<{ version?: [number, number, number] }>;
};

const makeWASocket: typeof import("@whiskeysockets/baileys").default =
  typeof baileysExports.makeWASocket === "function"
    ? baileysExports.makeWASocket
    : typeof baileysExports.default === "function"
      ? baileysExports.default
      : typeof baileysExports.default?.default === "function"
        ? baileysExports.default.default
        : (baileysExports.default
            ?.makeWASocket as typeof import("@whiskeysockets/baileys").default);

export {
  isValidBaileysQrPayload,
  normalizeWhatsAppPhone,
  resolveConfinedMediaPath,
  type WhatsAppConnectionState,
  type DiagnosticLogEntry,
  type ChatItem,
  type MessageItem,
  type GatewayState,
  type QrWaitResult,
  type RawBaileysMessage,
};

class WhatsAppService implements WhatsAppPipelineContext {
  public sock: WASocket | null = null;
  private tenantId: string = "";
  private instanceId: string = DEFAULT_INSTANCE_ID;
  private attemptCounter = 0;
  private socketGeneration = 0;
  private sessionInitPromise: Promise<GatewayState> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 10;
  private qrWaiters: Array<(qr: QrWaitResult) => void> = [];
  public diagnosticLogs: DiagnosticLogEntry[] = [];

  public pendingOutboundIds: Set<string> = new Set();
  public pendingOutboundFingerprints: Map<string, number> = new Map();

  public state: GatewayState = {
    connectionState: "DISCONNECTED",
    status: "disconnected",
    connectionAttemptId: "wa_attempt_init_0",
    qrSequence: 0,
    qrCodeDataUrl: null,
    rawQr: null,
    phoneNumber: null,
    profileName: null,
    lastUpdated: Date.now(),
    qrGeneratedAt: 0,
    qrExpiresAt: 0,
    errorCode: null,
    errorMessage: null,
    autoReplyEnabled: true,
    totalSyncedChats: 0,
    totalSyncedMessages: 0,
  };

  public chats: ChatItem[] = [];
  public messages: Record<string, MessageItem[]> = {};
  public contacts: Record<string, string> = {};
  public mediaIndex: Record<string, MediaIndexEntry> = {};

  constructor(tenantId = "") {
    this.tenantId = tenantId;
    if (!fs.existsSync(AUTH_DIR)) {
      fs.mkdirSync(AUTH_DIR, { recursive: true });
    }
    if (!fs.existsSync(MEDIA_DIR)) {
      fs.mkdirSync(MEDIA_DIR, { recursive: true });
    }
    this.loadData();
    setTimeout(() => {
      this.scanHistoricalMediaAttachmentsSilently().catch((err) => {
        logger.warn({ err }, "Notice in historical WhatsApp media scan");
      });
    }, 2500);
  }

  public getSock(): WASocket | null {
    return this.sock;
  }

  public setTenantId(tenantId: string): void {
    if (tenantId && tenantId.trim()) {
      this.tenantId = tenantId.trim();
    }
  }

  public getTenantId(): string {
    return this.tenantId;
  }

  public getInstanceId(): string {
    return this.instanceId;
  }

  public async scanHistoricalMediaAttachmentsSilently(): Promise<void> {
    if (!this.tenantId) return;
    try {
      for (const [chatId, list] of Object.entries(this.messages)) {
        if (!Array.isArray(list)) continue;
        const chat = this.chats.find((c) => c.id === chatId);
        const normalizedPhone = normalizeWhatsAppPhone(
          chat?.contactNumber || chatId,
        );
        if (!normalizedPhone) continue;
        const senderPhone = `+${normalizedPhone}`;
        const senderJid = chat?.jid || `${normalizedPhone}@s.whatsapp.net`;
        const senderName = chat?.contactName || `متعامل (${senderPhone})`;

        for (const m of list) {
          const hasAttachment = Boolean(
            m.mediaUrl ||
              m.fileName ||
              /\[(?:ملف مرفق|مستند مرفق|صورة مرفقة)/.test(m.text || ""),
          );
          if (!hasAttachment) continue;

          const mediaData = this.getMediaForMessage(m.id, m.fileName);
          if (!mediaData || !mediaData.buffer || mediaData.buffer.length === 0)
            continue;

          try {
            const res = await processIncomingWhatsAppMediaMessage({
              tenantId: this.tenantId,
              instanceId: this.instanceId,
              providerMessageId: m.id,
              senderPhone,
              senderJid,
              senderName,
              messageText: m.text,
              fileName:
                mediaData.fileName || m.fileName || `whatsapp_doc_${m.id}.pdf`,
              declaredMimeType:
                mediaData.mimeType || m.mimeType || "application/pdf",
              mediaBuffer: mediaData.buffer,
              sendWhatsAppReplyFn: async () => ({
                sentId: `silent-${Date.now()}`,
              }),
            });
            if (res?.companyName && chat) {
              chat.companyName = res.companyName;
              this.saveChatsToFile();
            }
          } catch (err) {
            logger.debug({ err, msgId: m.id }, "Historical media scan item skipped");
          }
        }
      }
    } catch (err) {
      logger.debug({ err }, "Historical media scan skipped");
    }
  }

  private generateAttemptId(): string {
    this.attemptCounter += 1;
    return `wa_attempt_${Date.now()}_${this.attemptCounter}`;
  }

  public logDiagnostic(
    eventType: string,
    errorCode: number | string | null = null,
    details?: string,
  ): DiagnosticLogEntry {
    const entry: DiagnosticLogEntry = {
      connectionAttemptId: this.state.connectionAttemptId,
      provider: "BAILEYS",
      connectionState: this.state.connectionState,
      eventType,
      errorCode,
      timestamp: new Date().toISOString(),
      qrSequence: this.state.qrSequence,
      ...(details ? { details } : {}),
    };
    this.diagnosticLogs.push(entry);
    if (this.diagnosticLogs.length > 250) {
      this.diagnosticLogs.shift();
    }
    return entry;
  }

  public getDiagnosticLogs(limit = 50): DiagnosticLogEntry[] {
    return this.diagnosticLogs.slice(-limit);
  }

  public loadData(): void {
    const rawSettings = loadJsonFileSafe<{ autoReplyEnabled?: boolean }>(
      SETTINGS_FILE,
      {},
    );
    if (typeof rawSettings?.autoReplyEnabled === "boolean") {
      this.state.autoReplyEnabled = rawSettings.autoReplyEnabled;
    }
    this.mediaIndex = loadJsonFileSafe<Record<string, MediaIndexEntry>>(
      MEDIA_INDEX_FILE,
      {},
    );
    this.chats = loadJsonFileSafe<ChatItem[]>(CHATS_FILE, []);
    this.messages = loadJsonFileSafe<Record<string, MessageItem[]>>(
      MESSAGES_FILE,
      {},
    );
    this.purgeAutoConfirmationMessagesFromHistory();
  }

  private purgeAutoConfirmationMessagesFromHistory(): void {
    let messagesModified = false;
    let chatsModified = false;

    for (const [chatId, list] of Object.entries(this.messages)) {
      if (!Array.isArray(list)) continue;
      const filtered = list.filter((m) => {
        const idStr = String(m?.id || "");
        if (
          idStr.startsWith("wa-doc-confirm-") ||
          idStr.startsWith("wa-doc-reply-") ||
          idStr.startsWith("wa-ingest-reply-")
        ) {
          return false;
        }
        if (m?.fromMe && isAutoConfirmationMessageText(m?.text)) {
          return false;
        }
        return true;
      });
      if (filtered.length !== list.length) {
        this.messages[chatId] = filtered;
        messagesModified = true;
      }
    }

    for (const chat of this.chats) {
      if (isAutoConfirmationMessageText(chat.lastMessage)) {
        const chatMsgs = this.messages[chat.id] || [];
        const lastValid = chatMsgs[chatMsgs.length - 1];
        chat.lastMessage = lastValid?.text || "";
        if (lastValid?.timestamp) {
          chat.lastMessageTime = lastValid.timestamp;
        }
        chatsModified = true;
      }
    }

    if (messagesModified) this.saveMessagesToFile();
    if (chatsModified) this.saveChatsToFile();
  }

  public saveSettingsToFile(): void {
    writeJsonFileAtomically(SETTINGS_FILE, {
      autoReplyEnabled: this.state.autoReplyEnabled,
      updatedAt: new Date().toISOString(),
    });
  }

  public saveMediaIndexToFile(): void {
    writeJsonFileAtomically(MEDIA_INDEX_FILE, this.mediaIndex);
  }

  public saveChatsToFile(): void {
    writeJsonFileAtomically(CHATS_FILE, this.chats);
  }

  public saveMessagesToFile(): void {
    writeJsonFileAtomically(MESSAGES_FILE, this.messages);
  }

  public saveMediaForMessage(
    msgId: string,
    fileName: string,
    mimeType: string,
    buffer: Buffer,
  ): { mediaUrl: string; fileName: string; mimeType: string; fileSize: number } {
    return saveMediaForMessageInStore(this, msgId, fileName, mimeType, buffer);
  }

  public getMediaForMessage(
    msgId: string,
    fallbackFileName?: string,
    callerTenantId?: string,
  ): { buffer: Buffer; fileName: string; mimeType: string } | null {
    return getMediaForMessageFromStore(
      this,
      msgId,
      fallbackFileName,
      callerTenantId,
    );
  }

  public getChats(): ChatItem[] {
    this.loadData();
    return this.chats;
  }

  private enrichMessagesWithMedia(msgs: MessageItem[]): MessageItem[] {
    return msgs.map((m) => {
      const indexed = this.mediaIndex[m.id];
      if (indexed) {
        return {
          ...m,
          mediaUrl:
            m.mediaUrl || `/api/whatsapp/media/${encodeURIComponent(m.id)}`,
          fileName: m.fileName || indexed.fileName,
          mimeType: m.mimeType || indexed.mimeType,
          fileSize: m.fileSize || indexed.fileSize,
        };
      }
      const match = m.text?.match(
        /\[(?:ملف مرفق|مستند مرفق|صورة مرفقة):\s*([^\]]+)\]/,
      );
      if (match && match[1]) {
        const fname = path.basename(match[1].trim());
        const lower = fname.toLowerCase();
        const mime = lower.endsWith(".png")
          ? "image/png"
          : lower.endsWith(".jpg") || lower.endsWith(".jpeg")
            ? "image/jpeg"
            : lower.endsWith(".webp")
              ? "image/webp"
              : "application/pdf";
        return {
          ...m,
          mediaUrl:
            m.mediaUrl ||
            `/api/whatsapp/media/${encodeURIComponent(m.id)}?fileName=${encodeURIComponent(fname)}`,
          fileName: m.fileName || fname,
          mimeType: m.mimeType || mime,
        };
      }
      return m;
    });
  }

  public getMessages(chatId: string): MessageItem[] {
    this.loadData();
    if (this.messages[chatId]) {
      return this.enrichMessagesWithMedia(this.messages[chatId]);
    }
    const cleanId = String(chatId).replace(/[^0-9]/g, "");
    if (cleanId) {
      for (const [k, msgs] of Object.entries(this.messages)) {
        if (k.replace(/[^0-9]/g, "") === cleanId) {
          return this.enrichMessagesWithMedia(msgs);
        }
      }
    }
    return [];
  }

  public isQrFresh(): boolean {
    if (!this.state.qrCodeDataUrl || !this.state.rawQr) return false;
    if (this.state.connectionState !== "QR_READY") return false;
    if (this.state.qrGeneratedAt <= 0) return false;
    const age = Date.now() - this.state.qrGeneratedAt;
    return age >= 0 && age < QR_FRESHNESS_TTL_MS;
  }

  public getState(): GatewayState {
    if (
      this.state.qrCodeDataUrl &&
      this.state.qrGeneratedAt > 0 &&
      Date.now() - this.state.qrGeneratedAt >= QR_FRESHNESS_TTL_MS
    ) {
      this.state.qrCodeDataUrl = null;
      this.state.rawQr = null;
      if (this.state.connectionState === "QR_READY") {
        this.state.connectionState = "INITIALIZING";
      }
      this.logDiagnostic(
        "QR_EXPIRED_STALE_CLEARED",
        null,
        "Cleared expired QR code from state",
      );
    }

    return {
      ...this.state,
      totalSyncedChats: this.chats.length,
      totalSyncedMessages: Object.values(this.messages).reduce(
        (acc, m) => acc + m.length,
        0,
      ),
    };
  }

  public setAutoReply(enabled: boolean): void {
    this.state.autoReplyEnabled = Boolean(enabled);
    this.saveSettingsToFile();
    this.logDiagnostic(
      "AUTO_REPLY_UPDATED",
      null,
      `autoReplyEnabled set to ${this.state.autoReplyEnabled}`,
    );
  }

  public clearChatsAndMessages(): void {
    this.chats = [];
    this.messages = {};
    this.saveChatsToFile();
    this.saveMessagesToFile();
  }

  private isLocalCredsAuthenticated(): boolean {
    try {
      const credsPath = path.join(AUTH_DIR, "creds.json");
      if (!fs.existsSync(credsPath)) return false;
      const parsed = JSON.parse(fs.readFileSync(credsPath, "utf-8")) as {
        me?: { id?: string };
      };
      return Boolean(parsed?.me?.id);
    } catch {
      return false;
    }
  }

  public async hasAuthenticatedCredentials(): Promise<boolean> {
    if (this.isLocalCredsAuthenticated()) return true;
    await this.restoreAuthFromDatabase();
    return this.isLocalCredsAuthenticated();
  }

  public async syncAuthToDatabase(): Promise<boolean> {
    if (!this.tenantId) return false;
    return syncAuthDirToPostgres({
      tenantId: this.tenantId,
      instanceId: this.instanceId,
      phoneNumber: this.state.phoneNumber,
      profileName: this.state.profileName,
      isLocalAuthenticated: this.isLocalCredsAuthenticated(),
    });
  }

  public async restoreAuthFromDatabase(): Promise<boolean> {
    if (!this.tenantId) return false;
    const res = await restoreAuthDirFromPostgres({
      tenantId: this.tenantId,
      instanceId: this.instanceId,
      isLocalAuthenticated: this.isLocalCredsAuthenticated(),
    });
    if (res.restored && res.restoredCount > 0) {
      if (res.phoneNumber && !this.state.phoneNumber) {
        this.state.phoneNumber = res.phoneNumber;
      }
      if (res.profileName && !this.state.profileName) {
        this.state.profileName = res.profileName;
      }
      this.logDiagnostic(
        "AUTH_DB_RESTORED",
        null,
        `Restored ${res.restoredCount} auth files from saved session`,
      );
    }
    return res.restored;
  }

  private resolveAllQrWaiters(result: QrWaitResult): void {
    while (this.qrWaiters.length > 0) {
      const waiter = this.qrWaiters.shift();
      if (waiter) {
        try {
          waiter(result);
        } catch {
          // Ignore waiter callback error
        }
      }
    }
  }

  public async handleConnectionUpdate(
    update: Partial<ConnectionState>,
    expectedAttemptId?: string,
    expectedSocketGeneration?: number,
  ): Promise<void> {
    if (
      expectedAttemptId &&
      expectedAttemptId !== this.state.connectionAttemptId
    ) {
      return;
    }
    if (
      expectedSocketGeneration !== undefined &&
      expectedSocketGeneration !== this.socketGeneration
    ) {
      return;
    }

    const { connection, lastDisconnect, qr } = update;

    if (
      connection === "connecting" &&
      !qr &&
      this.state.connectionState !== "QR_READY"
    ) {
      this.state.connectionState =
        this.reconnectAttempts > 0 ? "RECONNECTING" : "INITIALIZING";
      this.state.status = "connecting";
      this.state.lastUpdated = Date.now();
      this.logDiagnostic("SOCKET_CONNECTING", null);
    }

    if (qr !== undefined) {
      if (!isValidBaileysQrPayload(qr)) {
        this.logDiagnostic(
          "INVALID_QR_PAYLOAD_REJECTED",
          "INVALID_QR",
          "Rejected malformed or non-Baileys QR payload",
        );
        return;
      }

      try {
        const dataUrl = await QRCode.toDataURL(qr, {
          width: 320,
          margin: 4,
          color: { dark: "#000000", light: "#ffffff" },
          errorCorrectionLevel: "M",
        });

        const now = Date.now();
        const isReplacement =
          this.state.qrSequence > 0 && Boolean(this.state.rawQr);
        this.state.rawQr = qr;
        this.state.qrCodeDataUrl = dataUrl;
        this.state.qrGeneratedAt = now;
        this.state.qrExpiresAt = now + QR_FRESHNESS_TTL_MS;
        this.state.qrSequence += 1;
        this.state.connectionState = "QR_READY";
        this.state.status = "connecting";
        this.state.errorCode = null;
        this.state.errorMessage = null;
        this.state.lastUpdated = now;

        this.logDiagnostic(
          isReplacement ? "QR_ROTATED" : "QR_GENERATED",
          null,
          `QR sequence #${this.state.qrSequence} ready`,
        );

        this.resolveAllQrWaiters({
          qrCodeDataUrl: this.state.qrCodeDataUrl,
          rawQr: this.state.rawQr,
          connectionAttemptId: this.state.connectionAttemptId,
          qrSequence: this.state.qrSequence,
          qrGeneratedAt: this.state.qrGeneratedAt,
          connectionState: this.state.connectionState,
        });
      } catch (qrErr) {
        this.state.errorCode = "QR_ENCODE_ERROR";
        this.state.errorMessage =
          "فشل تحويل رمز الاستجابة السريعة إلى صورة قابلة للمسح";
        this.logDiagnostic(
          "QR_ENCODE_FAILED",
          "QR_ENCODE_ERROR",
          qrErr instanceof Error ? qrErr.message : String(qrErr),
        );
      }
    }

    if (connection === "open") {
      this.reconnectAttempts = 0;
      this.state.connectionState = "CONNECTED";
      this.state.status = "connected";
      this.state.qrCodeDataUrl = null;
      this.state.rawQr = null;
      this.state.qrGeneratedAt = 0;
      this.state.qrExpiresAt = 0;
      this.state.errorCode = null;
      this.state.errorMessage = null;

      // Fix #88: Use real authenticated user number or null instead of inventing "+968 9123 4567"
      const rawId = this.sock?.user?.id || "";
      const cleanPhone = rawId.split(":")[0]?.split("@")[0] || "";
      if (cleanPhone) {
        this.state.phoneNumber = `+${cleanPhone}`;
      }
      this.state.profileName =
        this.sock?.user?.name ||
        this.state.profileName ||
        "بوابة واتساب الرسمية";
      this.state.lastUpdated = Date.now();

      this.logDiagnostic(
        "SESSION_CONNECTED",
        null,
        `Connected phone: ${this.state.phoneNumber || "unknown"}`,
      );
      await this.syncAuthToDatabase();

      this.resolveAllQrWaiters({
        qrCodeDataUrl: null,
        rawQr: null,
        connectionAttemptId: this.state.connectionAttemptId,
        qrSequence: this.state.qrSequence,
        qrGeneratedAt: 0,
        connectionState: "CONNECTED",
      });
    }

    if (connection === "close") {
      const errObj = lastDisconnect?.error as
        | { output?: { statusCode?: number }; statusCode?: number }
        | undefined;
      const statusCode =
        errObj?.output?.statusCode ?? errObj?.statusCode ?? null;
      const isLoggedOut =
        statusCode === DisconnectReason.loggedOut || statusCode === 401;
      const isRestartRequired =
        statusCode === DisconnectReason.restartRequired || statusCode === 515;

      this.state.qrCodeDataUrl = null;
      this.state.rawQr = null;
      this.state.qrGeneratedAt = 0;
      this.state.qrExpiresAt = 0;
      this.state.errorCode = statusCode;
      this.state.lastUpdated = Date.now();

      if (isLoggedOut) {
        this.state.connectionState = "DISCONNECTED";
        this.state.status = "disconnected";
        this.state.phoneNumber = null;
        this.state.profileName = null;
        this.state.errorMessage =
          "تم تسجيل الخروج من جهاز واتساب. يرجى مسح رمز QR الجديد لإعادة الربط.";
        await this.clearAuthFiles();
        this.closeSocketInstance();
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
        this.reconnectTimer = setTimeout(() => {
          this.reconnectTimer = null;
          this.startSession(true, false).catch((err) => {
            logger.debug({ err }, "Reconnect after logout error");
          });
        }, 800);
      } else {
        this.reconnectAttempts += 1;
        if (this.reconnectAttempts > this.maxReconnectAttempts) {
          this.state.connectionState = "ERROR";
          this.state.status = "disconnected";
          this.state.errorMessage =
            "انتهت مهلة محاولات الاتصال بخادم واتساب. اضغط على تحديث الرمز لإعادة المحاولة.";
          return;
        }

        this.state.connectionState = isRestartRequired
          ? "AUTHENTICATING"
          : "RECONNECTING";
        this.state.status = "connecting";
        const reconnectDelay = isRestartRequired ? 250 : 1800;

        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
        this.reconnectTimer = setTimeout(() => {
          this.reconnectTimer = null;
          this.startSession(false, true).catch((err) => {
            logger.debug({ err }, "Reconnect error");
          });
        }, reconnectDelay);
      }
    }
  }

  private closeSocketInstance(): void {
    if (this.sock) {
      try {
        this.sock.ev.removeAllListeners("connection.update");
        this.sock.ev.removeAllListeners("creds.update");
        this.sock.ev.removeAllListeners("messages.upsert");
        this.sock.ev.removeAllListeners("messaging-history.set");
        this.sock.ev.removeAllListeners("chats.upsert");
        this.sock.ev.removeAllListeners("contacts.upsert");
        this.sock.end(undefined);
      } catch {
        // Ignore socket teardown errors
      }
      this.sock = null;
    }
  }

  public async startSession(
    forceRestart = false,
    preserveAttemptOnReconnect = false,
  ): Promise<GatewayState> {
    if (this.sock && this.state.status === "connected" && !forceRestart) {
      return this.getState();
    }
    if (this.sessionInitPromise && !forceRestart) {
      return this.sessionInitPromise;
    }
    if (!forceRestart && this.sock && this.isQrFresh()) {
      return this.getState();
    }
    // Fix #79: Always cancel pending reconnect timer before starting session
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    this.sessionInitPromise = this._executeStartSession(
      forceRestart,
      preserveAttemptOnReconnect,
    );
    try {
      return await this.sessionInitPromise;
    } finally {
      this.sessionInitPromise = null;
    }
  }

  private async _executeStartSession(
    forceRestart: boolean,
    preserveAttemptOnReconnect: boolean,
  ): Promise<GatewayState> {
    if (
      !preserveAttemptOnReconnect ||
      forceRestart ||
      this.state.connectionAttemptId === "wa_attempt_init_0"
    ) {
      this.state.connectionAttemptId = this.generateAttemptId();
      this.state.qrSequence = 0;
      this.reconnectAttempts = 0;
    }

    this.state.connectionState =
      this.reconnectAttempts > 0 ? "RECONNECTING" : "INITIALIZING";
    this.state.status = "connecting";
    if (forceRestart) {
      this.state.qrCodeDataUrl = null;
      this.state.rawQr = null;
      this.state.qrGeneratedAt = 0;
      this.state.qrExpiresAt = 0;
    }
    this.state.errorCode = null;
    this.state.errorMessage = null;
    this.state.lastUpdated = Date.now();

    const currentAttemptId = this.state.connectionAttemptId;
    this.socketGeneration += 1;
    const currentSocketGen = this.socketGeneration;

    try {
      if (forceRestart) {
        await this.clearAuthFiles();
      } else {
        if (!fs.existsSync(AUTH_DIR)) {
          fs.mkdirSync(AUTH_DIR, { recursive: true });
        }
        await this.restoreAuthFromDatabase();
      }

      const { state: authState, saveCreds } =
        await useMultiFileAuthState(AUTH_DIR);

      let version: [number, number, number] = [2, 3000, 1053647598];
      try {
        const fetchWa =
          baileysExports.fetchLatestWaWebVersion ||
          (typeof baileysExports.default === "object"
            ? baileysExports.default?.fetchLatestWaWebVersion
            : undefined);
        if (typeof fetchWa === "function") {
          const res = await fetchWa({});
          if (res?.version && Array.isArray(res.version)) {
            version = res.version;
          }
        } else {
          const res = await fetchLatestBaileysVersion();
          if (res?.version) version = res.version;
        }
      } catch {
        version = [2, 3000, 1053647598];
      }

      this.closeSocketInstance();

      const sock = makeWASocket({
        version,
        auth: authState,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        browser: Browsers.macOS("Chrome"),
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        keepAliveIntervalMs: 15000,
        emitOwnEvents: true,
        markOnlineOnConnect: true,
        syncFullHistory: false,
        getMessage: async (key) => {
          if (!key.id) return undefined;
          const remoteJid = key.remoteJid || "";
          const msgs = this.getMessages(remoteJid);
          const found = msgs.find((m) => m.id === key.id);
          return found ? { conversation: found.text } : undefined;
        },
      });

      this.sock = sock;

      sock.ev.on("creds.update", async () => {
        if (currentSocketGen !== this.socketGeneration) return;
        try {
          await saveCreds();
          if (
            authState.creds?.me?.id &&
            this.state.connectionState === "QR_READY"
          ) {
            this.state.connectionState = "AUTHENTICATING";
            this.state.qrCodeDataUrl = null;
            this.state.rawQr = null;
            this.state.lastUpdated = Date.now();
          }
          await this.syncAuthToDatabase();
        } catch (err) {
          logger.debug({ err }, "Creds save warning");
        }
      });

      sock.ev.on(
        "connection.update",
        async (update: Partial<ConnectionState>) => {
          await this.handleConnectionUpdate(
            update,
            currentAttemptId,
            currentSocketGen,
          );
        },
      );

      sock.ev.on("messages.upsert", async (m) => {
        if (currentSocketGen !== this.socketGeneration) return;
        const messagesList = (m.messages || []) as RawBaileysMessage[];
        const isNotify = m.type === "notify";
        for (const msg of messagesList) {
          await this.processRawWAMessage(msg, isNotify);
        }
      });

      return this.getState();
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : "فشل تهيئة جلسة واتساب";
      this.state.connectionState = "ERROR";
      this.state.status = "disconnected";
      this.state.errorCode = "INIT_FAILED";
      this.state.errorMessage = errMsg;
      return this.getState();
    }
  }

  public async resetSessionAndGenerateQr(): Promise<QrWaitResult> {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    await this.clearAuthFiles();
    this.state.connectionState = "INITIALIZING";
    this.state.status = "connecting";
    this.state.phoneNumber = null;
    this.state.profileName = null;
    this.state.qrCodeDataUrl = null;
    this.state.rawQr = null;
    this.state.qrSequence = 0;
    this.state.errorCode = null;
    this.state.errorMessage = null;

    await this.startSession(true);
    return this.waitForQrCode(15000, true);
  }

  public async waitForQrCode(
    timeoutMs = 15000,
    forceNew = false,
  ): Promise<QrWaitResult> {
    if (this.state.status === "connected" && !forceNew) {
      return {
        qrCodeDataUrl: null,
        rawQr: null,
        connectionAttemptId: this.state.connectionAttemptId,
        qrSequence: this.state.qrSequence,
        qrGeneratedAt: 0,
        connectionState: "CONNECTED",
      };
    }

    if (!forceNew && this.isQrFresh()) {
      return {
        qrCodeDataUrl: this.state.qrCodeDataUrl,
        rawQr: this.state.rawQr,
        connectionAttemptId: this.state.connectionAttemptId,
        qrSequence: this.state.qrSequence,
        qrGeneratedAt: this.state.qrGeneratedAt,
        connectionState: this.state.connectionState,
      };
    }

    if (
      forceNew ||
      !this.sock ||
      this.state.status === "disconnected" ||
      this.state.connectionState === "ERROR" ||
      this.state.connectionState === "DISCONNECTED"
    ) {
      const isCleanRestart =
        forceNew ||
        this.state.status === "disconnected" ||
        !this.isLocalCredsAuthenticated();
      await this.startSession(isCleanRestart);
    }

    if (this.isQrFresh()) {
      return {
        qrCodeDataUrl: this.state.qrCodeDataUrl,
        rawQr: this.state.rawQr,
        connectionAttemptId: this.state.connectionAttemptId,
        qrSequence: this.state.qrSequence,
        qrGeneratedAt: this.state.qrGeneratedAt,
        connectionState: this.state.connectionState,
      };
    }

    return new Promise((resolve) => {
      let resolved = false;
      const waiter = (res: QrWaitResult) => {
        if (!resolved) {
          resolved = true;
          resolve(res);
        }
      };
      this.qrWaiters.push(waiter);
      setTimeout(() => {
        if (!resolved) {
          resolved = true;
          const idx = this.qrWaiters.indexOf(waiter);
          if (idx !== -1) this.qrWaiters.splice(idx, 1);
          resolve({
            qrCodeDataUrl: this.state.qrCodeDataUrl,
            rawQr: this.state.rawQr,
            connectionAttemptId: this.state.connectionAttemptId,
            qrSequence: this.state.qrSequence,
            qrGeneratedAt: this.state.qrGeneratedAt,
            connectionState: this.state.connectionState,
          });
        }
      }, timeoutMs);
    });
  }

  public async requestPairingCode(phoneNumber: string): Promise<string> {
    const cleanPhone = normalizeWhatsAppPhone(phoneNumber);
    if (!cleanPhone || cleanPhone.length < 8) {
      throw new Error(
        "رقم الهاتف غير صالح. يرجى إدخال رقم هاتف صحيح مع رمز الدولة.",
      );
    }

    if (!this.sock || this.state.status === "disconnected") {
      await this.startSession(false);
    }

    if (!this.sock) {
      throw new Error("تعذر تهيئة جلسة واتساب. حاول مجدداً.");
    }

    const code = await this.sock.requestPairingCode(cleanPhone);
    this.logDiagnostic(
      "PAIRING_CODE_GENERATED",
      null,
      `Generated pairing code for phone ending in ${cleanPhone.slice(-4)}`,
    );
    return code;
  }

  public recordIngestedDocumentChatMessage(params: {
    msgId?: string;
    senderPhone: string;
    senderName: string;
    fileName: string;
    mimeType?: string;
    mediaBuffer?: Buffer;
    replyText?: string;
  }): ChatItem {
    const cleanDigits = normalizeWhatsAppPhone(params.senderPhone);
    const jid = cleanDigits
      ? `${cleanDigits}@s.whatsapp.net`
      : "unknown@s.whatsapp.net";
    const formattedPhone = cleanDigits ? `+${cleanDigits}` : "unknown";
    const nowIso = new Date().toISOString();
    const attachText = `📄 [ملف مرفق: ${params.fileName}]`;
    const chat = this.upsertChatFromJid(jid, {
      contactName: params.senderName || `متعامل (${formattedPhone})`,
      contactNumber: formattedPhone,
      lastMessage: attachText,
      lastMessageTime: nowIso,
      unreadIncrement: 0,
    });
    if (!this.messages[chat.id]) this.messages[chat.id] = [];
    const inMsgId = params.msgId || `wa-ingest-in-${Date.now()}`;
    let mediaInfo:
      | { mediaUrl: string; fileName: string; mimeType: string; fileSize: number }
      | undefined;
    if (params.mediaBuffer && Buffer.isBuffer(params.mediaBuffer)) {
      mediaInfo = this.saveMediaForMessage(
        inMsgId,
        params.fileName,
        params.mimeType || "application/pdf",
        params.mediaBuffer,
      );
    }
    if (!this.messages[chat.id].some((mItem) => mItem.id === inMsgId)) {
      appendMessageWithCap(this, chat.id, {
        id: inMsgId,
        chatId: chat.id,
        senderName: params.senderName || chat.contactName,
        senderNumber: formattedPhone,
        fromMe: false,
        text: attachText,
        timestamp: nowIso,
        status: "read",
        aiGenerated: false,
        mediaUrl:
          mediaInfo?.mediaUrl ||
          `/api/whatsapp/media/${encodeURIComponent(inMsgId)}`,
        fileName: params.fileName,
        mimeType: params.mimeType || "application/pdf",
        fileSize: mediaInfo?.fileSize,
      });
    }
    this.saveChatsToFile();
    this.saveMessagesToFile();
    return chat;
  }

  public async ensureCustomerRegisteredFromWhatsApp(
    formattedPhone: string,
    rawPushName?: string,
  ): Promise<{ customerId?: number; customerName: string; companyName?: string }> {
    return ensureCustomerRegisteredInDb(
      this.tenantId,
      formattedPhone,
      rawPushName,
    );
  }

  public async processRawWAMessage(
    msg: RawBaileysMessage,
    triggerAi = true,
  ): Promise<void> {
    return processRawBaileysMessage(this, msg, triggerAi);
  }

  public markChatAsRead(chatId: string): void {
    markChatAsReadInStore(this, chatId);
  }

  public upsertChatFromJid(
    jid: string,
    data: Partial<ChatItem> & { unreadIncrement?: number },
  ): ChatItem {
    return upsertChatFromJidInStore(this, jid, data);
  }

  public async sendManualMessage(
    chatId: string,
    text: string,
    media?: { buffer: Buffer; fileName: string; mimeType: string },
    clientMessageId?: string,
  ): Promise<MessageItem> {
    return sendManualWhatsAppMessage(this, chatId, text, media, clientMessageId);
  }

  public async logout(): Promise<void> {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    const keepAutoReply = this.state.autoReplyEnabled;
    this.socketGeneration += 1;
    try {
      if (this.sock) {
        this.sock.ev.removeAllListeners("connection.update");
        this.sock.ev.removeAllListeners("creds.update");
        await this.sock.logout().catch((err) => {
          logger.debug({ err }, "Socket logout notice");
        });
        this.closeSocketInstance();
      }
    } catch {
      // Ignore logout teardown error
    }
    await this.clearAuthFiles();
    this.clearChatsAndMessages();
    this.state = {
      connectionState: "DISCONNECTED",
      status: "disconnected",
      connectionAttemptId: this.generateAttemptId(),
      qrSequence: 0,
      qrCodeDataUrl: null,
      rawQr: null,
      phoneNumber: null,
      profileName: null,
      lastUpdated: Date.now(),
      qrGeneratedAt: 0,
      qrExpiresAt: 0,
      errorCode: null,
      errorMessage: null,
      autoReplyEnabled: keepAutoReply,
      totalSyncedChats: 0,
      totalSyncedMessages: 0,
    };
    this.logDiagnostic(
      "SESSION_LOGGED_OUT",
      null,
      "Cleared local and DB auth sessions",
    );
  }

  public async clearAuthFiles(): Promise<void> {
    try {
      if (fs.existsSync(AUTH_DIR)) {
        fs.rmSync(AUTH_DIR, { recursive: true, force: true });
        fs.mkdirSync(AUTH_DIR, { recursive: true });
      }
      if (this.tenantId) {
        await db
          .delete(whatsappAuthSessions)
          .where(
            and(
              eq(whatsappAuthSessions.tenantId, this.tenantId),
              eq(whatsappAuthSessions.instanceId, this.instanceId),
            ),
          )
          .catch((err) => {
            logger.debug({ err }, "Auth session delete notice");
          });
      }
    } catch (err) {
      logger.error({ err }, "Error clearing WhatsApp auth directory");
    }
  }
}

export const whatsAppService = new WhatsAppService();
export const whatsappService = whatsAppService;
