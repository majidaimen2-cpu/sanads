import path from "path";
import fs from "fs";
import { eq, and, isNull, or } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  whatsappAuthSessions,
  customers,
  companies,
} from "../../db/schema.js";
import { logger } from "../logger.js";

export const AUTH_DIR = path.join(process.cwd(), "data", "whatsapp_auth");
export const CHATS_FILE = path.join(process.cwd(), "data", "whatsapp_chats.json");
export const MESSAGES_FILE = path.join(process.cwd(), "data", "whatsapp_messages.json");
export const SETTINGS_FILE = path.join(process.cwd(), "data", "whatsapp_settings.json");
export const MEDIA_INDEX_FILE = path.join(process.cwd(), "data", "whatsapp_media_index.json");
export const MEDIA_DIR = path.join(process.cwd(), "backups", "whatsapp_media");
export const DEFAULT_INSTANCE_ID = "inst-main";
export const QR_FRESHNESS_TTL_MS = 55000;
export const MAX_MEDIA_DOWNLOAD_BYTES = 15 * 1024 * 1024; // 15 MB (#80)
export const MAX_MESSAGES_PER_CHAT = 500; // Cap in-memory & JSON history per chat (#85)

export type WhatsAppConnectionState =
  | "DISCONNECTED"
  | "INITIALIZING"
  | "QR_READY"
  | "AUTHENTICATING"
  | "CONNECTED"
  | "RECONNECTING"
  | "ERROR";

export interface DiagnosticLogEntry {
  connectionAttemptId: string;
  provider: "BAILEYS";
  connectionState: WhatsAppConnectionState;
  eventType: string;
  errorCode: number | string | null;
  timestamp: string;
  qrSequence?: number;
  details?: string;
}

export interface ChatItem {
  id: string;
  jid: string;
  contactName: string;
  contactNumber: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  tags: string[];
  avatarUrl: string;
  instanceId: string;
  companyName: string;
  isRealSync: boolean;
}

export interface MessageItem {
  id: string;
  chatId: string;
  senderName: string;
  senderNumber: string;
  fromMe: boolean;
  text: string;
  timestamp: string;
  status: string;
  aiGenerated: boolean;
  clientMessageId?: string;
  mediaUrl?: string;
  fileName?: string;
  mimeType?: string;
  fileSize?: number;
}

export interface GatewayState {
  connectionState: WhatsAppConnectionState;
  status: "disconnected" | "connecting" | "connected";
  connectionAttemptId: string;
  qrSequence: number;
  qrCodeDataUrl: string | null;
  rawQr: string | null;
  phoneNumber: string | null;
  profileName: string | null;
  lastUpdated: number;
  qrGeneratedAt: number;
  qrExpiresAt: number;
  errorCode: number | string | null;
  errorMessage: string | null;
  autoReplyEnabled: boolean;
  totalSyncedChats: number;
  totalSyncedMessages: number;
}

export interface QrWaitResult {
  qrCodeDataUrl: string | null;
  rawQr: string | null;
  connectionAttemptId: string;
  qrSequence: number;
  qrGeneratedAt: number;
  connectionState: WhatsAppConnectionState;
}

export interface MediaIndexEntry {
  filePath: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  tenantId?: string;
}

export function isValidBaileysQrPayload(qr: unknown): qr is string {
  if (typeof qr !== "string") return false;
  const trimmed = qr.trim();
  if (trimmed.length < 20 || trimmed.length > 2048) return false;
  if (
    trimmed.startsWith("http://") ||
    trimmed.startsWith("https://") ||
    trimmed.startsWith("data:")
  ) {
    return false;
  }
  return true;
}

/**
 * Fix #89: Build a local inline SVG data URL for initials instead of leaking customer names to ui-avatars.com.
 */
export function buildLocalInitialsAvatarSvg(name: string): string {
  const clean = String(name || "")
    .replace(/[()0-9+\-_]/g, " ")
    .trim();
  const parts = clean.split(/\s+/).filter(Boolean);
  const initials =
    parts.length >= 2
      ? `${parts[0][0] || ""}${parts[1][0] || ""}`
      : (clean.slice(0, 2) || "س").toUpperCase();
  const escaped = initials
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="32" fill="#059669"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" fill="#ffffff" font-family="sans-serif" font-size="24" font-weight="bold">${escaped}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

/**
 * Fix #85: Write JSON state atomically via a temporary file + rename so concurrent writes never corrupt JSON on disk.
 */
export function writeJsonFileAtomically(filePath: string, data: unknown): void {
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const tmpPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), "utf-8");
    fs.renameSync(tmpPath, filePath);
  } catch (err) {
    logger.warn({ err, filePath }, "[WhatsApp] Atomic JSON write warning");
  }
}

/**
 * Fix #83: Safe JSON file loader that preserves corrupt files by copying them to `.corrupt.<timestamp>.bak`
 * and logging via Pino instead of silently overwriting chat/message history.
 */
export function loadJsonFileSafe<T>(filePath: string, fallback: T): T {
  if (!fs.existsSync(filePath)) return fallback;
  try {
    const raw = fs.readFileSync(filePath, "utf-8");
    if (!raw.trim()) return fallback;
    return JSON.parse(raw) as T;
  } catch (err) {
    const corruptBackupPath = `${filePath}.corrupt.${Date.now()}.bak`;
    logger.error(
      { err, filePath, corruptBackupPath },
      "[WhatsApp] Corrupt JSON state file detected; backing up corrupt file before resetting state",
    );
    try {
      fs.copyFileSync(filePath, corruptBackupPath);
    } catch (backupErr) {
      logger.error(
        { err: backupErr, filePath },
        "[WhatsApp] Failed to back up corrupt JSON state file",
      );
    }
    return fallback;
  }
}

/**
 * Fix #84: Sanitize media filenames and confine paths strictly inside `MEDIA_DIR`.
 */
export function resolveConfinedMediaPath(rawFileName: string): string | null {
  if (!fs.existsSync(MEDIA_DIR)) {
    fs.mkdirSync(MEDIA_DIR, { recursive: true });
  }
  const rootDir = path.resolve(MEDIA_DIR);
  const safeBaseName = path
    .basename(String(rawFileName || ""))
    .replace(/[^a-zA-Z0-9._\-\u0600-\u06FF]/g, "_");
  if (!safeBaseName || safeBaseName === "." || safeBaseName === "..") {
    return null;
  }
  const candidate = path.resolve(rootDir, safeBaseName);
  const relative = path.relative(rootDir, candidate);
  if (relative.startsWith("..") || path.isAbsolute(relative)) {
    return null;
  }
  return candidate;
}

/**
 * Fix #85: Normalize Omani & international WhatsApp phone numbers accurately.
 */
export function normalizeWhatsAppPhone(rawPhone: string): string {
  const trimmed = String(rawPhone || "").trim();
  const hadPlus = trimmed.startsWith("+");
  const hadDoubleZero = trimmed.startsWith("00");
  let digits = trimmed.replace(/\D/g, "");
  if (!digits) return "";

  if (hadDoubleZero && digits.startsWith("00")) {
    digits = digits.slice(2);
  }
  if (digits.startsWith("968") && digits.length === 11) {
    return digits;
  }
  if (digits.length === 8 && /^[972]\d{7}$/.test(digits)) {
    return `968${digits}`;
  }
  if (digits.length === 9 && /^0[972]\d{7}$/.test(digits)) {
    return `968${digits.slice(1)}`;
  }
  if ((hadPlus || hadDoubleZero) && digits.length >= 10 && digits.length <= 15) {
    return digits;
  }
  if (
    /^(971|966|965|974|973|20|91|92|880|63)\d{7,11}$/.test(digits) &&
    digits.length >= 10 &&
    digits.length <= 15
  ) {
    return digits;
  }
  return digits;
}

export function isAutoConfirmationMessageText(text?: string): boolean {
  if (!text || typeof text !== "string") return false;
  return (
    text.includes("تم التحقق وتوثيق السجل التجاري") ||
    text.includes("تم استلام وتوثيق السجل التجاري") ||
    text.includes("تم استلام وقراءة مستند السجل التجاري") ||
    text.includes("تم التعرف على الشركة المسجلة مسبقاً") ||
    text.includes("تعذر قراءة الملف المرسل") ||
    text.includes("هذا المستند لا يحتوي على رقم سجل تجاري")
  );
}

export function unwrapBaileysMessageContent(
  rawMessage: Record<string, unknown> | null | undefined,
): Record<string, unknown> {
  if (!rawMessage || typeof rawMessage !== "object") return {};
  let m: Record<string, unknown> = rawMessage;
  for (let i = 0; i < 6; i++) {
    const ephemeral = m.ephemeralMessage as { message?: Record<string, unknown> } | undefined;
    const viewOnce = m.viewOnceMessage as { message?: Record<string, unknown> } | undefined;
    const viewOnceV2 = m.viewOnceMessageV2 as { message?: Record<string, unknown> } | undefined;
    const viewOnceV2Ext = m.viewOnceMessageV2Extension as { message?: Record<string, unknown> } | undefined;
    const docWithCaption = m.documentWithCaptionMessage as { message?: Record<string, unknown> } | undefined;
    const edited = m.editedMessage as {
      message?: { protocolMessage?: { editedMessage?: Record<string, unknown> } };
    } | undefined;
    const template = m.templateMessage as { hydratedTemplate?: Record<string, unknown> } | undefined;

    const next =
      ephemeral?.message ||
      viewOnce?.message ||
      viewOnceV2?.message ||
      viewOnceV2Ext?.message ||
      docWithCaption?.message ||
      edited?.message?.protocolMessage?.editedMessage ||
      template?.hydratedTemplate ||
      null;
    if (next && typeof next === "object") {
      m = next;
    } else {
      break;
    }
  }
  return m;
}

export function extractBaileysMessageText(
  rawMsg: { message?: Record<string, unknown> | null },
): string {
  if (!rawMsg.message) return "";
  const m = unwrapBaileysMessageContent(rawMsg.message);
  const extText = m.extendedTextMessage as { text?: string } | undefined;
  const imgMsg = m.imageMessage as { caption?: string } | undefined;
  const vidMsg = m.videoMessage as { caption?: string } | undefined;
  const docMsg = m.documentMessage as {
    caption?: string;
    title?: string;
    fileName?: string;
  } | undefined;

  const text =
    (typeof m.conversation === "string" ? m.conversation : "") ||
    extText?.text ||
    imgMsg?.caption ||
    vidMsg?.caption ||
    docMsg?.caption ||
    docMsg?.title ||
    docMsg?.fileName ||
    (m.imageMessage ? "📷 [صورة مرفقة]" : "") ||
    (m.audioMessage ? "🎤 [رسالة صوتية]" : "") ||
    (m.videoMessage ? "🎥 [مقطع فيديو]" : "") ||
    (m.documentMessage ? "📄 [مستند مرفق]" : "") ||
    (m.locationMessage ? "📍 [موقع جغرافي]" : "") ||
    (m.contactMessage ? "👤 [بطاقة جهة اتصال]" : "") ||
    "";

  return String(text).trim();
}

export async function syncAuthDirToPostgres(params: {
  tenantId: string;
  instanceId: string;
  phoneNumber: string | null;
  profileName: string | null;
  isLocalAuthenticated: boolean;
}): Promise<boolean> {
  try {
    if (!fs.existsSync(AUTH_DIR) || !params.isLocalAuthenticated) {
      return false;
    }
    const fileNames = fs.readdirSync(AUTH_DIR);
    if (fileNames.length === 0) return false;

    const filesMap: Record<string, string> = {};
    for (const file of fileNames) {
      if (
        file === "creds.json" ||
        file.startsWith("app-state-sync-key-") ||
        file.startsWith("app-state-sync-version-") ||
        file.startsWith("pre-key-") ||
        file.startsWith("session-")
      ) {
        const fullPath = path.join(AUTH_DIR, file);
        if (fs.statSync(fullPath).isFile()) {
          filesMap[file] = fs.readFileSync(fullPath, "utf-8");
        }
      }
    }
    if (Object.keys(filesMap).length === 0) return false;

    const existing = await db
      .select({ id: whatsappAuthSessions.id })
      .from(whatsappAuthSessions)
      .where(
        and(
          eq(whatsappAuthSessions.tenantId, params.tenantId),
          eq(whatsappAuthSessions.instanceId, params.instanceId),
        ),
      )
      .limit(1);

    const serializedState = JSON.stringify(filesMap);
    if (existing.length > 0) {
      await db
        .update(whatsappAuthSessions)
        .set({
          authStateJson: serializedState,
          phoneNumber: params.phoneNumber,
          profileName: params.profileName,
          updatedAt: new Date(),
        })
        .where(eq(whatsappAuthSessions.id, existing[0].id));
    } else {
      await db.insert(whatsappAuthSessions).values({
        tenantId: params.tenantId,
        instanceId: params.instanceId,
        authStateJson: serializedState,
        phoneNumber: params.phoneNumber,
        profileName: params.profileName,
      });
    }
    return true;
  } catch (err) {
    logger.warn({ err }, "[WhatsApp] Non-fatal auth DB sync warning");
    return false;
  }
}

export async function restoreAuthDirFromPostgres(params: {
  tenantId: string;
  instanceId: string;
  isLocalAuthenticated: boolean;
}): Promise<{
  restored: boolean;
  restoredCount: number;
  phoneNumber?: string | null;
  profileName?: string | null;
}> {
  try {
    if (!fs.existsSync(AUTH_DIR)) {
      fs.mkdirSync(AUTH_DIR, { recursive: true });
    }
    if (params.isLocalAuthenticated) {
      return { restored: true, restoredCount: 0 };
    }

    const rows = await db
      .select()
      .from(whatsappAuthSessions)
      .where(
        and(
          eq(whatsappAuthSessions.tenantId, params.tenantId),
          eq(whatsappAuthSessions.instanceId, params.instanceId),
        ),
      )
      .limit(1);

    const targetRow = rows.length > 0 && rows[0].authStateJson ? rows[0] : null;
    if (!targetRow || !targetRow.authStateJson) {
      return { restored: false, restoredCount: 0 };
    }

    const filesMap = JSON.parse(targetRow.authStateJson) as Record<string, string>;
    let restoredCount = 0;
    for (const [fileName, content] of Object.entries(filesMap)) {
      const safeName = path.basename(fileName);
      if (typeof content === "string" && safeName && safeName !== "." && safeName !== "..") {
        fs.writeFileSync(path.join(AUTH_DIR, safeName), content, "utf-8");
        restoredCount += 1;
      }
    }

    return {
      restored: restoredCount > 0,
      restoredCount,
      phoneNumber: targetRow.phoneNumber,
      profileName: targetRow.profileName,
    };
  } catch (err) {
    logger.warn({ err }, "[WhatsApp] Non-fatal auth DB restore warning");
    return { restored: false, restoredCount: 0 };
  }
}

// Per-phone in-flight registration lock to prevent concurrent first-message duplicates (#70)
const customerRegistrationLocks = new Map<string, Promise<{
  customerId?: number;
  customerName: string;
  companyName?: string;
}>>();

/**
 * Fix #70 & #73: Query by normalized phone in SQL without loading full tables or crDocumentUrl blobs,
 * prevent concurrent first-message duplicate customer inserts, and set nationality to null when unknown.
 */
export async function ensureCustomerRegisteredInDb(
  tenantId: string,
  formattedPhone: string,
  rawPushName?: string,
): Promise<{ customerId?: number; customerName: string; companyName?: string }> {
  const rawDigits = normalizeWhatsAppPhone(formattedPhone);
  if (!rawDigits || rawDigits.length < 7) {
    return { customerName: rawPushName || formattedPhone };
  }
  const lockKey = `${tenantId}::${rawDigits}`;
  const inFlight = customerRegistrationLocks.get(lockKey);
  if (inFlight) {
    return inFlight;
  }

  const task = (async () => {
    try {
      const plusNormalized = `+${rawDigits}`;
      const local8 = rawDigits.startsWith("968") && rawDigits.length === 11
        ? rawDigits.slice(3)
        : rawDigits;

      const candidateCompanies = await db
        .select({
          id: companies.id,
          name: companies.name,
          taxId: companies.taxId,
          contactPhone: companies.contactPhone,
          ownerCustomerId: companies.ownerCustomerId,
        })
        .from(companies)
        .where(
          and(
            eq(companies.tenantId, tenantId),
            isNull(companies.deletedAt),
            or(
              eq(companies.contactPhone, plusNormalized),
              eq(companies.contactPhone, rawDigits),
              eq(companies.contactPhone, local8),
            ),
          ),
        )
        .limit(5);

      const matchedCompany = candidateCompanies[0];
      const companyName = matchedCompany?.name;

      const isCleanName = (name?: string | null): boolean => {
        if (!name) return false;
        const t = name.trim();
        if (!t || t.length < 2) return false;
        if (t.startsWith("متعامل (") || t.startsWith("عميل واتساب")) return false;
        if (/^[+0-9\s()-]+$/.test(t)) return false;
        return true;
      };

      const cleanPushName = isCleanName(rawPushName) ? rawPushName!.trim() : null;
      const targetCustomerName = companyName
        ? cleanPushName || companyName
        : cleanPushName || `عميل واتساب (${plusNormalized})`;

      const existingCustomers = await db
        .select({
          id: customers.id,
          fullNameAr: customers.fullNameAr,
          customerType: customers.customerType,
          phone: customers.phone,
          whatsapp: customers.whatsapp,
        })
        .from(customers)
        .where(
          and(
            eq(customers.tenantId, tenantId),
            isNull(customers.deletedAt),
            or(
              eq(customers.phone, plusNormalized),
              eq(customers.phone, rawDigits),
              eq(customers.phone, local8),
              eq(customers.whatsapp, plusNormalized),
              eq(customers.whatsapp, rawDigits),
              eq(customers.whatsapp, local8),
            ),
          ),
        )
        .limit(1);

      const existingCustomer = existingCustomers[0];

      if (existingCustomer) {
        if (matchedCompany && !matchedCompany.ownerCustomerId) {
          await db
            .update(companies)
            .set({ ownerCustomerId: existingCustomer.id, updatedAt: new Date() })
            .where(eq(companies.id, matchedCompany.id));
        }
        const currentName = existingCustomer.fullNameAr || "";
        if (
          (!isCleanName(currentName) || currentName.startsWith("عميل واتساب")) &&
          isCleanName(targetCustomerName)
        ) {
          await db
            .update(customers)
            .set({
              fullNameAr: targetCustomerName,
              customerType: matchedCompany ? "COMPANY" : existingCustomer.customerType,
              updatedAt: new Date(),
            })
            .where(eq(customers.id, existingCustomer.id));
        }
        return {
          customerId: existingCustomer.id,
          customerName: targetCustomerName,
          companyName,
        };
      }

      const [newCust] = await db
        .insert(customers)
        .values({
          tenantId,
          customerType: matchedCompany ? "COMPANY" : "INDIVIDUAL",
          fullNameAr: targetCustomerName,
          phone: plusNormalized,
          whatsapp: plusNormalized,
          nationality: null, // Fix #70: Do not hardcode "عُماني" for every inbound phone number
          createdBy: "WhatsApp Auto-Registration",
        })
        .returning({ id: customers.id });

      if (matchedCompany && newCust) {
        await db
          .update(companies)
          .set({ ownerCustomerId: newCust.id, updatedAt: new Date() })
          .where(eq(companies.id, matchedCompany.id));
      }

      return {
        customerId: newCust?.id,
        customerName: targetCustomerName,
        companyName,
      };
    } catch (err) {
      logger.warn({ err }, "[WhatsApp] Customer auto-registration notice");
      return { customerName: rawPushName || formattedPhone };
    } finally {
      customerRegistrationLocks.delete(lockKey);
    }
  })();

  customerRegistrationLocks.set(lockKey, task);
  return task;
}
