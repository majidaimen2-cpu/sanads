import crypto from "crypto";
import { eq, and, or, isNull, desc, sql } from "drizzle-orm";
import { db, pool } from "../../db/index.js";
import {
  companies,
  customers,
  customerDocuments,
  whatsappMessages,
  whatsappProcessingJobs,
  whatsappOutbox,
  auditLogs,
  notifications,
  companyPeople,
  documentMatchCandidates,
} from "../../db/schema.js";
import {
  normalizeCrNumber,
  normalizeAndValidateDate,
  normalizeDigitsToAscii,
  extractPagesFromPdfBuffer,
  ocrPdfOrImageBuffer,
  parseCrDocumentDeterministically,
  detectPromptInjectionInDocument,
  extractCommercialRegistrationFromFile,
} from "./crExtractionService.js";
import {
  validateDocumentBuffer,
  storePermanentDocument,
  type StoredDocumentArtifact,
} from "./documentStorageService.js";
import { normalizeArabicText } from "../../lib/arabicNormalizer.js";
import { classifyDocumentExpiry } from "./expiryCronService.js";
import { toDocTypeCode, isPersonDocument, type DocTypeCode } from "../../lib/documentTypes.js";
import { detectNewDocumentType, extractTyped, type TypedExtraction } from "./documents/extractors/index.js";
import { classifyDocumentWithGemini } from "./documents/geminiClient.js";
import { matchDocumentToCompany, buildMatchInput, type MatchOutcome } from "./documentMatchingService.js";

export type CanonicalDocumentType =
  | "commercial_registry"
  | "municipal_license"
  | "tax_certificate"
  | "tax_invoice"
  | "chamber_certificate"
  | "labor_certificate"
  | "employment_certificate"
  | "contract"
  | "residence_card"
  | "passport"
  | "lease_contract"
  | "other";

export const DOCUMENT_TYPE_LABELS_AR: Record<CanonicalDocumentType, string> = {
  commercial_registry: "السجل التجاري",
  municipal_license: "الترخيص البلدي",
  tax_certificate: "الشهادة الضريبية",
  tax_invoice: "الفاتورة الضريبية",
  chamber_certificate: "شهادة انتساب الغرفة",
  labor_certificate: "ترخيص / بطاقة العمل",
  employment_certificate: "شهادة التعمين / التوظيف",
  contract: "العقد الرسمي",
  residence_card: "بطاقة الإقامة",
  passport: "جواز السفر",
  lease_contract: "عقد الإيجار",
  other: "وثيقة إضافية",
};

const GEMINI_CODE_TO_CANONICAL: Partial<Record<DocTypeCode, CanonicalDocumentType>> = {
  CR: "commercial_registry",
  MUNICIPAL_LICENSE: "municipal_license",
  COMMERCIAL_LICENSE: "municipal_license",
  TAX_CARD: "tax_certificate",
  CHAMBER_CERT: "chamber_certificate",
  LABOR_LICENSE: "labor_certificate",
  LABOR_CARD: "labor_certificate",
  OMANIZATION_CERT: "employment_certificate",
  LEASE_CONTRACT: "lease_contract",
  RESIDENCE_CARD: "residence_card",
  PASSPORT: "passport",
  OTHER: "other",
};

export type ProcessingState =
  | "RECEIVED"
  | "DOWNLOADING"
  | "DOWNLOADED"
  | "EXTRACTING"
  | "CLASSIFYING"
  | "MATCHING"
  | "VALIDATING"
  | "SAVING"
  | "COMPLETED"
  | "NEEDS_REVIEW"
  | "RETRY_PENDING"
  | "FAILED"
  | "REJECTED";

export interface ExtractedDocumentIntelligence {
  documentType: CanonicalDocumentType;
  documentTypeAr: string;
  crNumberRaw: string | null;
  normalizedCrNumber: string | null;
  companyNameAr: string | null;
  companyNameEn: string | null;
  tradeName: string | null;
  legalForm: string | null;
  issueDate: string | null;
  expiryDate: string | null;
  rawIssueDate: string | null;
  rawExpiryDate: string | null;
  documentNumber: string | null;
  taxCardNumber: string | null;
  chamberNumber: string | null;
  licenseNumber: string | null;
  issuingAuthority: string | null;
  capitalOmr: number | null;
  activities: string[];
  owners: string[];
  authorizedSignatories: string[];
  city: string | null;
  contactPhone: string | null;
  confidenceScore: number;
  confidenceLevel: "HIGH" | "MEDIUM" | "LOW";
  extractedText: string;
  promptInjectionDetected: boolean;
  chronologicalDateError: boolean;
  // Smart Company File additions (all optional so older stored extraction JSON stays valid)
  docTypeCode?: DocTypeCode;
  classificationMethod?: "REGEX" | "GEMINI" | "NONE";
  crFromFileNameOnly?: boolean;
  personName?: string | null;
  personCivilNumber?: string | null;
  personPassportNumber?: string | null;
  typedFields?: TypedExtraction | null;
}

export interface WhatsAppMediaIngestionInput {
  tenantId?: string;
  instanceId?: string;
  providerMessageId: string;
  senderPhone: string;
  senderJid?: string;
  senderName?: string;
  messageText?: string;
  fileName?: string;
  declaredMimeType?: string;
  mediaBuffer?: Buffer | null;
  mediaDownloadFn?: () => Promise<Buffer>;
  rawPayload?: any;
  sendWhatsAppReplyFn?: (recipientJidOrPhone: string, text: string) => Promise<{ sentId?: string } | void>;
  /**
   * Entry channel. WHATSAPP (default) is the primary flow. CHAT (in-app chatbot) and WEB (manual upload)
   * run through the exact same pipeline; they just do not send a WhatsApp reply.
   */
  channel?: "WHATSAPP" | "CHAT" | "WEB";
  /** Manual upload from a company page: company is already known, lanes are skipped. */
  forcedCompanyId?: number | null;
  /** Authenticated app user name for CHAT/WEB audit trails. */
  actorName?: string;
}

export interface WhatsAppProcessingResult {
  ok: boolean;
  deduplicatedReplay: boolean;
  jobId: string;
  correlationId: string;
  state: ProcessingState;
  documentType: CanonicalDocumentType | null;
  normalizedCrNumber: string | null;
  companyId: number | null;
  companyName: string | null;
  companyResolution:
    | "CREATED_NEW_COMPANY"
    | "MATCHED_EXISTING_COMPANY"
    | "DUPLICATE_FILE_SKIPPED"
    | "NEEDS_HUMAN_REVIEW"
    | "REJECTED_FILE"
    | null;
  savedDocumentId: number | null;
  versionNumber: number | null;
  isDuplicateFile: boolean;
  isNewCompany: boolean;
  senderAuthorized: boolean;
  nameDiscrepancyFlag: boolean;
  replyCategory: string;
  replyMessageText: string;
  outboxId: string | null;
  errorCode?: string;
  errorMessage?: string;
  /** Smart Company File: which lane the document ended in. */
  matchLane?: "AUTO" | "CONFIRM" | "UNMATCHED" | "MANUAL" | null;
  matchScore?: number | null;
}

/**
 * Normalizes a phone number into digits only (e.g., "+968 9123 4567" -> "96891234567" or last 8 digits for comparison).
 */
export function normalizePhoneDigits(rawPhone: string | null | undefined): string {
  if (!rawPhone) return "";
  const ascii = normalizeDigitsToAscii(String(rawPhone))
    .replace(/@s\.whatsapp\.net|@g\.us|@lid/gi, "")
    .replace(/\D/g, "");
  return ascii;
}

export function phonesMatch(phoneA: string | null | undefined, phoneB: string | null | undefined): boolean {
  const a = normalizePhoneDigits(phoneA);
  const b = normalizePhoneDigits(phoneB);
  if (!a || !b || a.length < 7 || b.length < 7) return false;
  if (a === b) return true;
  const tailA = a.slice(-8);
  const tailB = b.slice(-8);
  return tailA.length === 8 && tailA === tailB;
}

/**
 * Normalizes Arabic & English company names for fuzzy-safe matching across CRs and Licenses.
 * Handles PDF visual ligature inversions (e.g., مقاوالت <-> مقاولات) and strips legal form suffixes/prefixes.
 */
export function normalizeCompanyNameForMatch(rawName: string | null | undefined): string {
  if (!rawName) return "";
  let s = normalizeArabicText(rawName)
    // Normalize common PDF Arabic Lam-Alef ligature visual inversions
    .replace(/مقاوالت/g, "مقاولات")
    .replace(/صالحيه/g, "صلاحيه")
    .replace(/اعالن/g, "اعلان")
    .replace(/امالك/g, "املاك")
    .replace(/اصالح/g, "اصلاح")
    .replace(/انطالق/g, "انطلاق")
    .replace(/استغالل/g, "استغلال")
    .replace(/اخالص/g, "اخلاص")
    .replace(/لالست/g, "للاست")
    .replace(/لاللكت/g, "للالكت")
    .replace(/طالل/g, "طلال")
    .replace(/جالل/g, "جلال")
    .replace(/بالل/g, "بلال");

  // Remove punctuation
  s = s.replace(/[.,\-_/()|"'«»:`~]/g, " ");

  // Strip legal entity phrases and prefixes/suffixes
  s = s
    .replace(/\b(?:شركه الشخص الواحد|شركه محدوده المسؤوليه|محدوده المسؤوليه|شركه تضامنيه|شركه توصيه|شركه مساهمه)\b/g, " ")
    .replace(/\b(?:ش\s*م\s*م|ش\s*ش\s*و|ذ\s*م\s*م|ش\s*م\s*ع\s*ع|ش\s*م\s*ع\s*م)\b/g, " ")
    .replace(/\b(?:llc|l\s*l\s*c|spc|s\s*p\s*c|saog|saoc|company|co|establishment|est)\b/gi, " ")
    .replace(/^(?:شركه|مؤسسه|مكتب|فرع)\s+/g, "")
    .replace(/\s+(?:شركه|مؤسسه|مكتب|فرع)$/g, "")
    .replace(/\s+/g, " ")
    .trim();

  return s;
}

export function companyNamesMatch(
  nameA: string | null | undefined,
  nameB: string | null | undefined
): boolean {
  if (!nameA || !nameB) return false;
  const rawA = normalizeArabicText(nameA).replace(/\s+/g, " ").trim();
  const rawB = normalizeArabicText(nameB).replace(/\s+/g, " ").trim();
  if (rawA && rawB && rawA === rawB) return true;

  const coreA = normalizeCompanyNameForMatch(nameA);
  const coreB = normalizeCompanyNameForMatch(nameB);
  if (!coreA || !coreB || coreA.length < 4 || coreB.length < 4) return false;
  if (coreA === coreB) return true;

  // Allow high-precision containment only when the shorter core name has at least 2 words and >= 10 chars
  const shorter = coreA.length <= coreB.length ? coreA : coreB;
  const longer = coreA.length <= coreB.length ? coreB : coreA;
  if (shorter.length >= 10 && shorter.split(" ").length >= 2 && longer.includes(shorter)) {
    return true;
  }
  return false;
}

/**
 * Formats the 5 exact Arabic WhatsApp response templates required by Section 10.
 */
export function buildArabicWhatsAppReply(params: {
  category:
    | "NEW_COMPANY_REGISTERED"
    | "EXISTING_COMPANY_DOCUMENT_ADDED"
    | "DUPLICATE_FILE_ALREADY_STORED"
    | "MISSING_OR_UNREADABLE_DATA"
    | "DOCUMENT_QUEUED_FOR_CONFIRMATION"
    | "CORRUPTED_OR_UNSUPPORTED_FILE";
  companyName?: string | null;
  crNumber?: string | null;
  expiryDate?: string | null;
  documentType?: CanonicalDocumentType | null;
}): string {
  const companyName = params.companyName?.trim() || "غير محدد";
  const crNumber = params.crNumber?.trim() || "غير محدد";
  const expiryDate = params.expiryDate?.trim() || "غير محدد";
  const docLabel = params.documentType
    ? DOCUMENT_TYPE_LABELS_AR[params.documentType] || params.documentType
    : "وثيقة رسمية";

  switch (params.category) {
    case "NEW_COMPANY_REGISTERED":
      return [
        "تم استلام السجل التجاري وتسجيل الشركة بنجاح.",
        `اسم الشركة: ${companyName}`,
        `رقم السجل التجاري: ${crNumber}`,
        `تاريخ الانتهاء: ${expiryDate}`,
        "تم حفظ الوثيقة الأصلية في ملف الشركة.",
      ].join("\n");

    case "EXISTING_COMPANY_DOCUMENT_ADDED":
      return [
        "تم التعرف على الشركة المسجلة مسبقاً في النظام.",
        `اسم الشركة: ${companyName}`,
        `رقم السجل التجاري: ${crNumber}`,
        `تمت إضافة الوثيقة (${docLabel}) إلى ملف الشركة دون إنشاء سجل مكرر.`,
      ].join("\n");

    case "DUPLICATE_FILE_ALREADY_STORED":
      return [
        "تم استلام هذه الوثيقة مسبقاً وهي محفوظة بالفعل في ملف الشركة:",
        `اسم الشركة: ${companyName}`,
        `رقم السجل التجاري: ${crNumber}`,
        "لم يتم إنشاء سجل جديد أو تكرار الملف.",
      ].join("\n");

    case "MISSING_OR_UNREADABLE_DATA":
      return [
        "تم استلام الوثيقة وحفظ النسخة الأصلية، ولكن تعذر التحقق من رقم السجل التجاري أو بعض البيانات الأساسية بشكل مؤكد.",
        "تم تحويل الوثيقة للمراجعة اليدوية لحين إرسال السجل التجاري أو اعتمادها، وسيتم ربطها تلقائياً وإشعاركم فور اعتمادها.",
      ].join("\n");

    case "DOCUMENT_QUEUED_FOR_CONFIRMATION":
      return [
        `تم استلام الوثيقة (${docLabel}) وحفظ النسخة الأصلية.`,
        "سيقوم المكتب بتأكيد الشركة التابعة لها ثم حفظها في ملفها.",
      ].join("\n");

    case "CORRUPTED_OR_UNSUPPORTED_FILE":
      return "تعذر قراءة الملف المرسل. يرجى إعادة إرسال الوثيقة بصيغة PDF أو صورة واضحة (JPG أو PNG).";
  }
}

/**
 * Content-based document classifier (Section 7).
 * Never classifies by filename alone; inspects actual extracted text & structure.
 */
export function classifyDocumentByContent(text: string): {
  documentType: CanonicalDocumentType;
  issuingAuthority: string | null;
} {
  const clean = normalizeDigitsToAscii(text || "");

  // 0. Smart Company File types with strong markers (passport MRZ, residence card, lease). Checked first
  //    because their wording (employer, tenant, "Royal Oman Police") overlaps the generic rules below.
  const newType = detectNewDocumentType(clean);
  if (newType) {
    if (newType.type === "PASSPORT") return { documentType: "passport", issuingAuthority: "جواز سفر" };
    if (newType.type === "RESIDENCE_CARD") return { documentType: "residence_card", issuingAuthority: "شرطة عمان السلطانية" };
    if (newType.type === "LEASE_CONTRACT") return { documentType: "lease_contract", issuingAuthority: "عقد إيجار" };
  }

  // 1. Tax Invoice vs Tax Certificate (Critical distinction: Tests 14 & 20)
  const hasTaxInvoiceMarker =
    /فاتورة\s*ضريبية|Tax\s*Invoice|رقم\s*الفاتورة|Invoice\s*(?:No|Number)|المبلغ\s*الإجمالي\s*شامل\s*الضريبة|Total\s*Amount\s*Due/i.test(
      clean
    );
  const hasTaxCertificateMarker =
    /شهادة\s*(?:ال)?تسجيل\s*(?:في\s*)?ضريبة|الشهادة\s*الضريبية|شهادة\s*ضريبية|Tax\s*Registration\s*Certificate|VAT\s*Certificate|جهاز\s*الضرائب|Tax\s*Authority/i.test(
      clean
    );
  if (hasTaxInvoiceMarker && !hasTaxCertificateMarker) {
    return {
      documentType: "tax_invoice",
      issuingAuthority: "فاتورة تجارية / ضريبية",
    };
  }
  if (hasTaxCertificateMarker && !hasTaxInvoiceMarker) {
    return {
      documentType: "tax_certificate",
      issuingAuthority: "جهاز الضرائب - سلطنة عُمان",
    };
  }

  // 2. Employment / Omanization Certificate vs Labor License / Card (Critical distinction: Tests 16 & 17)
  const hasEmploymentCertMarker =
    /شهادة\s*(?:نسب\s*)?التعمين|نسبة\s*التعمين|شهادة\s*توطين|Omanization\s*Certificate|Employment\s*Status\s*Certificate|شهادة\s*اثبات\s*التعمين/i.test(
      clean
    );
  const hasLaborLicenseMarker =
    /ترخيص\s*(?:استقدام|عمل|قوى\s*عاملة)|بطاقة\s*عمل|تصريح\s*عمل|Labor\s*(?:Card|License|Permit|Clearance)|Clearance\s*Certificate\s*-\s*Ministry\s*of\s*Labour/i.test(
      clean
    );
  if (hasEmploymentCertMarker && !hasLaborLicenseMarker) {
    return {
      documentType: "employment_certificate",
      issuingAuthority: "وزارة العمل - سلطنة عُمان",
    };
  }
  if (hasLaborLicenseMarker) {
    return {
      documentType: "labor_certificate",
      issuingAuthority: "وزارة العمل - سلطنة عُمان",
    };
  }

  // 3. Municipal License (Test 13)
  if (
    /ترخيص\s*بلدي|الترخيص\s*البلدي|رخصة\s*بلدية|بلدية\s*(?:مسقط|ظفار|صحار|نزوى|صور|البريمي|عبري)|Municipal\s*License|Municipality\s*Permit/i.test(
      clean
    )
  ) {
    return {
      documentType: "municipal_license",
      issuingAuthority: "البلدية المختصة - سلطنة عُمان",
    };
  }

  // 4. Chamber of Commerce Certificate (Test 15)
  if (
    /شهادة\s*انتساب|غرفة\s*تجارة\s*وصناعة\s*عمان|عضوية\s*الغرفة|Oman\s*Chamber\s*of\s*Commerce|Chamber\s*Membership\s*Certificate/i.test(
      clean
    )
  ) {
    return {
      documentType: "chamber_certificate",
      issuingAuthority: "غرفة تجارة وصناعة عُمان",
    };
  }

  // 5. Contract (Test 18)
  if (
    /عقد\s*(?:إيجار|تأسيس|شراكة|خدمات|عمل|اتفاقية)|Lease\s*Agreement|Articles\s*of\s*Association|Service\s*Contract|الطرف\s*الأول[\s\S]{1,200}الطرف\s*الثاني/i.test(
      clean
    )
  ) {
    return {
      documentType: "contract",
      issuingAuthority: "عقد رسمي موثق",
    };
  }

  // 6. Commercial Registration (Tests 1–12)
  if (
    /شهادة\s*(?:ال)?سجل\s*(?:ال)?تجاري|مستخرج\s*(?:ال)?سجل\s*(?:ال)?تجاري|بيانات\s*السجل\s*التجاري|وزارة\s*التجارة\s*والصناعة\s*وترويج\s*الاستثمار|Commercial\s*Registration|Oman\s*Business\s*Platform|\|Registration\s*Name\||\|Legal\s*Type\||(?:رقم\s*السجل\s*التجاري[\s\S]{1,200}الشكل\s*القانوني)/i.test(
      clean
    ) ||
    (!/مذكرة\s*داخلية/i.test(clean) &&
      /(?:رقم\s*السجل(?:\s*التجاري)?|السجل\s*التجاري|C\.?\s*R\.?\s*No)/i.test(clean) &&
      /(?:تاريخ\s*الانتهاء|انتهاء\s*الصلاحية|انتهاء\s*الصالحية|Expiry\s*Date|الشكل\s*القانوني|النشاط\s*التجاري|رأس\s*المال)/i.test(
        clean
      ))
  ) {
    return {
      documentType: "commercial_registry",
      issuingAuthority: "وزارة التجارة والصناعة وترويج الاستثمار - سلطنة عُمان",
    };
  }

  return {
    documentType: "other",
    issuingAuthority: null,
  };
}

/**
 * Extracts structured intelligence from any PDF or Image document buffer without fabricating values.
 */
export async function extractDocumentIntelligence(
  buffer: Buffer,
  mimeType: string,
  supplementaryText?: string,
  fileName?: string
): Promise<ExtractedDocumentIntelligence> {
  let pages: Array<{ pageNumber: number; text: string }> = [];

  if (mimeType === "application/pdf") {
    const pdfRes = await extractPagesFromPdfBuffer(buffer);
    pages = pdfRes.pages;
  } else if (mimeType === "text/plain") {
    const utf8 = buffer.toString("utf8").trim();
    if (utf8) {
      pages = [{ pageNumber: 1, text: utf8 }];
    }
  }

  // If native PDF extraction returned empty or this is an image, check embedded UTF-8 text or run OCR
  if (pages.length === 0) {
    const rawUtf8 = buffer.toString("utf8");
    const readableMatch = rawUtf8.match(
      /(?:سلطنة\s*عمان|وزارة\s*التجارة|شهادة\s*(?:ال)?سجل\s*(?:ال)?تجاري|مستخرج\s*(?:ال)?سجل\s*(?:ال)?تجاري|(?:ال)?سجل\s*(?:ال)?تجاري|رقم\s*السجل|اسم\s*الشركة|اسم\s*المنشأة|المرخص\s*له|صاحب\s*الترخيص|ترخيص\s*بلدي|بلدية\s*مسقط|شهادة\s*(?:ال)?تسجيل|الشهادة\s*الضريبية|فاتورة\s*ضريبية|شهادة\s*انتساب|غرفة\s*تجارة|ترخيص\s*(?:استقدام|عمل)|شهادة\s*(?:نسب\s*)?التعمين|عقد\s*إيجار|مذكرة\s*داخلية|Commercial\s*Registration|Municipal\s*License|Tax\s*Certificate|Tax\s*Invoice|Chamber\s*of\s*Commerce|Labor\s*Card|Omanization\s*Certificate)[\s\S]+/i
    );
    if (readableMatch && (readableMatch[0].match(/\uFFFD/g) || []).length < 25) {
      pages = [{ pageNumber: 1, text: readableMatch[0] }];
    } else {
      const sha256 = crypto.createHash("sha256").update(buffer).digest("hex");
      pages = await ocrPdfOrImageBuffer(buffer, mimeType, sha256);
    }
  }

  if (supplementaryText && supplementaryText.trim().length > 10) {
    const existingJoined = pages.map((p) => p.text).join("\n");
    if (!existingJoined.includes(supplementaryText.trim())) {
      pages.push({ pageNumber: pages.length + 1, text: supplementaryText.trim() });
    }
  }

  const combinedText = pages.map((p) => p.text).join("\n\n").trim();
  const promptInjectionDetected = detectPromptInjectionInDocument(combinedText);

  // Run deterministic CR parser to harvest all structured fields
  const det = parseCrDocumentDeterministically(
    pages.length > 0 ? pages : [{ pageNumber: 1, text: combinedText }],
    mimeType === "application/pdf" ? "NATIVE_PDF" : "DETERMINISTIC_PARSER"
  );

  // Content-based classification (overrides generic classification)
  const classification = classifyDocumentByContent(combinedText);

  // Gemini fallback only when the regex classifier found nothing (never when it is confident).
  let classificationMethod: "REGEX" | "GEMINI" | "NONE" = classification.documentType !== "other" ? "REGEX" : "NONE";
  if (classification.documentType === "other" && combinedText.length >= 20 && !promptInjectionDetected) {
    const g = await classifyDocumentWithGemini({ text: combinedText });
    const mapped = g && g.confidence >= 60 ? GEMINI_CODE_TO_CANONICAL[g.type] : undefined;
    if (mapped && mapped !== "other") {
      classification.documentType = mapped;
      classification.issuingAuthority = null;
      classificationMethod = "GEMINI";
    }
  }

  let crFromFileName = false;
  let crNumberRaw = det.fields.crNumber.raw || det.fields.crNumber.normalized || null;
  if (!crNumberRaw) {
    const crRegexMatch = normalizeDigitsToAscii(combinedText).match(
      /(?:رقم\s*السجل\s*التجاري|السجل\s*التجاري\s*رقم|سجل\s*تجاري\s*رقم|رقم\s*السجل|س\s*\.\s*ت|Commercial\s*Registration\s*(?:No\.?|Number|#)?|C\.?\s*R\.?\s*(?:No\.?|Number|#))\s*[:\-]?\s*((?:CR[\s\-:/]*)?\d{5,10}(?:\s*\/\s*0?\d{1,2})?)/i
    );
    if (crRegexMatch) {
      crNumberRaw = crRegexMatch[1].trim();
    }
  }

  // Oman Business Platform markdown table & header patterns:
  // e.g. |Registration Number|||رقم السجل| followed by **1555101** or in table
  if (!crNumberRaw) {
    const omanTableCrMatch = normalizeDigitsToAscii(combinedText).match(
      /(?:Registration\s*Number|رقم\s*السجل)[\s\S]{0,100}?\*\*(\d{5,10})\*\*/i
    );
    if (omanTableCrMatch) {
      crNumberRaw = omanTableCrMatch[1].trim();
    }
  }
  // Bold digits right after Registration Details / Commercial Registration Certificate:
  if (!crNumberRaw) {
    const boldCrMatch = normalizeDigitsToAscii(combinedText).match(
      /(?:Commercial\s*Registration\s*Certificate|شهادة\s*السجل\s*التجاري)[\s\S]{0,350}?\*\*(\d{6,10})\*\*/i
    );
    if (boldCrMatch) {
      crNumberRaw = boldCrMatch[1].trim();
    }
  }
  // Look in filename: e.g. cr_certificate(1555101).pdf
  if (!crNumberRaw && fileName) {
    const fnCrMatch = normalizeDigitsToAscii(fileName).match(/\b(\d{6,10})\b/);
    if (fnCrMatch) {
      crNumberRaw = fnCrMatch[1].trim();
      crFromFileName = true;
    }
  }

  let normalizedCr = crNumberRaw ? normalizeCrNumber(crNumberRaw) : "";
  let validNormCr = normalizedCr && /^\d{5,10}$/.test(normalizedCr) ? normalizedCr : null;

  let companyNameAr = det.fields.companyNameAr.normalized || det.fields.tradeName.normalized || null;
  let companyNameEn = det.fields.companyNameEn.normalized || null;

  // Oman Business Platform table: |Registration Name|ALSafa General Contracting And Supplies|الصفا للمقاوالت العمومية والتوريدات|اسم السجل|
  const omanRegNameMatch = combinedText.match(/\|Registration\s*Name\|([^|]+)\|([^|]+)\|/i);
  if (omanRegNameMatch) {
    if (!companyNameEn && omanRegNameMatch[1].trim()) companyNameEn = omanRegNameMatch[1].trim();
    if (!companyNameAr && omanRegNameMatch[2].trim()) companyNameAr = omanRegNameMatch[2].trim();
  }

  if (!companyNameAr) {
    const nameMatch = combinedText.match(
      /(?:اسم\s*الشركة|اسم\s*المنشأة|الاسم\s*التجاري|اسم\s*المؤسسة|اسم\s*المرخص\s*له|المرخص\s*له|صاحب\s*الترخيص|اسم\s*صاحب\s*الترخيص|اسم\s*المستفيد|اسم\s*المكلف|اسم\s*الخاضع\s*للضريبة|اسم\s*العضو|اسم\s*صاحب\s*العمل|اسم\s*الكفيل)\s*[:\-]?\s*([^\r\n|]{3,90})/i
    );
    if (nameMatch) {
      companyNameAr = nameMatch[1].trim();
    }
  }

  if (!companyNameEn) {
    const enNameMatch = combinedText.match(
      /(?:Company\s*Name|Establishment\s*Name|Trade\s*Name|Licensee\s*Name|Taxpayer\s*Name|Member\s*Name|Employer\s*Name)\s*[:\-]?\s*([A-Za-z0-9\s.&,\-'()]{3,90})/i
    );
    if (enNameMatch) {
      companyNameEn = enNameMatch[1].trim();
    }
  }

  // Fallback to 3-Pass CR Extractor (AnyDoc + Gemini Vision OCR) when PDF/image is missing CR# or company name
  if (
    (mimeType === "application/pdf" || mimeType.startsWith("image/")) &&
    (!validNormCr || (!companyNameAr && !companyNameEn)) &&
    !/مذكرة\s*داخلية/i.test(combinedText)
  ) {
    try {
      const cr3Pass = await extractCommercialRegistrationFromFile({
        fileName: fileName || (mimeType === "application/pdf" ? "whatsapp_cr.pdf" : "whatsapp_cr.jpg"),
        mimeType,
        base64Data: buffer.toString("base64"),
      });
      if (cr3Pass.ok && cr3Pass.extraction) {
        const cf = cr3Pass.extraction.fields;
        if (!validNormCr && cf.crNumber.normalized) {
          crNumberRaw = cf.crNumber.raw || cf.crNumber.normalized;
          normalizedCr = normalizeCrNumber(crNumberRaw);
          validNormCr = normalizedCr && /^\d{5,10}$/.test(normalizedCr) ? normalizedCr : null;
        }
        if (!companyNameAr && (cf.companyNameAr.normalized || cf.tradeName.normalized)) {
          companyNameAr = cf.companyNameAr.normalized || cf.tradeName.normalized;
        }
        if (!companyNameEn && cf.companyNameEn.normalized) {
          companyNameEn = cf.companyNameEn.normalized;
        }
        if (!det.fields.legalForm.normalized && cf.legalForm.normalized) {
          det.fields.legalForm.normalized = cf.legalForm.normalized;
        }
        if (!det.fields.issueDate.normalized && cf.issueDate.normalized) {
          det.fields.issueDate.normalized = cf.issueDate.normalized;
          det.fields.issueDate.raw = cf.issueDate.raw || cf.issueDate.normalized;
        }
        if (!det.fields.expiryDate.normalized && cf.expiryDate.normalized) {
          det.fields.expiryDate.normalized = cf.expiryDate.normalized;
          det.fields.expiryDate.raw = cf.expiryDate.raw || cf.expiryDate.normalized;
        }
        if (!det.fields.taxCardNumber.normalized && cf.taxCardNumber.normalized) {
          det.fields.taxCardNumber.normalized = cf.taxCardNumber.normalized;
        }
        if (!det.fields.chamberNumber.normalized && cf.chamberNumber.normalized) {
          det.fields.chamberNumber.normalized = cf.chamberNumber.normalized;
        }
        if (!det.fields.licenseNumber.normalized && cf.licenseNumber.normalized) {
          det.fields.licenseNumber.normalized = cf.licenseNumber.normalized;
        }
        if (det.fields.capitalOmr.normalized === null && cf.capitalOmr.normalized !== null) {
          det.fields.capitalOmr.normalized = cf.capitalOmr.normalized;
        }
        if (!det.fields.city.normalized && cf.city.normalized) {
          det.fields.city.normalized = cf.city.normalized;
        }
        if (!det.fields.contactPhone.normalized && cf.contactPhone.normalized) {
          det.fields.contactPhone.normalized = cf.contactPhone.normalized;
        }
        if (det.activities.length === 0 && cr3Pass.extraction.activities.length > 0) {
          det.activities = cr3Pass.extraction.activities;
        }
        if (det.partners.length === 0 && cr3Pass.extraction.partners.length > 0) {
          det.partners = cr3Pass.extraction.partners;
        }
        if (
          det.authorizedSignatories.length === 0 &&
          cr3Pass.extraction.authorizedSignatories.length > 0
        ) {
          det.authorizedSignatories = cr3Pass.extraction.authorizedSignatories;
        }
        if (
          classification.documentType === "other" &&
          (validNormCr || companyNameAr || companyNameEn)
        ) {
          classification.documentType = "commercial_registry";
          classification.issuingAuthority =
            "وزارة التجارة والصناعة وترويج الاستثمار - سلطنة عُمان";
        }
      }
    } catch {
      // Proceed with deterministic fields if 3-pass fallback fails
    }
  }

  const tradeName = det.fields.tradeName.normalized || companyNameAr || companyNameEn || null;
  let legalForm = det.fields.legalForm.normalized || null;
  if (!legalForm) {
    const legalMatch = combinedText.match(/\|Legal\s*Type\|([^|]+)\|([^|]+)\|/i);
    if (legalMatch) {
      legalForm = legalMatch[2].trim() || legalMatch[1].trim();
    }
  }

  // Extract raw and normalized dates
  let rawIssueDate = det.fields.issueDate.raw || det.fields.issueDate.normalized || null;
  let rawExpiryDate = det.fields.expiryDate.raw || det.fields.expiryDate.normalized || null;

  // Oman table dates: |Expiry Date|11/05/2027| and |Establishment Date|11/05/2024|
  if (!rawExpiryDate) {
    const omanExpMatch = normalizeDigitsToAscii(combinedText).match(
      /\|(?:Expiry\s*Date|انتهاء\s*الصالحية|انتهاء\s*الصلاحية)\|([^|]+)\|/i
    );
    if (omanExpMatch) rawExpiryDate = omanExpMatch[1].trim();
  }
  if (!rawIssueDate) {
    const omanEstMatch = normalizeDigitsToAscii(combinedText).match(
      /\|(?:Establishment\s*Date|تاريخ\s*التأسيس|Registration\s*Date|تاريخ\s*التسجيل)\|([^|]+)\|/i
    );
    if (omanEstMatch) rawIssueDate = omanEstMatch[1].trim();
  }

  if (!rawIssueDate) {
    const issMatch = normalizeDigitsToAscii(combinedText).match(
      /(?:تاريخ\s*الإصدار|تاريخ\s*الاصدار|تاريخ\s*القيد|تاريخ\s*التسجيل|Issue\s*Date)\s*[:\-]?\s*(\d{1,4}[\/\-.\s]\d{1,2}[\/\-.\s]\d{1,4})/i
    );
    if (issMatch) rawIssueDate = issMatch[1].trim();
  }
  if (!rawExpiryDate) {
    const expMatch = normalizeDigitsToAscii(combinedText).match(
      /(?:تاريخ\s*الانتهاء|تاريخ\s*انتهاء\s*الصلاحية|تاريخ\s*انتهاء\s*الترخيص|تاريخ\s*انتهاء\s*الرخصة|صالح\s*لغاية|ينتهي\s*في|Expiry\s*Date|Valid\s*Until)\s*[:\-]?\s*(\d{1,4}[\/\-.\s]\d{1,2}[\/\-.\s]\d{1,4})/i
    );
    if (expMatch) rawExpiryDate = expMatch[1].trim();
  }

  let issueDate = rawIssueDate ? normalizeAndValidateDate(rawIssueDate) : null;
  let expiryDate = rawExpiryDate ? normalizeAndValidateDate(rawExpiryDate) : null;

  // Typed extraction for the Smart Company File document types (passport, residence card, lease).
  const typedCode = toDocTypeCode(classification.documentType);
  const typed = extractTyped(typedCode, combinedText);
  const isPersonDoc = isPersonDocument(typedCode);
  if (typed) {
    if (typed.issueDate) {
      issueDate = typed.issueDate;
      rawIssueDate = typed.issueDate;
    }
    if (typed.expiryDate) {
      expiryDate = typed.expiryDate;
      rawExpiryDate = typed.expiryDate;
    }
    // The generic CR regex (and the file-name fallback) must not decide which company a person document or
    // lease belongs to. Only a CR number printed in the text counts.
    crNumberRaw = typed.printedCrNumber || null;
    normalizedCr = typed.printedCrNumber || "";
    validNormCr = typed.printedCrNumber || null;
    crFromFileName = false;
    if (!companyNameAr && typed.relatedCompanyName) companyNameAr = typed.relatedCompanyName;
  }
  const chronologicalDateError = Boolean(
    (issueDate && expiryDate && expiryDate < issueDate) || typed?.reviewReasons.includes("EXPIRY_BEFORE_ISSUE")
  );

  // Extract document-specific numbers (Municipal License No, Tax Card No, Chamber No, Invoice No, Contract No)
  const asciiText = normalizeDigitsToAscii(combinedText);
  let documentNumber = validNormCr;
  const docNumMatch = asciiText.match(
    /(?:رقم\s*الترخيص(?:\s*البلدي)?|رقم\s*الرخصة(?:\s*البلدية)?|رقم\s*الشهادة|رقم\s*الفاتورة|رقم\s*العقد|رقم\s*البطاقة|رقم\s*التصريح|License\s*(?:No\.?|Number)|Permit\s*(?:No\.?|Number)|Certificate\s*(?:No\.?|Number)|Invoice\s*(?:No\.?|Number)|Contract\s*(?:No\.?|Number))\s*[:\-]?\s*([A-Z0-9\-\/]{3,28})/i
  );
  if (docNumMatch && classification.documentType !== "commercial_registry") {
    documentNumber = docNumMatch[1].trim();
  }

  const licMatch = asciiText.match(
    /(?:رقم\s*الترخيص(?:\s*البلدي)?|رقم\s*الرخصة(?:\s*البلدية)?|ترخيص\s*رقم|رخصة\s*رقم|رقم\s*التصريح|رقم\s*بطاقة\s*العمل|Municipal\s*License\s*(?:No\.?|Number)|License\s*(?:No\.?|Number)|Permit\s*(?:No\.?|Number))\s*[:\-]?\s*([A-Z0-9\-\/]{3,28})/i
  );
  const taxMatch = asciiText.match(
    /(?:رقم\s*البطاقة\s*الضريبية|البطاقة\s*الضريبية|الرقم\s*الضريبي|رقم\s*التعريف\s*الضريبي|رقم\s*التسجيل\s*الضريبي|Tax\s*Card\s*(?:No\.?|Number)?|Tax\s*Identification\s*Number|VAT\s*(?:IN|No\.?|Number)|TRN)\s*[:\-]?\s*([A-Z0-9\-\/]{4,28})/i
  );
  const chamberMatch = asciiText.match(
    /(?:رقم\s*(?:عضوية\s*|انتساب\s*|شهادة\s*|قيد\s*)?الغرفة(?:\s*التجارية)?|رقم\s*العضوية|رقم\s*الانتساب|Chamber\s*(?:Membership\s*)?(?:No\.?|Number)|OCCI\s*(?:No\.?|Number))\s*[:\-]?\s*([A-Z0-9\-\/]{3,28})/i
  );

  const resolvedLicenseNo =
    det.fields.licenseNumber.normalized ||
    (licMatch ? licMatch[1].trim() : null) ||
    (classification.documentType === "municipal_license" || classification.documentType === "labor_certificate"
      ? documentNumber
      : null);

  const resolvedTaxNo =
    det.fields.taxCardNumber.normalized ||
    (taxMatch ? taxMatch[1].trim() : null) ||
    (classification.documentType === "tax_certificate" ? documentNumber : null);

  const resolvedChamberNo =
    det.fields.chamberNumber.normalized ||
    (chamberMatch ? chamberMatch[1].trim() : null) ||
    (classification.documentType === "chamber_certificate" ? documentNumber : null);

  // Calculate confidence score honestly
  let confidenceScore = 0;
  if (combinedText.length >= 25 || (validNormCr && (companyNameAr || companyNameEn))) confidenceScore += 25;
  if (classification.documentType !== "other") confidenceScore += 25;
  if (validNormCr) {
    confidenceScore += 30;
  } else if (
    classification.documentType !== "other" &&
    classification.documentType !== "commercial_registry"
  ) {
    if (resolvedLicenseNo || resolvedTaxNo || resolvedChamberNo || documentNumber) {
      confidenceScore += 15;
    }
    if (expiryDate || issueDate) {
      confidenceScore += 15;
    }
  }
  if (companyNameAr || companyNameEn) confidenceScore += 20;
  confidenceScore = Math.min(100, confidenceScore);
  if (typed?.needsReview) {
    confidenceScore = Math.min(confidenceScore, 65);
  }
  if (promptInjectionDetected || chronologicalDateError) {
    confidenceScore = Math.min(confidenceScore, 40);
  }

  const confidenceLevel: "HIGH" | "MEDIUM" | "LOW" =
    confidenceScore >= 80 ? "HIGH" : confidenceScore >= 50 ? "MEDIUM" : "LOW";

  return {
    documentType: classification.documentType,
    documentTypeAr: DOCUMENT_TYPE_LABELS_AR[classification.documentType],
    crNumberRaw,
    normalizedCrNumber: validNormCr,
    companyNameAr,
    companyNameEn,
    tradeName,
    legalForm,
    issueDate: chronologicalDateError ? null : issueDate,
    expiryDate: chronologicalDateError ? null : expiryDate,
    rawIssueDate,
    rawExpiryDate,
    documentNumber: isPersonDoc
      ? typed?.person?.civilNumber || typed?.person?.passportNumber || null
      : documentNumber || resolvedLicenseNo || resolvedTaxNo || resolvedChamberNo || validNormCr,
    taxCardNumber: isPersonDoc ? null : resolvedTaxNo || null,
    chamberNumber: isPersonDoc ? null : resolvedChamberNo || null,
    licenseNumber: isPersonDoc ? null : resolvedLicenseNo || documentNumber || null,
    issuingAuthority: classification.issuingAuthority,
    capitalOmr: det.fields.capitalOmr.normalized ?? null,
    activities: det.activities.map((a) => `${a.code ? a.code + " - " : ""}${a.nameAr}`),
    owners: det.partners.map((p) => p.name),
    authorizedSignatories: det.authorizedSignatories.map((s) => s.name),
    city: det.fields.city.normalized || null,
    contactPhone: det.fields.contactPhone.normalized || null,
    confidenceScore,
    confidenceLevel,
    extractedText: combinedText,
    promptInjectionDetected,
    chronologicalDateError,
    docTypeCode: typedCode,
    classificationMethod,
    crFromFileNameOnly: crFromFileName,
    personName: typed?.person?.fullName || null,
    personCivilNumber: typed?.person?.civilNumber || null,
    personPassportNumber: typed?.person?.passportNumber || null,
    typedFields: typed,
  };
}

/**
 * Appends a state transition to a processing job row in PostgreSQL.
 */
async function updateJobState(
  jobId: string,
  newState: ProcessingState,
  note: string,
  extraFields: Partial<typeof whatsappProcessingJobs.$inferInsert> = {}
): Promise<void> {
  const [existing] = await db
    .select({ stateHistoryJson: whatsappProcessingJobs.stateHistoryJson })
    .from(whatsappProcessingJobs)
    .where(eq(whatsappProcessingJobs.jobId, jobId))
    .limit(1);

  let history: Array<{ state: string; timestamp: string; note: string }> = [];
  if (existing?.stateHistoryJson) {
    try {
      history = JSON.parse(existing.stateHistoryJson);
    } catch {
      history = [];
    }
  }
  history.push({
    state: newState,
    timestamp: new Date().toISOString(),
    note,
  });

  await db
    .update(whatsappProcessingJobs)
    .set({
      state: newState,
      stateHistoryJson: JSON.stringify(history),
      updatedAt: new Date(),
      ...extraFields,
    })
    .where(eq(whatsappProcessingJobs.jobId, jobId));
}

/**
 * Queues a WhatsApp reply in `whatsapp_outbox` idempotently (at most 1 reply per providerMessageId)
 * and dispatches it if a live sender callback is provided.
 */
async function enqueueAndDispatchWhatsAppReply(params: {
  tenantId: string;
  jobId: string;
  correlationId: string;
  providerMessageId: string;
  recipientPhone: string;
  recipientJid: string;
  replyCategory:
    | "NEW_COMPANY_REGISTERED"
    | "EXISTING_COMPANY_DOCUMENT_ADDED"
    | "DUPLICATE_FILE_ALREADY_STORED"
    | "MISSING_OR_UNREADABLE_DATA"
    | "DOCUMENT_QUEUED_FOR_CONFIRMATION"
    | "CORRUPTED_OR_UNSUPPORTED_FILE";
  messageText: string;
  sendWhatsAppReplyFn?: (recipientJidOrPhone: string, text: string) => Promise<{ sentId?: string } | void>;
}): Promise<string> {
  const idempotencyKey = `wa_reply:${params.tenantId}:${params.providerMessageId}`;
  const outboxId = `outbox_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`;

  // Insert idempotently into whatsapp_outbox
  const [existingOutbox] = await db
    .select()
    .from(whatsappOutbox)
    .where(eq(whatsappOutbox.idempotencyKey, idempotencyKey))
    .limit(1);

  let targetOutbox = existingOutbox;
  if (!targetOutbox) {
    try {
      const [inserted] = await db
        .insert(whatsappOutbox)
        .values({
          outboxId,
          idempotencyKey,
          correlationId: params.correlationId,
          tenantId: params.tenantId,
          jobId: params.jobId,
          providerMessageId: params.providerMessageId,
          recipientPhone: params.recipientPhone,
          recipientJid: params.recipientJid,
          replyCategory: params.replyCategory,
          messageText: params.messageText,
          status: "PENDING",
          deliveryAttempts: 0,
        })
        .returning();
      targetOutbox = inserted;
    } catch {
      const [foundAfterConflict] = await db
        .select()
        .from(whatsappOutbox)
        .where(eq(whatsappOutbox.idempotencyKey, idempotencyKey))
        .limit(1);
      targetOutbox = foundAfterConflict;
    }
  }

  if (!targetOutbox) return outboxId;

  // If already SENT, never send a second time!
  if (targetOutbox.status === "SENT") {
    return targetOutbox.outboxId;
  }

  if (params.sendWhatsAppReplyFn) {
    try {
      const sendRes = await params.sendWhatsAppReplyFn(
        params.recipientJid || params.recipientPhone,
        targetOutbox.messageText
      );
      await db
        .update(whatsappOutbox)
        .set({
          status: "SENT",
          deliveryAttempts: (targetOutbox.deliveryAttempts || 0) + 1,
          sentProviderMsgId: (sendRes && (sendRes as any).sentId) || null,
          sentAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(whatsappOutbox.id, targetOutbox.id));
    } catch (sendErr: any) {
      await db
        .update(whatsappOutbox)
        .set({
          status: "RETRY_PENDING",
          deliveryAttempts: (targetOutbox.deliveryAttempts || 0) + 1,
          lastError: sendErr?.message || String(sendErr),
          updatedAt: new Date(),
        })
        .where(eq(whatsappOutbox.id, targetOutbox.id));
    }
  }

  return targetOutbox.outboxId;
}

/**
 * Typed fields (with per-field provenance) stored in customer_documents.fields_json.
 * Never contains the raw OCR text.
 */
export function buildFieldsJson(intel: ExtractedDocumentIntelligence): string {
  const typed = intel.typedFields;
  return JSON.stringify({
    docTypeCode: toDocTypeCode(intel.documentType),
    classificationMethod: intel.classificationMethod || "REGEX",
    confidence: { level: intel.confidenceLevel, score: intel.confidenceScore },
    fields: typed?.fields || {},
    fieldMeta: typed?.fieldMeta || {},
    reviewReasons: typed?.reviewReasons || [],
    person: intel.personName || intel.personCivilNumber || intel.personPassportNumber
      ? {
          fullName: intel.personName || null,
          civilNumber: intel.personCivilNumber || null,
          passportNumber: intel.personPassportNumber || null,
        }
      : null,
  });
}

/**
 * Container customer for documents that are not filed under a company yet (customer_documents.customer_id is NOT NULL).
 * WhatsApp: one per sender phone (original behaviour). App channels: one shared "app uploads" container.
 */
async function getOrCreateHoldingCustomer(
  tx: any,
  params: {
    tenantId: string;
    channel: "WHATSAPP" | "CHAT" | "WEB";
    senderPhone: string;
    senderName?: string;
    fallbackName?: string | null;
  }
): Promise<typeof customers.$inferSelect> {
  const { tenantId, channel, senderPhone } = params;
  if (channel === "WHATSAPP") {
    const [existing] = await tx
      .select()
      .from(customers)
      .where(and(eq(customers.tenantId, tenantId), eq(customers.phone, senderPhone), isNull(customers.deletedAt)))
      .limit(1);
    if (existing) return existing;
    const [created] = await tx
      .insert(customers)
      .values({
        tenantId,
        customerType: "CORPORATE",
        fullNameAr: params.fallbackName || params.senderName || `مراجع واتساب (${senderPhone})`,
        phone: senderPhone,
        whatsapp: senderPhone,
        createdBy: "WhatsApp Autonomous Engine",
      })
      .returning();
    return created;
  }
  const holdingName = "مستندات مرفوعة من التطبيق (بانتظار التأكيد)";
  const [existing] = await tx
    .select()
    .from(customers)
    .where(and(eq(customers.tenantId, tenantId), eq(customers.fullNameAr, holdingName), isNull(customers.deletedAt)))
    .limit(1);
  if (existing) return existing;
  const [created] = await tx
    .insert(customers)
    .values({ tenantId, customerType: "CORPORATE", fullNameAr: holdingName, createdBy: "Smart Company File" })
    .returning();
  return created;
}

/**
 * For person documents (passport, residence card) filed under a company: find or create the person row
 * (company_people) by civil/passport number, so later documents of the same person match with a hard anchor.
 */
export async function ensureCompanyPersonForDocument(
  tx: any,
  params: {
    tenantId: string;
    companyId: number;
    documentId: number;
    intel: Pick<ExtractedDocumentIntelligence, "personName" | "personCivilNumber" | "personPassportNumber" | "documentType" | "typedFields">;
  }
): Promise<number | null> {
  const { tenantId, companyId, intel } = params;
  if (!isPersonDocument(toDocTypeCode(intel.documentType))) return null;
  const civil = intel.personCivilNumber || null;
  const pass = intel.personPassportNumber || null;
  if (!civil && !pass) return null;
  const conds = [eq(companyPeople.tenantId, tenantId), eq(companyPeople.companyId, companyId), isNull(companyPeople.deletedAt)];
  const people = await tx.select().from(companyPeople).where(and(...conds));
  let person = people.find(
    (pr: any) => (civil && pr.civilNumber === civil) || (pass && pr.passportNumber === pass)
  );
  if (!person) {
    const [created] = await tx
      .insert(companyPeople)
      .values({
        tenantId,
        companyId,
        fullName: intel.personName || civil || pass || "—",
        role: "EMPLOYEE",
        civilNumber: civil,
        passportNumber: pass,
        nationality: (intel.typedFields?.person?.nationality as string | null) || null,
      })
      .returning();
    person = created;
  } else if ((civil && !person.civilNumber) || (pass && !person.passportNumber)) {
    await tx
      .update(companyPeople)
      .set({ civilNumber: person.civilNumber || civil, passportNumber: person.passportNumber || pass })
      .where(eq(companyPeople.id, person.id));
  }
  await tx
    .update(customerDocuments)
    .set({ personId: person.id })
    .where(eq(customerDocuments.id, params.documentId));
  return person.id;
}

/**
 * Main autonomous WhatsApp document ingestion, deduplication, OCR, company matching/creation,
 * permanent storage, and reply engine.
 */
export async function processIncomingWhatsAppMediaMessage(
  input: WhatsAppMediaIngestionInput
): Promise<WhatsAppProcessingResult> {
  const tenantId = input.tenantId || "default_tenant";
  const instanceId = input.instanceId || "inst-main";
  const providerMessageId = String(input.providerMessageId || "").trim();
  const senderPhone = normalizePhoneDigits(input.senderPhone) || String(input.senderPhone || "").trim();
  const recipientJid = input.senderJid || `${senderPhone}@s.whatsapp.net`;
  const workerId = `worker_${process.pid}_${crypto.randomUUID().slice(0, 8)}`;
  const channel = input.channel || "WHATSAPP";
  const isWhatsAppChannel = channel === "WHATSAPP";
  const actorLabel = isWhatsAppChannel ? "WhatsApp Autonomous Engine" : input.actorName || "App user";
  const channelSourceLabel = isWhatsAppChannel ? "WHATSAPP_AUTONOMOUS_OCR" : `${channel}_UPLOAD_OCR`;

  if (!providerMessageId) {
    throw new Error("MISSING_PROVIDER_MESSAGE_ID: providerMessageId is required for idempotency");
  }

  // 1. Webhook / Message Deduplication Check by (tenantId, providerMessageId)
  const [existingJob] = await db
    .select()
    .from(whatsappProcessingJobs)
    .where(
      and(
        eq(whatsappProcessingJobs.tenantId, tenantId),
        eq(whatsappProcessingJobs.providerMessageId, providerMessageId)
      )
    )
    .limit(1);

  if (existingJob) {
    const isTerminal =
      existingJob.state === "COMPLETED" ||
      existingJob.state === "NEEDS_REVIEW" ||
      existingJob.state === "REJECTED";
    const isActivelyLocked =
      existingJob.lockedAt &&
      Date.now() - new Date(existingJob.lockedAt).getTime() < 60_000 &&
      existingJob.state !== "RETRY_PENDING" &&
      existingJob.state !== "FAILED";

    if (isTerminal || isActivelyLocked) {
      const [existingOutbox] = await db
        .select()
        .from(whatsappOutbox)
        .where(
          eq(
            whatsappOutbox.idempotencyKey,
            `wa_reply:${tenantId}:${providerMessageId}`
          )
        )
        .limit(1);

      return {
        ok: existingJob.state !== "REJECTED" && existingJob.state !== "FAILED",
        deduplicatedReplay: true,
        jobId: existingJob.jobId,
        correlationId: existingJob.correlationId,
        state: existingJob.state as ProcessingState,
        documentType: (existingJob.documentType as CanonicalDocumentType) || null,
        normalizedCrNumber: existingJob.normalizedCrNumber || null,
        companyId: existingJob.matchedCompanyId || null,
        companyName: existingJob.extractedCompanyNameAr || null,
        companyResolution: (existingJob.companyMatchResolution as any) || null,
        savedDocumentId: existingJob.savedDocumentId || null,
        versionNumber: 1,
        isDuplicateFile: existingJob.companyMatchResolution === "DUPLICATE_FILE_SKIPPED",
        isNewCompany: existingJob.companyMatchResolution === "CREATED_NEW_COMPANY",
        senderAuthorized: Boolean(existingJob.senderAuthorized),
        nameDiscrepancyFlag: false,
        replyCategory: existingOutbox?.replyCategory || "DUPLICATE_WEBHOOK_IGNORED",
        replyMessageText: existingOutbox?.messageText || "",
        outboxId: existingOutbox?.outboxId || null,
      };
    }
  }

  // 2. Create or acquire lock on persistent processing job in RECEIVED state
  const jobId = existingJob?.jobId || `wajob_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`;
  const correlationId = existingJob?.correlationId || `corr_${crypto.randomUUID().replace(/-/g, "").slice(0, 16)}`;

  if (!existingJob) {
    try {
      await db.insert(whatsappProcessingJobs).values({
        jobId,
        correlationId,
        tenantId,
        providerMessageId,
        instanceId,
        chatId: recipientJid,
        senderPhone,
        senderName: input.senderName || null,
        senderAuthorized: false,
        state: "RECEIVED",
        stateHistoryJson: JSON.stringify([
          { state: "RECEIVED", timestamp: new Date().toISOString(), note: "Incoming WhatsApp media received" },
        ]),
        originalFileName: input.fileName || null,
        mimeType: input.declaredMimeType || null,
        lockedByWorker: workerId,
        lockedAt: new Date(),
        lastAttemptAt: new Date(),
      });
    } catch (insertErr: any) {
      // Concurrent webhook retry hit unique index uq_wa_jobs_provider_msg
      const [concurrentJob] = await db
        .select()
        .from(whatsappProcessingJobs)
        .where(
          and(
            eq(whatsappProcessingJobs.tenantId, tenantId),
            eq(whatsappProcessingJobs.providerMessageId, providerMessageId)
          )
        )
        .limit(1);
      if (concurrentJob) {
        return {
          ok: true,
          deduplicatedReplay: true,
          jobId: concurrentJob.jobId,
          correlationId: concurrentJob.correlationId,
          state: concurrentJob.state as ProcessingState,
          documentType: (concurrentJob.documentType as CanonicalDocumentType) || null,
          normalizedCrNumber: concurrentJob.normalizedCrNumber || null,
          companyId: concurrentJob.matchedCompanyId || null,
          companyName: concurrentJob.extractedCompanyNameAr || null,
          companyResolution: (concurrentJob.companyMatchResolution as any) || null,
          savedDocumentId: concurrentJob.savedDocumentId || null,
          versionNumber: 1,
          isDuplicateFile: false,
          isNewCompany: false,
          senderAuthorized: Boolean(concurrentJob.senderAuthorized),
          nameDiscrepancyFlag: false,
          replyCategory: "CONCURRENT_WEBHOOK_DEDUPLICATED",
          replyMessageText: "",
          outboxId: null,
        };
      }
      throw insertErr;
    }
  } else {
    await updateJobState(jobId, "RECEIVED", "Retrying job execution", {
      lockedByWorker: workerId,
      lockedAt: new Date(),
      lastAttemptAt: new Date(),
      retryCount: (existingJob.retryCount || 0) + 1,
    });
  }

  // 3. Transition to DOWNLOADING and obtain binary buffer
  await updateJobState(jobId, "DOWNLOADING", "Downloading media attachment");
  let mediaBuffer: Buffer | null = input.mediaBuffer || null;
  if (!mediaBuffer && input.mediaDownloadFn) {
    try {
      mediaBuffer = await input.mediaDownloadFn();
    } catch (dlErr: any) {
      await updateJobState(jobId, "RETRY_PENDING", `Media download failed: ${dlErr?.message || dlErr}`, {
        errorCode: "MEDIA_DOWNLOAD_FAILED",
        errorMessage: dlErr?.message || String(dlErr),
        nextRetryAt: new Date(Date.now() + 30_000),
        lockedByWorker: null,
      });
      return {
        ok: false,
        deduplicatedReplay: false,
        jobId,
        correlationId,
        state: "RETRY_PENDING",
        documentType: null,
        normalizedCrNumber: null,
        companyId: null,
        companyName: null,
        companyResolution: null,
        savedDocumentId: null,
        versionNumber: null,
        isDuplicateFile: false,
        isNewCompany: false,
        senderAuthorized: false,
        nameDiscrepancyFlag: false,
        replyCategory: "NONE",
        replyMessageText: "",
        outboxId: null,
        errorCode: "MEDIA_DOWNLOAD_FAILED",
        errorMessage: dlErr?.message || String(dlErr),
      };
    }
  }

  // 4. Validate binary file magic bytes & security rules (Section 3 & 13)
  const validation = validateDocumentBuffer(mediaBuffer, input.fileName, input.declaredMimeType);
  if (!validation.valid || !mediaBuffer) {
    const replyText = buildArabicWhatsAppReply({
      category: "CORRUPTED_OR_UNSUPPORTED_FILE",
    });

    await db.insert(whatsappMessages).values({
      tenantId,
      providerMessageId,
      instanceId,
      chatId: recipientJid,
      phone: senderPhone,
      senderName: input.senderName || null,
      direction: "INBOUND",
      messageText: input.messageText || `[ملف مرفوض: ${validation.sanitizedOriginalName}]`,
      mediaType: "REJECTED_ATTACHMENT",
      mediaMimeType: validation.detectedMimeType,
      mediaSha256: validation.sha256 || null,
      correlationId,
      rawPayloadJson: input.rawPayload ? JSON.stringify(input.rawPayload).slice(0, 4000) : null,
      status: "REJECTED",
    });

    await updateJobState(jobId, "REJECTED", validation.errorMessage || "Invalid or unsupported file", {
      originalFileName: validation.sanitizedOriginalName,
      mimeType: validation.detectedMimeType,
      fileSizeBytes: validation.fileSizeBytes,
      fileSha256: validation.sha256 || null,
      companyMatchResolution: "REJECTED_FILE",
      errorCode: validation.errorCode || "INVALID_FILE",
      errorMessage: validation.errorMessage || "Corrupted or unsupported file",
      completedAt: new Date(),
      lockedByWorker: null,
    });

    const outboxId = await enqueueAndDispatchWhatsAppReply({
      tenantId,
      jobId,
      correlationId,
      providerMessageId,
      recipientPhone: senderPhone,
      recipientJid,
      replyCategory: "CORRUPTED_OR_UNSUPPORTED_FILE",
      messageText: replyText,
      sendWhatsAppReplyFn: input.sendWhatsAppReplyFn,
    });

    return {
      ok: false,
      deduplicatedReplay: false,
      jobId,
      correlationId,
      state: "REJECTED",
      documentType: null,
      normalizedCrNumber: null,
      companyId: null,
      companyName: null,
      companyResolution: "REJECTED_FILE",
      savedDocumentId: null,
      versionNumber: null,
      isDuplicateFile: false,
      isNewCompany: false,
      senderAuthorized: false,
      nameDiscrepancyFlag: false,
      replyCategory: "CORRUPTED_OR_UNSUPPORTED_FILE",
      replyMessageText: replyText,
      outboxId,
      errorCode: validation.errorCode,
      errorMessage: validation.errorMessage,
    };
  }

  // 5. Store original document permanently in Cloud Storage / Verified Vault (Section 4)
  let storedArtifact: StoredDocumentArtifact;
  try {
    storedArtifact = await storePermanentDocument({
      buffer: mediaBuffer,
      tenantId,
      originalFileName: input.fileName,
      declaredMimeType: validation.detectedMimeType,
    });
  } catch (storageErr: any) {
    // Storage failure -> mark RETRY_PENDING, do NOT send false success message!
    await updateJobState(jobId, "RETRY_PENDING", `Storage failure: ${storageErr?.message || storageErr}`, {
      errorCode: "STORAGE_WRITE_FAILED",
      errorMessage: storageErr?.message || String(storageErr),
      nextRetryAt: new Date(Date.now() + 30_000),
      lockedByWorker: null,
    });
    return {
      ok: false,
      deduplicatedReplay: false,
      jobId,
      correlationId,
      state: "RETRY_PENDING",
      documentType: null,
      normalizedCrNumber: null,
      companyId: null,
      companyName: null,
      companyResolution: null,
      savedDocumentId: null,
      versionNumber: null,
      isDuplicateFile: false,
      isNewCompany: false,
      senderAuthorized: false,
      nameDiscrepancyFlag: false,
      replyCategory: "NONE",
      replyMessageText: "",
      outboxId: null,
      errorCode: "STORAGE_WRITE_FAILED",
      errorMessage: storageErr?.message || String(storageErr),
    };
  }

  await updateJobState(jobId, "DOWNLOADED", "Original file validated and stored in vault", {
    originalFileName: storedArtifact.sanitizedOriginalName,
    mimeType: storedArtifact.mimeType,
    fileSizeBytes: storedArtifact.fileSizeBytes,
    fileSha256: storedArtifact.verifiedSha256,
    storageObjectKey: storedArtifact.storageObjectKey,
  });

  // Record incoming WhatsApp message in PostgreSQL (WhatsApp channel only; chat/web uploads are not WhatsApp traffic)
  if (isWhatsAppChannel) await db.insert(whatsappMessages).values({
    tenantId,
    providerMessageId,
    instanceId,
    chatId: recipientJid,
    phone: senderPhone,
    senderName: input.senderName || null,
    direction: "INBOUND",
    messageText: input.messageText || `📄 ${storedArtifact.sanitizedOriginalName}`,
    mediaType: storedArtifact.mimeType === "application/pdf" ? "DOCUMENT" : "IMAGE",
    mediaMimeType: storedArtifact.mimeType,
    mediaSha256: storedArtifact.verifiedSha256,
    storageObjectKey: storedArtifact.storageObjectKey,
    correlationId,
    rawPayloadJson: input.rawPayload ? JSON.stringify(input.rawPayload).slice(0, 4000) : null,
    status: "DELIVERED",
  });

  // 6. Transition to EXTRACTING & CLASSIFYING (Section 5 & 7)
  await updateJobState(jobId, "EXTRACTING", "Running OCR and structured field extraction");
  const intel = await extractDocumentIntelligence(
    mediaBuffer,
    storedArtifact.mimeType,
    input.messageText,
    storedArtifact.sanitizedOriginalName || input.fileName
  );

  await updateJobState(jobId, "CLASSIFYING", `Classified as ${intel.documentType}`, {
    documentType: intel.documentType,
    extractedCrNumber: intel.crNumberRaw,
    normalizedCrNumber: intel.normalizedCrNumber,
    extractedCompanyNameAr: intel.companyNameAr,
    extractedCompanyNameEn: intel.companyNameEn,
    extractionResultJson: JSON.stringify(intel),
    extractionConfidence: `${intel.confidenceLevel} (${intel.confidenceScore}%)`,
  });

  // 7. Transition to MATCHING, VALIDATING, SAVING inside an atomic PostgreSQL transaction
  await updateJobState(jobId, "MATCHING", "Matching company by CR number, company name, or sender phone");
  await updateJobState(jobId, "VALIDATING", "Validating extracted data and business rules");
  await updateJobState(jobId, "SAVING", "Executing atomic database transaction");

  let txOutcome: any;
  try {
    txOutcome = await db.transaction(async (tx) => {
      const normCr = intel.normalizedCrNumber;

      // Acquire transaction-scoped advisory lock on normalized CR number (Case H concurrency safety)
      if (normCr) {
        await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${`${tenantId}:cr:${normCr}`}))`);
      }

      // Smart Company File: ONE matching brain for every entry channel (WhatsApp, in-app chat, manual upload).
      let matchedCompany: typeof companies.$inferSelect | null = null;
      let matchOutcome: MatchOutcome | null = null;
      let matchLane: "AUTO" | "CONFIRM" | "UNMATCHED" | "MANUAL" | null = null;
      let matchScore: number | null = null;

      if (input.forcedCompanyId) {
        // Manual upload from a company page: the company is already known, lanes are skipped.
        const [forced] = await tx
          .select()
          .from(companies)
          .where(
            and(
              eq(companies.id, input.forcedCompanyId),
              eq(companies.tenantId, tenantId),
              isNull(companies.deletedAt)
            )
          )
          .limit(1);
        if (!forced) throw new Error("FORCED_COMPANY_NOT_FOUND");
        matchedCompany = forced;
        matchLane = "MANUAL";
        matchScore = 100;
      } else if (intel.documentType === "commercial_registry") {
        // A Commercial Registration IS the identity document: exact CR number lookup (never create a duplicate,
        // even if soft-deleted). Unchanged from the original engine.
        if (normCr) {
          const [byNormCr] = await tx
            .select()
            .from(companies)
            .where(
              and(
                eq(companies.tenantId, tenantId),
                or(
                  eq(companies.normalizedCrNumber, normCr),
                  eq(companies.taxId, normCr),
                  eq(companies.taxId, `CR-${normCr}`),
                  eq(companies.companyCode, `CR-${normCr}`)
                )
              )
            )
            .orderBy(desc(companies.id))
            .limit(1);
          matchedCompany = byNormCr || null;
          if (matchedCompany) {
            matchLane = "AUTO";
            matchScore = 100;
          }
        }
      } else {
        // Every other document: confidence-scored matching with three lanes.
        matchOutcome = await matchDocumentToCompany(tenantId, buildMatchInput(intel), senderPhone, {
          channelTrusted: !isWhatsAppChannel,
          executor: tx,
        });
        matchLane = matchOutcome.lane;
        matchScore = matchOutcome.topScore;
        if (matchOutcome.lane === "AUTO") {
          const [autoCompany] = await tx
            .select()
            .from(companies)
            .where(and(eq(companies.id, matchOutcome.candidates[0].companyId), eq(companies.tenantId, tenantId)))
            .limit(1);
          matchedCompany = autoCompany || null;
          if (!matchedCompany) matchLane = "CONFIRM";
        }
      }

      // CONFIRM / UNMATCHED lanes: hold the document in the confirmation inbox. Nothing is filed under a company.
      if (!matchedCompany && matchOutcome) {
        const heldCustomer = await getOrCreateHoldingCustomer(tx, {
          tenantId,
          channel,
          senderPhone,
          senderName: input.senderName,
          fallbackName: intel.companyNameAr,
        });
        const [heldDoc] = await tx
          .insert(customerDocuments)
          .values({
            tenantId,
            customerId: heldCustomer.id,
            companyId: null,
            docType: intel.documentType,
            docTypeCode: toDocTypeCode(intel.documentType),
            docNumber:
              intel.licenseNumber ||
              intel.taxCardNumber ||
              intel.chamberNumber ||
              intel.documentNumber ||
              normCr ||
              null,
            issueDate: intel.issueDate,
            expiryDate: intel.expiryDate,
            rawIssueDate: intel.rawIssueDate,
            rawExpiryDate: intel.rawExpiryDate,
            extractionSource: channelSourceLabel,
            hasNoExpiry: false,
            expiryStatus: "NEEDS_REVIEW",
            needsReview: true,
            fileUrl: storedArtifact.dataUrl,
            originalFileName: storedArtifact.sanitizedOriginalName,
            mimeType: storedArtifact.mimeType,
            fileSizeBytes: storedArtifact.fileSizeBytes,
            sha256: storedArtifact.verifiedSha256,
            storageObjectKey: storedArtifact.storageObjectKey,
            whatsappMessageId: providerMessageId,
            sourceChannel: channel,
            senderPhone: senderPhone || null,
            senderAuthorized: false,
            extractionConfidence: `${intel.confidenceLevel} (${intel.confidenceScore}%)`,
            processingStatus: "NEEDS_REVIEW",
            versionNumber: 1,
            extractedText: intel.extractedText,
            extractedMetadataJson: JSON.stringify(intel),
            issuingAuthority: intel.issuingAuthority,
            createdBy: actorLabel,
            matchLane: matchOutcome.lane,
            matchScore: matchOutcome.topScore,
            fieldsJson: buildFieldsJson(intel),
          })
          .returning();

        const shownCandidates = matchOutcome.candidates.filter((c) => c.score >= 15).slice(0, 3);
        for (let i = 0; i < shownCandidates.length; i++) {
          await tx.insert(documentMatchCandidates).values({
            tenantId,
            documentId: heldDoc.id,
            companyId: shownCandidates[i].companyId,
            score: shownCandidates[i].score,
            reasonsJson: JSON.stringify({ reasons: shownCandidates[i].reasons, laneReason: matchOutcome.laneReason }),
            rank: i + 1,
          });
        }

        await tx.insert(auditLogs).values({
          tenantId,
          actorId: "WHATSAPP_ENGINE",
          actorName: actorLabel,
          action: "DOCUMENT_HELD_FOR_CONFIRMATION",
          resource: "customer_documents",
          resourceId: String(heldDoc.id),
          details: JSON.stringify({
            correlationId,
            jobId,
            channel,
            lane: matchOutcome.lane,
            laneReason: matchOutcome.laneReason,
            topScore: matchOutcome.topScore,
            candidateCompanyIds: shownCandidates.map((c) => c.companyId),
            documentType: intel.documentType,
          }),
          ipAddress: "127.0.0.1",
        });

        // Dashboard notification for the office (idempotent per document).
        await tx
          .insert(notifications)
          .values({
            tenantId,
            idempotencyKey: `doc-confirm:${tenantId}:${heldDoc.id}`,
            type: "DOCUMENT_NEEDS_CONFIRMATION",
            title: "وثيقة جديدة تحتاج تأكيد الشركة",
            message: `وصلت وثيقة (${DOCUMENT_TYPE_LABELS_AR[intel.documentType]}) عبر ${channel === "WHATSAPP" ? "واتساب" : "التطبيق"} وتنتظر التأكيد.`,
            docType: intel.documentType,
            documentId: heldDoc.id,
            sourceEntity: "customer_documents",
            sourceId: String(heldDoc.id),
            severity: "INFO",
            status: "UNREAD",
            channel: "dashboard",
            link: "/documents/inbox",
          })
          .onConflictDoNothing();

        // A business document that carries a CR number for a company we do not have yet keeps the original
        // "awaiting CR" reply; it is linked automatically when that CR arrives.
        const awaitingCr = matchOutcome.lane === "UNMATCHED" && Boolean(normCr) && !isPersonDocument(toDocTypeCode(intel.documentType));
        return {
          finalState: "NEEDS_REVIEW" as ProcessingState,
          companyResolution: "NEEDS_HUMAN_REVIEW" as const,
          companyId: null,
          companyName: intel.companyNameAr || null,
          normalizedCrNumber: normCr || null,
          savedDocumentId: heldDoc.id,
          versionNumber: 1,
          isDuplicateFile: false,
          isNewCompany: false,
          senderAuthorized: false,
          nameDiscrepancyFlag: false,
          replyCategory: (awaitingCr ? "MISSING_OR_UNREADABLE_DATA" : "DOCUMENT_QUEUED_FOR_CONFIRMATION") as
            | "MISSING_OR_UNREADABLE_DATA"
            | "DOCUMENT_QUEUED_FOR_CONFIRMATION",
          expiryDateForReply: intel.expiryDate,
          matchLane: matchOutcome.lane,
          matchScore: matchOutcome.topScore,
        };
      }

      // CASE E: Missing or unreadable CR number (or unresolvable company / low confidence / prompt injection)
      const isMissingIdentity =
        !matchedCompany &&
        (!normCr ||
          (!intel.companyNameAr && !intel.companyNameEn && !intel.tradeName) ||
          intel.confidenceLevel === "LOW" ||
          intel.promptInjectionDetected);

      if (isMissingIdentity) {
        // Ensure a generic review customer container exists so customer_documents FK is satisfied
        const reviewCustomer = await getOrCreateHoldingCustomer(tx, {
          tenantId,
          channel,
          senderPhone,
          senderName: input.senderName,
          fallbackName: intel.companyNameAr,
        });

        const [reviewDoc] = await tx
          .insert(customerDocuments)
          .values({
            tenantId,
            customerId: reviewCustomer.id,
            companyId: null,
            docType: intel.documentType,
            docNumber:
              intel.licenseNumber ||
              intel.taxCardNumber ||
              intel.chamberNumber ||
              intel.documentNumber ||
              normCr ||
              null,
            issueDate: intel.issueDate,
            expiryDate: intel.expiryDate,
            rawIssueDate: intel.rawIssueDate,
            rawExpiryDate: intel.rawExpiryDate,
            extractionSource: "WHATSAPP_AUTONOMOUS_OCR",
            hasNoExpiry: false,
            expiryStatus: "NEEDS_REVIEW",
            needsReview: true,
            fileUrl: storedArtifact.dataUrl,
            originalFileName: storedArtifact.sanitizedOriginalName,
            mimeType: storedArtifact.mimeType,
            fileSizeBytes: storedArtifact.fileSizeBytes,
            sha256: storedArtifact.verifiedSha256,
            storageObjectKey: storedArtifact.storageObjectKey,
            whatsappMessageId: providerMessageId,
            sourceChannel: "WHATSAPP",
            senderPhone,
            senderAuthorized: false,
            extractionConfidence: `${intel.confidenceLevel} (${intel.confidenceScore}%)`,
            processingStatus: "NEEDS_REVIEW",
            versionNumber: 1,
            extractedText: intel.extractedText,
            extractedMetadataJson: JSON.stringify(intel),
            issuingAuthority: intel.issuingAuthority,
            createdBy: "WhatsApp Autonomous Engine",
            docTypeCode: toDocTypeCode(intel.documentType),
            fieldsJson: buildFieldsJson(intel),
          })
          .returning();

        await tx.insert(auditLogs).values({
          tenantId,
          actorId: "WHATSAPP_ENGINE",
          actorName: "WhatsApp Autonomous Engine",
          action: "WHATSAPP_DOCUMENT_NEEDS_REVIEW",
          resource: "customer_documents",
          resourceId: String(reviewDoc.id),
          details: JSON.stringify({
            correlationId,
            jobId,
            senderPhone,
            documentType: intel.documentType,
            extractedCrNumber: intel.crNumberRaw,
            extractedCompanyNameAr: intel.companyNameAr,
            confidenceScore: intel.confidenceScore,
            reason: "Unregistered company or missing CR number — held in review queue until CR is registered",
          }),
          ipAddress: "127.0.0.1",
        });

        return {
          finalState: "NEEDS_REVIEW" as ProcessingState,
          companyResolution: "NEEDS_HUMAN_REVIEW" as const,
          companyId: null,
          companyName: intel.companyNameAr || null,
          normalizedCrNumber: normCr || null,
          savedDocumentId: reviewDoc.id,
          versionNumber: 1,
          isDuplicateFile: false,
          isNewCompany: false,
          senderAuthorized: false,
          nameDiscrepancyFlag: false,
          replyCategory: "MISSING_OR_UNREADABLE_DATA" as const,
          expiryDateForReply: intel.expiryDate,
        };
      }

      // CASE A, B, C, D, G: Existing company matched!
      if (matchedCompany) {
        // Check Case D: Is senderPhone the registered phone for this company?
        let senderAuthorized = phonesMatch(matchedCompany.contactPhone, senderPhone);
        if (!senderAuthorized && matchedCompany.ownerCustomerId) {
          const [ownerCust] = await tx
            .select()
            .from(customers)
            .where(eq(customers.id, matchedCompany.ownerCustomerId))
            .limit(1);
          if (
            ownerCust &&
            (phonesMatch(ownerCust.phone, senderPhone) || phonesMatch(ownerCust.whatsapp, senderPhone))
          ) {
            senderAuthorized = true;
          }
        }

        // Check Case G: Name discrepancy on existing company (using fuzzy-safe companyNamesMatch so minor suffixes like ش.م.م don't trigger false discrepancy)
        let currentDocNameDiscrepancy = false;
        let nameDiscrepancyFlag = Boolean(matchedCompany.nameDiscrepancyFlag);
        let nameDiscrepancyDetails = matchedCompany.nameDiscrepancyDetails || null;
        if (
          intel.companyNameAr &&
          matchedCompany.name &&
          !companyNamesMatch(intel.companyNameAr, matchedCompany.name) &&
          (!matchedCompany.tradeName || !companyNamesMatch(intel.companyNameAr, matchedCompany.tradeName))
        ) {
          currentDocNameDiscrepancy = true;
          nameDiscrepancyFlag = true;
          nameDiscrepancyDetails = JSON.stringify({
            officialCompanyName: matchedCompany.name,
            submittedDocumentCompanyName: intel.companyNameAr,
            detectedAt: new Date().toISOString(),
            jobId,
            senderPhone,
          });
        }

        // Check Case B: Identical file SHA-256 already stored for this company
        const [existingSameHashDoc] = await tx
          .select()
          .from(customerDocuments)
          .where(
            and(
              eq(customerDocuments.tenantId, tenantId),
              eq(customerDocuments.companyId, matchedCompany.id),
              eq(customerDocuments.sha256, storedArtifact.verifiedSha256),
              isNull(customerDocuments.deletedAt)
            )
          )
          .limit(1);

        if (existingSameHashDoc) {
          // Update discrepancy flag if detected even on duplicate check, without creating duplicate company or doc
          if ((nameDiscrepancyFlag && !matchedCompany.nameDiscrepancyFlag) || matchedCompany.deletedAt) {
            await tx
              .update(companies)
              .set({
                deletedAt: null,
                nameDiscrepancyFlag,
                nameDiscrepancyDetails,
                updatedAt: new Date(),
              })
              .where(eq(companies.id, matchedCompany.id));
          }

          await tx.insert(auditLogs).values({
            tenantId,
            actorId: "WHATSAPP_ENGINE",
            actorName: "WhatsApp Autonomous Engine",
            action: "WHATSAPP_DUPLICATE_DOCUMENT_SKIPPED",
            resource: "companies",
            resourceId: String(matchedCompany.id),
            details: JSON.stringify({
              correlationId,
              jobId,
              companyId: matchedCompany.id,
              normalizedCrNumber: matchedCompany.normalizedCrNumber || normCr,
              sha256: storedArtifact.verifiedSha256,
              existingDocumentId: existingSameHashDoc.id,
              senderPhone,
              senderAuthorized,
            }),
            ipAddress: "127.0.0.1",
          });

          return {
            finalState: "COMPLETED" as ProcessingState,
            companyResolution: "DUPLICATE_FILE_SKIPPED" as const,
            companyId: matchedCompany.id,
            companyName: matchedCompany.name,
            normalizedCrNumber: matchedCompany.normalizedCrNumber || normCr,
            savedDocumentId: existingSameHashDoc.id,
            versionNumber: existingSameHashDoc.versionNumber || 1,
            isDuplicateFile: true,
            isNewCompany: false,
            senderAuthorized,
            nameDiscrepancyFlag,
            replyCategory: "DUPLICATE_FILE_ALREADY_STORED" as const,
            expiryDateForReply: matchedCompany.crExpiryDate,
          };
        }

        // Case C: Different file (new document or renewed version) for existing company.
        // Person documents (passport, residence card) are versioned per person: another employee's passport
        // is a new document, never a new version of the previous one.
        const personDocNumber = isPersonDocument(toDocTypeCode(intel.documentType)) ? intel.documentNumber : null;
        const existingDocsOfType = await tx
          .select()
          .from(customerDocuments)
          .where(
            and(
              eq(customerDocuments.tenantId, tenantId),
              eq(customerDocuments.companyId, matchedCompany.id),
              eq(customerDocuments.docType, intel.documentType),
              isNull(customerDocuments.deletedAt),
              ...(isPersonDocument(toDocTypeCode(intel.documentType))
                ? [personDocNumber ? eq(customerDocuments.docNumber, personDocNumber) : sql`false`]
                : [])
            )
          )
          .orderBy(desc(customerDocuments.versionNumber), desc(customerDocuments.id));

        const latestPreviousDoc = existingDocsOfType[0] || null;
        const nextVersionNumber = latestPreviousDoc ? (latestPreviousDoc.versionNumber || 1) + 1 : 1;

        // Ensure customerId for customer_documents FK
        let targetCustomerId = matchedCompany.ownerCustomerId;
        if (!targetCustomerId) {
          const [fallbackCust] = await tx
            .select()
            .from(customers)
            .where(and(eq(customers.tenantId, tenantId), isNull(customers.deletedAt)))
            .orderBy(desc(customers.id))
            .limit(1);
          if (fallbackCust) {
            targetCustomerId = fallbackCust.id;
          } else {
            const [createdOwner] = await tx
              .insert(customers)
              .values({
                tenantId,
                customerType: "CORPORATE",
                fullNameAr: matchedCompany.name,
                phone: matchedCompany.contactPhone || senderPhone,
                createdBy: "WhatsApp Autonomous Engine",
              })
              .returning();
            targetCustomerId = createdOwner.id;
          }
        }

        const expClass = classifyDocumentExpiry({
          expiryDate: intel.expiryDate,
          hasNoExpiry: intel.documentType === "contract" || intel.documentType === "tax_invoice",
        });

        // Direct attachment from any sender phone is allowed without forcing review unless THIS document has date/name errors
        const docNeedsReview = Boolean(
          currentDocNameDiscrepancy ||
          intel.chronologicalDateError ||
          expClass.needsReview
        );

        const resolvedDocNumber =
          intel.licenseNumber ||
          intel.taxCardNumber ||
          intel.chamberNumber ||
          intel.documentNumber ||
          matchedCompany.normalizedCrNumber ||
          matchedCompany.taxId;

        const [insertedDoc] = await tx
          .insert(customerDocuments)
          .values({
            tenantId,
            customerId: targetCustomerId!,
            companyId: matchedCompany.id,
            docType: intel.documentType,
            docNumber: resolvedDocNumber,
            issueDate: intel.issueDate,
            expiryDate: intel.expiryDate,
            rawIssueDate: intel.rawIssueDate,
            rawExpiryDate: intel.rawExpiryDate,
            extractionSource: channelSourceLabel,
            hasNoExpiry: intel.documentType === "contract" || intel.documentType === "tax_invoice",
            expiryStatus: expClass.status,
            needsReview: docNeedsReview,
            fileUrl: storedArtifact.dataUrl,
            originalFileName: storedArtifact.sanitizedOriginalName,
            mimeType: storedArtifact.mimeType,
            fileSizeBytes: storedArtifact.fileSizeBytes,
            sha256: storedArtifact.verifiedSha256,
            storageObjectKey: storedArtifact.storageObjectKey,
            whatsappMessageId: providerMessageId,
            sourceChannel: channel,
            senderPhone: senderPhone || null,
            senderAuthorized: isWhatsAppChannel ? senderAuthorized : true,
            extractionConfidence: `${intel.confidenceLevel} (${intel.confidenceScore}%)`,
            processingStatus: docNeedsReview ? "NEEDS_REVIEW" : "COMPLETED",
            versionNumber: nextVersionNumber,
            previousVersionId: latestPreviousDoc ? latestPreviousDoc.id : null,
            extractedText: intel.extractedText,
            extractedMetadataJson: JSON.stringify(intel),
            issuingAuthority: intel.issuingAuthority,
            createdBy: actorLabel,
            docTypeCode: toDocTypeCode(intel.documentType),
            matchLane,
            matchScore,
            matchConfirmedBy: matchLane === "MANUAL" ? actorLabel : null,
            matchConfirmedAt: matchLane === "MANUAL" ? new Date() : null,
            fieldsJson: buildFieldsJson(intel),
          })
          .returning();

        // Evidence for AUTO-filed documents: keep why it was filed (audit + "move to another company" undo).
        if (matchOutcome) {
          const shown = matchOutcome.candidates.filter((c) => c.score >= 15).slice(0, 3);
          for (let i = 0; i < shown.length; i++) {
            await tx.insert(documentMatchCandidates).values({
              tenantId,
              documentId: insertedDoc.id,
              companyId: shown[i].companyId,
              score: shown[i].score,
              reasonsJson: JSON.stringify({ reasons: shown[i].reasons, laneReason: matchOutcome.laneReason }),
              rank: i + 1,
            });
          }
        }
        await ensureCompanyPersonForDocument(tx, {
          tenantId,
          companyId: matchedCompany.id,
          documentId: insertedDoc.id,
          intel,
        });

        // Update existing company fields directly from any sender (never overwrite official name on discrepancy, never overwrite contactPhone from different sender)
        const updateCompanyFields: Partial<typeof companies.$inferInsert> = {
          normalizedCrNumber: matchedCompany.normalizedCrNumber || normCr,
          deletedAt: null,
          nameDiscrepancyFlag,
          nameDiscrepancyDetails,
          updatedAt: new Date(),
        };

        if (intel.documentType === "commercial_registry" && !currentDocNameDiscrepancy) {
          if (intel.expiryDate && (!matchedCompany.crExpiryDate || intel.expiryDate >= matchedCompany.crExpiryDate)) {
            updateCompanyFields.crExpiryDate = intel.expiryDate;
            const todayIso = new Date().toISOString().slice(0, 10);
            updateCompanyFields.status = intel.expiryDate < todayIso ? "Expired" : "Active";
          }
          if (intel.issueDate && !matchedCompany.crIssueDate) {
            updateCompanyFields.crIssueDate = intel.issueDate;
          }
          updateCompanyFields.crDocumentUrl = `/api/companies/${matchedCompany.id}/cr-download`;
          updateCompanyFields.crDocumentName = storedArtifact.sanitizedOriginalName;
        }

        if (intel.documentType === "municipal_license") {
          if (intel.expiryDate) {
            updateCompanyFields.licenseExpiryDate = intel.expiryDate;
          }
          const licNo = intel.licenseNumber || intel.documentNumber;
          if (licNo) {
            updateCompanyFields.licenseNumber = licNo;
          }
        }
        if (intel.documentType === "tax_certificate") {
          const taxNo = intel.taxCardNumber || intel.documentNumber;
          if (taxNo) {
            updateCompanyFields.taxCardNumber = taxNo;
          }
        }
        if (intel.documentType === "chamber_certificate") {
          const chNo = intel.chamberNumber || intel.documentNumber;
          if (chNo) {
            updateCompanyFields.chamberNumber = chNo;
          }
        }

        await tx
          .update(companies)
          .set(updateCompanyFields)
          .where(eq(companies.id, matchedCompany.id));

        // Also link any previously queued review documents that match this company
        await linkPendingReviewDocumentsToCompany(tx, {
          tenantId,
          company: {
            ...matchedCompany,
            ...updateCompanyFields,
          } as typeof companies.$inferSelect,
          normCr: matchedCompany.normalizedCrNumber || normCr,
        });

        await tx.insert(auditLogs).values({
          tenantId,
          actorId: isWhatsAppChannel ? "WHATSAPP_ENGINE" : "SMART_FILE_ENGINE",
          actorName: actorLabel,
          action: "WHATSAPP_ATTACH_DOCUMENT_EXISTING_COMPANY",
          resource: "companies",
          resourceId: String(matchedCompany.id),
          details: JSON.stringify({
            correlationId,
            jobId,
            companyId: matchedCompany.id,
            companyName: matchedCompany.name,
            normalizedCrNumber: matchedCompany.normalizedCrNumber || normCr,
            documentId: insertedDoc.id,
            documentType: intel.documentType,
            versionNumber: nextVersionNumber,
            previousVersionId: latestPreviousDoc?.id || null,
            senderPhone,
            senderAuthorized,
            nameDiscrepancyFlag,
            channel,
            matchLane,
            matchScore,
          }),
          ipAddress: "127.0.0.1",
        });

        return {
          finalState: (docNeedsReview && intel.chronologicalDateError ? "NEEDS_REVIEW" : "COMPLETED") as ProcessingState,
          companyResolution: "MATCHED_EXISTING_COMPANY" as const,
          companyId: matchedCompany.id,
          companyName: matchedCompany.name,
          normalizedCrNumber: matchedCompany.normalizedCrNumber || normCr,
          savedDocumentId: insertedDoc.id,
          versionNumber: nextVersionNumber,
          isDuplicateFile: false,
          isNewCompany: false,
          senderAuthorized,
          nameDiscrepancyFlag,
          replyCategory: "EXISTING_COMPANY_DOCUMENT_ADDED" as const,
          expiryDateForReply:
            intel.expiryDate || updateCompanyFields.crExpiryDate || matchedCompany.crExpiryDate,
          matchLane,
          matchScore,
        };
      }

      const rawCrCompanyName = (
        intel.companyNameAr ||
        intel.companyNameEn ||
        intel.tradeName ||
        ""
      ).trim();
      const effectiveCrCompanyName =
        rawCrCompanyName &&
        !/^(?:منشأة\s+سجل\s+تجاري|شركة\s+مستخرجة|غير\s+مذكور)/i.test(rawCrCompanyName)
          ? rawCrCompanyName
          : "";

      // New company creation is ONLY allowed for a valid Commercial Registration document with a verified CR number and real company name.
      // Any license sent for an unregistered company is saved in the review queue until the CR is sent!
      if (intel.documentType !== "commercial_registry" || !normCr || !effectiveCrCompanyName) {
        const reviewCustomer = await getOrCreateHoldingCustomer(tx, {
          tenantId,
          channel,
          senderPhone,
          senderName: input.senderName,
          fallbackName: intel.companyNameAr,
        });

        const [unmatchedDoc] = await tx
          .insert(customerDocuments)
          .values({
            tenantId,
            customerId: reviewCustomer.id,
            companyId: null,
            docType: intel.documentType,
            docNumber:
              intel.licenseNumber ||
              intel.taxCardNumber ||
              intel.chamberNumber ||
              intel.documentNumber ||
              normCr ||
              null,
            issueDate: intel.issueDate,
            expiryDate: intel.expiryDate,
            rawIssueDate: intel.rawIssueDate,
            rawExpiryDate: intel.rawExpiryDate,
            extractionSource: "WHATSAPP_AUTONOMOUS_OCR",
            hasNoExpiry: false,
            expiryStatus: "NEEDS_REVIEW",
            needsReview: true,
            fileUrl: storedArtifact.dataUrl,
            originalFileName: storedArtifact.sanitizedOriginalName,
            mimeType: storedArtifact.mimeType,
            fileSizeBytes: storedArtifact.fileSizeBytes,
            sha256: storedArtifact.verifiedSha256,
            storageObjectKey: storedArtifact.storageObjectKey,
            whatsappMessageId: providerMessageId,
            sourceChannel: "WHATSAPP",
            senderPhone,
            senderAuthorized: false,
            extractionConfidence: `${intel.confidenceLevel} (${intel.confidenceScore}%)`,
            processingStatus: "NEEDS_REVIEW",
            versionNumber: 1,
            extractedText: intel.extractedText,
            extractedMetadataJson: JSON.stringify(intel),
            issuingAuthority: intel.issuingAuthority,
            createdBy: "WhatsApp Autonomous Engine",
            docTypeCode: toDocTypeCode(intel.documentType),
            fieldsJson: buildFieldsJson(intel),
          })
          .returning();

        await tx.insert(auditLogs).values({
          tenantId,
          actorId: "WHATSAPP_ENGINE",
          actorName: "WhatsApp Autonomous Engine",
          action: "WHATSAPP_LICENSE_HELD_AWAITING_CR",
          resource: "customer_documents",
          resourceId: String(unmatchedDoc.id),
          details: JSON.stringify({
            correlationId,
            jobId,
            senderPhone,
            documentType: intel.documentType,
            extractedCrNumber: normCr,
            extractedCompanyNameAr: intel.companyNameAr,
            reason: "License for unregistered company held in review queue awaiting Commercial Registration",
          }),
          ipAddress: "127.0.0.1",
        });

        return {
          finalState: "NEEDS_REVIEW" as ProcessingState,
          companyResolution: "NEEDS_HUMAN_REVIEW" as const,
          companyId: null,
          companyName: intel.companyNameAr || null,
          normalizedCrNumber: normCr || null,
          savedDocumentId: unmatchedDoc.id,
          versionNumber: 1,
          isDuplicateFile: false,
          isNewCompany: false,
          senderAuthorized: false,
          nameDiscrepancyFlag: false,
          replyCategory: "MISSING_OR_UNREADABLE_DATA" as const,
          expiryDateForReply: intel.expiryDate,
        };
      }

      // Create owner customer record for the new company
      const ownerName = intel.owners[0] || effectiveCrCompanyName;
      let [ownerCustomer] = await tx
        .select()
        .from(customers)
        .where(
          and(
            eq(customers.tenantId, tenantId),
            eq(customers.phone, senderPhone),
            isNull(customers.deletedAt)
          )
        )
        .limit(1);

      if (!ownerCustomer) {
        [ownerCustomer] = await tx
          .insert(customers)
          .values({
            tenantId,
            customerType: "CORPORATE",
            fullNameAr: ownerName,
            fullNameEn: intel.companyNameEn,
            phone: senderPhone,
            whatsapp: senderPhone,
            address: intel.city,
            createdBy: "WhatsApp Autonomous Engine",
          })
          .returning();
      }

      let companyCode = `CR-${normCr}`;
      const [crossTenantCodeCollision] = await tx
        .select({ id: companies.id, tenantId: companies.tenantId, deletedAt: companies.deletedAt })
        .from(companies)
        .where(eq(companies.companyCode, companyCode))
        .limit(1);
      if (crossTenantCodeCollision) {
        const candidateCode =
          crossTenantCodeCollision.tenantId !== tenantId
            ? `CR-${normCr}-${tenantId.slice(0, 12)}`
            : `CR-${normCr}-${Date.now().toString(36).slice(-5)}`;
        const [secondCollision] = await tx
          .select({ id: companies.id })
          .from(companies)
          .where(eq(companies.companyCode, candidateCode))
          .limit(1);
        companyCode = secondCollision
          ? `CR-${normCr}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`
          : candidateCode;
      }

      const todayIso = new Date().toISOString().slice(0, 10);
      const isExpired = Boolean(intel.expiryDate && intel.expiryDate < todayIso);
      const capitalBaisa =
        typeof intel.capitalOmr === "number" && intel.capitalOmr > 0
          ? Math.round(intel.capitalOmr * 1000)
          : 0;

      const activitiesJson = JSON.stringify({
        activities: intel.activities,
        partners: intel.owners,
        authorizedSignatories: intel.authorizedSignatories,
        taxCardNumber: intel.taxCardNumber,
        chamberNumber: intel.chamberNumber,
        companyNameEn: intel.companyNameEn,
      });

      const [createdCompany] = await tx
        .insert(companies)
        .values({
          tenantId,
          ownerCustomerId: ownerCustomer.id,
          companyCode,
          name: effectiveCrCompanyName,
          companyNameEn: intel.companyNameEn,
          tradeName: (intel.tradeName || effectiveCrCompanyName).trim(),
          taxId: normCr,
          normalizedCrNumber: normCr,
          nameDiscrepancyFlag: false,
          nameDiscrepancyDetails: null,
          taxCardNumber: intel.taxCardNumber,
          chamberNumber: intel.chamberNumber,
          crIssueDate: intel.issueDate,
          crExpiryDate: intel.expiryDate,
          crDocumentUrl: null,
          crDocumentName: storedArtifact.sanitizedOriginalName,
          licenseNumber: intel.licenseNumber,
          sector: intel.activities[0] || null,
          activities: activitiesJson,
          status: isExpired ? "Expired" : "Active",
          city: intel.city,
          stateCountry: "سلطنة عُمان",
          contactPhone: intel.contactPhone || senderPhone,
          capitalBaisa,
          legalForm: intel.legalForm,
          revenueMonthlyBaisa: 0,
          employeesCount: 0,
          complianceScore: 100,
          createdBy: "WhatsApp Autonomous Engine",
        })
        .returning();

      // Store lightweight download URL on company record to prevent multi-MB base64 payload bloat
      const lightDownloadUrl = `/api/companies/${createdCompany.id}/cr-download`;
      await tx
        .update(companies)
        .set({ crDocumentUrl: lightDownloadUrl })
        .where(eq(companies.id, createdCompany.id));
      createdCompany.crDocumentUrl = lightDownloadUrl;

      const expClass = classifyDocumentExpiry({
        expiryDate: intel.expiryDate,
        hasNoExpiry: false,
      });

      const [createdDoc] = await tx
        .insert(customerDocuments)
        .values({
          tenantId,
          customerId: ownerCustomer.id,
          companyId: createdCompany.id,
          docType: "commercial_registry",
          docNumber: normCr,
          issueDate: intel.issueDate,
          expiryDate: intel.expiryDate,
          rawIssueDate: intel.rawIssueDate,
          rawExpiryDate: intel.rawExpiryDate,
          extractionSource: "WHATSAPP_AUTONOMOUS_OCR",
          hasNoExpiry: false,
          expiryStatus: expClass.status,
          needsReview: intel.chronologicalDateError || expClass.needsReview,
          fileUrl: storedArtifact.dataUrl,
          originalFileName: storedArtifact.sanitizedOriginalName,
          mimeType: storedArtifact.mimeType,
          fileSizeBytes: storedArtifact.fileSizeBytes,
          sha256: storedArtifact.verifiedSha256,
          storageObjectKey: storedArtifact.storageObjectKey,
          whatsappMessageId: providerMessageId,
          sourceChannel: "WHATSAPP",
          senderPhone,
          senderAuthorized: true,
          extractionConfidence: `${intel.confidenceLevel} (${intel.confidenceScore}%)`,
          processingStatus: intel.chronologicalDateError ? "NEEDS_REVIEW" : "COMPLETED",
          versionNumber: 1,
          previousVersionId: null,
          extractedText: intel.extractedText,
          extractedMetadataJson: JSON.stringify(intel),
          issuingAuthority: intel.issuingAuthority,
          createdBy: "WhatsApp Autonomous Engine",
          docTypeCode: toDocTypeCode(intel.documentType),
          fieldsJson: buildFieldsJson(intel),
        })
        .returning();

      // Auto-link any pending licenses that were sent BEFORE this Commercial Registration!
      const autoLinkedDocIds = await linkPendingReviewDocumentsToCompany(tx, {
        tenantId,
        company: createdCompany,
        normCr,
      });

      await tx.insert(auditLogs).values({
        tenantId,
        actorId: "WHATSAPP_ENGINE",
        actorName: "WhatsApp Autonomous Engine",
        action: "WHATSAPP_REGISTER_NEW_COMPANY",
        resource: "companies",
        resourceId: String(createdCompany.id),
        details: JSON.stringify({
          correlationId,
          jobId,
          companyId: createdCompany.id,
          companyName: createdCompany.name,
          normalizedCrNumber: normCr,
          documentId: createdDoc.id,
          autoLinkedPendingDocIds: autoLinkedDocIds,
          senderPhone,
        }),
        ipAddress: "127.0.0.1",
      });

      return {
        finalState: (intel.chronologicalDateError ? "NEEDS_REVIEW" : "COMPLETED") as ProcessingState,
        companyResolution: "CREATED_NEW_COMPANY" as const,
        companyId: createdCompany.id,
        companyName: createdCompany.name,
        normalizedCrNumber: normCr,
        savedDocumentId: createdDoc.id,
        versionNumber: 1,
        isDuplicateFile: false,
        isNewCompany: true,
        senderAuthorized: true,
        nameDiscrepancyFlag: false,
        replyCategory: "NEW_COMPANY_REGISTERED" as const,
        expiryDateForReply: createdCompany.crExpiryDate,
      };
    });
  } catch (txErr: any) {
    console.error(`[WhatsAppProcessor] Transaction failed for job ${jobId}:`, txErr);
    await updateJobState(jobId, "FAILED", txErr?.message || "Transaction failed", {
      errorCode: txErr?.code || "DB_TRANSACTION_FAILED",
      errorMessage: txErr?.message || "Failed to execute database transaction",
      completedAt: new Date(),
      lockedByWorker: null,
    });
    throw txErr;
  }

  // 8. Update job to final state (COMPLETED or NEEDS_REVIEW)
  await updateJobState(
    jobId,
    txOutcome.finalState,
    `Resolved with ${txOutcome.companyResolution}`,
    {
      matchedCompanyId: txOutcome.companyId,
      companyMatchResolution: txOutcome.companyResolution,
      savedDocumentId: txOutcome.savedDocumentId,
      senderAuthorized: txOutcome.senderAuthorized,
      completedAt: new Date(),
      lockedByWorker: null,
    }
  );

  // 9. Build Arabic WhatsApp reply & enqueue in whatsapp_outbox ONLY after storage & DB commit
  const replyText = buildArabicWhatsAppReply({
    category: txOutcome.replyCategory,
    companyName: txOutcome.companyName,
    crNumber: txOutcome.normalizedCrNumber,
    expiryDate: txOutcome.expiryDateForReply,
    documentType: intel.documentType,
  });

  const outboxId = isWhatsAppChannel
    ? await enqueueAndDispatchWhatsAppReply({
        tenantId,
        jobId,
        correlationId,
        providerMessageId,
        recipientPhone: senderPhone,
        recipientJid,
        replyCategory: txOutcome.replyCategory,
        messageText: replyText,
        sendWhatsAppReplyFn: input.sendWhatsAppReplyFn,
      })
    : null;

  return {
    ok: true,
    deduplicatedReplay: false,
    jobId,
    correlationId,
    state: txOutcome.finalState,
    documentType: intel.documentType,
    normalizedCrNumber: txOutcome.normalizedCrNumber,
    companyId: txOutcome.companyId,
    companyName: txOutcome.companyName,
    companyResolution: txOutcome.companyResolution,
    savedDocumentId: txOutcome.savedDocumentId,
    versionNumber: txOutcome.versionNumber,
    isDuplicateFile: txOutcome.isDuplicateFile,
    isNewCompany: txOutcome.isNewCompany,
    senderAuthorized: txOutcome.senderAuthorized,
    nameDiscrepancyFlag: txOutcome.nameDiscrepancyFlag,
    replyCategory: txOutcome.replyCategory,
    replyMessageText: replyText,
    outboxId,
    matchLane: txOutcome.matchLane ?? null,
    matchScore: txOutcome.matchScore ?? null,
  };
}

/**
 * Recovers interrupted or RETRY_PENDING jobs from PostgreSQL after a worker crash or transient outage.
 */
export async function recoverInterruptedWhatsAppJobs(tenantId = "default_tenant"): Promise<{
  scanned: number;
  recoveredIds: string[];
}> {
  const staleCutoff = new Date(Date.now() - 2 * 60_000);
  const rows = await db
    .select()
    .from(whatsappProcessingJobs)
    .where(eq(whatsappProcessingJobs.tenantId, tenantId));

  const recoveredIds: string[] = [];
  for (const job of rows) {
    const isInterrupted =
      job.state !== "COMPLETED" &&
      job.state !== "NEEDS_REVIEW" &&
      job.state !== "REJECTED" &&
      job.state !== "FAILED" &&
      (!job.lockedAt || new Date(job.lockedAt) < staleCutoff);

    if (isInterrupted) {
      if ((job.retryCount || 0) >= (job.maxRetries || 3)) {
        await updateJobState(job.jobId, "FAILED", "Max retries exceeded during recovery", {
          lockedByWorker: null,
        });
      } else {
        await updateJobState(job.jobId, "RETRY_PENDING", "Recovered stale lock for retry", {
          lockedByWorker: null,
          nextRetryAt: new Date(),
        });
        recoveredIds.push(job.jobId);
      }
    }
  }

  return {
    scanned: rows.length,
    recoveredIds,
  };
}

/**
 * Automatically links any pending documents/licenses in the review queue (`companyId IS NULL`)
 * that match the newly registered or updated company's CR number or normalized Company Name,
 * and populates the company's license/tax/chamber fields from those linked documents.
 */
export async function linkPendingReviewDocumentsToCompany(
  txOrDb: any,
  params: {
    tenantId: string;
    company: typeof companies.$inferSelect;
    normCr?: string | null;
  }
): Promise<number[]> {
  const { tenantId, company } = params;
  const effectiveCr = normalizeCrNumber(
    params.normCr || company.normalizedCrNumber || company.taxId || ""
  );

  const pendingDocs = await txOrDb
    .select()
    .from(customerDocuments)
    .where(
      and(
        eq(customerDocuments.tenantId, tenantId),
        isNull(customerDocuments.companyId),
        isNull(customerDocuments.deletedAt)
      )
    );

  if (pendingDocs.length === 0) return [];

  const linkedIds: number[] = [];
  const companyFieldUpdates: Partial<typeof companies.$inferInsert> = {};

  for (const doc of pendingDocs) {
    // Smart Company File: documents held for human confirmation are never linked automatically.
    if (doc.matchLane === "CONFIRM") continue;
    let meta: Partial<ExtractedDocumentIntelligence> | null = null;
    if (doc.extractedMetadataJson) {
      try {
        meta = JSON.parse(doc.extractedMetadataJson);
      } catch {
        meta = null;
      }
    }

    const docCr = normalizeCrNumber(meta?.normalizedCrNumber || meta?.crNumberRaw || "");
    let isMatch = false;

    // 1. Match by CR Number
    if (docCr && effectiveCr && docCr === effectiveCr) {
      isMatch = true;
    }

    // 2. Match by Company Name (only if there is no conflicting CR number).
    //    Documents that went through the lane pipeline (matchLane set) never auto-link on name alone.
    if (!isMatch && !doc.matchLane && (!docCr || !effectiveCr || docCr === effectiveCr)) {
      const candAr = meta?.companyNameAr || null;
      const candTrade = meta?.tradeName || null;
      const candEn = meta?.companyNameEn || null;

      if (
        (candAr && (companyNamesMatch(candAr, company.name) || companyNamesMatch(candAr, company.tradeName))) ||
        (candTrade && (companyNamesMatch(candTrade, company.name) || companyNamesMatch(candTrade, company.tradeName))) ||
        (candEn && company.companyNameEn && companyNamesMatch(candEn, company.companyNameEn))
      ) {
        isMatch = true;
      }
    }

    if (!isMatch) continue;

    const expClass = classifyDocumentExpiry({
      expiryDate: doc.expiryDate,
      hasNoExpiry: Boolean(doc.hasNoExpiry),
    });
    const stillNeedsReview = Boolean(meta?.chronologicalDateError || expClass.needsReview);

    await txOrDb
      .update(customerDocuments)
      .set({
        companyId: company.id,
        customerId: company.ownerCustomerId || doc.customerId,
        ...(doc.matchLane ? { matchLane: "AUTO", matchScore: 90 } : {}),
        needsReview: stillNeedsReview,
        processingStatus: meta?.chronologicalDateError ? "NEEDS_REVIEW" : "COMPLETED",
        expiryStatus: expClass.status,
        updatedAt: new Date(),
      })
      .where(eq(customerDocuments.id, doc.id));

    await txOrDb
      .update(whatsappProcessingJobs)
      .set({
        state: meta?.chronologicalDateError ? "NEEDS_REVIEW" : "COMPLETED",
        matchedCompanyId: company.id,
        companyMatchResolution: "MATCHED_EXISTING_COMPANY",
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(whatsappProcessingJobs.tenantId, tenantId),
          eq(whatsappProcessingJobs.savedDocumentId, doc.id)
        )
      );

    // Harvest license/certificate fields for the company record
    if (doc.docType === "municipal_license") {
      if (doc.expiryDate && (!company.licenseExpiryDate || doc.expiryDate >= company.licenseExpiryDate)) {
        companyFieldUpdates.licenseExpiryDate = doc.expiryDate;
      }
      const licNo = meta?.licenseNumber || meta?.documentNumber || doc.docNumber;
      if (licNo && licNo !== effectiveCr) {
        companyFieldUpdates.licenseNumber = licNo;
      }
    } else if (doc.docType === "tax_certificate") {
      const taxNo = meta?.taxCardNumber || meta?.documentNumber || doc.docNumber;
      if (taxNo && taxNo !== effectiveCr) {
        companyFieldUpdates.taxCardNumber = taxNo;
      }
    } else if (doc.docType === "chamber_certificate") {
      const chNo = meta?.chamberNumber || meta?.documentNumber || doc.docNumber;
      if (chNo && chNo !== effectiveCr) {
        companyFieldUpdates.chamberNumber = chNo;
      }
    }

    linkedIds.push(doc.id);
  }

  if (Object.keys(companyFieldUpdates).length > 0) {
    companyFieldUpdates.updatedAt = new Date();
    await txOrDb
      .update(companies)
      .set(companyFieldUpdates)
      .where(eq(companies.id, company.id));
  }

  if (linkedIds.length > 0) {
    await txOrDb.insert(auditLogs).values({
      tenantId,
      actorId: "WHATSAPP_ENGINE",
      actorName: "WhatsApp Autonomous Engine",
      action: "WHATSAPP_AUTO_LINKED_PENDING_LICENSES",
      resource: "companies",
      resourceId: String(company.id),
      details: JSON.stringify({
        companyId: company.id,
        companyName: company.name,
        normalizedCrNumber: effectiveCr,
        linkedDocumentIds: linkedIds,
        appliedCompanyUpdates: companyFieldUpdates,
      }),
      ipAddress: "127.0.0.1",
    });
  }

  return linkedIds;
}

