import fs from "fs";
import path from "path";
import crypto from "crypto";
import cron, { type ScheduledTask } from "node-cron";
import { eq, desc, and, lte, inArray } from "drizzle-orm";
import { pool, db } from "../../db/index.js";
import {
  backupHistory,
  backupSyncOutbox,
  notifications,
} from "../../db/schema.js";
import {
  SCHEMA_VERSION,
  APP_VERSION,
  ADVISORY_LOCK_KEY,
  EXCLUDED_SYSTEM_TABLES,
  getLocalBackupDir,
  getCloudVaultDir,
  validateSafeIdentifier,
  redactSensitiveError,
  detectStorageEnvironment,
  encryptBackupBuffer,
  decryptBackupBuffer,
  encryptBackupStream,
  writeFileAtomically,
  collectProtectedFiles,
  uploadToCloudStorage,
  type ProtectionState,
  type BackupCoverageReport,
  type DatabaseBackupManifest,
  type RestoreVerificationReport,
  type StorageEnvironmentReport,
} from "./backupCryptoAndStorage.js";
import {
  verifyAndValidateBackupFile,
  runIsolatedRestoreVerification,
} from "./backupRestoreVerifier.js";
import { getMuscatTodayString } from "./expiryClassification.js";
import { logger } from "../logger.js";

export {
  type ProtectionState,
  type BackupCoverageReport,
  type DatabaseBackupManifest,
  type RestoreVerificationReport,
  type StorageEnvironmentReport,
};

export class BackupService {
  private static isProcessingOutbox = false;
  private static scheduledTasks: ScheduledTask[] = [];
  private static lastRetentionPruneFailures = 0;

  static getLocalBackupDir = getLocalBackupDir;
  static getCloudVaultDir = getCloudVaultDir;
  static validateSafeIdentifier = validateSafeIdentifier;
  static redactSensitiveError = redactSensitiveError;
  static detectStorageEnvironment = detectStorageEnvironment;
  static encryptBackupBuffer = encryptBackupBuffer;
  static decryptBackupBuffer = decryptBackupBuffer;
  static encryptBackupStream = encryptBackupStream;
  static writeFileAtomically = writeFileAtomically;
  static verifyAndValidateBackup = verifyAndValidateBackupFile;
  static testIsolatedRestore = runIsolatedRestoreVerification;

  static async createBackupSnapshot(
    actorName = "System Admin",
    options?: {
      triggerType?:
        | "MANUAL"
        | "SCHEDULED"
        | "OUTBOX_SYNC"
        | "PRE_RESTORE_SAFETY";
      retentionTier?: "DAILY" | "WEEKLY" | "MONTHLY";
      simulateLocalFailure?: boolean;
      simulateCloudFailure?: boolean;
    },
  ): Promise<{
    manifest: DatabaseBackupManifest;
    filePath: string;
    encryptedFilePath: string;
  }> {
    const startTime = Date.now();
    const timestampStr = new Date().toISOString().replace(/[:.]/g, "-");
    const randSuffix = crypto.randomBytes(3).toString("hex");
    const backupId = `bkp_${timestampStr}_${randSuffix}`;
    const triggerType = options?.triggerType || "MANUAL";
    const retentionTier = options?.retentionTier || "DAILY";

    const client = await pool.connect();
    let pgSnapshotId = "unknown";
    const tableData: Record<string, Array<Record<string, unknown>>> = {};
    const tableRecordCounts: Record<string, number> = {};
    const tableChecksums: Record<string, string> = {};
    const includedTables: string[] = [];
    const excludedTables: BackupCoverageReport["excludedTables"] = [];
    let totalPublicTablesInDb = 0;

    try {
      await client.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");

      const snapRes = await client.query<{ snap?: string }>(
        "SELECT pg_current_snapshot()::text AS snap",
      );
      pgSnapshotId = snapRes.rows[0]?.snap || "repeatable_read_snapshot";

      const tablesRes = await client.query<{ table_name: string }>(`
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        ORDER BY table_name ASC
      `);

      const allPublicTables: string[] = tablesRes.rows.map((r) => r.table_name);
      totalPublicTablesInDb = allPublicTables.length;

      for (const tableName of allPublicTables) {
        if (EXCLUDED_SYSTEM_TABLES[tableName]) {
          excludedTables.push({
            tableName,
            reason: EXCLUDED_SYSTEM_TABLES[tableName],
            isSafeExclusion: true,
          });
          continue;
        }

        const safeTableName = tableName.replace(/"/g, '""');
        includedTables.push(tableName);
        const rowsRes = await client.query<Record<string, unknown>>(
          `SELECT * FROM public."${safeTableName}" ORDER BY 1 ASC`,
        );
        const sanitizedRows = rowsRes.rows.map((row) => {
          if (tableName === "users") {
            const copy: Record<string, unknown> = { ...row };
            if (copy.password_hash)
              copy.password_hash = "[REDACTED_CREDENTIAL_HASH]";
            if (copy.salt) copy.salt = "[REDACTED_CREDENTIAL_SALT]";
            return copy;
          }
          return row;
        });

        tableData[tableName] = sanitizedRows;
        tableRecordCounts[tableName] = sanitizedRows.length;
        tableChecksums[tableName] = crypto
          .createHash("sha256")
          .update(JSON.stringify(sanitizedRows))
          .digest("hex");
      }

      await client.query("COMMIT");
    } catch (dbErr) {
      try {
        await client.query("ROLLBACK");
      } catch {
        // Ignore rollback error
      }
      throw dbErr;
    } finally {
      client.release();
    }

    const { filesMeta, filesPayload } = collectProtectedFiles();

    const coverageReport: BackupCoverageReport = {
      schemaVersion: SCHEMA_VERSION,
      inspectedAt: new Date().toISOString(),
      totalPublicTablesInDb,
      includedTables,
      excludedTables,
      tableRecordCounts,
      tableChecksums,
      protectedFiles: filesMeta,
      coveragePercentage: includedTables.length > 0 ? 100 : 0,
    };

    const backupPayload = {
      backupId,
      schemaVersion: SCHEMA_VERSION,
      appVersion: APP_VERSION,
      exportedAt: new Date().toISOString(),
      pgSnapshotId,
      actorName,
      coverageReport,
      data: tableData,
      protectedFilesPayload: filesPayload,
    };

    const rawJsonBuffer = Buffer.from(
      JSON.stringify(backupPayload, null, 2),
      "utf-8",
    );
    const plaintextSha256 = crypto
      .createHash("sha256")
      .update(rawJsonBuffer)
      .digest("hex");
    const { encryptedBuffer, keyId, encryptedSha256 } =
      this.encryptBackupBuffer(rawJsonBuffer);

    let totalRecords = 0;
    for (const count of Object.values(tableRecordCounts)) {
      totalRecords += count;
    }

    const localDir = this.getLocalBackupDir();
    const encryptedFilePath = path.join(localDir, `${backupId}.enc`);
    const manifestPath = path.join(
      localDir,
      `manifest_${timestampStr}_${randSuffix}.json`,
    );

    let localStatus: "COMPLETED" | "FAILED" | "PENDING" = "PENDING";
    let cloudStatus: "COMPLETED" | "FAILED" | "PENDING" = "PENDING";
    let cloudObjectUri: string | null = null;
    let lastError: string | null = null;

    try {
      if (options?.simulateLocalFailure) {
        throw new Error(
          "SIMULATED_LOCAL_DISK_FAILURE: Local backup volume write rejected",
        );
      }

      // Only write the encrypted .enc file to disk; never write unencrypted JSON dumps (#12, #74)
      this.writeFileAtomically(encryptedFilePath, encryptedBuffer);

      const diskEncrypted = fs.readFileSync(encryptedFilePath);
      const decryptedBuf = this.decryptBackupBuffer(diskEncrypted);
      const decryptedSha = crypto
        .createHash("sha256")
        .update(decryptedBuf)
        .digest("hex");
      if (decryptedSha !== plaintextSha256) {
        throw new Error(
          "Local encrypted backup verification failed after decrypt",
        );
      }

      localStatus = "COMPLETED";
    } catch (localErr) {
      localStatus = "FAILED";
      lastError = this.redactSensitiveError(localErr);
    }

    const durationMs = Date.now() - startTime;
    const manifest: DatabaseBackupManifest = {
      backupId,
      createdAt: backupPayload.exportedAt,
      schemaVersion: SCHEMA_VERSION,
      appVersion: APP_VERSION,
      databaseEngine: "PostgreSQL 16 (Cloud SQL)",
      pgSnapshotId,
      triggerType,
      retentionTier,
      encryption: {
        enabled: true,
        algorithm: "AES-256-GCM",
        keyId,
        encryptedSha256,
        encryptedSizeBytes: encryptedBuffer.length,
      },
      plaintextSha256,
      plaintextSizeBytes: rawJsonBuffer.length,
      tables: tableRecordCounts,
      totalTables: includedTables.length,
      totalRecords,
      coverageReport,
      localStatus,
      cloudStatus: "PENDING",
      restoreVerifyStatus: "NOT_TESTED",
      localFilePath: localStatus === "COMPLETED" ? encryptedFilePath : "",
      cloudObjectUri: null,
      durationMs,
      protectionState:
        localStatus === "COMPLETED"
          ? "LOCAL_BACKUP_SUCCESSFUL"
          : "BACKUP_FAILED",
    };

    try {
      const cloudRes = await uploadToCloudStorage(
        backupId,
        encryptedBuffer,
        manifest,
        options,
      );
      cloudStatus = "COMPLETED";
      cloudObjectUri = cloudRes.cloudUri;
      manifest.cloudStatus = "COMPLETED";
      manifest.cloudObjectUri = cloudObjectUri;
      if (localStatus === "COMPLETED") {
        manifest.protectionState = "CLOUD_BACKUP_SUCCESSFUL";
      }
    } catch (cloudErr) {
      cloudStatus = "FAILED";
      manifest.cloudStatus = "FAILED";
      const redactedCloudErr = this.redactSensitiveError(cloudErr);
      lastError = lastError
        ? `${lastError} | ${redactedCloudErr}`
        : redactedCloudErr;

      await this.enqueueSyncJob({
        idempotencyKey: `cloud_retry_${backupId}`,
        operationType: "CLOUD_BACKUP_UPLOAD_RETRY",
        entityType: "backup",
        entityId: backupId,
        payloadSummary: `Retry cloud upload for backup ${backupId}`,
        localBackupStatus: localStatus,
        cloudBackupStatus: "FAILED",
        backupId,
        lastError: redactedCloudErr,
      });
    }

    manifest.durationMs = Date.now() - startTime;

    if (localStatus === "COMPLETED") {
      this.writeFileAtomically(
        manifestPath,
        Buffer.from(JSON.stringify(manifest, null, 2), "utf-8"),
      );
    }

    try {
      await db.insert(backupHistory).values({
        backupId,
        schemaVersion: SCHEMA_VERSION,
        appVersion: APP_VERSION,
        triggerType,
        retentionTier,
        localStatus,
        cloudStatus,
        restoreVerifyStatus: "NOT_TESTED",
        localFilePath: localStatus === "COMPLETED" ? encryptedFilePath : null,
        cloudObjectUri,
        fileSizeBytes: rawJsonBuffer.length,
        encryptedSizeBytes: encryptedBuffer.length,
        sha256Checksum: plaintextSha256,
        encryptedSha256,
        encryptionAlgorithm: "AES-256-GCM",
        encryptionKeyId: keyId,
        totalTables: includedTables.length,
        totalRecords,
        coverageReportJson: JSON.stringify(coverageReport),
        durationMs: manifest.durationMs,
        lastError,
        actorName,
      });
    } catch (err) {
      logger.warn({ err, backupId }, "Could not record backupHistory row");
    }

    if (localStatus === "FAILED" || cloudStatus === "FAILED") {
      try {
        await db.insert(notifications).values({
          type: "BACKUP_SYNC_FAILURE",
          title: `تنبيه حماية البيانات: تعذر مزامنة النسخة الاحتياطية (${backupId})`,
          message: `حالة الحفظ المحلي: ${localStatus} | حالة الحفظ السحابي: ${cloudStatus}. السبب: ${lastError || "غير محدد"}`,
          channel: "system",
          status: "PENDING",
        });
      } catch (notifErr) {
        logger.warn({ err: notifErr, backupId }, "Could not insert backup failure notification");
      }
    }

    if (localStatus === "FAILED" && options?.simulateLocalFailure) {
      const err = new Error(lastError || "Local backup failed") as Error & {
        manifest?: DatabaseBackupManifest;
      };
      err.manifest = manifest;
      throw err;
    }

    if (localStatus === "COMPLETED") {
      try {
        await this.applyRetentionPolicy();
      } catch (err) {
        logger.warn({ err }, "Retention policy execution warning");
      }
    }

    return {
      manifest,
      filePath: encryptedFilePath,
      encryptedFilePath,
    };
  }

  static async enqueueSyncJob(params: {
    idempotencyKey: string;
    operationType: string;
    entityType: string;
    entityId: string;
    payloadSummary?: string;
    localBackupStatus?: string;
    cloudBackupStatus?: string;
    backupId?: string;
    lastError?: string;
  }) {
    const existing = await db
      .select()
      .from(backupSyncOutbox)
      .where(eq(backupSyncOutbox.idempotencyKey, params.idempotencyKey))
      .limit(1);

    if (existing.length > 0) {
      return existing[0];
    }

    const jobId = `job_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
    const [inserted] = await db
      .insert(backupSyncOutbox)
      .values({
        jobId,
        idempotencyKey: params.idempotencyKey,
        operationType: params.operationType,
        entityType: params.entityType,
        entityId: String(params.entityId),
        payloadSummary: params.payloadSummary || null,
        status: "PENDING",
        localBackupStatus: params.localBackupStatus || "PENDING",
        cloudBackupStatus: params.cloudBackupStatus || "PENDING",
        backupId: params.backupId || null,
        lastError: params.lastError
          ? this.redactSensitiveError(params.lastError)
          : null,
      })
      .returning();

    return inserted;
  }

  static async processPendingSyncJobs(options?: {
    simulateCloudFailure?: boolean;
    forceImmediate?: boolean;
  }): Promise<{
    processedCount: number;
    succeededCount: number;
    failedCount: number;
  }> {
    if (this.isProcessingOutbox) {
      return { processedCount: 0, succeededCount: 0, failedCount: 0 };
    }
    this.isProcessingOutbox = true;

    const lockClient = await pool.connect();
    let processedCount = 0;
    let succeededCount = 0;
    let failedCount = 0;

    try {
      const lockRes = await lockClient.query<{ locked?: boolean }>(
        "SELECT pg_try_advisory_lock($1) AS locked",
        [ADVISORY_LOCK_KEY],
      );
      if (!lockRes.rows[0]?.locked) {
        return { processedCount: 0, succeededCount: 0, failedCount: 0 };
      }

      const now = new Date();
      // Fix #74: Reset any stale PROCESSING outbox rows older than 10 minutes back to FAILED
      const staleCutoff = new Date(now.getTime() - 10 * 60 * 1000);
      await db
        .update(backupSyncOutbox)
        .set({
          status: "FAILED",
          lastError: "Recovered from stale PROCESSING state (>10m)",
          updatedAt: now,
        })
        .where(
          and(
            eq(backupSyncOutbox.status, "PROCESSING"),
            lte(backupSyncOutbox.updatedAt, staleCutoff),
          ),
        );

      const pendingJobs = await db
        .select()
        .from(backupSyncOutbox)
        .where(
          options?.forceImmediate
            ? inArray(backupSyncOutbox.status, ["PENDING", "FAILED"])
            : and(
                inArray(backupSyncOutbox.status, ["PENDING", "FAILED"]),
                lte(backupSyncOutbox.nextRetryAt, now),
              ),
        )
        .orderBy(backupSyncOutbox.id)
        .limit(20);

      for (const job of pendingJobs) {
        if (job.retryCount >= job.maxRetries) {
          continue;
        }
        processedCount++;
        await db
          .update(backupSyncOutbox)
          .set({ status: "PROCESSING", updatedAt: new Date() })
          .where(eq(backupSyncOutbox.id, job.id));

        try {
          if (
            job.operationType === "CLOUD_BACKUP_UPLOAD_RETRY" &&
            job.backupId
          ) {
            if (options?.simulateCloudFailure) {
              throw new Error("SIMULATED_CLOUD_UPLOAD_FAILURE");
            }
            const localEncPath = path.join(
              this.getLocalBackupDir(),
              `${job.backupId}.enc`,
            );
            if (!fs.existsSync(localEncPath)) {
              throw new Error(
                `Local encrypted file missing for retry: ${job.backupId}`,
              );
            }
            const encBuf = fs.readFileSync(localEncPath);
            const cloudRes = await uploadToCloudStorage(
              job.backupId,
              encBuf,
              { backupId: job.backupId },
              options,
            );
            await db
              .update(backupHistory)
              .set({
                cloudStatus: "COMPLETED",
                cloudObjectUri: cloudRes.cloudUri,
                lastError: null,
              })
              .where(eq(backupHistory.backupId, job.backupId));

            await db
              .update(backupSyncOutbox)
              .set({
                status: "COMPLETED",
                localBackupStatus: "COMPLETED",
                cloudBackupStatus: "COMPLETED",
                completedAt: new Date(),
                updatedAt: new Date(),
                lastError: null,
              })
              .where(eq(backupSyncOutbox.id, job.id));
          } else {
            const snap = await this.createBackupSnapshot("Outbox Sync Worker", {
              triggerType: "OUTBOX_SYNC",
              simulateCloudFailure: options?.simulateCloudFailure,
            });
            if (snap.manifest.cloudStatus === "FAILED") {
              throw new Error("Cloud upload failed during outbox sync");
            }
            await db
              .update(backupSyncOutbox)
              .set({
                status: "COMPLETED",
                localBackupStatus: snap.manifest.localStatus,
                cloudBackupStatus: snap.manifest.cloudStatus,
                backupId: snap.manifest.backupId,
                completedAt: new Date(),
                updatedAt: new Date(),
                lastError: null,
              })
              .where(eq(backupSyncOutbox.id, job.id));
          }
          succeededCount++;
        } catch (jobErr) {
          failedCount++;
          const newRetry = job.retryCount + 1;
          const backoffSeconds = Math.min(3600, Math.pow(2, newRetry) * 10);
          const nextRetry = new Date(Date.now() + backoffSeconds * 1000);
          const redacted = this.redactSensitiveError(jobErr);

          await db
            .update(backupSyncOutbox)
            .set({
              status: "FAILED",
              cloudBackupStatus: "FAILED",
              retryCount: newRetry,
              nextRetryAt: nextRetry,
              lastError: redacted,
              updatedAt: new Date(),
            })
            .where(eq(backupSyncOutbox.id, job.id));

          if (newRetry >= job.maxRetries) {
            try {
              await db.insert(notifications).values({
                type: "BACKUP_SYNC_FAILURE",
                title: `فشل نهائي في مزامنة النسخ الاحتياطي (${job.jobId})`,
                message: `استنفدت المهمة ${job.jobId} الحد الأقصى للمحاولات (${job.maxRetries}). آخر خطأ: ${redacted}`,
                channel: "system",
                status: "PENDING",
              });
            } catch (notifErr) {
              logger.warn({ err: notifErr, jobId: job.jobId }, "Could not record outbox exhaustion notification");
            }
          }
        }
      }
    } finally {
      try {
        await lockClient.query("SELECT pg_advisory_unlock($1)", [
          ADVISORY_LOCK_KEY,
        ]);
      } catch {
        // Ignore unlock error
      }
      lockClient.release();
      this.isProcessingOutbox = false;
    }

    return { processedCount, succeededCount, failedCount };
  }

  /**
   * Fix #57, #75, #102: Tiered retention keeping N daily + 4 weekly + 6 monthly verified backups,
   * never deleting the last verified valid backup, and logging/counting any unlink failures.
   */
  static async applyRetentionPolicy(
    overrideMaxKeep?: number,
  ): Promise<{ retainedCount: number; prunedCount: number; pruneFailuresCount: number }> {
    const maxDaily = Math.max(
      1,
      overrideMaxKeep ??
        parseInt(process.env.BACKUP_RETENTION_DAILY || "3", 10),
    );
    const maxWeekly = overrideMaxKeep !== undefined
      ? 0
      : Math.max(1, parseInt(process.env.BACKUP_RETENTION_WEEKLY || "4", 10));
    const maxMonthly = overrideMaxKeep !== undefined
      ? 0
      : Math.max(1, parseInt(process.env.BACKUP_RETENTION_MONTHLY || "6", 10));

    const localDir = this.getLocalBackupDir();
    if (!fs.existsSync(localDir)) {
      return { retainedCount: 0, prunedCount: 0, pruneFailuresCount: 0 };
    }

    const manifests = this.listBackups();
    const completedBackups = manifests.filter(
      (m) => m.localStatus === "COMPLETED",
    );
    if (completedBackups.length === 0) {
      return { retainedCount: 0, prunedCount: 0, pruneFailuresCount: 0 };
    }

    const verifiedValidBackups = completedBackups.filter(
      (m) => this.verifyAndValidateBackup(m.backupId).valid,
    );
    if (verifiedValidBackups.length === 0) {
      return {
        retainedCount: completedBackups.length,
        prunedCount: 0,
        pruneFailuresCount: 0,
      };
    }

    const retainedBackups: DatabaseBackupManifest[] = [];
    const retainedIds = new Set<string>();
    const retainedSuffixes = new Set<string>();

    const addRetained = (bkp: DatabaseBackupManifest) => {
      if (retainedIds.has(bkp.backupId)) return;
      retainedIds.add(bkp.backupId);
      retainedSuffixes.add(bkp.backupId.replace(/^bkp_/, ""));
      retainedBackups.push(bkp);
    };

    if (overrideMaxKeep !== undefined) {
      for (const bkp of verifiedValidBackups.slice(0, maxDaily)) {
        addRetained(bkp);
      }
    } else {
      const monthlyBackups = verifiedValidBackups
        .filter((m) => m.retentionTier === "MONTHLY")
        .slice(0, maxMonthly);
      const weeklyBackups = verifiedValidBackups
        .filter((m) => m.retentionTier === "WEEKLY")
        .slice(0, maxWeekly);
      const dailyBackups = verifiedValidBackups
        .filter((m) => !m.retentionTier || m.retentionTier === "DAILY")
        .slice(0, maxDaily);

      for (const bkp of [...dailyBackups, ...weeklyBackups, ...monthlyBackups]) {
        addRetained(bkp);
      }
      if (retainedBackups.length === 0 && verifiedValidBackups.length > 0) {
        addRetained(verifiedValidBackups[0]);
      }
    }

    let prunedCount = 0;
    let pruneFailuresCount = 0;
    const toPrune = completedBackups.filter(
      (m) => !retainedIds.has(m.backupId),
    );
    for (const old of toPrune) {
      const suffix = old.backupId.replace(/^bkp_/, "");
      const candidateFiles = [
        path.join(localDir, `${old.backupId}.enc`),
        path.join(localDir, `backup_${suffix}.json`),
        path.join(localDir, `manifest_${suffix}.json`),
      ];
      for (const filePath of candidateFiles) {
        try {
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            prunedCount++;
          }
        } catch (unlinkErr) {
          pruneFailuresCount++;
          logger.warn({ err: unlinkErr, filePath }, "Failed to unlink expired backup file");
        }
      }
    }

    try {
      const allFiles = fs.readdirSync(localDir);
      for (const fileName of allFiles) {
        const isEnc = fileName.startsWith("bkp_") && fileName.endsWith(".enc");
        const isJson =
          fileName.startsWith("backup_") && fileName.endsWith(".json");
        const isManifest =
          fileName.startsWith("manifest_") && fileName.endsWith(".json");
        if (!isEnc && !isJson && !isManifest) continue;

        const baseNoExt = fileName.replace(/\.(enc|json)$/, "");
        const suffix = baseNoExt.replace(/^(bkp_|backup_|manifest_)/, "");

        if (!retainedIds.has(baseNoExt) && !retainedSuffixes.has(suffix)) {
          const orphanPath = path.join(localDir, fileName);
          try {
            fs.unlinkSync(orphanPath);
            prunedCount++;
          } catch (unlinkErr) {
            pruneFailuresCount++;
            logger.warn({ err: unlinkErr, filePath: orphanPath }, "Failed to unlink orphan backup file");
          }
        }
      }
    } catch (dirErr) {
      logger.warn({ err: dirErr, localDir }, "Directory scan warning during backup prune");
    }

    this.lastRetentionPruneFailures = pruneFailuresCount;
    return { retainedCount: retainedBackups.length, prunedCount, pruneFailuresCount };
  }

  static listBackups(): DatabaseBackupManifest[] {
    const localDir = this.getLocalBackupDir();
    const manifestsMap = new Map<string, DatabaseBackupManifest>();

    if (fs.existsSync(localDir)) {
      const files = fs
        .readdirSync(localDir)
        .filter((f) => f.startsWith("manifest_") && f.endsWith(".json"));
      for (const f of files) {
        try {
          const raw = fs.readFileSync(path.join(localDir, f), "utf-8");
          const parsed = JSON.parse(raw) as DatabaseBackupManifest;
          if (parsed.backupId) {
            manifestsMap.set(parsed.backupId, parsed);
          }
        } catch (err) {
          logger.debug({ err, file: f }, "Skipped malformed backup manifest");
        }
      }
    }

    const vaultObjDir = path.join(this.getCloudVaultDir(), "objects");
    if (fs.existsSync(vaultObjDir)) {
      try {
        for (const bkpDir of fs.readdirSync(vaultObjDir)) {
          const mfPath = path.join(
            vaultObjDir,
            bkpDir,
            "v1",
            `manifest_${bkpDir}.json`,
          );
          if (fs.existsSync(mfPath) && !manifestsMap.has(bkpDir)) {
            const parsed = JSON.parse(
              fs.readFileSync(mfPath, "utf-8"),
            ) as DatabaseBackupManifest;
            manifestsMap.set(bkpDir, parsed);
          }
        }
      } catch (err) {
        logger.debug({ err }, "Vault manifest scan notice");
      }
    }

    return Array.from(manifestsMap.values()).sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }

  static async getBackupHealthSummary() {
    const envReport = this.detectStorageEnvironment();

    let dbConnected = false;
    try {
      await pool.query("SELECT 1");
      dbConnected = true;
    } catch {
      // Disconnected
    }

    const historyRows = await db
      .select()
      .from(backupHistory)
      .orderBy(desc(backupHistory.createdAt))
      .limit(50);

    const outboxRows = await db
      .select()
      .from(backupSyncOutbox)
      .where(
        inArray(backupSyncOutbox.status, ["PENDING", "PROCESSING", "FAILED"]),
      )
      .orderBy(desc(backupSyncOutbox.updatedAt))
      .limit(25);

    const lastLocalSuccess = historyRows.find(
      (r) => r.localStatus === "COMPLETED",
    );
    const lastCloudSuccess = historyRows.find(
      (r) => r.cloudStatus === "COMPLETED",
    );
    const lastVerifiedRestore = historyRows.find(
      (r) => r.restoreVerifyStatus === "RECOVERY_VERIFIED",
    );
    const latestFailure = historyRows.find(
      (r) =>
        r.localStatus === "FAILED" ||
        r.cloudStatus === "FAILED" ||
        Boolean(r.lastError),
    );

    const pendingOutboxCount = outboxRows.filter(
      (r) => r.status === "PENDING" || r.status === "PROCESSING",
    ).length;
    const failedOutboxCount = outboxRows.filter(
      (r) => r.status === "FAILED",
    ).length;

    const validRetainedCount = historyRows.filter(
      (r) => r.localStatus === "COMPLETED" || r.cloudStatus === "COMPLETED",
    ).length;

    let overallProtectionState: ProtectionState = "DATABASE_SAVE_SUCCESSFUL";
    if (lastVerifiedRestore) {
      overallProtectionState = "RECOVERY_VERIFIED";
    } else if (lastCloudSuccess) {
      overallProtectionState = "CLOUD_BACKUP_SUCCESSFUL";
    } else if (lastLocalSuccess) {
      overallProtectionState = "LOCAL_BACKUP_SUCCESSFUL";
    } else if (pendingOutboxCount > 0) {
      overallProtectionState = "BACKUP_PENDING";
    }

    if (
      historyRows[0] &&
      (historyRows[0].localStatus === "FAILED" ||
        historyRows[0].cloudStatus === "FAILED")
    ) {
      overallProtectionState = "BACKUP_FAILED";
    }

    return {
      primaryDatabaseStatus: dbConnected ? "CONNECTED" : "DISCONNECTED",
      localBackupStatus: lastLocalSuccess
        ? historyRows[0]?.localStatus === "FAILED"
          ? "WARNING_LAST_FAILED"
          : "HEALTHY"
        : "NO_BACKUP_YET",
      cloudBackupStatus: lastCloudSuccess
        ? historyRows[0]?.cloudStatus === "FAILED"
          ? "WARNING_LAST_FAILED"
          : "SYNCHRONIZED"
        : "PENDING_FIRST_UPLOAD",
      overallProtectionState,
      lastSuccessfulBackupAt:
        lastLocalSuccess?.createdAt?.toISOString() || null,
      lastSuccessfulCloudSyncAt:
        lastCloudSuccess?.createdAt?.toISOString() || null,
      lastSuccessfulRestoreTestAt:
        lastVerifiedRestore?.verifiedAt?.toISOString() || null,
      lastVerifiedBackupId: lastVerifiedRestore?.backupId || null,
      retainedValidBackupsCount: validRetainedCount,
      retentionPruneFailuresCount: this.lastRetentionPruneFailures,
      pendingSyncJobsCount: pendingOutboxCount,
      failedSyncJobsCount: failedOutboxCount,
      latestBackupError: latestFailure?.lastError
        ? this.redactSensitiveError(latestFailure.lastError)
        : outboxRows.find((o) => o.lastError)?.lastError || null,
      environment: envReport,
      recentBackups: historyRows.slice(0, 10),
    };
  }

  /**
   * Fix #98: Determine retention tier using Asia/Muscat date and tag MONTHLY/WEEKLY
   * only on the first scheduled backup of that Muscat calendar day.
   */
  private static determineMuscatRetentionTier(): "DAILY" | "WEEKLY" | "MONTHLY" {
    const muscatDateStr = getMuscatTodayString(); // YYYY-MM-DD in Asia/Muscat
    const [y, m, d] = muscatDateStr.split("-").map(Number);
    const muscatUtcMidnight = new Date(Date.UTC(y, m - 1, d));
    const dayOfMonth = d;
    const dayOfWeek = muscatUtcMidnight.getUTCDay(); // 0 = Sunday

    const existingToday = this.listBackups().some((b) => {
      const bMuscatDate = getMuscatTodayString(new Date(b.createdAt));
      return (
        bMuscatDate === muscatDateStr &&
        (b.retentionTier === "MONTHLY" || b.retentionTier === "WEEKLY")
      );
    });
    if (existingToday) {
      return "DAILY";
    }
    if (dayOfMonth === 1) {
      return "MONTHLY";
    }
    if (dayOfWeek === 0) {
      return "WEEKLY";
    }
    return "DAILY";
  }

  static initBackupSchedule() {
    for (const task of this.scheduledTasks) {
      try {
        task.stop();
      } catch {
        // Ignore stop error
      }
    }
    this.scheduledTasks = [];

    this.applyRetentionPolicy().catch((err) => {
      logger.warn({ err }, "Initial backup retention check warning");
    });

    const fullBackupCron = process.env.BACKUP_SCHEDULE_CRON || "0 */6 * * *";
    const outboxSyncCron = "*/5 * * * *";
    const dailyIntegrityCron = "30 2 * * *";

    this.scheduledTasks.push(
      cron.schedule(fullBackupCron, async () => {
        const lockClient = await pool.connect();
        let locked = false;
        try {
          const lockRes = await lockClient.query<{ locked?: boolean }>(
            "SELECT pg_try_advisory_lock($1) AS locked",
            [ADVISORY_LOCK_KEY + 1],
          );
          locked = Boolean(lockRes.rows[0]?.locked);
          if (!locked) return;

          const snap = await this.createBackupSnapshot(
            "Scheduled Backup Cron",
            {
              triggerType: "SCHEDULED",
              retentionTier: this.determineMuscatRetentionTier(),
            },
          );
          await this.testIsolatedRestore(
            snap.manifest.backupId,
            "Scheduled Integrity Verifier",
          );
        } catch (err) {
          logger.warn(
            { err: this.redactSensitiveError(err) },
            "Scheduled backup notice",
          );
        } finally {
          if (locked) {
            try {
              await lockClient.query("SELECT pg_advisory_unlock($1)", [
                ADVISORY_LOCK_KEY + 1,
              ]);
            } catch {
              // Ignore unlock error
            }
          }
          lockClient.release();
        }
      }),
    );

    this.scheduledTasks.push(
      cron.schedule(outboxSyncCron, async () => {
        try {
          await this.processPendingSyncJobs();
        } catch (err) {
          logger.warn({ err }, "Outbox sync cron notice");
        }
      }),
    );

    this.scheduledTasks.push(
      cron.schedule(dailyIntegrityCron, async () => {
        try {
          const backups = this.listBackups();
          if (backups.length > 0) {
            await this.testIsolatedRestore(
              backups[0].backupId,
              "Daily Recovery Verifier",
            );
          }
        } catch (err) {
          logger.warn({ err }, "Daily integrity verification cron notice");
        }
      }),
    );
  }
}
