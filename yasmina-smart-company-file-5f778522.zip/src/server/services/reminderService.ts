import crypto from "crypto";
import cron, { type ScheduledTask } from "node-cron";
import { and, eq, inArray, isNotNull, isNull, like, or, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { companies, customerDocuments, customers, reminderRules, whatsappOutbox } from "../../db/schema.js";
import {
  AFTER_EXPIRY_MAX_REMINDERS,
  AFTER_EXPIRY_REPEAT_DAYS,
  DOC_TYPES,
  toDocTypeCode,
  type DocTypeCode,
} from "../../lib/documentTypes.js";
import { getMuscatTodayString } from "./expiryClassification.js";
import { loadStaffPhones } from "./documentMatchingService.js";
import { normalizePhoneDigits, phonesMatch } from "./whatsappDocumentProcessor.js";
import { logger } from "../logger.js";

/**
 * Expiry reminders over WhatsApp. A reminder is a row in whatsapp_outbox (retries and idempotency already there).
 *  - Staff numbers (tenant_settings.reminder_staff_phones) get reminders by default.
 *  - The client only gets one with company opt-in + recorded consent, and never for a document that needs review.
 *  - Messages use fixed templates: no text from the document is ever put into an outgoing message.
 *  - Quiet hours 09:00 to 20:00 Asia/Muscat, Friday before 14:00 excluded. Max 20 messages per minute per
 *    instance and 3 per client phone per day.
 */
export const REMINDER_CATEGORY_STAFF = "EXPIRY_REMINDER_STAFF";
export const REMINDER_CATEGORY_CLIENT = "EXPIRY_REMINDER_CLIENT";
export const QUIET_HOURS = { startHour: 9, endHour: 20, fridayStartHour: 14 } as const;
export const MAX_PER_MINUTE = 20;
export const MAX_CLIENT_PER_DAY = 3;
const MAX_ATTEMPTS = 5;
const MUSCAT_OFFSET_MS = 4 * 3600_000;

export type SendFn = (phoneDigits: string, text: string) => Promise<void>;

async function defaultSend(phoneDigits: string, text: string): Promise<void> {
  const { whatsAppService } = await import("./whatsappService.js");
  await whatsAppService.sendManualMessage(`chat-${phoneDigits}`, text);
}

/** True when `now` is inside the allowed sending window in Muscat. */
export function isWithinSendingWindow(now: Date): boolean {
  const m = new Date(now.getTime() + MUSCAT_OFFSET_MS); // read UTC fields of the shifted date = Muscat wall clock
  const hour = m.getUTCHours();
  const isFriday = m.getUTCDay() === 5;
  const start = isFriday ? QUIET_HOURS.fridayStartHour : QUIET_HOURS.startHour;
  return hour >= start && hour < QUIET_HOURS.endHour;
}

function daysBetween(fromIso: string, toIso: string): number {
  return Math.round((Date.parse(toIso) - Date.parse(fromIso)) / 86400_000);
}

export function pickReminderOffset(daysRemaining: number, offsets: number[]): string | null {
  if (daysRemaining >= 0) {
    const candidates = offsets.filter((o) => o >= daysRemaining);
    if (candidates.length === 0) return null;
    return String(Math.min(...candidates));
  }
  const n = Math.min(AFTER_EXPIRY_MAX_REMINDERS, Math.floor(-daysRemaining / AFTER_EXPIRY_REPEAT_DAYS));
  return n >= 1 ? `after${n}` : null;
}

function staffMessage(p: { companyName: string; labelAr: string; expiryDate: string; days: number }): string {
  const when =
    p.days > 0 ? `بعد ${p.days} يوم` : p.days === 0 ? "اليوم" : `منذ ${-p.days} يوم`;
  return [
    "تذكير بانتهاء وثيقة",
    `الشركة: ${p.companyName}`,
    `الوثيقة: ${p.labelAr}`,
    `تاريخ الانتهاء: ${p.expiryDate} (${when})`,
    "يرجى التجديد في الوقت المناسب.",
  ].join("\n");
}

function clientMessage(p: { companyName: string; labelAr: string; expiryDate: string; days: number }): string {
  const when = p.days >= 0 ? `ستنتهي بتاريخ ${p.expiryDate}` : `انتهت بتاريخ ${p.expiryDate}`;
  return [
    `مرحباً، نذكّركم بأن وثيقة (${p.labelAr}) الخاصة بـ ${p.companyName} ${when}.`,
    "للتجديد تواصلوا معنا. لإيقاف هذه التذكيرات أرسلوا: ايقاف",
  ].join("\n");
}

function phoneTail(p: string): string {
  return normalizePhoneDigits(p).slice(-8);
}

async function loadRules(tenantId: string) {
  const stored = await db.select().from(reminderRules).where(eq(reminderRules.tenantId, tenantId));
  const byCode = new Map(stored.map((r) => [r.docTypeCode, r]));
  return (code: DocTypeCode) => {
    const r = byCode.get(code);
    if (!r) return { offsets: DOC_TYPES[code].defaultReminderOffsets, notifyStaff: true, notifyClient: false, active: DOC_TYPES[code].hasExpiry };
    return { offsets: JSON.parse(r.offsetsDaysJson) as number[], notifyStaff: r.notifyStaff, notifyClient: r.notifyClient, active: r.active };
  };
}

async function enqueue(row: {
  tenantId: string;
  documentId: number;
  key: string;
  phone: string;
  category: string;
  text: string;
}): Promise<boolean> {
  const digits = normalizePhoneDigits(row.phone);
  if (digits.length < 7) return false;
  const res = await db
    .insert(whatsappOutbox)
    .values({
      outboxId: `outbox_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`,
      idempotencyKey: row.key,
      correlationId: `reminder_${row.documentId}`,
      tenantId: row.tenantId,
      jobId: `doc:${row.documentId}`,
      recipientPhone: digits,
      recipientJid: `${digits}@s.whatsapp.net`,
      replyCategory: row.category,
      messageText: row.text,
      status: "PENDING",
    })
    .onConflictDoNothing()
    .returning({ id: whatsappOutbox.id });
  return res.length > 0;
}

export interface QueueResult {
  scanned: number;
  queuedStaff: number;
  queuedClient: number;
  alreadyQueued: number;
}

/** Queue every due reminder exactly once (idempotency key reminder:{documentId}:{offset}:{audience}:{phone}). */
export async function queueDueReminders(params: { tenantId: string; referenceDate?: string; now?: Date }): Promise<QueueResult> {
  const { tenantId } = params;
  const today = getMuscatTodayString(params.referenceDate || params.now);
  const rules = await loadRules(tenantId);
  const staffPhones = await loadStaffPhones(tenantId);

  const docs = await db
    .select()
    .from(customerDocuments)
    .where(
      and(
        eq(customerDocuments.tenantId, tenantId),
        isNotNull(customerDocuments.companyId),
        isNotNull(customerDocuments.expiryDate),
        eq(customerDocuments.hasNoExpiry, false),
        isNull(customerDocuments.deletedAt)
      )
    );
  // Only the latest version of a document is reminded: a renewal supersedes the old one.
  const supersededIds = new Set(docs.map((d) => d.previousVersionId).filter((x): x is number => Boolean(x)));
  const compRows = await db.select().from(companies).where(and(eq(companies.tenantId, tenantId), isNull(companies.deletedAt)));
  const compById = new Map(compRows.map((c) => [c.id, c]));
  const custRows = await db.select().from(customers).where(eq(customers.tenantId, tenantId));
  const custById = new Map(custRows.map((c) => [c.id, c]));

  const out: QueueResult = { scanned: 0, queuedStaff: 0, queuedClient: 0, alreadyQueued: 0 };
  for (const d of docs) {
    if (supersededIds.has(d.id)) continue;
    const company = compById.get(d.companyId!);
    if (!company) continue;
    const code = (d.docTypeCode as DocTypeCode | null) || toDocTypeCode(d.docType);
    const rule = rules(code);
    if (!rule.active || !DOC_TYPES[code].hasExpiry) continue;
    out.scanned++;
    const days = daysBetween(today, d.expiryDate!);
    const offsetKey = pickReminderOffset(days, rule.offsets);
    if (offsetKey === null) continue;

    const p = { companyName: company.name, labelAr: DOC_TYPES[code].labelAr, expiryDate: d.expiryDate!, days };
    const tally = (ok: boolean, kind: "Staff" | "Client") => {
      if (ok) kind === "Staff" ? out.queuedStaff++ : out.queuedClient++;
      else out.alreadyQueued++;
    };
    if (rule.notifyStaff) {
      for (const phone of staffPhones) {
        const ok = await enqueue({
          tenantId,
          documentId: d.id,
          key: `reminder:${d.id}:${offsetKey}:staff:${phoneTail(phone)}`,
          phone,
          category: REMINDER_CATEGORY_STAFF,
          text: staffMessage(p),
        });
        tally(ok, "Staff");
      }
    }
    // Client reminders: opt-in per company + recorded consent + document not flagged for review.
    if (rule.notifyClient && company.clientRemindersEnabled && company.clientReminderConsentAt && !d.needsReview) {
      const owner = company.ownerCustomerId ? custById.get(company.ownerCustomerId) : null;
      const clientPhone = company.contactPhone || owner?.whatsapp || owner?.phone || "";
      if (clientPhone) {
        const ok = await enqueue({
          tenantId,
          documentId: d.id,
          key: `reminder:${d.id}:${offsetKey}:client:${phoneTail(clientPhone)}`,
          phone: clientPhone,
          category: REMINDER_CATEGORY_CLIENT,
          text: clientMessage(p),
        });
        tally(ok, "Client");
      }
    }
  }
  return out;
}

/** Cancel reminders still waiting for a document that has just been superseded by a renewed version. */
export async function cancelPendingReminders(tenantId: string, oldDocumentId: number, exec: any = db): Promise<number> {
  const res = await exec
    .update(whatsappOutbox)
    .set({ status: "CANCELED", lastError: "SUPERSEDED_BY_NEW_VERSION", updatedAt: new Date() })
    .where(
      and(
        eq(whatsappOutbox.tenantId, tenantId),
        eq(whatsappOutbox.jobId, `doc:${oldDocumentId}`),
        inArray(whatsappOutbox.status, ["PENDING", "RETRY_PENDING"]),
        like(whatsappOutbox.replyCategory, "EXPIRY_REMINDER%")
      )
    )
    .returning({ id: whatsappOutbox.id });
  return res.length;
}

export interface FlushResult {
  sent: number;
  held: number;
  failed: number;
  canceled: number;
  rateLimited: number;
  inWindow: boolean;
}

/** Send queued reminders. Outside quiet hours nothing is sent; messages simply wait for the next window. */
export async function flushReminderOutbox(params: { tenantId?: string; now?: Date; sendFn?: SendFn } = {}): Promise<FlushResult> {
  const now = params.now || new Date();
  const send = params.sendFn || defaultSend;
  const res: FlushResult = { sent: 0, held: 0, failed: 0, canceled: 0, rateLimited: 0, inWindow: isWithinSendingWindow(now) };

  const pending = await db
    .select()
    .from(whatsappOutbox)
    .where(
      and(
        inArray(whatsappOutbox.status, ["PENDING", "RETRY_PENDING"]),
        or(eq(whatsappOutbox.replyCategory, REMINDER_CATEGORY_STAFF), eq(whatsappOutbox.replyCategory, REMINDER_CATEGORY_CLIENT)),
        ...(params.tenantId ? [eq(whatsappOutbox.tenantId, params.tenantId)] : [])
      )
    )
    .orderBy(whatsappOutbox.id);
  if (pending.length === 0) return res;
  if (!res.inWindow) {
    res.held = pending.length;
    return res;
  }

  // Re-validate each reminder right before sending: the document may have been renewed, deleted or flagged since.
  const docIds = [...new Set(pending.map((p) => Number(String(p.jobId || "").replace("doc:", ""))).filter(Boolean))];
  const docs = docIds.length ? await db.select().from(customerDocuments).where(inArray(customerDocuments.id, docIds)) : [];
  const docById = new Map(docs.map((d) => [d.id, d]));
  const superseded = new Set(
    docs.length
      ? (
          await db
            .select({ prev: customerDocuments.previousVersionId })
            .from(customerDocuments)
            .where(and(isNotNull(customerDocuments.previousVersionId), isNull(customerDocuments.deletedAt)))
        ).map((r) => r.prev)
      : []
  );
  const dayStart = new Date(Math.floor((now.getTime() + MUSCAT_OFFSET_MS) / 86400_000) * 86400_000 - MUSCAT_OFFSET_MS);
  const sentToday = await db
    .select({ phone: whatsappOutbox.recipientPhone })
    .from(whatsappOutbox)
    .where(and(eq(whatsappOutbox.replyCategory, REMINDER_CATEGORY_CLIENT), eq(whatsappOutbox.status, "SENT"), sql`${whatsappOutbox.sentAt} >= ${dayStart}`));
  const clientCount = new Map<string, number>();
  for (const r of sentToday) clientCount.set(r.phone, (clientCount.get(r.phone) || 0) + 1);

  let sentThisMinute = 0;
  for (const row of pending) {
    const docId = Number(String(row.jobId || "").replace("doc:", ""));
    const doc = docById.get(docId);
    const stale = !doc || doc.deletedAt || !doc.companyId || superseded.has(docId);
    if (stale) {
      await db.update(whatsappOutbox).set({ status: "CANCELED", lastError: "DOCUMENT_NO_LONGER_ACTIVE", updatedAt: now }).where(eq(whatsappOutbox.id, row.id));
      res.canceled++;
      continue;
    }
    if (row.replyCategory === REMINDER_CATEGORY_CLIENT) {
      const [company] = await db.select().from(companies).where(eq(companies.id, doc.companyId!)).limit(1);
      if (!company?.clientRemindersEnabled || !company.clientReminderConsentAt || doc.needsReview) {
        await db.update(whatsappOutbox).set({ status: "CANCELED", lastError: "NO_CLIENT_CONSENT_OR_NEEDS_REVIEW", updatedAt: now }).where(eq(whatsappOutbox.id, row.id));
        res.canceled++;
        continue;
      }
      if ((clientCount.get(row.recipientPhone) || 0) >= MAX_CLIENT_PER_DAY) {
        res.held++;
        continue;
      }
    }
    if (sentThisMinute >= MAX_PER_MINUTE) {
      res.rateLimited++;
      continue;
    }
    try {
      await send(row.recipientPhone, row.messageText);
      sentThisMinute++;
      if (row.replyCategory === REMINDER_CATEGORY_CLIENT) clientCount.set(row.recipientPhone, (clientCount.get(row.recipientPhone) || 0) + 1);
      await db
        .update(whatsappOutbox)
        .set({ status: "SENT", deliveryAttempts: (row.deliveryAttempts || 0) + 1, sentAt: now, updatedAt: now, lastError: null })
        .where(eq(whatsappOutbox.id, row.id));
      res.sent++;
    } catch (err) {
      const attempts = (row.deliveryAttempts || 0) + 1;
      await db
        .update(whatsappOutbox)
        .set({ status: attempts >= MAX_ATTEMPTS ? "FAILED" : "RETRY_PENDING", deliveryAttempts: attempts, lastError: String((err as Error)?.message || err).slice(0, 300), updatedAt: now })
        .where(eq(whatsappOutbox.id, row.id));
      res.failed++;
    }
  }
  return res;
}

/** One full cycle: queue what is due, then try to send. */
export async function runReminderCycle(params: { tenantId?: string; referenceDate?: string; now?: Date; sendFn?: SendFn } = {}) {
  const tenants = params.tenantId
    ? [params.tenantId]
    : (await db.selectDistinct({ t: customerDocuments.tenantId }).from(customerDocuments)).map((r) => r.t);
  const queued: QueueResult[] = [];
  for (const t of tenants) queued.push(await queueDueReminders({ tenantId: t, referenceDate: params.referenceDate, now: params.now }));
  const flush = await flushReminderOutbox({ tenantId: params.tenantId, now: params.now, sendFn: params.sendFn });
  return {
    queued: queued.reduce(
      (a, q) => ({ scanned: a.scanned + q.scanned, queuedStaff: a.queuedStaff + q.queuedStaff, queuedClient: a.queuedClient + q.queuedClient, alreadyQueued: a.alreadyQueued + q.alreadyQueued }),
      { scanned: 0, queuedStaff: 0, queuedClient: 0, alreadyQueued: 0 }
    ),
    flush,
  };
}

const STOP_WORDS = new Set(["stop", "unsubscribe", "ايقاف", "إيقاف", "ايقاف التذكيرات", "توقف", "الغاء الاشتراك", "إلغاء الاشتراك"]);

export function isStopKeyword(text: string | null | undefined): boolean {
  const t = String(text || "").trim().toLowerCase().replace(/[.!؟?]+$/g, "");
  return STOP_WORDS.has(t);
}

/** A client replying "stop" / "ايقاف" clears client-reminder consent immediately. Returns affected company ids. */
export async function handleReminderStopKeyword(tenantId: string, senderPhone: string, text: string | null | undefined): Promise<number[]> {
  if (!isStopKeyword(text) || !senderPhone) return [];
  const comps = await db
    .select()
    .from(companies)
    .where(and(eq(companies.tenantId, tenantId), eq(companies.clientRemindersEnabled, true)));
  const custs = await db.select().from(customers).where(eq(customers.tenantId, tenantId));
  const custById = new Map(custs.map((c) => [c.id, c]));
  const hit = comps.filter((c) => {
    const owner = c.ownerCustomerId ? custById.get(c.ownerCustomerId) : null;
    return phonesMatch(senderPhone, c.contactPhone) || (owner && (phonesMatch(senderPhone, owner.phone) || phonesMatch(senderPhone, owner.whatsapp)));
  });
  for (const c of hit) {
    await db.update(companies).set({ clientRemindersEnabled: false, clientReminderConsentAt: null, updatedAt: new Date() }).where(eq(companies.id, c.id));
    await db
      .update(whatsappOutbox)
      .set({ status: "CANCELED", lastError: "CLIENT_OPTED_OUT", updatedAt: new Date() })
      .where(and(eq(whatsappOutbox.tenantId, tenantId), eq(whatsappOutbox.replyCategory, REMINDER_CATEGORY_CLIENT), inArray(whatsappOutbox.status, ["PENDING", "RETRY_PENDING"]), eq(whatsappOutbox.recipientPhone, normalizePhoneDigits(c.contactPhone || senderPhone))));
  }
  return hit.map((c) => c.id);
}

let dailyTask: ScheduledTask | null = null;
let flushTask: ScheduledTask | null = null;

/** Daily 08:30 Muscat: queue reminders (after the 08:00 expiry audit). Every minute: flush within the sending window. */
export function startReminderDispatcher() {
  for (const t of [dailyTask, flushTask]) {
    try {
      t?.stop();
    } catch {
      /* ignore */
    }
  }
  dailyTask = cron.schedule(
    "30 8 * * *",
    () => {
      runReminderCycle().catch((err) => logger.error({ err }, "[Reminders] daily cycle failed"));
    },
    { timezone: "Asia/Muscat" }
  );
  flushTask = cron.schedule("* * * * *", () => {
    flushReminderOutbox().catch((err) => logger.error({ err }, "[Reminders] flush failed"));
  });
  logger.info("[Reminders] Dispatcher scheduled (daily queue 08:30 Asia/Muscat, outbox flush every minute inside 09:00-20:00).");
}
