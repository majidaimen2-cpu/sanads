import { normalizeAndValidateDate, normalizeDigitsToAscii, normalizeCrNumber } from "../../crExtractionService.js";
import type { FieldMeta, TypedExtraction } from "./types.js";

export function ascii(text: string): string {
  return normalizeDigitsToAscii(text || "");
}

export function pick(text: string, re: RegExp): string | null {
  const m = text.match(re);
  if (!m || !m[1]) return null;
  const v = m[1].replace(/\s+/g, " ").trim();
  return v.length ? v : null;
}

const DATE = String.raw`(\d{1,4}[\/\-.]\d{1,2}[\/\-.]\d{1,4})`;

export function pickDate(text: string, labels: string): string | null {
  const m = ascii(text).match(new RegExp(`(?:${labels})\\s*[:\\-]?\\s*${DATE}`, "i"));
  return m ? normalizeAndValidateDate(m[1]) : null;
}

export function pickPrintedCr(text: string): string | null {
  const m = ascii(text).match(
    /(?:رقم\s*السجل\s*التجاري|السجل\s*التجاري\s*رقم|C\.?\s*R\.?\s*(?:No\.?|Number|#)|Commercial\s*Registration\s*(?:No\.?|Number|#))\s*[:\-]?\s*((?:CR[\s\-:/]*)?\d{5,10})/i,
  );
  if (!m) return null;
  const n = normalizeCrNumber(m[1]);
  return /^\d{5,10}$/.test(n) ? n : null;
}

export function meta(method: FieldMeta["method"], confidence: number): FieldMeta {
  return { method, confidence };
}

/** Chronology check shared by all extractors: expiry after issue and not absurdly far in the future. */
export function validateDates(out: TypedExtraction, today = new Date()): void {
  const { issueDate, expiryDate } = out;
  if (issueDate && expiryDate && expiryDate < issueDate) {
    out.needsReview = true;
    out.reviewReasons.push("EXPIRY_BEFORE_ISSUE");
  }
  if (expiryDate) {
    const limit = new Date(today.getTime());
    limit.setUTCFullYear(limit.getUTCFullYear() + 25);
    if (expiryDate > limit.toISOString().slice(0, 10)) {
      out.needsReview = true;
      out.reviewReasons.push("EXPIRY_TOO_FAR");
    }
  }
}

export function emptyExtraction(type: TypedExtraction["type"]): TypedExtraction {
  return { type, fields: {}, fieldMeta: {}, issueDate: null, expiryDate: null, needsReview: false, reviewReasons: [] };
}
