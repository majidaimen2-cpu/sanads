import type { DocumentExtractor, TypedExtraction } from "./types.js";
import { ascii, emptyExtraction, meta, pick, pickDate, pickPrintedCr, validateDates } from "./common.js";

export const residenceCardExtractor: DocumentExtractor = {
  type: "RESIDENCE_CARD",
  detect(text) {
    const t = ascii(text);
    let score = 0;
    if (/بطاقة\s*(?:ال)?إقامة|بطاقة\s*(?:ال)?اقامة|Resident\s*Card|Residence\s*(?:Card|Permit)|Resident\s*ID/i.test(t)) score += 70;
    if (/شرطة\s*عمان\s*السلطانية|Royal\s*Oman\s*Police/i.test(t)) score += 15;
    if (/(?:الرقم\s*المدني|Civil\s*(?:No|Number))/i.test(t)) score += 10;
    return Math.min(100, score);
  },
  extract(text) {
    const out: TypedExtraction = emptyExtraction("RESIDENCE_CARD");
    const t = ascii(text);
    const fullName = pick(t, /(?:اسم\s*حامل\s*البطاقة|الاسم|Name)\s*[:\-]?\s*([^\r\n|]{3,80})/i);
    const civilNumber = pick(t, /(?:الرقم\s*المدني|Civil\s*(?:No\.?|Number)|Civil\s*ID)\s*[:\-]?\s*(\d{6,12})/i);
    const nationality = pick(t, /(?:الجنسية|Nationality)\s*[:\-]?\s*([^\r\n|]{2,40})/i);
    const employer = pick(t, /(?:جهة\s*العمل|صاحب\s*العمل|الكفيل|Employer|Sponsor)\s*[:\-]?\s*([^\r\n|]{3,90})/i);
    out.issueDate = pickDate(t, "تاريخ\\s*الإصدار|تاريخ\\s*الاصدار|Issue\\s*Date|Date\\s*of\\s*Issue");
    out.expiryDate = pickDate(t, "تاريخ\\s*الانتهاء|تاريخ\\s*انتهاء\\s*الإقامة|ينتهي\\s*في|Expiry\\s*Date|Valid\\s*Until|Date\\s*of\\s*Expiry");
    out.fields = { fullName, civilNumber, nationality, employer };
    for (const [k, v] of Object.entries(out.fields)) if (v) out.fieldMeta[k] = meta("regex", 70);
    if (out.issueDate) out.fieldMeta.issueDate = meta("regex", 70);
    if (out.expiryDate) out.fieldMeta.expiryDate = meta("regex", 70);
    out.person = { fullName, civilNumber, passportNumber: null, nationality };
    out.relatedCompanyName = employer;
    out.printedCrNumber = pickPrintedCr(t);
    if (!out.expiryDate) {
      out.needsReview = true;
      out.reviewReasons.push("EXPIRY_MISSING");
    }
    if (!civilNumber) {
      out.needsReview = true;
      out.reviewReasons.push("CIVIL_NUMBER_MISSING");
    }
    validateDates(out);
    return out;
  },
};
