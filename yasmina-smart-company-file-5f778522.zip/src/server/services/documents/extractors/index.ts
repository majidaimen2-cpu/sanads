import type { DocTypeCode } from "../../../../lib/documentTypes.js";
import type { DocumentExtractor, TypedExtraction } from "./types.js";
import { passportExtractor } from "./passport.js";
import { residenceCardExtractor } from "./residenceCard.js";
import { leaseContractExtractor } from "./leaseContract.js";

export type { DocumentExtractor, TypedExtraction, PersonFields, FieldMeta } from "./types.js";
export { parseMrzTd3, mrzCheckDigit } from "./passport.js";

/**
 * Extractors for the document types added by the Smart Company File feature.
 * CR, municipal license, tax card, chamber and labor documents keep using the existing
 * extractDocumentIntelligence() fields (whatsappDocumentProcessor), which already handle them.
 */
export const EXTRACTORS: Partial<Record<DocTypeCode, DocumentExtractor>> = {
  PASSPORT: passportExtractor,
  RESIDENCE_CARD: residenceCardExtractor,
  LEASE_CONTRACT: leaseContractExtractor,
};

/** Best new-type detection over the registry. Returns null when nothing is a clear hit (>= 70). */
export function detectNewDocumentType(text: string): { type: DocTypeCode; score: number } | null {
  let best: { type: DocTypeCode; score: number } | null = null;
  for (const ex of Object.values(EXTRACTORS)) {
    if (!ex) continue;
    const score = ex.detect(text);
    if (score >= 70 && (!best || score > best.score)) best = { type: ex.type, score };
  }
  return best;
}

export function extractTyped(type: DocTypeCode, text: string): TypedExtraction | null {
  const ex = EXTRACTORS[type];
  return ex ? ex.extract(text) : null;
}
