import type { DocumentExtractor, TypedExtraction } from "./types.js";
import { ascii, emptyExtraction, meta, pick, pickDate, pickPrintedCr, validateDates } from "./common.js";

export const leaseContractExtractor: DocumentExtractor = {
  type: "LEASE_CONTRACT",
  detect(text) {
    const t = ascii(text);
    let score = 0;
    if (/عقد\s*(?:إيجار|ايجار)|Lease\s*(?:Agreement|Contract)|Tenancy\s*(?:Agreement|Contract)/i.test(t)) score += 75;
    if (/المؤجر|المستأجر|Landlord|Lessor|Tenant|Lessee/i.test(t)) score += 15;
    return Math.min(100, score);
  },
  extract(text) {
    const out: TypedExtraction = emptyExtraction("LEASE_CONTRACT");
    const t = ascii(text);
    const landlord = pick(t, /(?:المؤجر|Landlord|Lessor)\s*[:\-]?\s*([^\r\n|]{3,90})/i);
    const tenant = pick(t, /(?:المستأجر|Tenant|Lessee)\s*[:\-]?\s*([^\r\n|]{3,90})/i);
    const property = pick(t, /(?:العقار|الوحدة|موقع\s*العقار|Property|Unit|Premises)\s*[:\-]?\s*([^\r\n|]{2,90})/i);
    const rentRaw = pick(t, /(?:الإيجار\s*السنوي|قيمة\s*الإيجار\s*السنوي|Annual\s*Rent)\s*[:\-]?\s*([\d.,]+)/i);
    const annualRentOmr = rentRaw ? Number(rentRaw.replace(/,/g, "")) : NaN;
    out.issueDate = pickDate(t, "تاريخ\\s*بداية\\s*العقد|بداية\\s*العقد|تاريخ\\s*البداية|Start\\s*Date|Commencement\\s*Date");
    out.expiryDate = pickDate(t, "تاريخ\\s*نهاية\\s*العقد|نهاية\\s*العقد|تاريخ\\s*انتهاء\\s*العقد|End\\s*Date|Expiry\\s*Date");
    out.fields = {
      landlord,
      tenant,
      property,
      annualRentOmr: Number.isFinite(annualRentOmr) ? annualRentOmr : null,
    };
    for (const [k, v] of Object.entries(out.fields)) if (v !== null) out.fieldMeta[k] = meta("regex", 65);
    if (out.issueDate) out.fieldMeta.startDate = meta("regex", 70);
    if (out.expiryDate) out.fieldMeta.endDate = meta("regex", 70);
    out.relatedCompanyName = tenant;
    out.printedCrNumber = pickPrintedCr(t);
    if (!out.expiryDate) {
      out.needsReview = true;
      out.reviewReasons.push("EXPIRY_MISSING");
    }
    validateDates(out);
    return out;
  },
};
