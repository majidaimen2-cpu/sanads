import type { DocTypeCode } from "../../../../lib/documentTypes.js";

export type FieldMethod = "regex" | "mrz" | "gemini" | "manual";

export interface FieldMeta {
  method: FieldMethod;
  confidence: number; // 0..100
}

export interface PersonFields {
  fullName: string | null;
  civilNumber: string | null;
  passportNumber: string | null;
  nationality: string | null;
}

export interface TypedExtraction {
  type: DocTypeCode;
  fields: Record<string, string | number | null>;
  fieldMeta: Record<string, FieldMeta>;
  issueDate: string | null;
  expiryDate: string | null;
  needsReview: boolean;
  reviewReasons: string[];
  person?: PersonFields;
  /** Employer / sponsor / tenant company name printed on the document, used as a soft match signal. */
  relatedCompanyName?: string | null;
  /** CR number printed on the document, if any (hard identifier, also used for conflict checks). */
  printedCrNumber?: string | null;
}

export interface DocumentExtractor {
  type: DocTypeCode;
  /** 0..100: how strongly this text looks like this document type. */
  detect(text: string): number;
  /** Deterministic extraction. Never throws, never invents values. */
  extract(text: string): TypedExtraction;
}
