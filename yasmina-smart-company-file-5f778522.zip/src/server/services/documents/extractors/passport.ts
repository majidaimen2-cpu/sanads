import type { DocumentExtractor, TypedExtraction } from "./types.js";
import { ascii, emptyExtraction, meta, pick, pickDate, validateDates } from "./common.js";

const WEIGHTS = [7, 3, 1];
function charValue(c: string): number {
  if (c >= "0" && c <= "9") return c.charCodeAt(0) - 48;
  if (c >= "A" && c <= "Z") return c.charCodeAt(0) - 55;
  return 0; // '<'
}
export function mrzCheckDigit(field: string): number {
  let sum = 0;
  for (let i = 0; i < field.length; i++) sum += charValue(field[i]) * WEIGHTS[i % 3];
  return sum % 10;
}

function yymmddToIso(yymmdd: string, kind: "expiry" | "birth"): string | null {
  if (!/^\d{6}$/.test(yymmdd)) return null;
  const yy = parseInt(yymmdd.slice(0, 2), 10);
  const mm = parseInt(yymmdd.slice(2, 4), 10);
  const dd = parseInt(yymmdd.slice(4, 6), 10);
  if (mm < 1 || mm > 12 || dd < 1 || dd > 31) return null;
  let year = 2000 + yy;
  if (kind === "birth") {
    const nowYy = new Date().getUTCFullYear() % 100;
    year = yy > nowYy ? 1900 + yy : 2000 + yy;
  }
  return `${year}-${String(mm).padStart(2, "0")}-${String(dd).padStart(2, "0")}`;
}

export interface MrzResult {
  passportNumber: string;
  nationality: string;
  surname: string;
  givenNames: string;
  expiryDate: string | null;
  birthDate: string | null;
  checksOk: boolean;
}

/** Parses a TD3 (passport) machine-readable zone. Returns null when no valid-shaped MRZ is present. */
export function parseMrzTd3(text: string): MrzResult | null {
  const lines = ascii(text)
    .toUpperCase()
    .split(/\r?\n/)
    .map((l) => l.replace(/\s+/g, ""))
    .filter((l) => l.length >= 40);
  for (let i = 0; i < lines.length - 1; i++) {
    const l1 = lines[i];
    const l2 = lines[i + 1];
    if (!/^P[<A-Z][A-Z<]{3}/.test(l1)) continue;
    const a = l1.padEnd(44, "<").slice(0, 44);
    const b = l2.padEnd(44, "<").slice(0, 44);
    if (!/^[A-Z0-9<]{44}$/.test(b)) continue;
    const names = a.slice(5).split("<<");
    const surname = (names[0] || "").replace(/</g, " ").trim();
    const givenNames = (names[1] || "").replace(/</g, " ").trim();
    const number = b.slice(0, 9);
    const numberOk = mrzCheckDigit(number) === parseInt(b[9], 10);
    const expiry = b.slice(21, 27);
    const expiryOk = mrzCheckDigit(expiry) === parseInt(b[27], 10);
    const birth = b.slice(13, 19);
    const birthOk = mrzCheckDigit(birth) === parseInt(b[19], 10);
    return {
      passportNumber: number.replace(/</g, ""),
      nationality: b.slice(10, 13).replace(/</g, ""),
      surname,
      givenNames,
      expiryDate: yymmddToIso(expiry, "expiry"),
      birthDate: yymmddToIso(birth, "birth"),
      checksOk: numberOk && expiryOk && birthOk,
    };
  }
  return null;
}

export const passportExtractor: DocumentExtractor = {
  type: "PASSPORT",
  detect(text) {
    if (parseMrzTd3(text)) return 95;
    if (/P<[A-Z]{3}/.test(ascii(text).toUpperCase())) return 85;
    if (/جواز\s*سفر|\bPassport\b/i.test(text)) return 75;
    return 0;
  },
  extract(text) {
    const out: TypedExtraction = emptyExtraction("PASSPORT");
    const t = ascii(text);
    const mrz = parseMrzTd3(text);
    let fullName: string | null = null;
    let passportNumber: string | null = null;
    let nationality: string | null = null;
    if (mrz) {
      fullName = `${mrz.givenNames} ${mrz.surname}`.trim() || null;
      passportNumber = mrz.passportNumber || null;
      nationality = mrz.nationality || null;
      out.expiryDate = mrz.expiryDate;
      out.fieldMeta.expiryDate = meta("mrz", mrz.checksOk ? 98 : 60);
      out.fieldMeta.passportNumber = meta("mrz", mrz.checksOk ? 98 : 60);
      out.fieldMeta.fullName = meta("mrz", 90);
      if (!mrz.checksOk) {
        out.needsReview = true;
        out.reviewReasons.push("MRZ_CHECKSUM_FAILED");
      }
    }
    if (!passportNumber) {
      passportNumber = pick(t, /(?:Passport\s*(?:No\.?|Number)|رقم\s*الجواز)\s*[:\-]?\s*([A-Z0-9]{6,12})/i);
      if (passportNumber) out.fieldMeta.passportNumber = meta("regex", 70);
    }
    if (!fullName) {
      fullName = pick(t, /(?:Name|الاسم)\s*[:\-]?\s*([^\r\n|]{3,80})/i);
      if (fullName) out.fieldMeta.fullName = meta("regex", 60);
    }
    if (!out.expiryDate) {
      out.expiryDate = pickDate(t, "Date\\s*of\\s*Expiry|Expiry\\s*Date|تاريخ\\s*الانتهاء|تاريخ\\s*انتهاء\\s*الجواز");
      if (out.expiryDate) out.fieldMeta.expiryDate = meta("regex", 70);
    }
    out.issueDate = pickDate(t, "Date\\s*of\\s*Issue|Issue\\s*Date|تاريخ\\s*الإصدار|تاريخ\\s*الاصدار");
    if (out.issueDate) out.fieldMeta.issueDate = meta("regex", 70);
    out.fields = { fullName, passportNumber, nationality };
    out.person = { fullName, civilNumber: null, passportNumber, nationality };
    if (!out.expiryDate) {
      out.needsReview = true;
      out.reviewReasons.push("EXPIRY_MISSING");
    }
    validateDates(out);
    return out;
  },
};
