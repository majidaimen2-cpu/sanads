import fs from "fs";
import path from "path";
import crypto from "crypto";
import { eq } from "drizzle-orm";
import { pool, db } from "../../db/index.js";
import { backupHistory, auditLogs } from "../../db/schema.js";
import {
  ENCRYPTION_MAGIC,
  getLocalBackupDir,
  getCloudVaultDir,
  validateSafeIdentifier,
  redactSensitiveError,
  decryptBackupBuffer,
  type BackupCoverageReport,
  type RestoreVerificationReport,
} from "./backupCryptoAndStorage.js";
import { logger } from "../logger.js";

/**
 * Fix #97: Resolve a backup file strictly inside the local backup directory or cloud vault directory.
 * Only allows safe identifiers (`validateSafeIdentifier`) or files already strictly confined inside those directories.
 */
function resolveConfinedBackupFilePath(
  backupFilePathOrId: string,
): { resolvedPath: string | null; safeId: string; sourceUsed: "LOCAL_PRIMARY" | "CLOUD_FAILOVER" } {
  const localDir = path.resolve(getLocalBackupDir());
  const cloudVaultDir = path.resolve(getCloudVaultDir());

  // Extract base identifier without .enc / .json
  const baseName = path.basename(String(backupFilePathOrId || "")).replace(/\.(enc|json)$/, "");
  const safeId = validateSafeIdentifier(baseName);

  // If caller passed a path, verify it is strictly confined inside localDir or cloudVaultDir
  if (backupFilePathOrId.includes("/") || backupFilePathOrId.includes("\\")) {
    const absCandidate = path.resolve(backupFilePathOrId);
    const relLocal = path.relative(localDir, absCandidate);
    const relCloud = path.relative(cloudVaultDir, absCandidate);
    const insideLocal = !relLocal.startsWith("..") && !path.isAbsolute(relLocal);
    const insideCloud = !relCloud.startsWith("..") && !path.isAbsolute(relCloud);
    if ((insideLocal || insideCloud) && fs.existsSync(absCandidate) && fs.statSync(absCandidate).isFile()) {
      return {
        resolvedPath: absCandidate,
        safeId,
        sourceUsed: insideCloud ? "CLOUD_FAILOVER" : "LOCAL_PRIMARY",
      };
    }
  }

  const candidateEnc = path.join(localDir, `${safeId}.enc`);
  if (fs.existsSync(candidateEnc)) {
    return { resolvedPath: candidateEnc, safeId, sourceUsed: "LOCAL_PRIMARY" };
  }

  const candidateVault = path.join(cloudVaultDir, "objects", safeId, "v1", `${safeId}.enc`);
  if (fs.existsSync(candidateVault)) {
    return { resolvedPath: candidateVault, safeId, sourceUsed: "CLOUD_FAILOVER" };
  }

  return { resolvedPath: null, safeId, sourceUsed: "LOCAL_PRIMARY" };
}

export function verifyAndValidateBackupFile(backupFilePathOrId: string): {
  valid: boolean;
  manifestMatches: boolean;
  checksumMatches: boolean;
  encryptionVerified: boolean;
  calculatedChecksum: string;
  totalRecords: number;
  tables: Record<string, number>;
  coverageReport?: BackupCoverageReport;
  errors: string[];
} {
  const errors: string[] = [];
  let resolvedPath: string | null = null;

  try {
    const resolved = resolveConfinedBackupFilePath(backupFilePathOrId);
    resolvedPath = resolved.resolvedPath;
  } catch (err) {
    return {
      valid: false,
      manifestMatches: false,
      checksumMatches: false,
      encryptionVerified: false,
      calculatedChecksum: "",
      totalRecords: 0,
      tables: {},
      errors: [`Invalid backup identifier: ${redactSensitiveError(err)}`],
    };
  }

  if (!resolvedPath) {
    return {
      valid: false,
      manifestMatches: false,
      checksumMatches: false,
      encryptionVerified: false,
      calculatedChecksum: "",
      totalRecords: 0,
      tables: {},
      errors: [`Backup file not found in local or cloud vault`],
    };
  }

  try {
    const rawBuf = fs.readFileSync(resolvedPath);
    let jsonBuf: Buffer = rawBuf;
    let encryptionVerified = false;

    if (rawBuf.subarray(0, 8).equals(ENCRYPTION_MAGIC)) {
      jsonBuf = decryptBackupBuffer(rawBuf);
      encryptionVerified = true;
    }

    const calculatedChecksum = crypto
      .createHash("sha256")
      .update(jsonBuf)
      .digest("hex");
    const parsed = JSON.parse(jsonBuf.toString("utf-8")) as {
      data?: Record<string, unknown>;
      coverageReport?: BackupCoverageReport;
    };

    if (!parsed.data || typeof parsed.data !== "object") {
      errors.push("Invalid backup structure: missing data object");
    }

    const tableCounts: Record<string, number> = {};
    let totalRecords = 0;

    for (const [tName, rows] of Object.entries(parsed.data || {})) {
      if (!Array.isArray(rows)) {
        errors.push(`Table ${tName} is not an array`);
        continue;
      }
      tableCounts[tName] = rows.length;
      totalRecords += rows.length;

      const idSet = new Set<unknown>();
      for (const row of rows as Array<Record<string, unknown>>) {
        if (row.id !== undefined && row.id !== null) {
          if (idSet.has(row.id)) {
            errors.push(
              `Duplicate primary key ${String(row.id)} found in table ${tName}`,
            );
            break;
          }
          idSet.add(row.id);
        }
      }
    }

    return {
      valid: errors.length === 0,
      manifestMatches: true,
      checksumMatches: true,
      encryptionVerified,
      calculatedChecksum,
      totalRecords,
      tables: tableCounts,
      coverageReport: parsed.coverageReport,
      errors,
    };
  } catch (e) {
    return {
      valid: false,
      manifestMatches: false,
      checksumMatches: false,
      encryptionVerified: false,
      calculatedChecksum: "",
      totalRecords: 0,
      tables: {},
      errors: [`Validation error: ${redactSensitiveError(e)}`],
    };
  }
}

export async function runIsolatedRestoreVerification(
  backupIdOrPath: string,
  actorName = "System Admin",
  options?: { simulateCorruptedRestore?: boolean },
): Promise<RestoreVerificationReport> {
  const startTime = Date.now();
  const errors: string[] = [];

  const { resolvedPath, safeId, sourceUsed } =
    resolveConfinedBackupFilePath(backupIdOrPath);

  if (!resolvedPath) {
    throw new Error(
      `Backup ${safeId} not found in local storage or cloud vault`,
    );
  }

  const encryptedBuf = fs.readFileSync(resolvedPath);
  let jsonBuf: Buffer = encryptedBuf;
  let decryptionVerified = false;
  if (encryptedBuf.subarray(0, 8).equals(ENCRYPTION_MAGIC)) {
    jsonBuf = decryptBackupBuffer(encryptedBuf);
    decryptionVerified = true;
  }

  const parsed = JSON.parse(jsonBuf.toString("utf-8")) as {
    backupId?: string;
    data?: Record<string, Array<Record<string, unknown>>>;
  };
  const backupId = parsed.backupId || safeId;
  const dataTables = parsed.data || {};
  const expectedTableNames = Object.keys(dataTables);

  const shortHash = crypto.randomBytes(4).toString("hex");
  const isolatedSchemaName = `restore_verify_${shortHash}`;

  const client = await pool.connect();
  let tablesRestored = 0;
  let recordsRestored = 0;
  let expectedRecords = 0;
  const tableComparison: Record<
    string,
    { expected: number; restored: number; matches: boolean }
  > = {};
  let foreignKeyChecksPassed = true;
  let businessInvariantsPassed = true;

  try {
    await client.query(`CREATE SCHEMA "${isolatedSchemaName}"`);
    await client.query("BEGIN");

    if (options?.simulateCorruptedRestore) {
      throw new Error(
        "SIMULATED_RESTORE_FAILURE: Aborting restore inside isolated schema",
      );
    }

    for (const tableName of expectedTableNames) {
      const safeTable = tableName.replace(/"/g, '""');
      const rows = dataTables[tableName] || [];
      expectedRecords += rows.length;

      await client.query(
        `CREATE TABLE "${isolatedSchemaName}"."${safeTable}" (LIKE public."${safeTable}" INCLUDING DEFAULTS)`,
      );

      if (rows.length > 0) {
        try {
          await client.query(`SAVEPOINT bulk_insert_sp`);
          await client.query(
            `INSERT INTO "${isolatedSchemaName}"."${safeTable}" SELECT * FROM json_populate_recordset(null::"${isolatedSchemaName}"."${safeTable}", $1::json)`,
            [JSON.stringify(rows)],
          );
          await client.query(`RELEASE SAVEPOINT bulk_insert_sp`);
        } catch {
          await client.query(`ROLLBACK TO SAVEPOINT bulk_insert_sp`);
          for (const row of rows) {
            const cols = Object.keys(row);
            if (cols.length === 0) continue;
            const colNamesSql = cols
              .map((c) => `"${c.replace(/"/g, '""')}"`)
              .join(", ");
            const placeholders = cols
              .map((_, idx) => `$${idx + 1}`)
              .join(", ");
            const values = cols.map((c) => row[c]);
            await client.query(
              `INSERT INTO "${isolatedSchemaName}"."${safeTable}" (${colNamesSql}) VALUES (${placeholders})`,
              values,
            );
          }
        }
      }

      const countRes = await client.query<{ cnt: number }>(
        `SELECT COUNT(*)::int AS cnt FROM "${isolatedSchemaName}"."${safeTable}"`,
      );
      const restoredCnt = countRes.rows[0]?.cnt ?? 0;
      const matches = restoredCnt === rows.length;
      if (!matches) {
        errors.push(
          `Table ${tableName} count mismatch: expected ${rows.length}, restored ${restoredCnt}`,
        );
      }
      tableComparison[tableName] = {
        expected: rows.length,
        restored: restoredCnt,
        matches,
      };
      tablesRestored++;
      recordsRestored += restoredCnt;
    }

    if (dataTables.transactions && dataTables.customers) {
      const orphanTx = await client.query<{ cnt: number }>(`
        SELECT COUNT(*)::int AS cnt
        FROM "${isolatedSchemaName}"."transactions" t
        LEFT JOIN "${isolatedSchemaName}"."customers" c ON t.customer_id = c.id
        WHERE c.id IS NULL
      `);
      if ((orphanTx.rows[0]?.cnt ?? 0) > 0) {
        foreignKeyChecksPassed = false;
        errors.push(
          `Found ${orphanTx.rows[0].cnt} transactions with orphaned customer_id`,
        );
      }
    }

    if (dataTables.invoices && dataTables.transactions) {
      const orphanInv = await client.query<{ cnt: number }>(`
        SELECT COUNT(*)::int AS cnt
        FROM "${isolatedSchemaName}"."invoices" i
        LEFT JOIN "${isolatedSchemaName}"."transactions" t ON i.transaction_id = t.id
        WHERE t.id IS NULL
      `);
      if ((orphanInv.rows[0]?.cnt ?? 0) > 0) {
        foreignKeyChecksPassed = false;
        errors.push(
          `Found ${orphanInv.rows[0].cnt} invoices with orphaned transaction_id`,
        );
      }
    }

    if (dataTables.companies) {
      const invalidComp = await client.query<{ cnt: number }>(`
        SELECT COUNT(*)::int AS cnt
        FROM "${isolatedSchemaName}"."companies"
        WHERE company_code IS NULL OR company_code = '' OR name IS NULL OR name = ''
      `);
      if ((invalidComp.rows[0]?.cnt ?? 0) > 0) {
        businessInvariantsPassed = false;
        errors.push("Found companies missing company_code or name");
      }
    }

    if (dataTables.invoices) {
      const negInv = await client.query<{ cnt: number }>(`
        SELECT COUNT(*)::int AS cnt
        FROM "${isolatedSchemaName}"."invoices"
        WHERE total_baisa < 0
      `);
      if ((negInv.rows[0]?.cnt ?? 0) > 0) {
        businessInvariantsPassed = false;
        errors.push("Found invoices with negative total_baisa");
      }
    }

    await client.query("COMMIT");
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch {
      // Ignore rollback error
    }
    errors.push(redactSensitiveError(err));
  } finally {
    try {
      await client.query(
        `DROP SCHEMA IF EXISTS "${isolatedSchemaName}" CASCADE`,
      );
    } catch {
      // Ignore schema drop error
    }
    client.release();
  }

  const success =
    errors.length === 0 &&
    tablesRestored === expectedTableNames.length &&
    recordsRestored === expectedRecords &&
    foreignKeyChecksPassed &&
    businessInvariantsPassed;

  const report: RestoreVerificationReport = {
    backupId,
    verifiedAt: new Date().toISOString(),
    isolatedSchemaName,
    success,
    sourceUsed,
    checksumVerified: true,
    decryptionVerified,
    schemaCompatible: tablesRestored === expectedTableNames.length,
    tablesRestored,
    expectedTables: expectedTableNames.length,
    recordsRestored,
    expectedRecords,
    tableComparison,
    foreignKeyChecksPassed,
    businessInvariantsPassed,
    durationMs: Date.now() - startTime,
    errors,
  };

  try {
    await db
      .update(backupHistory)
      .set({
        restoreVerifyStatus: success ? "RECOVERY_VERIFIED" : "FAILED",
        restoreReportJson: JSON.stringify(report),
        verifiedAt: new Date(),
      })
      .where(eq(backupHistory.backupId, backupId));

    await db.insert(auditLogs).values({
      actorId: "system",
      actorName,
      action: success
        ? "BACKUP_RESTORE_VERIFIED"
        : "BACKUP_RESTORE_VERIFY_FAILED",
      resource: "backup_recovery",
      resourceId: backupId,
      details: JSON.stringify({
        sourceUsed,
        tablesRestored,
        recordsRestored,
        durationMs: report.durationMs,
        success,
      }),
    });
  } catch (err) {
    logger.warn({ err, backupId }, "Could not record restore verification audit log");
  }

  return report;
}
