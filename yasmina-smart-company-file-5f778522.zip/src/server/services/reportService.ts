import { eq, and, sql, isNull, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  cashSessions,
  payments,
  expenses,
  invoices,
  companies,
  employees,
  customerDocuments,
} from "../../db/schema.js";

export async function getDailyCashReport(tenantId: string, dateStr?: string) {
  const targetDate = dateStr ? new Date(dateStr) : new Date();
  const startOfDay = new Date(
    targetDate.getFullYear(),
    targetDate.getMonth(),
    targetDate.getDate(),
  );
  const endOfDay = new Date(
    targetDate.getFullYear(),
    targetDate.getMonth(),
    targetDate.getDate(),
    23,
    59,
    59,
    999,
  );
  const sessions = await db
    .select()
    .from(cashSessions)
    .where(
      and(
        eq(cashSessions.tenantId, tenantId),
        sql`${cashSessions.openedAt} >= ${startOfDay} AND ${cashSessions.openedAt} <= ${endOfDay}`,
      ),
    );
  const paymentsSummary = await db
    .select({
      method: payments.method,
      totalAmountBaisa: sql`coalesce(sum(${payments.amountBaisa}), 0)`,
      count: sql`count(*)`,
    })
    .from(payments)
    .where(
      and(
        eq(payments.tenantId, tenantId),
        sql`${payments.createdAt} >= ${startOfDay} AND ${payments.createdAt} <= ${endOfDay}`,
      ),
    )
    .groupBy(payments.method);
  let cashTotalBaisa = 0;
  let cardTotalBaisa = 0;
  let bankTotalBaisa = 0;
  for (const p of paymentsSummary) {
    const amt = Number(p.totalAmountBaisa);
    if (p.method === "CASH") cashTotalBaisa += amt;
    else if (p.method === "CARD") cardTotalBaisa += amt;
    else bankTotalBaisa += amt;
  }
  const expensesResult = await db
    .select({
      totalExpensesBaisa: sql`coalesce(sum(${expenses.amountBaisa}), 0)`,
      count: sql`count(*)`,
    })
    .from(expenses)
    .where(
      and(
        eq(expenses.tenantId, tenantId),
        sql`${expenses.createdAt} >= ${startOfDay} AND ${expenses.createdAt} <= ${endOfDay}`,
      ),
    );
  const totalExpensesBaisa = Number(expensesResult[0]?.totalExpensesBaisa ?? 0);
  const totalOpeningBalanceBaisa = sessions.reduce(
    (sum, s) => sum + (s.openingBalanceBaisa || 0),
    0,
  );
  const totalVarianceBaisa = sessions.reduce(
    (sum, s) => sum + (s.varianceBaisa || 0),
    0,
  );
  const netCashCollectedBaisa = cashTotalBaisa - totalExpensesBaisa;
  return {
    date: startOfDay.toISOString().slice(0, 10),
    sessionsCount: sessions.length,
    sessions,
    totalOpeningBalanceBaisa,
    cashTotalBaisa,
    cardTotalBaisa,
    bankTotalBaisa,
    totalRevenueBaisa: cashTotalBaisa + cardTotalBaisa + bankTotalBaisa,
    totalExpensesBaisa,
    netCashCollectedBaisa,
    totalVarianceBaisa,
  };
}

export async function getVatSummaryReport(
  tenantId: string,
  startDate?: string,
  endDate?: string,
) {
  const conditions: SQL[] = [
    eq(invoices.tenantId, tenantId),
    isNull(invoices.deletedAt),
  ];
  if (startDate) {
    conditions.push(sql`${invoices.issuedAt} >= ${new Date(startDate)}`);
  }
  if (endDate) {
    conditions.push(sql`${invoices.issuedAt} <= ${new Date(endDate)}`);
  }
  const vatStats = await db
    .select({
      invoicesCount: sql`count(*)`,
      totalGovFeeBaisa: sql`coalesce(sum(${invoices.govFeeBaisa}), 0)`,
      totalOfficeFeeBaisa: sql`coalesce(sum(${invoices.officeFeeBaisa}), 0)`,
      totalVatBaisa: sql`coalesce(sum(${invoices.vatBaisa}), 0)`,
      totalDiscountBaisa: sql`coalesce(sum(${invoices.discountBaisa}), 0)`,
      grandTotalBaisa: sql`coalesce(sum(${invoices.totalBaisa}), 0)`,
    })
    .from(invoices)
    .where(and(...conditions));
  const stats = vatStats[0] || {
    invoicesCount: 0,
    totalGovFeeBaisa: 0,
    totalOfficeFeeBaisa: 0,
    totalVatBaisa: 0,
    totalDiscountBaisa: 0,
    grandTotalBaisa: 0,
  };
  return {
    vatRatePct: 5,
    invoicesCount: Number(stats.invoicesCount),
    totalGovFeeBaisa: Number(stats.totalGovFeeBaisa),
    totalOfficeFeeBaisa: Number(stats.totalOfficeFeeBaisa),
    totalVatBaisa: Number(stats.totalVatBaisa),
    totalDiscountBaisa: Number(stats.totalDiscountBaisa),
    grandTotalBaisa: Number(stats.grandTotalBaisa),
    period: { startDate: startDate || null, endDate: endDate || null },
  };
}

export async function getExpiringDocsReport(
  tenantId: string,
  daysAhead: number = 60,
) {
  const now = new Date();
  const future = new Date();
  future.setDate(now.getDate() + daysAhead);
  const nowIso = now.toISOString().slice(0, 10);
  const futureIso = future.toISOString().slice(0, 10);
  const expiringCompanies = await db
    .select({
      id: companies.id,
      name: companies.name,
      taxId: companies.taxId,
      crExpiryDate: companies.crExpiryDate,
      licenseExpiryDate: companies.licenseExpiryDate,
      contactPhone: companies.contactPhone,
    })
    .from(companies)
    .where(
      and(
        eq(companies.tenantId, tenantId),
        isNull(companies.deletedAt),
        sql`(${companies.crExpiryDate} BETWEEN ${nowIso} AND ${futureIso} OR ${companies.licenseExpiryDate} BETWEEN ${nowIso} AND ${futureIso})`,
      ),
    );
  const expiringEmployees = await db
    .select({
      id: employees.id,
      employeeName: employees.employeeName,
      companyId: employees.companyId,
      residenceExpiry: employees.residenceExpiry,
      passportExpiry: employees.passportExpiry,
      civilId: employees.civilId,
    })
    .from(employees)
    .where(
      and(
        eq(employees.tenantId, tenantId),
        isNull(employees.deletedAt),
        sql`(${employees.residenceExpiry} BETWEEN ${nowIso} AND ${futureIso} OR ${employees.passportExpiry} BETWEEN ${nowIso} AND ${futureIso})`,
      ),
    );
  const expiringCustomerDocs = await db
    .select({
      id: customerDocuments.id,
      customerId: customerDocuments.customerId,
      docType: customerDocuments.docType,
      docNumber: customerDocuments.docNumber,
      expiryDate: customerDocuments.expiryDate,
    })
    .from(customerDocuments)
    .where(
      and(
        eq(customerDocuments.tenantId, tenantId),
        isNull(customerDocuments.deletedAt),
        sql`${customerDocuments.expiryDate} BETWEEN ${nowIso} AND ${futureIso}`,
      ),
    );
  return {
    daysAhead,
    thresholdDate: futureIso,
    totalExpiring:
      expiringCompanies.length +
      expiringEmployees.length +
      expiringCustomerDocs.length,
    companies: expiringCompanies,
    employees: expiringEmployees,
    customerDocuments: expiringCustomerDocs,
  };
}
