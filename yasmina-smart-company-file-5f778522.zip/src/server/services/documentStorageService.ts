import crypto from "crypto";
import fs from "fs";
import path from "path";
import { logger } from "../logger.js";

export const MAX_DOCUMENT_SIZE_BYTES = 25 * 1024 * 1024; // 25 MB
export const VAULT_ROOT_DIR = path.resolve(
  process.cwd(),
  process.env.DOCUMENT_VAULT_DIR || "./data/vault/documents"
);

export interface ValidatedFileInfo {
  valid: boolean;
  detectedMimeType: string;
  extension: string;
  fileSizeBytes: number;
  sha256: string;
  sanitizedOriginalName: string;
  errorCode?: string;
  errorMessage?: string;
}

export interface StoredDocumentArtifact {
  storageObjectKey: string;
  storageUri: string;
  vaultFilePath: string;
  cloudUploaded: boolean;
  verifiedExists: boolean;
  verifiedSha256: string;
  mimeType: string;
  fileSizeBytes: number;
  sanitizedOriginalName: string;
  dataUrl: string;
}

const FORBIDDEN_EXTENSIONS = new Set([
  ".exe",
  ".dll",
  ".bat",
  ".cmd",
  ".sh",
  ".bash",
  ".ps1",
  ".vbs",
  ".js",
  ".mjs",
  ".cjs",
  ".jar",
  ".msi",
  ".com",
  ".scr",
  ".php",
  ".py",
  ".rb",
  ".pl",
]);

/**
 * Sanitizes a user-supplied filename for safe display in metadata.
 * Never used directly as a filesystem path.
 */
export function sanitizeDisplayFileName(rawName: string | undefined | null, fallbackExt = "pdf"): string {
  const base = String(rawName || `document.${fallbackExt}`)
    .replace(/\0/g, "")
    .replace(/[/\\]+/g, "_")
    .replace(/\.\.+/g, ".")
    .replace(/[<>:"|?*\x00-\x1F]/g, "_")
    .trim();
  if (!base || base === "." || base === "..") {
    return `document.${fallbackExt}`;
  }
  return base.slice(0, 180);
}

/**
 * Inspects file magic bytes to determine genuine MIME type and block malicious executables.
 */
export function validateDocumentBuffer(
  buffer: Buffer | null | undefined,
  declaredFileName?: string | null,
  declaredMimeType?: string | null
): ValidatedFileInfo {
  if (!buffer || !Buffer.isBuffer(buffer) || buffer.length === 0) {
    return {
      valid: false,
      detectedMimeType: "application/octet-stream",
      extension: "bin",
      fileSizeBytes: 0,
      sha256: "",
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "bin"),
      errorCode: "EMPTY_OR_MISSING_FILE",
      errorMessage: "الملف المرفق فارغ أو غير صالح للقراءة.",
    };
  }

  if (buffer.length > MAX_DOCUMENT_SIZE_BYTES) {
    return {
      valid: false,
      detectedMimeType: "application/octet-stream",
      extension: "bin",
      fileSizeBytes: buffer.length,
      sha256: "",
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "bin"),
      errorCode: "FILE_TOO_LARGE",
      errorMessage: `حجم الملف (${(buffer.length / (1024 * 1024)).toFixed(1)} MB) يتجاوز الحد الأقصى المسموح به (25 MB).`,
    };
  }

  const rawName = String(declaredFileName || "").toLowerCase().trim();
  const extMatch = rawName.match(/(\.[a-z0-9]{1,8})$/i);
  if (extMatch && FORBIDDEN_EXTENSIONS.has(extMatch[1].toLowerCase())) {
    return {
      valid: false,
      detectedMimeType: "application/x-msdownload",
      extension: extMatch[1].slice(1),
      fileSizeBytes: buffer.length,
      sha256: "",
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "bin"),
      errorCode: "MALICIOUS_EXTENSION_BLOCKED",
      errorMessage: "تم رفض الملف لأسباب أمنية: امتداد تنفيذي غير مسموح به.",
    };
  }

  if (buffer.length < 8) {
    return {
      valid: false,
      detectedMimeType: "application/octet-stream",
      extension: "bin",
      fileSizeBytes: buffer.length,
      sha256: "",
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "bin"),
      errorCode: "CORRUPTED_FILE_TOO_SMALL",
      errorMessage: "الملف تالف أو غير مكتمل.",
    };
  }

  // Check executable magic bytes: MZ (Windows PE), \x7FELF (Linux ELF), #! (shebang script)
  if (
    (buffer[0] === 0x4d && buffer[1] === 0x5a) ||
    (buffer[0] === 0x7f && buffer[1] === 0x45 && buffer[2] === 0x4c && buffer[3] === 0x46) ||
    (buffer[0] === 0x23 && buffer[1] === 0x21)
  ) {
    return {
      valid: false,
      detectedMimeType: "application/x-executable",
      extension: "bin",
      fileSizeBytes: buffer.length,
      sha256: "",
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "bin"),
      errorCode: "EXECUTABLE_MAGIC_BYTES_BLOCKED",
      errorMessage: "تم رفض الملف لأسباب أمنية: محتوى تنفيذي غير مسموح به.",
    };
  }

  const sha256 = crypto.createHash("sha256").update(buffer).digest("hex");

  // Detect PDF (%PDF-) anywhere in the first 16 bytes
  const headAscii = buffer.subarray(0, Math.min(64, buffer.length)).toString("latin1");
  if (headAscii.includes("%PDF-")) {
    // Also check that PDF isn't obviously truncated (e.g., check minimal structure)
    const tailAscii = buffer.subarray(Math.max(0, buffer.length - 1024)).toString("latin1");
    const hasPdfStructure =
      tailAscii.includes("%%EOF") ||
      buffer.toString("latin1", 0, Math.min(4096, buffer.length)).includes("obj");
    if (!hasPdfStructure) {
      return {
        valid: false,
        detectedMimeType: "application/pdf",
        extension: "pdf",
        fileSizeBytes: buffer.length,
        sha256,
        sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "pdf"),
        errorCode: "CORRUPTED_PDF",
        errorMessage: "ملف PDF تالف أو غير مكتمل ولا يمكن قراءته.",
      };
    }
    return {
      valid: true,
      detectedMimeType: "application/pdf",
      extension: "pdf",
      fileSizeBytes: buffer.length,
      sha256,
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "pdf"),
    };
  }

  // Detect JPEG (\xFF\xD8\xFF)
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return {
      valid: true,
      detectedMimeType: "image/jpeg",
      extension: "jpg",
      fileSizeBytes: buffer.length,
      sha256,
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "jpg"),
    };
  }

  // Detect PNG (\x89PNG\r\n\x1a\n)
  if (
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a
  ) {
    return {
      valid: true,
      detectedMimeType: "image/png",
      extension: "png",
      fileSizeBytes: buffer.length,
      sha256,
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "png"),
    };
  }

  // Detect WEBP (RIFF....WEBP)
  if (
    buffer[0] === 0x52 &&
    buffer[1] === 0x49 &&
    buffer[2] === 0x46 &&
    buffer[3] === 0x46 &&
    buffer.length >= 12 &&
    buffer[8] === 0x57 &&
    buffer[9] === 0x45 &&
    buffer[10] === 0x42 &&
    buffer[11] === 0x50
  ) {
    return {
      valid: true,
      detectedMimeType: "image/webp",
      extension: "webp",
      fileSizeBytes: buffer.length,
      sha256,
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "webp"),
    };
  }

  // Detect TIFF (II*\x00 or MM\x00*)
  if (
    (buffer[0] === 0x49 && buffer[1] === 0x49 && buffer[2] === 0x2a && buffer[3] === 0x00) ||
    (buffer[0] === 0x4d && buffer[1] === 0x4d && buffer[2] === 0x00 && buffer[3] === 0x2a)
  ) {
    return {
      valid: true,
      detectedMimeType: "image/tiff",
      extension: "tiff",
      fileSizeBytes: buffer.length,
      sha256,
      sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "tiff"),
    };
  }

  // Detect structured plain-text CR / official document message
  const lowerMime = String(declaredMimeType || "").toLowerCase();
  const lowerFileName = String(declaredFileName || "").toLowerCase();
  if (lowerMime.startsWith("text/plain") || lowerFileName.endsWith(".txt")) {
    const utf8Text = buffer.toString("utf8");
    const hasDocKeywords =
      /(?:سجل\s*تجاري|رقم\s*السجل|اسم\s*الشركة|الاسم\s*التجاري|شهادة\s*الانتساب|ترخيص\s*بلدي|Commercial\s*Registration|C\.?\s*R\.?\s*No)/i.test(
        utf8Text
      );
    if (hasDocKeywords && !utf8Text.includes("\u0000")) {
      return {
        valid: true,
        detectedMimeType: "text/plain",
        extension: "txt",
        fileSizeBytes: buffer.length,
        sha256,
        sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "txt"),
      };
    }
  }

  return {
    valid: false,
    detectedMimeType: String(declaredMimeType || "application/octet-stream"),
    extension: "bin",
    fileSizeBytes: buffer.length,
    sha256,
    sanitizedOriginalName: sanitizeDisplayFileName(declaredFileName, "bin"),
    errorCode: "UNSUPPORTED_OR_CORRUPTED_FORMAT",
    errorMessage: "صيغة الملف غير مدعومة أو أن الملف تالف. يرجى إرسال ملف PDF أو صورة واضحة (JPG/PNG/WEBP).",
  };
}

/**
 * Generates a unique, non-user-controlled object storage key.
 */
export function buildSafeStorageObjectKey(tenantId: string, sha256: string, extension: string): string {
  const safeTenant = String(tenantId || "default_tenant")
    .replace(/[^a-zA-Z0-9_-]/g, "_")
    .slice(0, 48);
  const safeExt = String(extension || "pdf")
    .replace(/[^a-z0-9]/gi, "")
    .toLowerCase()
    .slice(0, 8) || "pdf";
  const now = new Date();
  const yyyy = String(now.getUTCFullYear());
  const mm = String(now.getUTCMonth() + 1).padStart(2, "0");
  const uuid = crypto.randomUUID().replace(/-/g, "");
  const shortHash = String(sha256 || "").replace(/[^a-f0-9]/gi, "").slice(0, 16) || "0000000000000000";
  return `docs/${safeTenant}/${yyyy}/${mm}/doc_${uuid}_${shortHash}.${safeExt}`;
}

/**
 * Resolves a storageObjectKey safely inside VAULT_ROOT_DIR, preventing any path traversal.
 */
export function resolveVaultPath(storageObjectKey: string): string {
  const normalizedKey = String(storageObjectKey || "")
    .replace(/\0/g, "")
    .replace(/^[/\\]+/, "");
  const resolvedRoot = path.resolve(VAULT_ROOT_DIR);
  const resolvedTarget = path.resolve(resolvedRoot, normalizedKey);
  if (!resolvedTarget.startsWith(resolvedRoot + path.sep) && resolvedTarget !== resolvedRoot) {
    throw new Error("SECURITY_VIOLATION: Invalid storage object key path traversal attempt");
  }
  return resolvedTarget;
}

/**
 * Stores the original binary document permanently in Cloud Storage / Verified Cloud Vault,
 * verifies that the stored object exists and matches its SHA-256 checksum, and returns metadata.
 */
export async function storePermanentDocument(params: {
  buffer: Buffer;
  tenantId: string;
  originalFileName?: string | null;
  declaredMimeType?: string | null;
}): Promise<StoredDocumentArtifact> {
  const validation = validateDocumentBuffer(
    params.buffer,
    params.originalFileName,
    params.declaredMimeType
  );
  if (!validation.valid) {
    const err = new Error(validation.errorMessage || "Invalid document file") as any;
    err.code = validation.errorCode || "INVALID_DOCUMENT";
    throw err;
  }

  const storageObjectKey = buildSafeStorageObjectKey(
    params.tenantId,
    validation.sha256,
    validation.extension
  );

  const vaultFilePath = resolveVaultPath(storageObjectKey);
  const vaultDir = path.dirname(vaultFilePath);
  if (!fs.existsSync(vaultDir)) {
    fs.mkdirSync(vaultDir, { recursive: true });
  }

  // Write atomically via temp file + rename
  const tempPath = `${vaultFilePath}.tmp_${process.pid}_${Date.now()}`;
  fs.writeFileSync(tempPath, params.buffer);
  fs.renameSync(tempPath, vaultFilePath);

  // Verify the written file exists and matches SHA-256
  if (!fs.existsSync(vaultFilePath)) {
    throw new Error("STORAGE_VERIFY_FAILED: Stored file does not exist after write");
  }
  const readBackBuffer = fs.readFileSync(vaultFilePath);
  const verifiedSha256 = crypto.createHash("sha256").update(readBackBuffer).digest("hex");
  if (verifiedSha256 !== validation.sha256 || readBackBuffer.length !== params.buffer.length) {
    throw new Error("STORAGE_VERIFY_FAILED: Checksum mismatch after writing document");
  }

  let cloudUploaded = false;
  let storageUri = `vault://${storageObjectKey}`;

  // Optional live Google Cloud Storage upload if bucket + token are configured
  const gcsBucket = process.env.GCS_DOCUMENT_BUCKET || process.env.CLOUD_BACKUP_BUCKET;
  const gcsToken = process.env.GCS_BEARER_TOKEN;
  if (gcsBucket && gcsToken) {
    try {
      const uploadUrl = `https://storage.googleapis.com/upload/storage/v1/b/${encodeURIComponent(
        gcsBucket
      )}/o?uploadType=media&name=${encodeURIComponent(storageObjectKey)}`;
      const resp = await fetch(uploadUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${gcsToken}`,
          "Content-Type": validation.detectedMimeType,
        },
        body: new Uint8Array(params.buffer),
      });
      if (resp.ok) {
        cloudUploaded = true;
        storageUri = `gs://${gcsBucket}/${storageObjectKey}`;
      }
    } catch (gcsErr) {
      logger.warn({ err: gcsErr }, "GCS direct upload notice (Vault copy verified)");
    }
  }

  const dataUrl = `data:${validation.detectedMimeType};base64,${params.buffer.toString("base64")}`;

  return {
    storageObjectKey,
    storageUri,
    vaultFilePath,
    cloudUploaded,
    verifiedExists: true,
    verifiedSha256,
    mimeType: validation.detectedMimeType,
    fileSizeBytes: validation.fileSizeBytes,
    sanitizedOriginalName: validation.sanitizedOriginalName,
    dataUrl,
  };
}

export const SAFE_DOWNLOAD_MIME_TYPES = new Set([
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/webp",
]);

export function sanitizeDownloadMimeType(mimeType?: string | null): string {
  const clean = String(mimeType || "").toLowerCase().trim();
  return SAFE_DOWNLOAD_MIME_TYPES.has(clean) ? clean : "application/octet-stream";
}

export function buildContentDispositionAttachment(rawFileName?: string | null, fallbackName = "document.pdf"): string {
  const sanitized = sanitizeDisplayFileName(rawFileName, fallbackName.split(".").pop() || "pdf");
  const asciiFallback = sanitized.replace(/[^\x20-\x7E]/g, "_").replace(/["\\]/g, "_") || fallbackName;
  const encodedUtf8 = encodeURIComponent(sanitized);
  return `attachment; filename="${asciiFallback}"; filename*=UTF-8''${encodedUtf8}`;
}

/**
 * Reads back a stored document binary from the verified vault (or falls back to decoding a data URL).
 * Strictly confines any file path lookup to VAULT_ROOT_DIR to prevent arbitrary file read.
 */
export function readStoredDocumentBuffer(
  storageObjectKey?: string | null,
  fallbackFileUrl?: string | null
): { buffer: Buffer; mimeType: string } | null {
  if (storageObjectKey) {
    try {
      const vaultPath = resolveVaultPath(storageObjectKey);
      if (fs.existsSync(vaultPath)) {
        const buffer = fs.readFileSync(vaultPath);
        const validation = validateDocumentBuffer(buffer, storageObjectKey);
        return {
          buffer,
          mimeType: sanitizeDownloadMimeType(validation.detectedMimeType),
        };
      }
    } catch (err: unknown) {
      logger.warn({ err }, "Failed to read from storageObjectKey");
    }
  }

  if (fallbackFileUrl) {
    if (fallbackFileUrl.startsWith("vault://")) {
      const key = fallbackFileUrl.slice("vault://".length);
      try {
        const vaultPath = resolveVaultPath(key);
        if (fs.existsSync(vaultPath)) {
          const buffer = fs.readFileSync(vaultPath);
          const validation = validateDocumentBuffer(buffer, key);
          return {
            buffer,
            mimeType: sanitizeDownloadMimeType(validation.detectedMimeType),
          };
        }
      } catch (err: unknown) {
        logger.warn({ err }, "Failed to read from vault:// URI");
      }
    } else if (fallbackFileUrl.startsWith("data:")) {
      const match = fallbackFileUrl.match(/^data:([^;,]+);base64,(.+)$/s);
      if (match) {
        const buffer = Buffer.from(match[2], "base64");
        return {
          buffer,
          mimeType: sanitizeDownloadMimeType(match[1]),
        };
      }
    } else if (!fallbackFileUrl.startsWith("/api/") && !fallbackFileUrl.startsWith("http")) {
      // Only allow reading if the resolved path is strictly inside VAULT_ROOT_DIR (#105)
      try {
        const resolvedRoot = path.resolve(VAULT_ROOT_DIR);
        const candidatePath = path.resolve(resolvedRoot, fallbackFileUrl);
        if (candidatePath.startsWith(resolvedRoot + path.sep) && fs.existsSync(candidatePath)) {
          const buffer = fs.readFileSync(candidatePath);
          const validation = validateDocumentBuffer(buffer, candidatePath);
          return {
            buffer,
            mimeType: sanitizeDownloadMimeType(validation.detectedMimeType),
          };
        }
      } catch {
        // Ignore paths outside vault
      }
    }
  }

  return null;
}

