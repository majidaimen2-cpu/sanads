import { eq, and, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  invoices,
  payments,
  cashSessions,
  creditNotes,
  transactionSteps,
} from "../../db/schema.js";
import { getNextCreditNoteNumber } from "./invoiceService.js";

interface HttpError extends Error {
  status?: number;
  code?: string;
  details?: unknown;
}

function httpError(message: string, status: number, code: string, details?: unknown): HttpError {
  const err: HttpError = new Error(message);
  err.status = status;
  err.code = code;
  if (details !== undefined) err.details = details;
  return err;
}

/**
 * Issues a credit note against a PAID / PARTIAL invoice and refunds the money.
 *
 * - The refund is stored as a NEGATIVE payment row (same method as the refund), so every
 *   existing "sum of payments" calculation (invoice paid total, cash session expected balance)
 *   automatically nets it out.
 * - The credit note reduces what the invoice is due. Full credit => invoice status REFUNDED.
 * - Everything happens in one DB transaction with the invoice row locked, exactly like recordPayment.
 */
export async function createCreditNote(params: {
  tenantId: string;
  userId?: number;
  invoiceId: number;
  amountBaisa?: number;
  refundMethod: "CASH" | "CARD" | "BANK" | "TRANSFER";
  reason: string;
  referenceNo?: string | null;
}) {
  const { tenantId, userId, invoiceId, refundMethod, reason, referenceNo } = params;

  return await db.transaction(async (tx) => {
    const [inv] = await tx
      .select()
      .from(invoices)
      .where(and(eq(invoices.id, invoiceId), eq(invoices.tenantId, tenantId)))
      .for("update")
      .limit(1);

    if (!inv || inv.deletedAt) {
      throw httpError("الفاتورة غير موجودة", 404, "INVOICE_NOT_FOUND");
    }
    if (inv.status === "REFUNDED") {
      throw httpError("الفاتورة مستردة بالكامل مسبقاً", 400, "ALREADY_REFUNDED");
    }
    if (inv.status !== "PAID" && inv.status !== "PARTIAL") {
      throw httpError(
        "لا يمكن إصدار إشعار دائن إلا لفاتورة مدفوعة أو مدفوعة جزئياً",
        400,
        "INVOICE_NOT_REFUNDABLE",
      );
    }

    const [paidRow] = await tx
      .select({ total: sql<string>`coalesce(sum(${payments.amountBaisa}), 0)` })
      .from(payments)
      .where(and(eq(payments.invoiceId, inv.id), eq(payments.tenantId, tenantId)));
    const netPaidBaisa = Number(paidRow?.total ?? 0);

    const [creditRow] = await tx
      .select({ total: sql<string>`coalesce(sum(${creditNotes.amountBaisa}), 0)` })
      .from(creditNotes)
      .where(and(eq(creditNotes.invoiceId, inv.id), eq(creditNotes.tenantId, tenantId)));
    const creditedBaisa = Number(creditRow?.total ?? 0);

    if (netPaidBaisa <= 0) {
      throw httpError("لا يوجد مبلغ مدفوع قابل للاسترداد", 422, "NOTHING_TO_REFUND");
    }

    const refundBaisa = params.amountBaisa ?? netPaidBaisa;
    if (!Number.isInteger(refundBaisa) || refundBaisa <= 0) {
      throw httpError("مبلغ الاسترداد يجب أن يكون أكبر من صفر", 422, "INVALID_AMOUNT");
    }
    if (refundBaisa > netPaidBaisa) {
      throw httpError(
        `مبلغ الاسترداد أكبر من صافي المدفوع (${netPaidBaisa} بيسة)`,
        422,
        "REFUND_EXCEEDS_PAID",
        { refundableBaisa: netPaidBaisa },
      );
    }

    let cashSessionId: number | null = null;
    if (refundMethod === "CASH") {
      const [session] = await tx
        .select()
        .from(cashSessions)
        .where(
          and(
            eq(cashSessions.tenantId, tenantId),
            eq(cashSessions.openedBy, userId || 0),
            eq(cashSessions.status, "OPEN"),
          ),
        )
        .limit(1);
      if (!session) {
        throw httpError(
          "لا توجد جلسة صندوق كاش مفتوحة للمستخدم الحالي",
          409,
          "NO_OPEN_CASH_SESSION",
        );
      }
      cashSessionId = session.id;
    }

    const creditNoteNumber = await getNextCreditNoteNumber(tenantId, tx);

    const [refundPayment] = await tx
      .insert(payments)
      .values({
        tenantId,
        branchId: inv.branchId,
        transactionId: inv.transactionId,
        invoiceId: inv.id,
        method: refundMethod,
        amountBaisa: -refundBaisa,
        receivedBy: userId,
        cashSessionId,
        referenceNo: referenceNo || creditNoteNumber,
        notes: `استرداد بموجب إشعار دائن ${creditNoteNumber}: ${reason}`,
      })
      .returning();

    const [creditNote] = await tx
      .insert(creditNotes)
      .values({
        tenantId,
        creditNoteNumber,
        invoiceId: inv.id,
        transactionId: inv.transactionId,
        customerId: inv.customerId,
        amountBaisa: refundBaisa,
        refundMethod,
        refundPaymentId: refundPayment.id,
        reason,
        createdBy: userId ?? null,
      })
      .returning();

    const newCreditedBaisa = creditedBaisa + refundBaisa;
    const newNetPaidBaisa = netPaidBaisa - refundBaisa;
    const dueBaisa = inv.totalBaisa - newCreditedBaisa;
    let newStatus: string;
    if (dueBaisa <= 0) newStatus = "REFUNDED";
    else if (newNetPaidBaisa >= dueBaisa) newStatus = "PAID";
    else if (newNetPaidBaisa > 0) newStatus = "PARTIAL";
    else newStatus = "UNPAID";

    const [updatedInvoice] = await tx
      .update(invoices)
      .set({ status: newStatus, updatedAt: new Date() })
      .where(and(eq(invoices.id, inv.id), eq(invoices.tenantId, tenantId)))
      .returning();

    // Audit trail on the transaction timeline (does not change the transaction's own status).
    await tx.insert(transactionSteps).values({
      transactionId: inv.transactionId,
      stepName: "إشعار دائن / استرداد",
      status: "REFUNDED",
      notes: `إشعار دائن ${creditNoteNumber} على الفاتورة ${inv.invoiceNumber} بقيمة ${refundBaisa} بيسة`,
      userId: userId ?? null,
    });

    return {
      creditNote,
      refundPayment,
      invoice: updatedInvoice,
      netPaidBaisa: newNetPaidBaisa,
      dueBaisa: Math.max(0, dueBaisa),
    };
  });
}
