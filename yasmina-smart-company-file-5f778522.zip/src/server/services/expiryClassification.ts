import { eq, and, isNull } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  companies,
  customerDocuments,
  employees,
  contracts,
  customers,
  tenantSettings,
} from "../../db/schema.js";
import { normalizeAndValidateDate } from "./crExtractionService.js";

export type ExpiryStatusCode =
  | "EXPIRED"
  | "EXPIRING_TODAY"
  | "EXPIRING_7"
  | "EXPIRING_30"
  | "NEEDS_REVIEW"
  | "VALID"
  | "NO_EXPIRY";

export type AlertSeverity =
  | "CRITICAL"
  | "URGENT"
  | "HIGH"
  | "WARNING"
  | "LOW"
  | "NONE";

export interface ExpiryClassificationResult {
  status: ExpiryStatusCode;
  statusAr: string;
  alertStage: string;
  severity: AlertSeverity;
  daysRemaining: number | null;
  normalizedExpiryDate: string | null;
  needsReview: boolean;
  hasNoExpiry: boolean;
  priorityRank: number;
}

export interface MonitoredDocumentItem {
  key: string;
  tenantId: string;
  sourceEntity: "companies" | "customer_documents" | "employees" | "contracts";
  sourceId: string;
  companyId: number | null;
  companyName: string;
  ownerName: string;
  documentId: number | null;
  docTypeCode: string;
  docTypeAr: string;
  docNumber: string;
  issueDate: string | null;
  rawExpiryDate: string | null;
  expiryDate: string | null;
  extractionSource: string;
  hasNoExpiry: boolean;
  status: ExpiryStatusCode;
  statusAr: string;
  alertStage: string;
  severity: AlertSeverity;
  daysRemaining: number | null;
  needsReview: boolean;
  priorityRank: number;
  link: string;
}

export interface ExpiryAuditOptions {
  tenantId?: string;
  referenceDate?: string | Date;
  warningDays?: number;
  urgentDays?: number;
  triggerType?:
    | "CRON"
    | "MANUAL"
    | "IMMEDIATE_UPLOAD"
    | "DATE_UPDATE"
    | "TEST";
  simulateDeliveryFailureForDocNumber?: string;
}

export interface ExpiryAuditRunResult {
  runId: string;
  referenceDate: string;
  totalScanned: number;
  expiredCount: number;
  expiringTodayCount: number;
  expiring7DaysCount: number;
  expiring30DaysCount: number;
  expiringSoonCount: number;
  needsReviewCount: number;
  validCount: number;
  noExpiryCount: number;
  notificationsCreated: number;
  notificationsDeduplicated: number;
  failedDeliveries: number;
  retriedDeliveries: number;
  durationMs: number;
}

const DOC_TYPE_LABELS_AR: Record<string, string> = {
  CR: "السجل التجاري",
  COMMERCIAL_REGISTRATION: "السجل التجاري",
  COMMERCIAL_LICENSE: "الترخيص التجاري / البلدي",
  MUNICIPAL_LICENSE: "الترخيص البلدي",
  TAX_CARD: "البطاقة الضريبية",
  VAT_CERTIFICATE: "شهادة ضريبة القيمة المضافة",
  CHAMBER_CERTIFICATE: "شهادة انتساب غرفة التجارة",
  CIVIL_ID: "بطاقة الهوية",
  RESIDENCE_CARD: "بطاقة الإقامة",
  PASSPORT: "جواز السفر",
  LABOR_PERMIT: "تصريح العمل",
  LEASE_CONTRACT: "عقد الإيجار",
  CONTRACT: "عقد تجاري / إيجار",
  OTHER: "وثيقة رسمية",
};

export function resolveDocTypeAr(docType: string | null | undefined): string {
  if (!docType) return "وثيقة رسمية";
  const upper = docType.trim().toUpperCase();
  if (DOC_TYPE_LABELS_AR[upper]) return DOC_TYPE_LABELS_AR[upper];
  return docType.trim();
}

export function normalizeDocTypeCode(
  docType: string | null | undefined,
): string {
  if (!docType) return "OTHER";
  const trimmed = docType.trim();
  const upper = trimmed.toUpperCase();
  if (upper === "COMMERCIAL_REGISTRATION" || upper === "CR") return "CR";
  if (DOC_TYPE_LABELS_AR[upper]) return upper;
  if (trimmed.includes("سجل تجاري")) return "CR";
  if (trimmed.includes("ترخيص بلدي")) return "MUNICIPAL_LICENSE";
  if (trimmed.includes("ترخيص")) return "COMMERCIAL_LICENSE";
  if (trimmed.includes("ضريب")) return "TAX_CARD";
  if (trimmed.includes("هوية") || trimmed.includes("مدنية")) return "CIVIL_ID";
  if (trimmed.includes("إقامة") || trimmed.includes("اقامة"))
    return "RESIDENCE_CARD";
  if (trimmed.includes("جواز")) return "PASSPORT";
  if (trimmed.includes("عمل") || trimmed.includes("مأذونية"))
    return "LABOR_PERMIT";
  if (
    trimmed.includes("إيجار") ||
    trimmed.includes("ايجار") ||
    trimmed.includes("عقد")
  )
    return "LEASE_CONTRACT";
  return upper.replace(/\s+/g, "_");
}

export function getMuscatTodayString(referenceDate?: string | Date): string {
  if (
    typeof referenceDate === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(referenceDate.trim())
  ) {
    return referenceDate.trim();
  }
  const dateObj = referenceDate ? new Date(referenceDate) : new Date();
  if (isNaN(dateObj.getTime())) {
    return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Muscat" });
  }
  return dateObj.toLocaleDateString("en-CA", { timeZone: "Asia/Muscat" });
}

export function classifyDocumentExpiry(params: {
  expiryDate?: string | null;
  hasNoExpiry?: boolean | null;
  referenceDate?: string | Date;
  warningDays?: number;
  urgentDays?: number;
}): ExpiryClassificationResult {
  const warningDays = params.warningDays ?? 30;
  const urgentDays = params.urgentDays ?? 7;

  if (params.hasNoExpiry === true) {
    return {
      status: "NO_EXPIRY",
      statusAr: "دائمة / بلا تاريخ انتهاء",
      alertStage: "NONE",
      severity: "NONE",
      daysRemaining: null,
      normalizedExpiryDate: null,
      needsReview: false,
      hasNoExpiry: true,
      priorityRank: 7,
    };
  }

  const rawDate = params.expiryDate ? String(params.expiryDate).trim() : "";
  if (!rawDate) {
    return {
      status: "NEEDS_REVIEW",
      statusAr: "تحتاج إلى مراجعة",
      alertStage: "NEEDS_REVIEW",
      severity: "WARNING",
      daysRemaining: null,
      normalizedExpiryDate: null,
      needsReview: true,
      hasNoExpiry: false,
      priorityRank: 5,
    };
  }

  const normalized = normalizeAndValidateDate(rawDate);
  if (!normalized) {
    return {
      status: "NEEDS_REVIEW",
      statusAr: "تحتاج إلى مراجعة (تاريخ غير صالح)",
      alertStage: "NEEDS_REVIEW",
      severity: "WARNING",
      daysRemaining: null,
      normalizedExpiryDate: null,
      needsReview: true,
      hasNoExpiry: false,
      priorityRank: 5,
    };
  }

  const todayStr = getMuscatTodayString(params.referenceDate);
  const [ty, tm, td] = todayStr.split("-").map(Number);
  const [ey, em, ed] = normalized.split("-").map(Number);

  const todayUtcMs = Date.UTC(ty, tm - 1, td);
  const expiryUtcMs = Date.UTC(ey, em - 1, ed);
  const daysRemaining = Math.round(
    (expiryUtcMs - todayUtcMs) / (1000 * 60 * 60 * 24),
  );

  if (daysRemaining < 0) {
    return {
      status: "EXPIRED",
      statusAr: "منتهية",
      alertStage: "EXPIRED",
      severity: "CRITICAL",
      daysRemaining,
      normalizedExpiryDate: normalized,
      needsReview: false,
      hasNoExpiry: false,
      priorityRank: 1,
    };
  }

  if (daysRemaining === 0) {
    return {
      status: "EXPIRING_TODAY",
      statusAr: "تنتهي اليوم",
      alertStage: "EXPIRING_TODAY",
      severity: "URGENT",
      daysRemaining: 0,
      normalizedExpiryDate: normalized,
      needsReview: false,
      hasNoExpiry: false,
      priorityRank: 2,
    };
  }

  if (daysRemaining <= urgentDays) {
    return {
      status: "EXPIRING_7",
      statusAr: "تنتهي قريبًا جدًا",
      alertStage: "EXPIRING_7",
      severity: "HIGH",
      daysRemaining,
      normalizedExpiryDate: normalized,
      needsReview: false,
      hasNoExpiry: false,
      priorityRank: 3,
    };
  }

  if (daysRemaining <= warningDays) {
    return {
      status: "EXPIRING_30",
      statusAr: "قربت تنتهي",
      alertStage: "EXPIRING_30",
      severity: "WARNING",
      daysRemaining,
      normalizedExpiryDate: normalized,
      needsReview: false,
      hasNoExpiry: false,
      priorityRank: 4,
    };
  }

  return {
    status: "VALID",
    statusAr: "سارية",
    alertStage: "NONE",
    severity: "LOW",
    daysRemaining,
    normalizedExpiryDate: normalized,
    needsReview: false,
    hasNoExpiry: false,
    priorityRank: 6,
  };
}

export async function discoverAllMonitoredDocuments(
  tenantId?: string,
  options?: {
    referenceDate?: string | Date;
    warningDays?: number;
    urgentDays?: number;
  },
): Promise<MonitoredDocumentItem[]> {
  const companyColumns = {
    id: companies.id,
    tenantId: companies.tenantId,
    name: companies.name,
    tradeName: companies.tradeName,
    taxId: companies.taxId,
    crIssueDate: companies.crIssueDate,
    crExpiryDate: companies.crExpiryDate,
    licenseNumber: companies.licenseNumber,
    licenseExpiryDate: companies.licenseExpiryDate,
    ownerCustomerId: companies.ownerCustomerId,
    activities: companies.activities,
    createdBy: companies.createdBy,
  };

  const [
    allCompanies,
    allCustomerDocs,
    allCustomers,
    allEmployees,
    allContracts,
    allSettings,
  ] = await Promise.all([
    tenantId
      ? db
          .select(companyColumns)
          .from(companies)
          .where(
            and(eq(companies.tenantId, tenantId), isNull(companies.deletedAt)),
          )
      : db
          .select(companyColumns)
          .from(companies)
          .where(isNull(companies.deletedAt)),
    tenantId
      ? db
          .select()
          .from(customerDocuments)
          .where(
            and(
              eq(customerDocuments.tenantId, tenantId),
              isNull(customerDocuments.deletedAt),
            ),
          )
      : db
          .select()
          .from(customerDocuments)
          .where(isNull(customerDocuments.deletedAt)),
    tenantId
      ? db
          .select()
          .from(customers)
          .where(
            and(eq(customers.tenantId, tenantId), isNull(customers.deletedAt)),
          )
      : db.select().from(customers).where(isNull(customers.deletedAt)),
    tenantId
      ? db
          .select()
          .from(employees)
          .where(
            and(eq(employees.tenantId, tenantId), isNull(employees.deletedAt)),
          )
      : db.select().from(employees).where(isNull(employees.deletedAt)),
    tenantId
      ? db
          .select()
          .from(contracts)
          .where(
            and(eq(contracts.tenantId, tenantId), isNull(contracts.deletedAt)),
          )
      : db.select().from(contracts).where(isNull(contracts.deletedAt)),
    db.select().from(tenantSettings),
  ]);

  const settingsByTenant = new Map<
    string,
    { warningDays: number; urgentDays: number }
  >();
  for (const s of allSettings) {
    settingsByTenant.set(s.tenantId, {
      warningDays: s.warningDays ?? 30,
      urgentDays: s.urgentDays ?? 7,
    });
  }

  const getThresholds = (tId: string) => {
    const tSettings = settingsByTenant.get(tId);
    return {
      warningDays: options?.warningDays ?? tSettings?.warningDays ?? 30,
      urgentDays: options?.urgentDays ?? tSettings?.urgentDays ?? 7,
    };
  };

  const companyById = new Map<number, (typeof allCompanies)[number]>();
  for (const c of allCompanies) {
    companyById.set(c.id, c);
  }

  const customerById = new Map<number, (typeof allCustomers)[number]>();
  for (const cust of allCustomers) {
    customerById.set(cust.id, cust);
  }

  const mergedCustomerDocIds = new Set<number>();
  const items: MonitoredDocumentItem[] = [];

  for (const comp of allCompanies) {
    const compTenant = comp.tenantId || "default_tenant";
    const thresholds = getThresholds(compTenant);
    const ownerCust = comp.ownerCustomerId
      ? customerById.get(comp.ownerCustomerId)
      : undefined;
    let parsedOwnerFromActivities: string | null = null;
    if (comp.activities) {
      try {
        const parsed = JSON.parse(comp.activities) as {
          ownerOrManagerName?: string;
        };
        if (parsed && typeof parsed === "object" && parsed.ownerOrManagerName) {
          parsedOwnerFromActivities = parsed.ownerOrManagerName;
        }
      } catch {
        // Ignore non-JSON activities text
      }
    }

    const ownerName =
      parsedOwnerFromActivities ||
      ownerCust?.fullNameAr ||
      ownerCust?.fullNameEn ||
      comp.createdBy ||
      "غير محدد";

    const linkedCrDoc = allCustomerDocs.find(
      (d) =>
        (d.companyId === comp.id ||
          (comp.taxId && d.docNumber === comp.taxId)) &&
        normalizeDocTypeCode(d.docType) === "CR",
    );
    if (linkedCrDoc) {
      mergedCustomerDocIds.add(linkedCrDoc.id);
    }

    const crHasNoExpiry = linkedCrDoc?.hasNoExpiry ?? false;
    const rawCrExpiry =
      comp.crExpiryDate ??
      linkedCrDoc?.rawExpiryDate ??
      linkedCrDoc?.expiryDate ??
      null;
    const crClassification = classifyDocumentExpiry({
      expiryDate: rawCrExpiry,
      hasNoExpiry: crHasNoExpiry,
      referenceDate: options?.referenceDate,
      warningDays: thresholds.warningDays,
      urgentDays: thresholds.urgentDays,
    });

    items.push({
      key: `companies:${comp.id}:CR`,
      tenantId: compTenant,
      sourceEntity: "companies",
      sourceId: String(comp.id),
      companyId: comp.id,
      companyName: comp.name || comp.tradeName || "شركة غير مسماة",
      ownerName,
      documentId: linkedCrDoc?.id ?? null,
      docTypeCode: "CR",
      docTypeAr: "السجل التجاري",
      docNumber: comp.taxId || linkedCrDoc?.docNumber || `CR-${comp.id}`,
      issueDate: comp.crIssueDate || linkedCrDoc?.issueDate || null,
      rawExpiryDate: linkedCrDoc?.rawExpiryDate || rawCrExpiry,
      expiryDate: crClassification.normalizedExpiryDate,
      extractionSource: linkedCrDoc?.extractionSource || "COMPANY_REGISTRY",
      hasNoExpiry: crHasNoExpiry,
      status: crClassification.status,
      statusAr: crClassification.statusAr,
      alertStage: crClassification.alertStage,
      severity: crClassification.severity,
      daysRemaining: crClassification.daysRemaining,
      needsReview: crClassification.needsReview,
      priorityRank: crClassification.priorityRank,
      link: `/companies?companyId=${comp.id}`,
    });

    if (comp.licenseNumber || comp.licenseExpiryDate) {
      const licClassification = classifyDocumentExpiry({
        expiryDate: comp.licenseExpiryDate,
        hasNoExpiry: false,
        referenceDate: options?.referenceDate,
        warningDays: thresholds.warningDays,
        urgentDays: thresholds.urgentDays,
      });

      items.push({
        key: `companies:${comp.id}:COMMERCIAL_LICENSE`,
        tenantId: compTenant,
        sourceEntity: "companies",
        sourceId: `${comp.id}:LICENSE`,
        companyId: comp.id,
        companyName: comp.name || comp.tradeName || "شركة غير مسماة",
        ownerName,
        documentId: null,
        docTypeCode: "COMMERCIAL_LICENSE",
        docTypeAr: "الترخيص التجاري / البلدي",
        docNumber: comp.licenseNumber || `LIC-${comp.id}`,
        issueDate: null,
        rawExpiryDate: comp.licenseExpiryDate || null,
        expiryDate: licClassification.normalizedExpiryDate,
        extractionSource: "COMPANY_REGISTRY",
        hasNoExpiry: false,
        status: licClassification.status,
        statusAr: licClassification.statusAr,
        alertStage: licClassification.alertStage,
        severity: licClassification.severity,
        daysRemaining: licClassification.daysRemaining,
        needsReview: licClassification.needsReview,
        priorityRank: licClassification.priorityRank,
        link: `/companies?companyId=${comp.id}`,
      });
    }
  }

  for (const doc of allCustomerDocs) {
    if (mergedCustomerDocIds.has(doc.id)) continue;
    const docTenant = doc.tenantId || "default_tenant";
    const thresholds = getThresholds(docTenant);

    const linkedCompany = doc.companyId
      ? companyById.get(doc.companyId)
      : undefined;
    const linkedCustomer = doc.customerId
      ? customerById.get(doc.customerId)
      : undefined;

    const companyName =
      linkedCompany?.name ||
      linkedCustomer?.fullNameAr ||
      linkedCustomer?.fullNameEn ||
      "وثيقة عامة";
    const ownerName =
      linkedCustomer?.fullNameAr ||
      linkedCustomer?.fullNameEn ||
      doc.createdBy ||
      "غير محدد";

    const docTypeCode = normalizeDocTypeCode(doc.docType);
    const docTypeAr = resolveDocTypeAr(doc.docType);

    const rawExpiry = doc.expiryDate ?? doc.rawExpiryDate ?? null;
    const classification = classifyDocumentExpiry({
      expiryDate: rawExpiry,
      hasNoExpiry: doc.hasNoExpiry,
      referenceDate: options?.referenceDate,
      warningDays: thresholds.warningDays,
      urgentDays: thresholds.urgentDays,
    });

    items.push({
      key: `customer_documents:${doc.id}:${docTypeCode}`,
      tenantId: docTenant,
      sourceEntity: "customer_documents",
      sourceId: String(doc.id),
      companyId: doc.companyId ?? null,
      companyName,
      ownerName,
      documentId: doc.id,
      docTypeCode,
      docTypeAr,
      docNumber: doc.docNumber || `DOC-${doc.id}`,
      issueDate: doc.issueDate || doc.rawIssueDate || null,
      rawExpiryDate: doc.rawExpiryDate || doc.expiryDate || null,
      expiryDate: classification.normalizedExpiryDate,
      extractionSource: doc.extractionSource || "MANUAL",
      hasNoExpiry: Boolean(doc.hasNoExpiry),
      status: classification.status,
      statusAr: classification.statusAr,
      alertStage: classification.alertStage,
      severity: classification.severity,
      daysRemaining: classification.daysRemaining,
      needsReview: classification.needsReview,
      priorityRank: classification.priorityRank,
      link: doc.companyId
        ? `/companies?companyId=${doc.companyId}`
        : `/documents?docId=${doc.id}`,
    });
  }

  for (const emp of allEmployees) {
    const empTenant = emp.tenantId || "default_tenant";
    const thresholds = getThresholds(empTenant);
    const linkedComp = emp.companyId
      ? companyById.get(emp.companyId)
      : undefined;
    const empCompanyName = linkedComp?.name || "الموارد البشرية";

    if (emp.residenceExpiry || emp.civilId) {
      const resClass = classifyDocumentExpiry({
        expiryDate: emp.residenceExpiry,
        hasNoExpiry: false,
        referenceDate: options?.referenceDate,
        warningDays: thresholds.warningDays,
        urgentDays: thresholds.urgentDays,
      });

      items.push({
        key: `employees:${emp.id}:RESIDENCE_CARD`,
        tenantId: empTenant,
        sourceEntity: "employees",
        sourceId: `${emp.id}:RESIDENCE`,
        companyId: emp.companyId ?? null,
        companyName: empCompanyName,
        ownerName: emp.employeeName,
        documentId: null,
        docTypeCode: "RESIDENCE_CARD",
        docTypeAr: "بطاقة الهوية / الإقامة",
        docNumber: emp.civilId || emp.laborCardNo || `EMP-RES-${emp.id}`,
        issueDate: null,
        rawExpiryDate: emp.residenceExpiry || null,
        expiryDate: resClass.normalizedExpiryDate,
        extractionSource: "HR_RECORD",
        hasNoExpiry: false,
        status: resClass.status,
        statusAr: resClass.statusAr,
        alertStage: resClass.alertStage,
        severity: resClass.severity,
        daysRemaining: resClass.daysRemaining,
        needsReview: resClass.needsReview,
        priorityRank: resClass.priorityRank,
        link: `/hr?employeeId=${emp.id}`,
      });
    }

    if (emp.passportExpiry || emp.passportNo) {
      const passClass = classifyDocumentExpiry({
        expiryDate: emp.passportExpiry,
        hasNoExpiry: false,
        referenceDate: options?.referenceDate,
        warningDays: thresholds.warningDays,
        urgentDays: thresholds.urgentDays,
      });

      items.push({
        key: `employees:${emp.id}:PASSPORT`,
        tenantId: empTenant,
        sourceEntity: "employees",
        sourceId: `${emp.id}:PASSPORT`,
        companyId: emp.companyId ?? null,
        companyName: empCompanyName,
        ownerName: emp.employeeName,
        documentId: null,
        docTypeCode: "PASSPORT",
        docTypeAr: "جواز السفر",
        docNumber: emp.passportNo || `EMP-PASS-${emp.id}`,
        issueDate: null,
        rawExpiryDate: emp.passportExpiry || null,
        expiryDate: passClass.normalizedExpiryDate,
        extractionSource: "HR_RECORD",
        hasNoExpiry: false,
        status: passClass.status,
        statusAr: passClass.statusAr,
        alertStage: passClass.alertStage,
        severity: passClass.severity,
        daysRemaining: passClass.daysRemaining,
        needsReview: passClass.needsReview,
        priorityRank: passClass.priorityRank,
        link: `/hr?employeeId=${emp.id}`,
      });
    }
  }

  for (const contract of allContracts) {
    if (contract.status === "CANCELLED") continue;
    const contractTenant = contract.tenantId || "default_tenant";
    const thresholds = getThresholds(contractTenant);
    const linkedComp = contract.companyId
      ? companyById.get(contract.companyId)
      : undefined;
    const linkedCustomer = contract.customerId
      ? customerById.get(contract.customerId)
      : undefined;
    const contractClass = classifyDocumentExpiry({
      expiryDate: contract.endDate,
      hasNoExpiry: false,
      referenceDate: options?.referenceDate,
      warningDays: thresholds.warningDays,
      urgentDays: thresholds.urgentDays,
    });

    items.push({
      key: `contracts:${contract.id}:LEASE_CONTRACT`,
      tenantId: contractTenant,
      sourceEntity: "contracts",
      sourceId: String(contract.id),
      companyId: contract.companyId ?? null,
      companyName:
        linkedComp?.name || linkedCustomer?.fullNameAr || contract.title,
      ownerName: linkedCustomer?.fullNameAr || "غير محدد",
      documentId: null,
      docTypeCode: "LEASE_CONTRACT",
      docTypeAr: "عقد الإيجار / الخدمة",
      docNumber: `CNT-${contract.id}`,
      issueDate: contract.startDate || null,
      rawExpiryDate: contract.endDate || null,
      expiryDate: contractClass.normalizedExpiryDate,
      extractionSource: "CONTRACT_REGISTRY",
      hasNoExpiry: false,
      status: contractClass.status,
      statusAr: contractClass.statusAr,
      alertStage: contractClass.alertStage,
      severity: contractClass.severity,
      daysRemaining: contractClass.daysRemaining,
      needsReview: contractClass.needsReview,
      priorityRank: contractClass.priorityRank,
      link: `/contracts?contractId=${contract.id}`,
    });
  }

  items.sort((a, b) => {
    if (a.priorityRank !== b.priorityRank) {
      return a.priorityRank - b.priorityRank;
    }
    const aDays = a.daysRemaining ?? 999999;
    const bDays = b.daysRemaining ?? 999999;
    return aDays - bDays;
  });

  return items;
}

export function buildNotificationCopy(item: MonitoredDocumentItem): {
  title: string;
  message: string;
  type: string;
} {
  const docLabel = `${item.docTypeAr} (${item.docNumber})`;
  const entityLabel = item.companyName
    ? `لشركة ${item.companyName}`
    : `لـ ${item.ownerName}`;

  if (item.status === "EXPIRED") {
    const overdueDays = Math.abs(item.daysRemaining ?? 0);
    return {
      title: `🚨 وثيقة منتهية: ${item.docTypeAr} - ${item.companyName}`,
      message: `انتهت صلاحية ${docLabel} ${entityLabel} (المالك: ${item.ownerName}) بتاريخ ${item.expiryDate} منذ ${overdueDays} يوم. يرجى التجديد الفوري.`,
      type: "DOCUMENT_EXPIRED",
    };
  }

  if (item.status === "EXPIRING_TODAY") {
    return {
      title: `⚠️ تنتهي اليوم: ${item.docTypeAr} - ${item.companyName}`,
      message: `تنتهي اليوم صلاحية ${docLabel} ${entityLabel} (المالك: ${item.ownerName}) بتاريخ ${item.expiryDate}. يرجى اتخاذ إجراء التجديد اليوم.`,
      type: "DOCUMENT_EXPIRING_TODAY",
    };
  }

  if (item.status === "EXPIRING_7") {
    return {
      title: `⚡ تنتهي خلال ${item.daysRemaining} أيام: ${item.docTypeAr} - ${item.companyName}`,
      message: `تنتهي صلاحية ${docLabel} ${entityLabel} (المالك: ${item.ownerName}) بتاريخ ${item.expiryDate} (متبقي ${item.daysRemaining} يوم).`,
      type: "DOCUMENT_EXPIRING_URGENT",
    };
  }

  if (item.status === "EXPIRING_30") {
    return {
      title: `🔔 قرب انتهاء وثيقة: ${item.docTypeAr} - ${item.companyName}`,
      message: `قربت نهاية صلاحية ${docLabel} ${entityLabel} (المالك: ${item.ownerName}) بتاريخ ${item.expiryDate} (متبقي ${item.daysRemaining} يوم).`,
      type: "DOCUMENT_EXPIRING_SOON",
    };
  }

  return {
    title: `📋 وثيقة تحتاج إلى مراجعة: ${item.docTypeAr} - ${item.companyName}`,
    message: `تاريخ انتهاء ${docLabel} ${entityLabel} (المالك: ${item.ownerName}) غير واضح أو غير صالح. يرجى مراجعة الوثيقة وتحديث تاريخ الانتهاء يدوياً.`,
    type: "DOCUMENT_NEEDS_REVIEW",
  };
}
