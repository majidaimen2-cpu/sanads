import { eq, and, isNull } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  companies,
  companyPeople,
  customers,
  customerDocuments,
  tenantSettings,
} from "../../db/schema.js";
import { normalizeCompanyNameForMatch, companyNamesMatch, phonesMatch } from "./whatsappDocumentProcessor.js";

export type MatchLane = "AUTO" | "CONFIRM" | "UNMATCHED";

/** What the matcher needs from an extracted document. Built by buildMatchInput(). */
export interface MatchInput {
  documentType: string; // legacy canonical type, e.g. municipal_license
  normalizedCr: string | null;
  /** True when the CR number came only from the file name. Then it is a soft signal, never a hard anchor. */
  crFromFileNameOnly: boolean;
  companyNames: string[];
  licenseNumber: string | null;
  taxCardNumber: string | null;
  chamberNumber: string | null;
  civilNumber: string | null;
  passportNumber: string | null;
  extractionLevel: "HIGH" | "MEDIUM" | "LOW";
  promptInjectionDetected: boolean;
  dateError: boolean;
}

export interface MatchReason {
  code: string;
  points: number;
  hard: boolean;
  detail: string;
}

export interface MatchCandidate {
  companyId: number;
  companyName: string;
  score: number;
  hardAnchor: boolean;
  reasons: MatchReason[];
}

export interface MatchSettings {
  autoFileEnabled: boolean;
  autoFileMinScore: number;
}

export interface MatchOutcome {
  lane: MatchLane;
  candidates: MatchCandidate[];
  topScore: number;
  laneReason: string;
  senderKnown: boolean;
}

export interface MatchCompanyRow {
  id: number;
  name: string;
  tradeName: string | null;
  companyNameEn: string | null;
  normalizedCrNumber: string | null;
  taxId: string | null;
  companyCode: string;
  licenseNumber: string | null;
  taxCardNumber: string | null;
  chamberNumber: string | null;
  contactPhone: string | null;
  ownerPhones: string[];
}

export interface MatchPersonRow {
  companyId: number;
  civilNumber: string | null;
  passportNumber: string | null;
}

export const POINTS = {
  CR_EXACT: 70,
  CR_FILENAME_ONLY: 30,
  LICENSE_EXACT: 50,
  PERSON_ID: 60,
  NAME_EXACT: 25,
  NAME_FUZZY: 15,
  PHONE: 20,
  PRIOR_FILING: 5,
} as const;

/** A candidate scoring at least this is shown to staff (fuzzy-name-only counts). */
export const MIN_CANDIDATE_SCORE = 15;
export const AMBIGUITY_GAP = 10;

function alnum(v: string | null | undefined): string {
  return String(v || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const m = a.length;
  const n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = cur;
  }
  return prev[n];
}

/** Arabic-aware (works on normalizeCompanyNameForMatch output) similarity 0..1. No external dependency. */
export function nameSimilarity(rawA: string | null | undefined, rawB: string | null | undefined): number {
  const a = normalizeCompanyNameForMatch(rawA);
  const b = normalizeCompanyNameForMatch(rawB);
  if (!a || !b || a.length < 4 || b.length < 4) return 0;
  if (a === b) return 1;
  const charSim = 1 - levenshtein(a, b) / Math.max(a.length, b.length);
  const ta = a.split(" ").filter(Boolean);
  const tb = b.split(" ").filter(Boolean);
  const setB = new Set(tb);
  const inter = ta.filter((t) => setB.has(t)).length;
  const dice = (2 * inter) / (ta.length + tb.length);
  return Math.max(charSim, dice);
}

export function scoreCandidates(params: {
  input: MatchInput;
  companies: MatchCompanyRow[];
  people: MatchPersonRow[];
  senderPhone: string;
  priorFilingCompanyIds: Set<number>;
}): MatchCandidate[] {
  const { input, senderPhone } = params;
  const out: MatchCandidate[] = [];
  const licenseTypes = new Set(["municipal_license", "labor_certificate"]);

  for (const c of params.companies) {
    const reasons: MatchReason[] = [];
    const add = (code: string, points: number, hard: boolean, detail: string) =>
      reasons.push({ code, points, hard, detail });

    // Conflict: the document prints a different CR number than this company has. Candidate is dropped.
    const cr = input.normalizedCr;
    if (cr) {
      const companyCrs = [c.normalizedCrNumber, c.taxId, c.companyCode?.replace(/^CR-/, "")]
        .map((x) => alnum(x))
        .filter(Boolean);
      const sameCr = companyCrs.includes(alnum(cr));
      if (sameCr) {
        if (input.crFromFileNameOnly) add("CR_FILENAME", POINTS.CR_FILENAME_ONLY, false, "CR number found only in the file name");
        else add("CR_EXACT", POINTS.CR_EXACT, true, "CR number matches exactly");
      } else if (c.normalizedCrNumber && !input.crFromFileNameOnly) {
        continue; // -100: conflicting printed CR number
      }
    }

    const lic = alnum(input.licenseNumber);
    if (lic && lic !== alnum(cr) && licenseTypes.has(input.documentType) && alnum(c.licenseNumber) === lic) {
      add("LICENSE_EXACT", POINTS.LICENSE_EXACT, true, "License number matches exactly");
    }
    const tax = alnum(input.taxCardNumber);
    if (tax && tax !== alnum(cr) && alnum(c.taxCardNumber) === tax) {
      add("TAX_EXACT", POINTS.LICENSE_EXACT, true, "Tax card number matches exactly");
    }
    const ch = alnum(input.chamberNumber);
    if (ch && ch !== alnum(cr) && alnum(c.chamberNumber) === ch) {
      add("CHAMBER_EXACT", POINTS.LICENSE_EXACT, true, "Chamber number matches exactly");
    }

    const civil = alnum(input.civilNumber);
    const pass = alnum(input.passportNumber);
    if (civil || pass) {
      const hit = params.people.find(
        (p) => p.companyId === c.id && ((civil && alnum(p.civilNumber) === civil) || (pass && alnum(p.passportNumber) === pass)),
      );
      if (hit) add("PERSON_ID", POINTS.PERSON_ID, true, "Civil/passport number belongs to a known person of this company");
    }

    // Names: exact core match is worth more than a fuzzy one. Only the best name signal counts.
    let nameExact = false;
    let bestSim = 0;
    const companyNames = [c.name, c.tradeName, c.companyNameEn].filter(Boolean) as string[];
    for (const docName of input.companyNames) {
      for (const cn of companyNames) {
        if (companyNamesMatch(docName, cn)) nameExact = true;
        bestSim = Math.max(bestSim, nameSimilarity(docName, cn));
      }
    }
    if (nameExact) add("NAME_EXACT", POINTS.NAME_EXACT, false, "Company name matches");
    else if (bestSim >= 0.85) add("NAME_FUZZY", POINTS.NAME_FUZZY, false, `Company name ${Math.round(bestSim * 100)}% similar`);

    if (senderPhone && (phonesMatch(senderPhone, c.contactPhone) || c.ownerPhones.some((p) => phonesMatch(senderPhone, p)))) {
      add("PHONE", POINTS.PHONE, false, "Sender phone belongs to this company");
    }
    if (params.priorFilingCompanyIds.has(c.id)) {
      add("PRIOR_FILING", POINTS.PRIOR_FILING, false, "Sender previously filed documents to this company");
    }

    if (reasons.length === 0) continue;
    const score = Math.min(100, reasons.reduce((s, r) => s + r.points, 0));
    out.push({
      companyId: c.id,
      companyName: c.name,
      score,
      hardAnchor: reasons.some((r) => r.hard),
      reasons,
    });
  }
  return out.sort((a, b) => b.score - a.score || a.companyId - b.companyId);
}

export function decideLane(params: {
  candidates: MatchCandidate[];
  input: MatchInput;
  settings: MatchSettings;
  senderKnown: boolean;
}): { lane: MatchLane; reason: string } {
  const shown = params.candidates.filter((c) => c.score >= MIN_CANDIDATE_SCORE);
  if (shown.length === 0) return { lane: "UNMATCHED", reason: "No candidate company" };
  const top = shown[0];
  const second = shown[1];
  const { settings, input } = params;
  if (!settings.autoFileEnabled) return { lane: "CONFIRM", reason: "Auto-filing is off for this tenant" };
  if (top.score < settings.autoFileMinScore) return { lane: "CONFIRM", reason: "Score below auto-file threshold" };
  if (!top.hardAnchor) return { lane: "CONFIRM", reason: "No hard identifier (name or phone only)" };
  if (second && top.score - second.score <= AMBIGUITY_GAP) return { lane: "CONFIRM", reason: "Another company scores within 10 points" };
  if (input.extractionLevel === "LOW") return { lane: "CONFIRM", reason: "Low extraction confidence" };
  if (input.promptInjectionDetected) return { lane: "CONFIRM", reason: "Document flagged for instructions aimed at the AI" };
  if (input.dateError) return { lane: "CONFIRM", reason: "Date conflict in document" };
  if (!params.senderKnown) return { lane: "CONFIRM", reason: "Sender is not linked to any company or staff" };
  return { lane: "AUTO", reason: "Hard identifier, high score, unambiguous" };
}

export async function loadMatchSettings(tenantId: string): Promise<MatchSettings> {
  const [row] = await db.select().from(tenantSettings).where(eq(tenantSettings.tenantId, tenantId)).limit(1);
  return {
    autoFileEnabled: row?.autoFileEnabled === true,
    autoFileMinScore: row?.autoFileMinScore ?? 90,
  };
}

export async function loadStaffPhones(tenantId: string): Promise<string[]> {
  const [row] = await db.select().from(tenantSettings).where(eq(tenantSettings.tenantId, tenantId)).limit(1);
  return String(row?.reminderStaffPhones || "")
    .split(/[,\s;]+/)
    .map((p) => p.trim())
    .filter(Boolean);
}

/**
 * DB-backed matching. Pure scoring lives in scoreCandidates()/decideLane() so it is unit-testable.
 * `executor` is the drizzle db or a transaction.
 */
export async function matchDocumentToCompany(
  tenantId: string,
  input: MatchInput,
  senderPhone: string,
  options: { channelTrusted?: boolean; executor?: any; settings?: MatchSettings } = {},
): Promise<MatchOutcome> {
  const ex = options.executor || db;
  const comps = await ex
    .select()
    .from(companies)
    .where(and(eq(companies.tenantId, tenantId), isNull(companies.deletedAt)));
  const custs = await ex
    .select()
    .from(customers)
    .where(and(eq(customers.tenantId, tenantId), isNull(customers.deletedAt)));
  const custById = new Map<number, (typeof custs)[number]>(custs.map((c: any) => [c.id, c]));
  const rows: MatchCompanyRow[] = comps.map((c: any) => {
    const owner = c.ownerCustomerId ? custById.get(c.ownerCustomerId) : null;
    return {
      id: c.id,
      name: c.name,
      tradeName: c.tradeName,
      companyNameEn: c.companyNameEn,
      normalizedCrNumber: c.normalizedCrNumber,
      taxId: c.taxId,
      companyCode: c.companyCode,
      licenseNumber: c.licenseNumber,
      taxCardNumber: c.taxCardNumber,
      chamberNumber: c.chamberNumber,
      contactPhone: c.contactPhone,
      ownerPhones: owner ? [owner.phone, owner.whatsapp].filter(Boolean) : [],
    };
  });

  const people: MatchPersonRow[] =
    input.civilNumber || input.passportNumber
      ? (
          await ex
            .select()
            .from(companyPeople)
            .where(and(eq(companyPeople.tenantId, tenantId), isNull(companyPeople.deletedAt)))
        ).map((p: any) => ({ companyId: p.companyId, civilNumber: p.civilNumber, passportNumber: p.passportNumber }))
      : [];

  const prior = new Set<number>();
  if (senderPhone) {
    const priorDocs = await ex
      .select({ companyId: customerDocuments.companyId })
      .from(customerDocuments)
      .where(
        and(
          eq(customerDocuments.tenantId, tenantId),
          eq(customerDocuments.senderPhone, senderPhone),
          isNull(customerDocuments.deletedAt),
        ),
      );
    for (const d of priorDocs) if (d.companyId) prior.add(d.companyId);
  }

  const candidates = scoreCandidates({ input, companies: rows, people, senderPhone, priorFilingCompanyIds: prior });

  let senderKnown = Boolean(options.channelTrusted);
  if (!senderKnown && senderPhone) {
    // "Known" means: owner/contact phone of a registered company, or a configured staff number.
    // (Customers auto-created for unknown WhatsApp senders deliberately do not count.)
    senderKnown =
      rows.some((r) => phonesMatch(senderPhone, r.contactPhone) || r.ownerPhones.some((p) => phonesMatch(senderPhone, p))) ||
      (await loadStaffPhones(tenantId)).some((p) => phonesMatch(senderPhone, p));
  }

  const settings = options.settings || (await loadMatchSettings(tenantId));
  const decision = decideLane({ candidates, input, settings, senderKnown });
  return {
    lane: decision.lane,
    candidates,
    topScore: candidates[0]?.score || 0,
    laneReason: decision.reason,
    senderKnown,
  };
}

/** Builds the matcher input from the processor's extraction result (structural type, no import cycle). */
export function buildMatchInput(intel: {
  documentType: string;
  normalizedCrNumber: string | null;
  crFromFileNameOnly?: boolean;
  companyNameAr: string | null;
  companyNameEn: string | null;
  tradeName: string | null;
  licenseNumber: string | null;
  taxCardNumber: string | null;
  chamberNumber: string | null;
  personCivilNumber?: string | null;
  personPassportNumber?: string | null;
  confidenceLevel: "HIGH" | "MEDIUM" | "LOW";
  promptInjectionDetected: boolean;
  chronologicalDateError: boolean;
}): MatchInput {
  return {
    documentType: intel.documentType,
    normalizedCr: intel.normalizedCrNumber,
    crFromFileNameOnly: Boolean(intel.crFromFileNameOnly),
    companyNames: [intel.companyNameAr, intel.companyNameEn, intel.tradeName].filter(Boolean) as string[],
    licenseNumber: intel.licenseNumber,
    taxCardNumber: intel.taxCardNumber,
    chamberNumber: intel.chamberNumber,
    civilNumber: intel.personCivilNumber || null,
    passportNumber: intel.personPassportNumber || null,
    extractionLevel: intel.confidenceLevel,
    promptInjectionDetected: intel.promptInjectionDetected,
    dateError: intel.chronologicalDateError,
  };
}
