import crypto from "crypto";
import { and, asc, desc, eq, inArray, isNotNull, isNull, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  auditLogs,
  companies,
  companyPeople,
  customerDocuments,
  customers,
  documentMatchCandidates,
  notifications,
  reminderRules,
  tenantSettings,
  whatsappProcessingJobs,
} from "../../db/schema.js";
import {
  DOC_TYPES,
  DOC_TYPE_CODES,
  isPersonDocument,
  toDocTypeCode,
  type DocTypeCode,
} from "../../lib/documentTypes.js";
import { normalizeAndValidateDate } from "./crExtractionService.js";
import { classifyDocumentExpiry } from "./expiryClassification.js";
import { extractDocumentIntelligence, processIncomingWhatsAppMediaMessage, type WhatsAppProcessingResult } from "./whatsappDocumentProcessor.js";

const PRIVILEGED_ROLES = new Set(["SUPER_ADMIN", "MANAGER"]);

/** Civil / passport numbers are PII: show only the last 3 characters unless the role is MANAGER or higher. */
export function maskIdNumber(value: string | null | undefined): string | null {
  if (!value) return null;
  const v = String(value);
  if (v.length <= 3) return "•••";
  return `${"•".repeat(Math.min(6, v.length - 3))}${v.slice(-3)}`;
}

export function canSeeFullIds(role: string | undefined): boolean {
  return PRIVILEGED_ROLES.has(String(role || ""));
}

function maskFieldsJson(raw: string | null, full: boolean): unknown {
  if (!raw) return null;
  try {
    const obj = JSON.parse(raw);
    if (!full) {
      if (obj.person) {
        obj.person.civilNumber = maskIdNumber(obj.person.civilNumber);
        obj.person.passportNumber = maskIdNumber(obj.person.passportNumber);
      }
      if (obj.fields) {
        for (const k of ["civilNumber", "passportNumber"]) {
          if (k in obj.fields) obj.fields[k] = maskIdNumber(obj.fields[k] as string | null);
        }
      }
    }
    return obj;
  } catch {
    return null;
  }
}

type DocRow = typeof customerDocuments.$inferSelect;

export function toDocumentDto(row: DocRow, opts: { fullIds: boolean; companyName?: string | null }) {
  const code = (row.docTypeCode as DocTypeCode | null) || toDocTypeCode(row.docType);
  const person = isPersonDocument(code);
  return {
    id: row.id,
    companyId: row.companyId,
    companyName: opts.companyName ?? null,
    docType: row.docType,
    docTypeCode: code,
    labelAr: DOC_TYPES[code].labelAr,
    labelEn: DOC_TYPES[code].labelEn,
    isPersonDocument: person,
    docNumber: person && !opts.fullIds ? maskIdNumber(row.docNumber) : row.docNumber,
    issueDate: row.issueDate,
    expiryDate: row.expiryDate,
    hasNoExpiry: row.hasNoExpiry,
    expiryStatus: row.expiryStatus,
    needsReview: row.needsReview,
    processingStatus: row.processingStatus,
    matchLane: row.matchLane,
    matchScore: row.matchScore,
    matchConfirmedBy: row.matchConfirmedBy,
    matchConfirmedAt: row.matchConfirmedAt,
    personId: row.personId,
    versionNumber: row.versionNumber,
    previousVersionId: row.previousVersionId,
    originalFileName: row.originalFileName,
    mimeType: row.mimeType,
    sourceChannel: row.sourceChannel,
    senderPhone: row.senderPhone,
    extractionConfidence: row.extractionConfidence,
    createdAt: row.createdAt,
    fields: maskFieldsJson(row.fieldsJson, opts.fullIds),
    downloadUrl: `/api/customer-documents/${row.id}/download`,
  };
}

function httpError(status: number, code: string, message: string): Error {
  const e = new Error(message) as Error & { status?: number; code?: string };
  e.status = status;
  e.code = code;
  return e;
}

async function audit(
  tx: any,
  p: { tenantId: string; actorId: string; actorName: string; action: string; resource: string; resourceId: string; details: unknown }
) {
  await tx.insert(auditLogs).values({
    tenantId: p.tenantId,
    actorId: p.actorId,
    actorName: p.actorName,
    action: p.action,
    resource: p.resource,
    resourceId: p.resourceId,
    details: JSON.stringify(p.details),
    ipAddress: "127.0.0.1",
  });
}

/** Company-level fields that the original engine harvests from licences/certificates when a document is filed. */
async function applyDocumentToCompanyFields(tx: any, company: typeof companies.$inferSelect, doc: DocRow) {
  const upd: Partial<typeof companies.$inferInsert> = {};
  const crNorm = company.normalizedCrNumber;
  if (doc.docType === "municipal_license") {
    if (doc.expiryDate && (!company.licenseExpiryDate || doc.expiryDate >= company.licenseExpiryDate)) upd.licenseExpiryDate = doc.expiryDate;
    if (doc.docNumber && doc.docNumber !== crNorm) upd.licenseNumber = doc.docNumber;
  } else if (doc.docType === "tax_certificate") {
    if (doc.docNumber && doc.docNumber !== crNorm) upd.taxCardNumber = doc.docNumber;
  } else if (doc.docType === "chamber_certificate") {
    if (doc.docNumber && doc.docNumber !== crNorm) upd.chamberNumber = doc.docNumber;
  } else if (doc.docType === "commercial_registry") {
    if (doc.expiryDate && (!company.crExpiryDate || doc.expiryDate >= company.crExpiryDate)) upd.crExpiryDate = doc.expiryDate;
  }
  if (Object.keys(upd).length) {
    upd.updatedAt = new Date();
    await tx.update(companies).set(upd).where(eq(companies.id, company.id));
  }
}

async function loadCompany(tx: any, tenantId: string, companyId: number) {
  const [c] = await tx
    .select()
    .from(companies)
    .where(and(eq(companies.id, companyId), eq(companies.tenantId, tenantId), isNull(companies.deletedAt)))
    .limit(1);
  if (!c) throw httpError(422, "INVALID_TENANT_REFERENCE", `Company ${companyId} does not exist in this tenant`);
  return c as typeof companies.$inferSelect;
}

async function loadDoc(tx: any, tenantId: string, documentId: number) {
  const [d] = await tx
    .select()
    .from(customerDocuments)
    .where(and(eq(customerDocuments.id, documentId), eq(customerDocuments.tenantId, tenantId), isNull(customerDocuments.deletedAt)))
    .limit(1);
  if (!d) throw httpError(404, "DOCUMENT_NOT_FOUND", "Document not found");
  return d as DocRow;
}

export interface Actor {
  userId: string;
  name: string;
}

/**
 * Attach a held (inbox) or already filed document to a company.
 * mode "confirm": document must be in the inbox (no company yet). mode "move": document must already be filed.
 * Versioning is recomputed against the target company, and an audit row records from/to company and score.
 */
async function attachDocumentToCompany(
  tenantId: string,
  documentId: number,
  companyId: number,
  actor: Actor,
  mode: "confirm" | "move"
) {
  return db.transaction(async (tx) => {
    const doc = await loadDoc(tx, tenantId, documentId);
    if (mode === "confirm" && doc.companyId) throw httpError(409, "ALREADY_FILED", "Document is already filed under a company; use move");
    if (mode === "move" && !doc.companyId) throw httpError(409, "NOT_FILED", "Document is not filed yet; use confirm-match");
    if (mode === "move" && doc.companyId === companyId) throw httpError(409, "SAME_COMPANY", "Document is already under this company");
    const company = await loadCompany(tx, tenantId, companyId);

    const code = (doc.docTypeCode as DocTypeCode | null) || toDocTypeCode(doc.docType);
    const person = isPersonDocument(code);
    const sameKind = await tx
      .select()
      .from(customerDocuments)
      .where(
        and(
          eq(customerDocuments.tenantId, tenantId),
          eq(customerDocuments.companyId, companyId),
          eq(customerDocuments.docType, doc.docType),
          isNull(customerDocuments.deletedAt),
          ...(person ? [doc.docNumber ? eq(customerDocuments.docNumber, doc.docNumber) : sql`false`] : [])
        )
      )
      .orderBy(desc(customerDocuments.versionNumber), desc(customerDocuments.id));
    const prev = sameKind.find((d: DocRow) => d.id !== doc.id) || null;

    // Same file already filed under the target company: do not create a duplicate row.
    if (doc.sha256) {
      const dup = sameKind.find((d: DocRow) => d.id !== doc.id && d.sha256 === doc.sha256);
      if (dup) throw httpError(409, "DUPLICATE_FILE", "The same file is already stored under this company");
    }

    const expClass = classifyDocumentExpiry({ expiryDate: doc.expiryDate, hasNoExpiry: doc.hasNoExpiry });
    const fromCompanyId = doc.companyId;
    const targetCustomerId = company.ownerCustomerId || doc.customerId;
    const now = new Date();
    const [updated] = await tx
      .update(customerDocuments)
      .set({
        companyId,
        customerId: targetCustomerId,
        matchLane: "MANUAL",
        matchConfirmedBy: actor.name,
        matchConfirmedAt: now,
        versionNumber: prev ? (prev.versionNumber || 1) + 1 : 1,
        previousVersionId: prev ? prev.id : null,
        expiryStatus: expClass.status,
        needsReview: expClass.needsReview,
        processingStatus: expClass.needsReview ? "NEEDS_REVIEW" : "COMPLETED",
        updatedAt: now,
      })
      .where(eq(customerDocuments.id, doc.id))
      .returning();

    let meta: any = null;
    try {
      meta = doc.extractedMetadataJson ? JSON.parse(doc.extractedMetadataJson) : null;
    } catch {
      meta = null;
    }
    if (person) {
      const civil = meta?.personCivilNumber || null;
      const pass = meta?.personPassportNumber || null;
      if (civil || pass) {
        const people = await tx
          .select()
          .from(companyPeople)
          .where(and(eq(companyPeople.tenantId, tenantId), eq(companyPeople.companyId, companyId), isNull(companyPeople.deletedAt)));
        let p = people.find((x: any) => (civil && x.civilNumber === civil) || (pass && x.passportNumber === pass));
        if (!p) {
          [p] = await tx
            .insert(companyPeople)
            .values({ tenantId, companyId, fullName: meta?.personName || civil || pass, role: "EMPLOYEE", civilNumber: civil, passportNumber: pass })
            .returning();
        }
        await tx.update(customerDocuments).set({ personId: p.id }).where(eq(customerDocuments.id, doc.id));
      }
    }
    await applyDocumentToCompanyFields(tx, company, updated);

    // Keep the job row consistent so the WhatsApp processing history shows the final company.
    await tx
      .update(whatsappProcessingJobs)
      .set({ matchedCompanyId: companyId, companyMatchResolution: "MATCHED_EXISTING_COMPANY", state: expClass.needsReview ? "NEEDS_REVIEW" : "COMPLETED", updatedAt: now })
      .where(and(eq(whatsappProcessingJobs.tenantId, tenantId), eq(whatsappProcessingJobs.savedDocumentId, doc.id)));

    // Mark the inbox notification as handled.
    await tx
      .update(notifications)
      .set({ isRead: true, readAt: now, readBy: actor.name })
      .where(and(eq(notifications.tenantId, tenantId), eq(notifications.idempotencyKey, `doc-confirm:${tenantId}:${doc.id}`)));

    await audit(tx, {
      tenantId,
      actorId: actor.userId,
      actorName: actor.name,
      action: mode === "confirm" ? "VAULT_CONFIRM_MATCH" : "VAULT_MOVE_DOCUMENT",
      resource: "customer_documents",
      resourceId: String(doc.id),
      details: {
        documentId: doc.id,
        fromCompanyId,
        toCompanyId: companyId,
        score: doc.matchScore,
        previousLane: doc.matchLane,
        versionNumber: updated.versionNumber,
        previousVersionId: updated.previousVersionId,
      },
    });
    return updated;
  });
}

export const confirmDocumentMatch = (t: string, id: number, companyId: number, a: Actor) =>
  attachDocumentToCompany(t, id, companyId, a, "confirm");
export const moveDocumentToCompany = (t: string, id: number, companyId: number, a: Actor) =>
  attachDocumentToCompany(t, id, companyId, a, "move");

export async function rejectDocument(tenantId: string, documentId: number, actor: Actor, reason?: string) {
  return db.transaction(async (tx) => {
    const doc = await loadDoc(tx, tenantId, documentId);
    const now = new Date();
    await tx
      .update(customerDocuments)
      .set({ deletedAt: now, processingStatus: "REJECTED", updatedAt: now })
      .where(eq(customerDocuments.id, doc.id));
    await tx
      .update(whatsappProcessingJobs)
      .set({ state: "REJECTED", updatedAt: now })
      .where(and(eq(whatsappProcessingJobs.tenantId, tenantId), eq(whatsappProcessingJobs.savedDocumentId, doc.id)));
    await tx
      .update(notifications)
      .set({ isRead: true, readAt: now, readBy: actor.name })
      .where(and(eq(notifications.tenantId, tenantId), eq(notifications.idempotencyKey, `doc-confirm:${tenantId}:${doc.id}`)));
    await audit(tx, {
      tenantId,
      actorId: actor.userId,
      actorName: actor.name,
      action: "VAULT_REJECT_DOCUMENT",
      resource: "customer_documents",
      resourceId: String(doc.id),
      details: { documentId: doc.id, companyId: doc.companyId, score: doc.matchScore, reason: reason || null },
    });
    return { id: doc.id };
  });
}

export interface FieldEdit {
  docTypeCode?: DocTypeCode;
  docNumber?: string | null;
  issueDate?: string | null;
  expiryDate?: string | null;
  hasNoExpiry?: boolean;
  personName?: string | null;
  civilNumber?: string | null;
  passportNumber?: string | null;
}

/** Staff correction of extracted fields. Dates are validated; a clean edit clears needs_review. */
export async function updateDocumentFields(tenantId: string, documentId: number, edit: FieldEdit, actor: Actor) {
  return db.transaction(async (tx) => {
    const doc = await loadDoc(tx, tenantId, documentId);
    const set: Partial<typeof customerDocuments.$inferInsert> = { updatedAt: new Date() };
    const changed: string[] = [];
    if (edit.docTypeCode && edit.docTypeCode !== doc.docTypeCode) {
      set.docTypeCode = edit.docTypeCode;
      set.docType = edit.docTypeCode.toLowerCase();
      changed.push("docTypeCode");
    }
    if (edit.docNumber !== undefined) {
      set.docNumber = edit.docNumber;
      changed.push("docNumber");
    }
    const issue = edit.issueDate === undefined ? doc.issueDate : edit.issueDate === null ? null : normalizeAndValidateDate(edit.issueDate);
    const expiry = edit.expiryDate === undefined ? doc.expiryDate : edit.expiryDate === null ? null : normalizeAndValidateDate(edit.expiryDate);
    if (edit.issueDate && !issue) throw httpError(400, "INVALID_DATE", "تاريخ الإصدار غير صالح");
    if (edit.expiryDate && !expiry) throw httpError(400, "INVALID_DATE", "تاريخ الانتهاء غير صالح");
    if (issue && expiry && expiry < issue) throw httpError(400, "EXPIRY_BEFORE_ISSUE", "تاريخ الانتهاء قبل تاريخ الإصدار");
    if (edit.issueDate !== undefined) {
      set.issueDate = issue;
      changed.push("issueDate");
    }
    if (edit.expiryDate !== undefined) {
      set.expiryDate = expiry;
      changed.push("expiryDate");
    }
    if (edit.hasNoExpiry !== undefined) {
      set.hasNoExpiry = edit.hasNoExpiry;
      changed.push("hasNoExpiry");
    }
    const hasNoExpiry = edit.hasNoExpiry ?? doc.hasNoExpiry;
    const expClass = classifyDocumentExpiry({ expiryDate: expiry, hasNoExpiry });
    set.expiryStatus = expClass.status;
    set.needsReview = expClass.needsReview;
    if (doc.companyId) set.processingStatus = expClass.needsReview ? "NEEDS_REVIEW" : "COMPLETED";

    if (edit.personName !== undefined || edit.civilNumber !== undefined || edit.passportNumber !== undefined) {
      let f: any = {};
      try {
        f = doc.fieldsJson ? JSON.parse(doc.fieldsJson) : {};
      } catch {
        f = {};
      }
      f.person = { ...(f.person || {}) };
      if (edit.personName !== undefined) f.person.fullName = edit.personName;
      if (edit.civilNumber !== undefined) f.person.civilNumber = edit.civilNumber;
      if (edit.passportNumber !== undefined) f.person.passportNumber = edit.passportNumber;
      f.edited = { by: actor.name, at: new Date().toISOString(), method: "manual" };
      set.fieldsJson = JSON.stringify(f);
      changed.push("person");
    }
    const [updated] = await tx.update(customerDocuments).set(set).where(eq(customerDocuments.id, doc.id)).returning();
    // Field names only, never the values (they can be civil / passport numbers).
    await audit(tx, {
      tenantId,
      actorId: actor.userId,
      actorName: actor.name,
      action: "VAULT_EDIT_FIELDS",
      resource: "customer_documents",
      resourceId: String(doc.id),
      details: { documentId: doc.id, companyId: doc.companyId, changedFields: changed },
    });
    return updated;
  });
}

export async function listInbox(tenantId: string, fullIds: boolean) {
  const rows = await db
    .select()
    .from(customerDocuments)
    .where(
      and(
        eq(customerDocuments.tenantId, tenantId),
        isNull(customerDocuments.companyId),
        isNull(customerDocuments.deletedAt),
        isNotNull(customerDocuments.matchLane)
      )
    )
    .orderBy(desc(customerDocuments.createdAt), desc(customerDocuments.id))
    .limit(200);
  if (rows.length === 0) return [];
  const cands = await db
    .select()
    .from(documentMatchCandidates)
    .where(and(eq(documentMatchCandidates.tenantId, tenantId), inArray(documentMatchCandidates.documentId, rows.map((r) => r.id))))
    .orderBy(asc(documentMatchCandidates.rank));
  const companyIds = [...new Set(cands.map((c) => c.companyId))];
  const comps = companyIds.length
    ? await db.select({ id: companies.id, name: companies.name, normalizedCrNumber: companies.normalizedCrNumber }).from(companies).where(and(eq(companies.tenantId, tenantId), inArray(companies.id, companyIds)))
    : [];
  const compById = new Map(comps.map((c) => [c.id, c]));
  return rows.map((r) => ({
    ...toDocumentDto(r, { fullIds }),
    candidates: cands
      .filter((c) => c.documentId === r.id)
      .map((c) => {
        let reasons: unknown = [];
        let laneReason: string | null = null;
        try {
          const p = JSON.parse(c.reasonsJson);
          reasons = (p.reasons || []).map((x: any) => ({ code: x.code, points: x.points, detail: x.detail }));
          laneReason = p.laneReason || null;
        } catch {
          /* ignore */
        }
        return {
          companyId: c.companyId,
          companyName: compById.get(c.companyId)?.name || null,
          score: c.score,
          rank: c.rank,
          reasons,
          laneReason,
        };
      }),
  }));
}

export async function listCompanyVault(tenantId: string, companyId: number, fullIds: boolean) {
  const company = await loadCompany(db, tenantId, companyId);
  const rows = await db
    .select()
    .from(customerDocuments)
    .where(and(eq(customerDocuments.tenantId, tenantId), eq(customerDocuments.companyId, companyId), isNull(customerDocuments.deletedAt)))
    .orderBy(desc(customerDocuments.versionNumber), desc(customerDocuments.id));
  const supersededIds = new Set(rows.map((r) => r.previousVersionId).filter((x): x is number => Boolean(x)));
  const items = rows.map((r) => ({
    ...toDocumentDto(r, { fullIds, companyName: company.name }),
    isLatestVersion: !supersededIds.has(r.id),
  }));
  const groups: Record<string, typeof items> = {};
  for (const it of items) (groups[it.docTypeCode] ||= []).push(it);
  const people = await db
    .select()
    .from(companyPeople)
    .where(and(eq(companyPeople.tenantId, tenantId), eq(companyPeople.companyId, companyId), isNull(companyPeople.deletedAt)));
  return {
    company: {
      id: company.id,
      name: company.name,
      clientRemindersEnabled: company.clientRemindersEnabled,
      clientReminderConsentAt: company.clientReminderConsentAt,
    },
    groups: Object.entries(groups).map(([code, docs]) => ({
      docTypeCode: code,
      labelAr: DOC_TYPES[code as DocTypeCode]?.labelAr || code,
      documents: docs,
    })),
    people: people.map((p) => ({
      id: p.id,
      fullName: p.fullName,
      role: p.role,
      nationality: p.nationality,
      civilNumber: fullIds ? p.civilNumber : maskIdNumber(p.civilNumber),
      passportNumber: fullIds ? p.passportNumber : maskIdNumber(p.passportNumber),
    })),
  };
}

export async function listExpiring(tenantId: string, days: number, fullIds: boolean, today = new Date()) {
  const rows = await db
    .select()
    .from(customerDocuments)
    .where(
      and(
        eq(customerDocuments.tenantId, tenantId),
        isNotNull(customerDocuments.companyId),
        isNotNull(customerDocuments.expiryDate),
        isNull(customerDocuments.deletedAt)
      )
    );
  const supersededIds = new Set(rows.map((r) => r.previousVersionId).filter((x): x is number => Boolean(x)));
  const todayIso = new Date(today.getTime() + 4 * 3600_000).toISOString().slice(0, 10); // Asia/Muscat (UTC+4)
  const limitIso = new Date(today.getTime() + 4 * 3600_000 + days * 86400_000).toISOString().slice(0, 10);
  const comps = await db.select({ id: companies.id, name: companies.name }).from(companies).where(eq(companies.tenantId, tenantId));
  const nameById = new Map(comps.map((c) => [c.id, c.name]));
  return rows
    .filter((r) => !supersededIds.has(r.id) && r.expiryDate! <= limitIso && !r.hasNoExpiry)
    .sort((a, b) => a.expiryDate!.localeCompare(b.expiryDate!))
    .map((r) => ({
      ...toDocumentDto(r, { fullIds, companyName: nameById.get(r.companyId!) || null }),
      daysRemaining: Math.round((Date.parse(r.expiryDate!) - Date.parse(todayIso)) / 86400_000),
    }));
}

// ---------------------------------------------------------------------------------------------
// Reminder rules and company-level client reminder consent
// ---------------------------------------------------------------------------------------------

export async function getReminderRules(tenantId: string) {
  const stored = await db.select().from(reminderRules).where(eq(reminderRules.tenantId, tenantId));
  const byCode = new Map(stored.map((r) => [r.docTypeCode, r]));
  const [settings] = await db.select().from(tenantSettings).where(eq(tenantSettings.tenantId, tenantId)).limit(1);
  return {
    rules: DOC_TYPE_CODES.filter((c) => DOC_TYPES[c].hasExpiry).map((code) => {
      const r = byCode.get(code);
      return {
        docTypeCode: code,
        labelAr: DOC_TYPES[code].labelAr,
        offsetsDays: r ? (JSON.parse(r.offsetsDaysJson) as number[]) : DOC_TYPES[code].defaultReminderOffsets,
        notifyStaff: r ? r.notifyStaff : true,
        notifyClient: r ? r.notifyClient : false,
        active: r ? r.active : true,
        isDefault: !r,
      };
    }),
    settings: {
      autoFileEnabled: settings?.autoFileEnabled === true,
      autoFileMinScore: settings?.autoFileMinScore ?? 90,
      reminderStaffPhones: settings?.reminderStaffPhones || "",
    },
  };
}

export interface RulesUpdate {
  rules?: Array<{ docTypeCode: DocTypeCode; offsetsDays: number[]; notifyStaff?: boolean; notifyClient?: boolean; active?: boolean }>;
  settings?: { autoFileEnabled?: boolean; autoFileMinScore?: number; reminderStaffPhones?: string };
}

export async function updateReminderRules(tenantId: string, upd: RulesUpdate, actor: Actor) {
  await db.transaction(async (tx) => {
    for (const r of upd.rules || []) {
      const offsets = [...new Set(r.offsetsDays)].sort((a, b) => b - a);
      await tx
        .insert(reminderRules)
        .values({
          tenantId,
          docTypeCode: r.docTypeCode,
          offsetsDaysJson: JSON.stringify(offsets),
          notifyStaff: r.notifyStaff ?? true,
          notifyClient: r.notifyClient ?? false,
          active: r.active ?? true,
        })
        .onConflictDoUpdate({
          target: [reminderRules.tenantId, reminderRules.docTypeCode],
          set: {
            offsetsDaysJson: JSON.stringify(offsets),
            notifyStaff: r.notifyStaff ?? true,
            notifyClient: r.notifyClient ?? false,
            active: r.active ?? true,
          },
        });
    }
    if (upd.settings) {
      const s = upd.settings;
      await tx
        .insert(tenantSettings)
        .values({
          tenantId,
          autoFileEnabled: s.autoFileEnabled ?? false,
          autoFileMinScore: s.autoFileMinScore ?? 90,
          reminderStaffPhones: s.reminderStaffPhones ?? null,
        })
        .onConflictDoUpdate({
          target: tenantSettings.tenantId,
          set: {
            ...(s.autoFileEnabled !== undefined ? { autoFileEnabled: s.autoFileEnabled } : {}),
            ...(s.autoFileMinScore !== undefined ? { autoFileMinScore: s.autoFileMinScore } : {}),
            ...(s.reminderStaffPhones !== undefined ? { reminderStaffPhones: s.reminderStaffPhones } : {}),
            updatedAt: new Date(),
          },
        });
    }
    await audit(tx, {
      tenantId,
      actorId: actor.userId,
      actorName: actor.name,
      action: "VAULT_SETTINGS_UPDATE",
      resource: "tenant_settings",
      resourceId: tenantId,
      details: {
        rulesChanged: (upd.rules || []).map((r) => r.docTypeCode),
        settingsChanged: Object.keys(upd.settings || {}),
        autoFileEnabled: upd.settings?.autoFileEnabled,
      },
    });
  });
  return getReminderRules(tenantId);
}

export async function setCompanyClientReminders(tenantId: string, companyId: number, enabled: boolean, consentGiven: boolean, actor: Actor) {
  return db.transaction(async (tx) => {
    const company = await loadCompany(tx, tenantId, companyId);
    if (enabled && !consentGiven && !company.clientReminderConsentAt) {
      throw httpError(400, "CONSENT_REQUIRED", "Client reminders need the client's recorded consent");
    }
    const now = new Date();
    const consentAt = enabled ? (consentGiven ? now : company.clientReminderConsentAt) : null;
    await tx
      .update(companies)
      .set({ clientRemindersEnabled: enabled, clientReminderConsentAt: consentAt, updatedAt: now })
      .where(eq(companies.id, companyId));
    await audit(tx, {
      tenantId,
      actorId: actor.userId,
      actorName: actor.name,
      action: "VAULT_CLIENT_REMINDERS",
      resource: "companies",
      resourceId: String(companyId),
      details: { companyId, enabled, consentRecorded: Boolean(consentAt) },
    });
    return { companyId, clientRemindersEnabled: enabled, clientReminderConsentAt: consentAt };
  });
}

// ---------------------------------------------------------------------------------------------
// Ingestion from the app (manual upload and in-app chatbot): same pipeline as WhatsApp
// ---------------------------------------------------------------------------------------------

export async function ingestAppDocument(params: {
  tenantId: string;
  channel: "CHAT" | "WEB";
  buffer: Buffer;
  fileName: string;
  mimeType: string;
  actorName: string;
  forcedCompanyId?: number | null;
  messageText?: string;
}): Promise<WhatsAppProcessingResult> {
  return processIncomingWhatsAppMediaMessage({
    tenantId: params.tenantId,
    providerMessageId: `${params.channel.toLowerCase()}:${crypto.randomUUID()}`,
    senderPhone: "",
    fileName: params.fileName,
    declaredMimeType: params.mimeType,
    mediaBuffer: params.buffer,
    messageText: params.messageText,
    channel: params.channel,
    forcedCompanyId: params.forcedCompanyId ?? null,
    actorName: params.actorName,
  });
}


/**
 * In-app chatbot entry point. Same pipeline as WhatsApp (processIncomingWhatsAppMediaMessage).
 * Returns the reply text, or null when the attachment is a commercial registration (or unreadable):
 * those keep the existing verified-CR chat flow so company registration behaves exactly as before.
 */
export async function tryChatDocumentIngest(
  attachment: { name?: string; mimeType?: string; data?: string } | null | undefined,
  tenantId: string,
  actorName: string,
): Promise<string | null> {
  if (!attachment?.data) return null;
  const buffer = Buffer.from(attachment.data.replace(/^data:[^;]+;base64,/, ""), "base64");
  if (buffer.length === 0) return null;
  const fileName = attachment.name || "chat-upload";
  const mimeType = attachment.mimeType || "application/pdf";
  const intel = await extractDocumentIntelligence(buffer, mimeType, undefined, fileName);
  if (intel.documentType === "commercial_registry") return null;
  const result = await ingestAppDocument({ tenantId, channel: "CHAT", buffer, fileName, mimeType, actorName });
  return result.replyMessageText || null;
}
