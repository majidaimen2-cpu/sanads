import fs from "fs";
import path from "path";
import pino from "pino";
import { downloadMediaMessage, type WASocket } from "@whiskeysockets/baileys";
import { db } from "../../db/index.js";
import { whatsappMessages } from "../../db/schema.js";
import { requestService } from "./requestService.js";
import { processIncomingWhatsAppMediaMessage } from "./whatsappDocumentProcessor.js";
import {
  MEDIA_DIR,
  MAX_MEDIA_DOWNLOAD_BYTES,
  MAX_MESSAGES_PER_CHAT,
  resolveConfinedMediaPath,
  normalizeWhatsAppPhone,
  isAutoConfirmationMessageText,
  unwrapBaileysMessageContent,
  extractBaileysMessageText,
  buildLocalInitialsAvatarSvg,
  ensureCustomerRegisteredInDb,
  type ChatItem,
  type MessageItem,
  type MediaIndexEntry,
  type GatewayState,
} from "./whatsappTypesAndStorage.js";
import { handleReminderStopKeyword, isStopKeyword } from "./reminderService.js";
import { logger } from "../logger.js";

export interface RawBaileysMessage {
  key?: {
    id?: string | null;
    remoteJid?: string | null;
    fromMe?: boolean | null;
  };
  message?: Record<string, unknown> | null;
  messageTimestamp?: number | { low?: number } | null;
  pushName?: string | null;
  mediaBuffer?: Buffer | null;
  base64Data?: string | null;
}

export interface WhatsAppPipelineContext {
  getSock(): WASocket | null;
  getState(): GatewayState;
  getTenantId(): string;
  getInstanceId(): string;
  chats: ChatItem[];
  messages: Record<string, MessageItem[]>;
  contacts: Record<string, string>;
  mediaIndex: Record<string, MediaIndexEntry>;
  pendingOutboundIds: Set<string>;
  pendingOutboundFingerprints: Map<string, number>;
  loadData(): void;
  saveChatsToFile(): void;
  saveMessagesToFile(): void;
  saveMediaIndexToFile(): void;
}

export function makeOutboundFingerprint(jid: string, text: string): string {
  return `${jid.split("@")[0]}::${text.trim().slice(0, 120)}`;
}

export function appendMessageWithCap(
  ctx: WhatsAppPipelineContext,
  chatId: string,
  msg: MessageItem,
): void {
  if (!ctx.messages[chatId]) {
    ctx.messages[chatId] = [];
  }
  ctx.messages[chatId].push(msg);
  if (ctx.messages[chatId].length > MAX_MESSAGES_PER_CHAT) {
    ctx.messages[chatId] = ctx.messages[chatId].slice(-MAX_MESSAGES_PER_CHAT);
  }
}

export function saveMediaForMessageInStore(
  ctx: WhatsAppPipelineContext,
  msgId: string,
  fileName: string,
  mimeType: string,
  buffer: Buffer,
): { mediaUrl: string; fileName: string; mimeType: string; fileSize: number } {
  const safeId = String(msgId || `m_${Date.now()}`).replace(
    /[^a-zA-Z0-9_-]/g,
    "_",
  );
  const safeName = path
    .basename(String(fileName || "document.pdf"))
    .replace(/[^a-zA-Z0-9._\u0600-\u06FF-]/g, "_");
  const diskPath = resolveConfinedMediaPath(`${safeId}__${safeName}`);

  if (diskPath) {
    try {
      fs.writeFileSync(diskPath, buffer);
      const entry: MediaIndexEntry = {
        filePath: diskPath,
        fileName: safeName,
        mimeType: mimeType || "application/pdf",
        fileSize: buffer.length,
        tenantId: ctx.getTenantId(),
      };
      ctx.mediaIndex[msgId] = entry;
      ctx.saveMediaIndexToFile();
    } catch (err) {
      logger.warn({ err }, "Failed to save WhatsApp media file");
    }
  }

  return {
    mediaUrl: `/api/whatsapp/media/${encodeURIComponent(msgId)}`,
    fileName: safeName,
    mimeType: mimeType || "application/pdf",
    fileSize: buffer.length,
  };
}

export function getMediaForMessageFromStore(
  ctx: WhatsAppPipelineContext,
  msgId: string,
  fallbackFileName?: string,
  callerTenantId?: string,
): { buffer: Buffer; fileName: string; mimeType: string } | null {
  ctx.loadData();
  const indexed = ctx.mediaIndex[msgId];
  // Fix #50: Enforce tenant isolation on mediaIndex lookup when callerTenantId is provided
  if (
    callerTenantId &&
    indexed?.tenantId &&
    indexed.tenantId !== callerTenantId
  ) {
    return null;
  }

  if (indexed && indexed.filePath) {
    const confined = resolveConfinedMediaPath(path.basename(indexed.filePath));
    if (confined && fs.existsSync(confined)) {
      return {
        buffer: fs.readFileSync(confined),
        fileName: path.basename(indexed.fileName),
        mimeType: indexed.mimeType,
      };
    }
  }

  let msgItem: MessageItem | undefined;
  for (const list of Object.values(ctx.messages)) {
    const found = list.find((m) => m.id === msgId);
    if (found) {
      msgItem = found;
      break;
    }
  }

  const candidateName = path.basename(
    fallbackFileName ||
      msgItem?.fileName ||
      msgItem?.text
        ?.match(/\[(?:ملف مرفق|مستند مرفق|صورة مرفقة):\s*([^\]]+)\]/)?.[1]
        ?.trim() ||
      "",
  );

  const inferMime = (name: string): string => {
    const lower = name.toLowerCase();
    if (lower.endsWith(".png")) return "image/png";
    if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
    if (lower.endsWith(".webp")) return "image/webp";
    if (lower.endsWith(".gif")) return "image/gif";
    if (lower.endsWith(".txt")) return "text/plain; charset=utf-8";
    return "application/pdf";
  };

  if (fs.existsSync(MEDIA_DIR)) {
    const safeId = String(msgId).replace(/[^a-zA-Z0-9_-]/g, "_");
    const files = fs.readdirSync(MEDIA_DIR);
    const matchById = files.find((f) => f.startsWith(`${safeId}__`));
    if (matchById) {
      const full = resolveConfinedMediaPath(matchById);
      if (full && fs.existsSync(full)) {
        const extractedName =
          matchById.split("__").slice(1).join("__") ||
          candidateName ||
          "document.pdf";
        return {
          buffer: fs.readFileSync(full),
          fileName: candidateName || extractedName,
          mimeType: msgItem?.mimeType || inferMime(extractedName),
        };
      }
    }
    if (candidateName) {
      const safeCand = candidateName.replace(
        /[^a-zA-Z0-9._\u0600-\u06FF-]/g,
        "_",
      );
      const matchByName = files.find(
        (f) => f.endsWith(safeCand) || f.includes(safeCand),
      );
      if (matchByName) {
        const full = resolveConfinedMediaPath(matchByName);
        if (full && fs.existsSync(full)) {
          return {
            buffer: fs.readFileSync(full),
            fileName: candidateName,
            mimeType: msgItem?.mimeType || inferMime(candidateName),
          };
        }
      }
    }
  }

  return null;
}

export function upsertChatFromJidInStore(
  ctx: WhatsAppPipelineContext,
  jid: string,
  data: Partial<ChatItem> & { unreadIncrement?: number },
): ChatItem {
  const isGroup = jid.endsWith("@g.us");
  const rawNumber = isGroup
    ? jid.split("@")[0]?.replace(/[^0-9]/g, "") || ""
    : normalizeWhatsAppPhone(jid.split("@")[0] || "");
  const chatId = `chat-${rawNumber || jid.replace(/[^a-zA-Z0-9]/g, "_")}`;
  const formattedPhone = isGroup
    ? "مجموعة واتساب"
    : data.contactNumber || (rawNumber ? `+${rawNumber}` : "unknown");

  let chat = ctx.chats.find((c) => c.id === chatId || c.jid === jid);
  if (!chat) {
    const defaultName = isGroup
      ? `مجموعة (${rawNumber})`
      : `متعامل (${formattedPhone})`;
    const name = data.contactName || ctx.contacts[jid] || defaultName;
    // Fix #88 & #89: Render local SVG initials avatar instead of ui-avatars.com, and avoid fake office companyName on every chat
    chat = {
      id: chatId,
      jid,
      contactName: name,
      contactNumber: formattedPhone,
      lastMessage: data.lastMessage || "",
      lastMessageTime: data.lastMessageTime || new Date().toISOString(),
      unreadCount: data.unreadCount ?? (data.unreadIncrement || 0),
      tags: [isGroup ? "مجموعة" : "واتساب متزامن", "محادثة حقيقية"],
      avatarUrl: buildLocalInitialsAvatarSvg(name),
      instanceId: ctx.getInstanceId(),
      companyName: data.companyName || "",
      isRealSync: true,
    };
    ctx.chats.unshift(chat);
  } else {
    if (data.contactName && data.contactName !== formattedPhone) {
      chat.contactName = data.contactName;
      chat.avatarUrl = buildLocalInitialsAvatarSvg(data.contactName);
    }
    if (data.companyName) chat.companyName = data.companyName;
    if (data.lastMessage) chat.lastMessage = data.lastMessage;
    if (data.lastMessageTime) chat.lastMessageTime = data.lastMessageTime;
    if (data.unreadCount !== undefined) {
      chat.unreadCount = data.unreadCount;
    } else if (data.unreadIncrement) {
      chat.unreadCount = (chat.unreadCount || 0) + data.unreadIncrement;
    }
    ctx.chats = [chat, ...ctx.chats.filter((c) => c.id !== chat!.id)];
  }
  return chat;
}

export function markChatAsReadInStore(
  ctx: WhatsAppPipelineContext,
  chatId: string,
): void {
  const chat = ctx.chats.find((c) => c.id === chatId || c.jid === chatId);
  if (chat && chat.unreadCount > 0) {
    chat.unreadCount = 0;
    ctx.saveChatsToFile();
    const sock = ctx.getSock();
    if (sock && chat.jid) {
      // Fix #87: Pass the real message ID of the last inbound message to readMessages
      const chatMsgs = ctx.messages[chat.id] || [];
      const lastInbound = [...chatMsgs].reverse().find((m) => !m.fromMe && m.id);
      if (lastInbound && lastInbound.id) {
        sock
          .readMessages([{ remoteJid: chat.jid, id: lastInbound.id, fromMe: false }])
          .catch((err) => {
            logger.debug({ err, chatId }, "WhatsApp readMessages notice");
          });
      }
    }
  }
}

export async function processRawBaileysMessage(
  ctx: WhatsAppPipelineContext,
  msg: RawBaileysMessage,
  triggerAi = true,
): Promise<void> {
  const fromJid = msg.key?.remoteJid;
  // Fix #71: Ignore group chats (@g.us) unless explicitly enabled via WHATSAPP_ALLOW_GROUPS=true
  const allowGroups = process.env.WHATSAPP_ALLOW_GROUPS === "true";
  if (
    !fromJid ||
    fromJid.includes("@broadcast") ||
    fromJid.includes("@newsletter") ||
    (!allowGroups && fromJid.endsWith("@g.us"))
  ) {
    return;
  }

  const m = unwrapBaileysMessageContent(msg.message);
  const docMsg = (m.documentMessage ||
    (msg.message as Record<string, unknown> | undefined)?.documentMessage ||
    null) as {
    fileName?: string;
    title?: string;
    mimetype?: string;
    fileLength?: number | string | { low?: number };
  } | null;

  const imgMsg = (m.imageMessage ||
    (msg.message as Record<string, unknown> | undefined)?.imageMessage ||
    null) as {
    mimetype?: string;
    fileLength?: number | string | { low?: number };
  } | null;

  const isMediaDocumentOrImage = Boolean(docMsg || imgMsg);
  const msgId = msg.key?.id || `m-${Date.now()}`;
  const declaredFileName =
    docMsg?.fileName ||
    docMsg?.title ||
    (imgMsg ? `whatsapp_image_${msgId}.jpg` : undefined);
  const declaredMimeType =
    docMsg?.mimetype ||
    imgMsg?.mimetype ||
    (docMsg ? "application/pdf" : imgMsg ? "image/jpeg" : undefined);

  let text = extractBaileysMessageText(msg);
  if (!text && isMediaDocumentOrImage) {
    text = declaredFileName
      ? `📄 [ملف مرفق: ${declaredFileName}]`
      : docMsg
        ? "📄 [مستند مرفق]"
        : "📷 [صورة مرفقة]";
  }
  if (!text || isAutoConfirmationMessageText(text)) return;

  const fromMe = Boolean(msg.key?.fromMe);
  // Fix #78: Deduplicate outbound echo messages before sendMessage resolves
  if (fromMe) {
    if (ctx.pendingOutboundIds.has(msgId)) return;
    const fp = makeOutboundFingerprint(fromJid, text);
    const pendingTs = ctx.pendingOutboundFingerprints.get(fp);
    if (pendingTs && Date.now() - pendingTs < 15_000) {
      ctx.pendingOutboundFingerprints.delete(fp);
      ctx.pendingOutboundIds.add(msgId);
      return;
    }
  }

  if (
    isMediaDocumentOrImage &&
    declaredFileName &&
    !text.includes("[ملف مرفق:")
  ) {
    text =
      text === "📄 [مستند مرفق]" ||
      text === "📷 [صورة مرفقة]" ||
      text === declaredFileName
        ? `📄 [ملف مرفق: ${declaredFileName}]`
        : `${text}\n📄 [ملف مرفق: ${declaredFileName}]`;
  }

  const rawNumber = normalizeWhatsAppPhone(fromJid.split("@")[0] || "");
  if (!rawNumber) return;
  const formattedPhone = `+${rawNumber}`;

  let registeredCust: {
    customerId?: number;
    customerName: string;
    companyName?: string;
  } | null = null;
  if (!fromMe) {
    registeredCust = await ensureCustomerRegisteredInDb(
      ctx.getTenantId(),
      formattedPhone,
      msg.pushName || ctx.contacts[fromJid],
    );
  }

  const state = ctx.getState();
  const contactName =
    registeredCust?.customerName ||
    ctx.contacts[fromJid] ||
    msg.pushName ||
    (fromMe
      ? state.profileName || "أنا (الرقم المرتبط)"
      : `متعامل (${formattedPhone})`);

  const rawTimestamp = msg.messageTimestamp;
  const dateObj =
    typeof rawTimestamp === "number"
      ? new Date(rawTimestamp * 1000)
      : rawTimestamp && typeof rawTimestamp === "object" && rawTimestamp.low
        ? new Date(rawTimestamp.low * 1000)
        : new Date();

  // Fix #86: Store full ISO timestamp so client can format in Asia/Muscat and derive date ordering
  const isoTimestamp = dateObj.toISOString();

  const chat = upsertChatFromJidInStore(ctx, fromJid, {
    contactName,
    contactNumber: formattedPhone,
    companyName: registeredCust?.companyName,
    lastMessage: text,
    lastMessageTime: isoTimestamp,
    unreadIncrement: fromMe ? 0 : 1,
  });

  if (!ctx.messages[chat.id]) ctx.messages[chat.id] = [];

  // Fix #72: Return immediately if message ID already exists in chat history (prevent duplicate DB insert, CR processing & AI double-reply)
  const alreadyExists = ctx.messages[chat.id].some((mItem) => mItem.id === msgId);
  if (alreadyExists) {
    return;
  }

  appendMessageWithCap(ctx, chat.id, {
    id: msgId,
    chatId: chat.id,
    senderName: fromMe ? state.profileName || "أنا" : contactName,
    senderNumber: fromMe
      ? state.phoneNumber || "unknown"
      : formattedPhone,
    fromMe,
    text,
    timestamp: isoTimestamp,
    status: "read",
    aiGenerated: false,
    ...(isMediaDocumentOrImage
      ? {
          mediaUrl: `/api/whatsapp/media/${encodeURIComponent(msgId)}`,
          fileName: declaredFileName,
          mimeType: declaredMimeType,
        }
      : {}),
  });
  ctx.saveMessagesToFile();
  ctx.saveChatsToFile();

  try {
    await db.insert(whatsappMessages).values({
      tenantId: ctx.getTenantId(),
      instanceId: ctx.getInstanceId(),
      chatId: chat.id,
      phone: formattedPhone,
      direction: fromMe ? "OUTBOUND" : "INBOUND",
      messageText: text,
      status: "DELIVERED",
    });
  } catch (dbErr) {
    logger.debug({ err: dbErr }, "WhatsApp message DB persistence notice");
  }

  // Client opt-out from expiry reminders ("stop" / "ايقاف") takes effect immediately.
  if (!fromMe && !isMediaDocumentOrImage && isStopKeyword(text)) {
    handleReminderStopKeyword(ctx.getTenantId(), formattedPhone, text).catch((err) =>
      logger.warn({ err }, "Reminder stop-keyword handling failed"),
    );
  }

  const downloadAndPersistMediaBuffer = async (): Promise<Buffer> => {
    // Fix #80: Check declared fileLength BEFORE calling downloadMediaMessage to prevent OOM
    const rawLen = docMsg?.fileLength ?? imgMsg?.fileLength ?? 0;
    const declaredBytes =
      typeof rawLen === "object" && rawLen !== null
        ? Number(rawLen.low || 0)
        : Number(rawLen || 0);
    if (declaredBytes > MAX_MEDIA_DOWNLOAD_BYTES) {
      throw new Error(
        `ATTACHMENT_TOO_LARGE: ${declaredBytes} bytes exceeds 15 MB limit`,
      );
    }

    let resolvedBuf: Buffer | null = null;
    if (Buffer.isBuffer(msg.mediaBuffer)) {
      resolvedBuf = msg.mediaBuffer;
    } else if (typeof msg.base64Data === "string" && msg.base64Data.length > 0) {
      const cleaned = msg.base64Data.replace(/^data:[^;]+;base64,/, "");
      resolvedBuf = Buffer.from(cleaned, "base64");
    } else {
      const sock = ctx.getSock();
      const buf = await downloadMediaMessage(
        msg as Parameters<typeof downloadMediaMessage>[0],
        "buffer",
        {},
        sock
          ? {
              logger: pino({ level: "silent" }),
              reuploadRequest: sock.updateMediaMessage,
            }
          : undefined,
      );
      if (buf && (buf as Buffer).length > 0) {
        resolvedBuf = Buffer.from(buf as Buffer);
      }
    }

    if (!resolvedBuf || resolvedBuf.length === 0) {
      const cached = getMediaForMessageFromStore(ctx, msgId, declaredFileName);
      if (cached && cached.buffer.length > 0) {
        resolvedBuf = cached.buffer;
      }
    }
    if (!resolvedBuf) throw new Error("Empty media buffer");
    if (resolvedBuf.length > MAX_MEDIA_DOWNLOAD_BYTES) {
      throw new Error("Downloaded media buffer exceeds 15 MB limit");
    }

    const savedMedia = saveMediaForMessageInStore(
      ctx,
      msgId,
      declaredFileName || `whatsapp_media_${msgId}.pdf`,
      declaredMimeType || "application/pdf",
      resolvedBuf,
    );
    const existingMsg = ctx.messages[chat.id]?.find(
      (item) => item.id === msgId,
    );
    if (existingMsg) {
      existingMsg.mediaUrl = savedMedia.mediaUrl;
      existingMsg.fileName = savedMedia.fileName;
      existingMsg.mimeType = savedMedia.mimeType;
      existingMsg.fileSize = savedMedia.fileSize;
      ctx.saveMessagesToFile();
    }
    return resolvedBuf;
  };

  const isSyntheticDashboardEcho =
    String(msgId).startsWith("wa-") || String(msgId).startsWith("ai-");

  // Fix #84: Only run autonomous CR document registration on INBOUND (!fromMe) attachments
  if (!fromMe && !isSyntheticDashboardEcho && isMediaDocumentOrImage) {
    try {
      const procRes = await processIncomingWhatsAppMediaMessage({
        tenantId: ctx.getTenantId(),
        instanceId: ctx.getInstanceId(),
        providerMessageId: msgId,
        senderPhone: formattedPhone,
        senderJid: fromJid,
        senderName: contactName,
        messageText: text,
        fileName: declaredFileName || `whatsapp_document_${msgId}.pdf`,
        declaredMimeType: declaredMimeType || "application/pdf",
        rawPayload: msg,
        mediaBuffer: Buffer.isBuffer(msg.mediaBuffer) ? msg.mediaBuffer : null,
        mediaDownloadFn: downloadAndPersistMediaBuffer,
        sendWhatsAppReplyFn: async () => ({ sentId: `silent-${Date.now()}` }),
      });

      if (procRes?.companyName && chat) {
        chat.companyName = procRes.companyName;
        ctx.saveChatsToFile();
      }
    } catch (docErr) {
      logger.error(
        { err: docErr },
        "Error in autonomous WhatsApp document processor",
      );
    }
    return;
  }

  if (!fromMe && triggerAi && state.autoReplyEnabled) {
    await replyWithAiToCustomer(ctx, fromJid, chat, text, contactName);
  }
}

export async function replyWithAiToCustomer(
  ctx: WhatsAppPipelineContext,
  fromJid: string,
  chat: ChatItem,
  userText: string,
  senderName: string,
): Promise<void> {
  const state = ctx.getState();
  if (!state.autoReplyEnabled) return;
  try {
    const rawNum = normalizeWhatsAppPhone(fromJid.split("@")[0] || "");
    const senderPhone = chat.contactNumber || (rawNum ? `+${rawNum}` : "");
    if (!senderPhone || senderPhone === "unknown") return;

    const recentHistory = (ctx.messages[chat.id] || [])
      .slice(-8)
      .map((m) => ({
        fromMe: m.fromMe,
        senderName: m.senderName,
        text: m.text,
        timestamp: m.timestamp,
      }));

    const { humanReply } =
      await requestService.analyzeAndProcessCustomerMessage({
        text: userText,
        senderName,
        senderPhone,
        chatId: chat.id,
        recentHistory,
        tenantId: ctx.getTenantId(),
      });

    if (!ctx.getState().autoReplyEnabled) return;

    const fp = makeOutboundFingerprint(fromJid, humanReply);
    ctx.pendingOutboundFingerprints.set(fp, Date.now());

    // Fix #83: Track real send status ("sent" only when socket connected and sendMessage succeeds, otherwise "failed")
    let deliveryStatus: "sent" | "failed" = "failed";
    const sock = ctx.getSock();
    if (sock && ctx.getState().status === "connected") {
      try {
        const sent = await sock.sendMessage(fromJid, { text: humanReply });
        if (sent?.key?.id) {
          ctx.pendingOutboundIds.add(sent.key.id);
        }
        deliveryStatus = "sent";
      } catch (sendErr) {
        logger.error({ err: sendErr }, "Failed to deliver AI reply over Baileys socket");
        deliveryStatus = "failed";
      }
    }

    const replyTimestamp = new Date().toISOString();

    const outMsg: MessageItem = {
      id: `ai-${Date.now()}`,
      chatId: chat.id,
      senderName: "المساعد الذكي (مكتب سند)",
      senderNumber: ctx.getState().phoneNumber || "unknown",
      fromMe: true,
      text: humanReply,
      timestamp: replyTimestamp,
      status: deliveryStatus,
      aiGenerated: true,
    };

    appendMessageWithCap(ctx, chat.id, outMsg);
    chat.lastMessage = humanReply;
    chat.lastMessageTime = replyTimestamp;

    ctx.saveChatsToFile();
    ctx.saveMessagesToFile();
  } catch (err) {
    logger.error({ err }, "Error generating or sending AI reply");
  }
}

export async function sendManualWhatsAppMessage(
  ctx: WhatsAppPipelineContext,
  chatId: string,
  text: string,
  media?: { buffer: Buffer; fileName: string; mimeType: string },
  clientMessageId?: string,
): Promise<MessageItem> {
  let chat = ctx.chats.find((c) => c.id === chatId);
  const normalizedTarget = chat?.contactNumber
    ? normalizeWhatsAppPhone(chat.contactNumber)
    : normalizeWhatsAppPhone(chatId);

  const jid =
    chat?.jid ||
    (chatId.includes("@")
      ? chatId
      : normalizedTarget
        ? `${normalizedTarget}@s.whatsapp.net`
        : "");

  // Fix #88: Refuse to invent a fake phone number when target number is missing
  if (!jid) {
    throw new Error("رقم هاتف المستلم غير صالح أو غير متوفر.");
  }

  const displayText =
    text || (media?.fileName ? `📄 [ملف مرفق: ${media.fileName}]` : "");

  if (!chat) {
    chat = upsertChatFromJidInStore(ctx, jid, {
      lastMessage: displayText,
    });
    chatId = chat.id;
  }

  const timestamp = new Date().toISOString();
  const msgId = `m-${Date.now()}`;
  ctx.pendingOutboundIds.add(msgId);
  const fp = makeOutboundFingerprint(jid, displayText);
  ctx.pendingOutboundFingerprints.set(fp, Date.now());

  let savedMedia:
    | { mediaUrl: string; fileName: string; mimeType: string; fileSize: number }
    | undefined;

  if (media && media.buffer) {
    if (media.buffer.length > MAX_MEDIA_DOWNLOAD_BYTES) {
      throw new Error("حجم المرفق يتجاوز الحد المسموح به (15 ميجابايت).");
    }
    savedMedia = saveMediaForMessageInStore(
      ctx,
      msgId,
      media.fileName,
      media.mimeType,
      media.buffer,
    );
  }

  // Fix #83: If socket is connected, send and throw if send fails; if disconnected in production (without media local record), record status accurately
  const sock = ctx.getSock();
  const isConnected = Boolean(sock && ctx.getState().status === "connected");
  let deliveryStatus: "sent" | "failed" = isConnected ? "sent" : "failed";

  if (isConnected && sock) {
    try {
      if (media && media.buffer) {
        const sent = media.mimeType.startsWith("image/")
          ? await sock.sendMessage(jid, {
              image: media.buffer,
              caption: text || undefined,
            })
          : await sock.sendMessage(jid, {
              document: media.buffer,
              mimetype: media.mimeType,
              fileName: media.fileName,
              caption: text || undefined,
            });
        if (sent?.key?.id) ctx.pendingOutboundIds.add(sent.key.id);
      } else {
        const sent = await sock.sendMessage(jid, { text: displayText });
        if (sent?.key?.id) ctx.pendingOutboundIds.add(sent.key.id);
      }
      deliveryStatus = "sent";
    } catch (err) {
      deliveryStatus = "failed";
      logger.error({ err }, "Failed to send manual WhatsApp message");
      throw new Error("فشل إرسال الرسالة عبر خادم واتساب.");
    }
  }

  const msg: MessageItem = {
    id: msgId,
    clientMessageId,
    chatId,
    senderName: ctx.getState().profileName || "فريق الدعم (سند)",
    senderNumber: ctx.getState().phoneNumber || "unknown",
    fromMe: true,
    text: displayText,
    timestamp,
    status: deliveryStatus,
    aiGenerated: false,
    ...(savedMedia
      ? {
          mediaUrl: savedMedia.mediaUrl,
          fileName: savedMedia.fileName,
          mimeType: savedMedia.mimeType,
          fileSize: savedMedia.fileSize,
        }
      : {}),
  };

  appendMessageWithCap(ctx, chatId, msg);

  if (chat) {
    chat.lastMessage = displayText;
    chat.lastMessageTime = timestamp;
    chat.unreadCount = 0;
    ctx.saveChatsToFile();
  }
  ctx.saveMessagesToFile();

  // Fix #84: Do NOT run outbound staff-sent files through the inbound CR auto-registration pipeline!
  return msg;
}
