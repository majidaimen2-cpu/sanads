import { SignJWT, jwtVerify } from "jose";
import crypto from "crypto";
import type { AuthUser } from "../types/express.js";

const DEFAULT_PBKDF2_ITERATIONS = 600000;
const LEGACY_PBKDF2_ITERATIONS = 100000;

function getJwtSecret(): Uint8Array {
  const secret = process.env.JWT_SECRET?.trim();
  if (!secret || secret.length < 32) {
    throw new Error(
      "CRITICAL SECURITY ERROR: JWT_SECRET environment variable must be set and at least 32 characters long."
    );
  }
  return new TextEncoder().encode(secret);
}

function getJwtRefreshSecret(): Uint8Array {
  const secret = process.env.JWT_REFRESH_SECRET?.trim();
  if (!secret || secret.length < 32) {
    throw new Error(
      "CRITICAL SECURITY ERROR: JWT_REFRESH_SECRET environment variable must be set and at least 32 characters long."
    );
  }
  return new TextEncoder().encode(secret);
}

export interface TokenPayloadInput {
  userId: number;
  username: string;
  role: string;
  tenantId: string;
  tokenVersion: number;
}

export interface RefreshTokenSignResult {
  token: string;
  jti: string;
}

async function signAccessToken(payload: TokenPayloadInput): Promise<string> {
  const secret = getJwtSecret();
  return new SignJWT({
    userId: payload.userId,
    username: payload.username,
    role: payload.role,
    tenantId: payload.tenantId,
    tokenVersion: payload.tokenVersion,
    typ: "access",
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("8h")
    .sign(secret);
}

async function signRefreshToken(
  payload: TokenPayloadInput,
  customJti?: string
): Promise<RefreshTokenSignResult> {
  const secret = getJwtRefreshSecret();
  const jti = customJti || crypto.randomUUID();
  const token = await new SignJWT({
    userId: payload.userId,
    username: payload.username,
    role: payload.role,
    tenantId: payload.tenantId,
    tokenVersion: payload.tokenVersion,
    typ: "refresh",
    jti,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setJti(jti)
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(secret);
  return { token, jti };
}

async function verifyAccessToken(token: string): Promise<AuthUser | null> {
  try {
    const secret = getJwtSecret();
    const { payload } = await jwtVerify(token, secret);
    if (payload.typ !== "access") {
      return null;
    }
    if (
      typeof payload.userId !== "number" ||
      typeof payload.username !== "string" ||
      typeof payload.role !== "string" ||
      typeof payload.tenantId !== "string" ||
      !payload.tenantId.trim()
    ) {
      return null;
    }
    return {
      userId: payload.userId,
      username: payload.username,
      role: payload.role,
      tenantId: payload.tenantId,
      tokenVersion: typeof payload.tokenVersion === "number" ? payload.tokenVersion : 1,
      typ: "access",
    };
  } catch {
    return null;
  }
}

async function verifyRefreshToken(token: string): Promise<(AuthUser & { jti: string }) | null> {
  try {
    const secret = getJwtRefreshSecret();
    const { payload } = await jwtVerify(token, secret);
    if (payload.typ !== "refresh" || typeof payload.jti !== "string" || !payload.jti) {
      return null;
    }
    if (typeof payload.userId !== "number") {
      return null;
    }
    return {
      userId: payload.userId,
      username: typeof payload.username === "string" ? payload.username : "",
      role: typeof payload.role === "string" ? payload.role : "CLERK",
      tenantId: typeof payload.tenantId === "string" ? payload.tenantId : "",
      tokenVersion: typeof payload.tokenVersion === "number" ? payload.tokenVersion : 1,
      typ: "refresh",
      jti: payload.jti,
    };
  } catch {
    return null;
  }
}

const verifyToken = verifyAccessToken;

function validatePasswordComplexity(password: string): { valid: boolean; reason?: string } {
  if (password.length < 10) {
    return { valid: false, reason: "Password must be at least 10 characters long." };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, reason: "Password must contain at least one uppercase letter." };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, reason: "Password must contain at least one lowercase letter." };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, reason: "Password must contain at least one digit." };
  }
  return { valid: true };
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString("hex");
}

function hashPasswordPBKDF2(
  password: string,
  salt: string,
  iterations = DEFAULT_PBKDF2_ITERATIONS
): string {
  return crypto.pbkdf2Sync(password, salt, iterations, 64, "sha512").toString("hex");
}

function verifyPasswordHash(
  password: string,
  salt: string,
  storedHash: string
): { matches: boolean; needsRehash: boolean } {
  const storedBuf = Buffer.from(storedHash, "hex");
  if (storedBuf.length !== 64) {
    return { matches: false, needsRehash: false };
  }

  const currentBuf = crypto.pbkdf2Sync(password, salt, DEFAULT_PBKDF2_ITERATIONS, 64, "sha512");
  if (crypto.timingSafeEqual(currentBuf, storedBuf)) {
    return { matches: true, needsRehash: false };
  }

  const legacyBuf = crypto.pbkdf2Sync(password, salt, LEGACY_PBKDF2_ITERATIONS, 64, "sha512");
  if (crypto.timingSafeEqual(legacyBuf, storedBuf)) {
    return { matches: true, needsRehash: true };
  }

  return { matches: false, needsRehash: false };
}

export {
  DEFAULT_PBKDF2_ITERATIONS,
  LEGACY_PBKDF2_ITERATIONS,
  generateSalt,
  getJwtRefreshSecret,
  getJwtSecret,
  hashPasswordPBKDF2,
  signAccessToken,
  signRefreshToken,
  validatePasswordComplexity,
  verifyAccessToken,
  verifyPasswordHash,
  verifyRefreshToken,
  verifyToken,
};
