export const PERMISSION_MATRIX: Record<string, string[]> = {
  // vault_settings:update (reminder rules, auto-file switch) is covered by "*": SUPER_ADMIN only.
  SUPER_ADMIN: ["*"],
  MANAGER: [
    "customers:*",
    "customer_documents:*",
    "companies:*",
    "employees:*",
    "contracts:*",
    "services:*",
    "transactions:*",
    "payments:*",
    "invoices:*",
    "cash_sessions:*",
    "expenses:*",
    "commissions:*",
    "reports:*",
    "users:read",
    "branches:*",
    "notifications:*",
    "audit_logs:read",
    "ai:use",
  ],
  ACCOUNTANT: [
    "payments:*",
    "invoices:*",
    "cash_sessions:*",
    "expenses:*",
    "commissions:*",
    "reports:*",
    "transactions:read",
    "customers:read",
    "companies:read",
    "services:read",
    "ai:use",
  ],
  CASHIER: [
    "payments:create",
    "payments:read",
    "invoices:create",
    "invoices:read",
    "cash_sessions:create",
    "cash_sessions:read",
    "cash_sessions:update",
    "expenses:create",
    "expenses:read",
    "transactions:read",
    "customers:read",
    "services:read",
    "ai:use",
  ],
  CLERK: [
    "transactions:*",
    "customers:*",
    "customer_documents:*",
    "companies:*",
    "employees:*",
    "contracts:*",
    "services:read",
    "invoices:read",
    "payments:read",
    "notifications:read",
    "notifications:update",
    "notifications:delete",
    "ai:use",
  ],
  VIEWER: [
    "customers:read",
    "customer_documents:read",
    "companies:read",
    "employees:read",
    "contracts:read",
    "services:read",
    "transactions:read",
    "payments:read",
    "invoices:read",
    "reports:read",
  ],
};

export function hasPermission(role: string, requiredPermission: string): boolean {
  const permissions = PERMISSION_MATRIX[role] || [];
  if (permissions.includes("*")) return true;
  if (permissions.includes(requiredPermission)) return true;
  const [resource, action] = requiredPermission.split(":");
  if (resource && action) {
    if (permissions.includes(`${resource}:*`)) return true;
  }
  return false;
}
