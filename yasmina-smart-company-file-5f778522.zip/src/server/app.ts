import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import { db } from "../db/index.js";
import { sql } from "drizzle-orm";
import { authRouter } from "./routes/authRoutes.js";
import { customerRouter } from "./routes/customerRoutes.js";
import { customerDocumentRouter } from "./routes/customerDocumentRoutes.js";
import { companyRouter } from "./routes/companyRoutes.js";
import { employeeRouter } from "./routes/employeeRoutes.js";
import { contractRouter } from "./routes/contractRoutes.js";
import { serviceRouter } from "./routes/serviceRoutes.js";
import { transactionRouter } from "./routes/transactionRoutes.js";
import { paymentRouter } from "./routes/paymentRoutes.js";
import { invoiceRouter } from "./routes/invoiceRoutes.js";
import { cashSessionRouter } from "./routes/cashSessionRoutes.js";
import { expenseRouter } from "./routes/expenseRoutes.js";
import { commissionRouter } from "./routes/commissionRoutes.js";
import { userRouter } from "./routes/userRoutes.js";
import { branchRouter } from "./routes/branchRoutes.js";
import { notificationRouter } from "./routes/notificationRoutes.js";
import { reportRouter } from "./routes/reportRoutes.js";
import { systemRouter } from "./routes/systemRoutes.js";
import { webhookRouter } from "./routes/webhookRoutes.js";
import { importRouter } from "./routes/importRoutes.js";
import { evolutionRouter } from "./routes/evolutionRoutes.js";
import { requestRouter } from "./routes/requestRoutes.js";
import { settingsRouter } from "./routes/settingsRoutes.js";
import aiRouter from "./routes/aiRoutes.js";
import { documentVaultRouter } from "./routes/documentVaultRoutes.js";
import { errorHandler, requestIdMiddleware } from "./middleware/errorHandler.js";

const UPLOAD_ROUTE_PREFIXES = [
  "/api/companies",
  "/api/customer-documents",
  "/api/customers",
  "/api/employees",
  "/api/contracts",
  "/api/import",
  "/api/cr/extract",
  "/api/anydoc/convert",
  "/api/webhooks",
  "/api/whatsapp",
  "/api/vault",
  "/api/chat",
  "/api/ask",
];

function isUploadCapableRequest(req: express.Request): boolean {
  if (req.method !== "POST" && req.method !== "PUT") return false;
  const url = req.originalUrl || req.url || "";
  return UPLOAD_ROUTE_PREFIXES.some((prefix) => url.startsWith(prefix));
}

async function createApp() {
  const app = express();
  app.set("trust proxy", Number(process.env.TRUST_PROXY ?? 0));
  app.use(requestIdMiddleware);

  const corsOrigins = (process.env.CORS_ORIGINS || "http://localhost:3000")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  if (process.env.NODE_ENV === "production" && !process.env.CORS_ORIGINS?.trim()) {
    throw new Error("CRITICAL SECURITY ERROR: CORS_ORIGINS must be configured in production.");
  }

  app.use(
    cors({
      origin: corsOrigins,
      credentials: true,
    })
  );

  app.use(
    helmet({
      frameguard: false,
      crossOriginOpenerPolicy: false,
      crossOriginResourcePolicy: false,
      crossOriginEmbedderPolicy: false,
      contentSecurityPolicy: {
        useDefaults: true,
        directives: {
          "frame-ancestors": ["'self'", "https://*.google.com", "https://aistudio.google.com"],
          "img-src": ["'self'", "data:", "blob:", "https:"],
          "connect-src": ["'self'", "https:", "wss:", "ws:"],
          "script-src": ["'self'", "'unsafe-inline'"],
          "style-src": ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          "font-src": ["'self'", "data:", "https://fonts.gstatic.com"],
        },
      },
    })
  );

  app.use(cookieParser());

  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
    validate: false,
    message: {
      success: false,
      error: {
        code: "RATE_LIMIT_EXCEEDED",
        message: "Too many API requests. Please try again later.",
      },
    },
  });
  app.use("/api/", apiLimiter);

  const smallJsonParser = express.json({ limit: "100kb" });
  const smallUrlParser = express.urlencoded({ extended: true, limit: "100kb" });
  const uploadJsonParser = express.json({ limit: "20mb" });
  const uploadUrlParser = express.urlencoded({ extended: true, limit: "20mb" });

  app.use((req, res, next) => {
    const jsonMiddleware = isUploadCapableRequest(req) ? uploadJsonParser : smallJsonParser;
    const urlMiddleware = isUploadCapableRequest(req) ? uploadUrlParser : smallUrlParser;
    jsonMiddleware(req, res, (err) => {
      if (err) return next(err);
      urlMiddleware(req, res, next);
    });
  });

  // Single minimal public health check endpoint (#23)
  app.get("/api/health", async (_req, res) => {
    try {
      await db.execute(sql`SELECT 1`);
      res.status(200).json({ status: "ok" });
    } catch {
      res.status(503).json({ status: "degraded" });
    }
  });

  app.use("/api/auth", authRouter);
  app.use("/api/customers", customerRouter);
  app.use("/api/customer-documents", customerDocumentRouter);
  app.use("/api/vault", documentVaultRouter);
  app.use("/api/companies", companyRouter);
  app.use("/api/employees", employeeRouter);
  app.use("/api/contracts", contractRouter);
  app.use("/api/services", serviceRouter);
  app.use("/api/transactions", transactionRouter);
  app.use("/api/payments", paymentRouter);
  app.use("/api/invoices", invoiceRouter);
  app.use("/api/cash-sessions", cashSessionRouter);
  app.use("/api/expenses", expenseRouter);
  app.use("/api/commissions", commissionRouter);
  app.use("/api/users", userRouter);
  app.use("/api/branches", branchRouter);
  app.use("/api/notifications", notificationRouter);
  app.use("/api/reports", reportRouter);
  app.use("/api/system", systemRouter);
  app.use("/api/webhooks", webhookRouter);
  app.use("/api/import", importRouter);
  app.use("/api/whatsapp", evolutionRouter);
  app.use("/api/requests", requestRouter);
  app.use("/api/settings", settingsRouter);
  app.use("/api", aiRouter);

  app.use("/api", (req, res) => {
    res.status(404).json({
      success: false,
      error: { code: "NOT_FOUND", message: "Not found" },
      requestId: req.id,
    });
  });

  app.use(errorHandler);
  return app;
}

export { createApp };
