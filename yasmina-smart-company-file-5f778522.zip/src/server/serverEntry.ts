import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { runMigrations } from "../db/index.js";
import { createApp } from "./app.js";
import { initExpiryCron } from "./services/expiryCronService.js";
import { startReminderDispatcher } from "./services/reminderService.js";
import * as fsModule from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Port configuration: In Cloud Run / container, PORT=8080 is used by Nginx, which proxies to 3000.
// Parse CLI arguments (--port 3000) or APP_PORT or fallback to 3000.
function resolvePort(): number {
  const portArgIndex = process.argv.indexOf("--port");
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    const parsed = parseInt(process.argv[portArgIndex + 1], 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  if (process.env.APP_PORT) {
    const parsed = parseInt(process.env.APP_PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  if (process.env.PORT && process.env.PORT !== "8080") {
    const parsed = parseInt(process.env.PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 3000;
}

const PORT = resolvePort();

export async function startServer() {
  const app = await createApp();
  const rootDir = process.cwd();
  const distDir = path.resolve(rootDir, "dist");
  const publicDir = path.resolve(rootDir, "public");
  const distIndexHtml = path.resolve(distDir, "index.html");
  const rootIndexHtml = path.resolve(rootDir, "index.html");

  // Serve static assets from public and dist
  if (fsModule.existsSync(publicDir)) {
    app.use(express.static(publicDir));
  }
  if (fsModule.existsSync(distDir)) {
    app.use(express.static(distDir));
  }

  // Explicit route for service worker to ensure correct Content-Type and avoid SPA HTML fallback
  app.get("/sw.js", (req, res) => {
    res.setHeader("Content-Type", "application/javascript; charset=UTF-8");
    res.setHeader("Service-Worker-Allowed", "/");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    const swPublic = path.resolve(publicDir, "sw.js");
    if (fsModule.existsSync(swPublic)) {
      return res.sendFile(swPublic);
    }
    const swDist = path.resolve(distDir, "sw.js");
    if (fsModule.existsSync(swDist)) {
      return res.sendFile(swDist);
    }
    return res.send(`self.addEventListener('install',()=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));self.addEventListener('fetch',e=>{if(e.request.url.includes('/api/'))return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));});`);
  });

  // SPA fallback for all non-API routes
  app.get("*", async (req, res, next) => {
    if (req.originalUrl.startsWith("/api")) return next();
    if (fsModule.existsSync(distIndexHtml)) {
      return res.sendFile(distIndexHtml);
    }
    if (fsModule.existsSync(rootIndexHtml)) {
      return res.sendFile(rootIndexHtml);
    }
    next();
  });

  // Start listening on PORT immediately so pre-warming and health checks succeed without waiting for DB cold-start
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 Yasmina Sanad ERP Server started successfully on port ${PORT}`);
  });

  let eaddrRetries = 0;
  server.on("error", (err: NodeJS.ErrnoException) => {
    if (err.code === "EADDRINUSE" && eaddrRetries < 6) {
      eaddrRetries++;
      console.warn(`⚠️ Port ${PORT} in use, retrying in 500ms (attempt ${eaddrRetries}/6)...`);
      setTimeout(() => {
        server.close();
        server.listen(PORT, "0.0.0.0");
      }, 500);
      return;
    }
    console.error("❌ HTTP server encountered error:", err);
  });

  // Run database migrations, drift checks, and background schedulers asynchronously
  (async () => {
    // Migration failure or schema drift is FATAL: running against a half-migrated database
    // produces 500 errors in the middle of a customer's workday.
    try {
      await runMigrations();
    } catch (migErr) {
      console.error("❌ FATAL: database migration failed. Refusing to run.", migErr);
      process.exit(1);
    }

    try {
      const { checkSchemaDrift } = await import("../db/driftCheck.js");
      const drift = await checkSchemaDrift();
      if (drift && drift.hasDrift) {
        console.error(
          "❌ FATAL: database schema does not match schema.ts:\n" +
            drift.issues.map((i: string) => `  - ${i}`).join("\n")
        );
        process.exit(1);
      }
      console.log("✅ [DRIFT CHECK] Database schema in sync with 0 drift.");
    } catch (driftErr) {
      console.error("❌ FATAL: schema drift check could not run.", driftErr);
      process.exit(1);
    }

    try {
      initExpiryCron();
    } catch (cronErr) {
      console.warn("⚠️ Expiry cron init notice:", cronErr);
    }

    try {
      startReminderDispatcher();
    } catch (remErr) {
      console.warn("⚠️ Reminder dispatcher init notice:", remErr);
    }

    try {
      const { BackupService } = await import("./services/backupService.js");
      BackupService.initBackupSchedule();
    } catch (backupErr) {
      console.warn("⚠️ Backup scheduler initialization notice:", backupErr);
    }

    // Auto-start authenticated WhatsApp session if credentials exist
    try {
      const { whatsAppService } = await import("./services/whatsappService.js");
      const hasCreds = await whatsAppService.hasAuthenticatedCredentials();
      if (hasCreds) {
        whatsAppService.startSession(false).catch(() => {});
      }
    } catch (_) {}
  })();

  const handleShutdown = (signal: string) => {
    console.log(`Received ${signal}, closing HTTP server gracefully...`);
    server.close(() => {
      console.log("HTTP server closed.");
      process.exit(0);
    });
  };

  process.on("SIGINT", () => handleShutdown("SIGINT"));
  process.on("SIGTERM", () => handleShutdown("SIGTERM"));

  return server;
}

process.on("unhandledRejection", (reason) => {
  console.warn("⚠️ Unhandled Promise Rejection (kept server alive):", reason);
});

process.on("uncaughtException", (err) => {
  console.error("⚠️ Uncaught Exception (kept server alive):", err);
});

// Auto-start if executed directly or bundled
startServer().catch((err) => {
  console.error("Failed to start server:", err);
});

