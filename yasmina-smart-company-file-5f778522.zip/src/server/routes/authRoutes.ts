import { Router } from "express";
import rateLimit from "express-rate-limit";
import { and, eq, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { users } from "../../db/schema.js";
import {
  findUserForAuth,
  seedInitialAdminIfNone,
  updateUserPassword,
  insertAuditLog,
} from "../../db/users.js";
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  hashPasswordPBKDF2,
  generateSalt,
  validatePasswordComplexity,
  verifyPasswordHash,
  DEFAULT_PBKDF2_ITERATIONS,
} from "../auth.js";
import { requireAuth } from "../middleware/rbac.js";

const authRouter = Router();

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000;

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  validate: false,
  keyGenerator: (req) => `${req.ip || "127.0.0.1"}_${String(req.body?.username || "").trim().toLowerCase()}`,
  message: {
    success: false,
    error: {
      code: "TOO_MANY_ATTEMPTS",
      message: "Too many login attempts. Please try again in 15 minutes.",
    },
  },
});

authRouter.post("/login", loginLimiter, async (req, res, next) => {
  try {
    const { username = "", password = "" } = req.body || {};
    const cleanUser = String(username).trim().toLowerCase();
    const rawPass = String(password);
    const clientIp = req.ip || "127.0.0.1";

    if (!cleanUser || !rawPass) {
      res.status(400).json({
        success: false,
        error: {
          code: "MISSING_CREDENTIALS",
          message: "Username and password are required.",
        },
        requestId: req.id,
      });
      return;
    }

    await seedInitialAdminIfNone();

    const dbUser = await findUserForAuth(cleanUser);
    const now = new Date();

    if (dbUser && dbUser.lockedUntil && dbUser.lockedUntil.getTime() > now.getTime()) {
      const waitMins = Math.ceil((dbUser.lockedUntil.getTime() - now.getTime()) / 60000);
      res.status(429).json({
        success: false,
        error: {
          code: "ACCOUNT_LOCKED",
          message: `Account locked due to multiple failed login attempts. Please wait ${waitMins} minutes.`,
        },
        requestId: req.id,
      });
      return;
    }

    let authenticated = false;

    if (dbUser && dbUser.active && dbUser.passwordHash && dbUser.salt) {
      const { matches, needsRehash } = verifyPasswordHash(
        rawPass,
        dbUser.salt,
        dbUser.passwordHash
      );
      if (matches) {
        authenticated = true;
        if (needsRehash) {
          const newSalt = generateSalt();
          const newHash = hashPasswordPBKDF2(rawPass, newSalt, DEFAULT_PBKDF2_ITERATIONS);
          await db
            .update(users)
            .set({ passwordHash: newHash, salt: newSalt })
            .where(eq(users.id, dbUser.id));
        }
      }
    }

    if (!authenticated || !dbUser) {
      let isLocking = false;
      if (dbUser) {
        const nextCount = (dbUser.failedAttempts || 0) + 1;
        isLocking = nextCount >= MAX_FAILED_ATTEMPTS;
        const lockedUntil = isLocking ? new Date(now.getTime() + LOCKOUT_DURATION_MS) : null;
        await db
          .update(users)
          .set({
            failedAttempts: nextCount,
            lockedUntil,
            updatedAt: now,
          })
          .where(eq(users.id, dbUser.id));
      }

      await insertAuditLog({
        tenantId: dbUser?.tenantId || "default_tenant",
        actorId: cleanUser,
        actorName: cleanUser,
        action: isLocking ? "ACCOUNT_LOCKOUT" : "LOGIN_FAILED",
        resource: "auth",
        details: isLocking
          ? "Account locked in PostgreSQL after failed login attempts"
          : "Failed login attempt",
        ipAddress: String(clientIp),
      });

      res.status(isLocking ? 429 : 401).json({
        success: false,
        error: {
          code: isLocking ? "ACCOUNT_LOCKED" : "INVALID_CREDENTIALS",
          message: isLocking
            ? "Account locked due to multiple failed login attempts. Please wait 15 minutes."
            : "اسم المستخدم أو كلمة المرور غير صحيحة. يرجى استخدام بيانات الدخول المعتمدة.",
        },
        requestId: req.id,
      });
      return;
    }

    const userPayload = {
      userId: dbUser.id,
      username: dbUser.uid,
      role: dbUser.role || "CLERK",
      tenantId: dbUser.tenantId,
      tokenVersion: dbUser.tokenVersion || 1,
    };

    const accessToken = await signAccessToken(userPayload);
    const { token: refreshToken, jti } = await signRefreshToken(userPayload);

    await db
      .update(users)
      .set({
        failedAttempts: 0,
        lockedUntil: null,
        activeRefreshJti: jti,
        updatedAt: now,
      })
      .where(eq(users.id, dbUser.id));

    const isProd = process.env.NODE_ENV === "production";

    res.cookie("accessToken", accessToken, {
      httpOnly: true,
      secure: isProd,
      sameSite: "lax",
      maxAge: 8 * 60 * 60 * 1000,
    });
    res.cookie("refreshToken", refreshToken, {
      httpOnly: true,
      secure: isProd,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });

    await insertAuditLog({
      tenantId: userPayload.tenantId,
      actorId: String(userPayload.userId),
      actorName: userPayload.username,
      action: "LOGIN_SUCCESS",
      resource: "auth",
      details: "Logged in successfully via HS256 JWT",
      ipAddress: String(clientIp),
    });

    res.json({
      success: true,
      token: accessToken,
      refreshToken,
      user: {
        id: String(userPayload.userId),
        name: dbUser.displayName || userPayload.username,
        username: userPayload.username,
        email: dbUser.email,
        role: userPayload.role,
        tenantId: userPayload.tenantId,
        mustChangePassword: dbUser.mustChangePassword,
      },
    });
  } catch (err) {
    next(err);
  }
});

authRouter.post("/refresh", async (req, res, next) => {
  try {
    const rawRefreshToken =
      req.cookies?.refreshToken ||
      (typeof req.body?.refreshToken === "string" ? req.body.refreshToken : undefined);

    if (!rawRefreshToken) {
      res.status(401).json({
        success: false,
        error: {
          code: "MISSING_REFRESH_TOKEN",
          message: "Refresh token is required",
        },
        requestId: req.id,
      });
      return;
    }

    const decoded = await verifyRefreshToken(String(rawRefreshToken));
    if (!decoded) {
      res.status(401).json({
        success: false,
        error: {
          code: "INVALID_REFRESH_TOKEN",
          message: "Invalid or expired refresh token",
        },
        requestId: req.id,
      });
      return;
    }

    const [dbUser] = await db
      .select()
      .from(users)
      .where(eq(users.id, decoded.userId))
      .limit(1);

    if (!dbUser || !dbUser.active) {
      res.status(401).json({
        success: false,
        error: {
          code: "USER_INACTIVE",
          message: "User account is not active",
        },
        requestId: req.id,
      });
      return;
    }

    // Reuse detection (#60): if jti or tokenVersion does not match, revoke all sessions immediately
    if (
      dbUser.tokenVersion !== decoded.tokenVersion ||
      !dbUser.activeRefreshJti ||
      dbUser.activeRefreshJti !== decoded.jti
    ) {
      await db
        .update(users)
        .set({
          tokenVersion: sql`${users.tokenVersion} + 1`,
          activeRefreshJti: null,
          updatedAt: new Date(),
        })
        .where(eq(users.id, dbUser.id));

      res.clearCookie("accessToken");
      res.clearCookie("refreshToken");

      res.status(401).json({
        success: false,
        error: {
          code: "REFRESH_TOKEN_REUSED",
          message: "Refresh token reuse detected. All sessions have been revoked.",
        },
        requestId: req.id,
      });
      return;
    }

    const userPayload = {
      userId: dbUser.id,
      username: dbUser.uid,
      role: dbUser.role || "CLERK",
      tenantId: dbUser.tenantId,
      tokenVersion: dbUser.tokenVersion,
    };

    const accessToken = await signAccessToken(userPayload);
    const { token: newRefreshToken, jti: newJti } = await signRefreshToken(userPayload);

    await db
      .update(users)
      .set({
        activeRefreshJti: newJti,
        updatedAt: new Date(),
      })
      .where(eq(users.id, dbUser.id));

    const isProd = process.env.NODE_ENV === "production";
    res.cookie("accessToken", accessToken, {
      httpOnly: true,
      secure: isProd,
      sameSite: "lax",
      maxAge: 8 * 60 * 60 * 1000,
    });
    res.cookie("refreshToken", newRefreshToken, {
      httpOnly: true,
      secure: isProd,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });

    res.json({
      success: true,
      token: accessToken,
      refreshToken: newRefreshToken,
    });
  } catch (err) {
    next(err);
  }
});

authRouter.post("/logout", requireAuth, async (req, res, next) => {
  try {
    if (req.user?.userId) {
      await db
        .update(users)
        .set({
          tokenVersion: sql`${users.tokenVersion} + 1`,
          activeRefreshJti: null,
          updatedAt: new Date(),
        })
        .where(eq(users.id, req.user.userId));
    }
    res.clearCookie("accessToken");
    res.clearCookie("refreshToken");
    res.json({ success: true, message: "Logged out successfully" });
  } catch (err) {
    next(err);
  }
});

authRouter.get("/session", requireAuth, (req, res) => {
  res.json({ success: true, authenticated: true, user: req.user });
});

authRouter.get("/me", requireAuth, async (req, res, next) => {
  try {
    const userId = Number(req.user?.userId);
    if (!userId) {
      res.status(401).json({
        success: false,
        error: { code: "UNAUTHORIZED", message: "غير مصرح" },
        requestId: req.id,
      });
      return;
    }
    const rows = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    const user = rows[0];
    if (!user) {
      res.status(404).json({
        success: false,
        error: { code: "NOT_FOUND", message: "المستخدم غير موجود." },
        requestId: req.id,
      });
      return;
    }
    res.json({
      success: true,
      user: {
        id: String(user.id),
        name: user.displayName || user.uid,
        displayName: user.displayName || user.uid,
        username: user.uid,
        email: user.email,
        role: user.role,
        tenantId: user.tenantId,
      },
    });
  } catch (err) {
    next(err);
  }
});

authRouter.post("/change-username", requireAuth, async (req, res, next) => {
  try {
    const {
      newUsername = "",
      displayName = "",
      currentPassword = "",
    } = req.body || {};
    const cleanUser = String(newUsername).trim().toLowerCase();
    const cleanDisplayName = String(displayName).trim();
    const rawPass = String(currentPassword);

    if (!cleanUser) {
      res.status(400).json({
        success: false,
        error: { code: "VALIDATION_ERROR", message: "اسم المستخدم الجديد مطلوب." },
        requestId: req.id,
      });
      return;
    }

    if (cleanUser.length < 3 || cleanUser.length > 32) {
      res.status(400).json({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: "اسم المستخدم يجب أن يتكون من 3 إلى 32 حرفاً.",
        },
        requestId: req.id,
      });
      return;
    }

    if (!/^[a-zA-Z0-9_.-]+$/.test(cleanUser)) {
      res.status(400).json({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message:
            "اسم المستخدم يجب أن يحتوي على أحرف إنجليزية وأرقام وعلامات (_ . -) فقط بدون مسافات.",
        },
        requestId: req.id,
      });
      return;
    }

    if (!rawPass) {
      res.status(400).json({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: "يرجى إدخال كلمة المرور الحالية لتأكيد التغيير.",
        },
        requestId: req.id,
      });
      return;
    }

    const userId = Number(req.user?.userId);
    const rows = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    const user = rows[0];
    if (!user || !user.passwordHash || !user.salt) {
      res.status(404).json({
        success: false,
        error: {
          code: "NOT_FOUND",
          message: "المستخدم غير موجود في قاعدة البيانات.",
        },
        requestId: req.id,
      });
      return;
    }

    const { matches } = verifyPasswordHash(rawPass, user.salt, user.passwordHash);
    if (!matches) {
      res.status(400).json({
        success: false,
        error: {
          code: "INVALID_PASSWORD",
          message: "كلمة المرور الحالية غير صحيحة لتأكيد العملية.",
        },
        requestId: req.id,
      });
      return;
    }

    if (cleanUser !== user.uid.toLowerCase()) {
      const existing = await db
        .select()
        .from(users)
        .where(
          and(
            eq(users.tenantId, user.tenantId),
            sql`LOWER(${users.uid}) = LOWER(${cleanUser})`
          )
        )
        .limit(1);

      if (existing.length > 0 && existing[0].id !== user.id) {
        res.status(409).json({
          success: false,
          error: {
            code: "USERNAME_EXISTS",
            message: "اسم المستخدم هذا مسجل مسبقاً، يرجى اختيار اسم مستخدم آخر.",
          },
          requestId: req.id,
        });
        return;
      }
    }

    const updatedDisplayName = cleanDisplayName || user.displayName || cleanUser;

    await db
      .update(users)
      .set({
        uid: cleanUser,
        displayName: updatedDisplayName,
        updatedAt: new Date(),
      })
      .where(eq(users.id, user.id));

    const userPayload = {
      userId: user.id,
      username: cleanUser,
      role: user.role || "CLERK",
      tenantId: user.tenantId,
      tokenVersion: user.tokenVersion || 1,
    };

    const accessToken = await signAccessToken(userPayload);
    const isProd = process.env.NODE_ENV === "production";
    res.cookie("accessToken", accessToken, {
      httpOnly: true,
      secure: isProd,
      sameSite: "lax",
      maxAge: 8 * 60 * 60 * 1000,
    });

    await insertAuditLog({
      tenantId: user.tenantId,
      actorId: String(user.id),
      actorName: cleanUser,
      action: "CHANGE_USERNAME",
      resource: "auth",
      details: `Username changed from "${user.uid}" to "${cleanUser}"`,
      ipAddress: req.ip || "127.0.0.1",
    });

    res.json({
      success: true,
      message: "تم تحديث اسم المستخدم والبيانات الشخصية بنجاح.",
      token: accessToken,
      user: {
        id: String(user.id),
        name: updatedDisplayName,
        displayName: updatedDisplayName,
        username: cleanUser,
        email: user.email,
        role: user.role,
        tenantId: user.tenantId,
      },
    });
  } catch (err) {
    next(err);
  }
});

authRouter.post("/change-password", requireAuth, async (req, res, next) => {
  try {
    const {
      oldPassword = "",
      currentPassword = "",
      newPassword = "",
    } = req.body || {};
    const rawOld = String(currentPassword || oldPassword);
    const rawNew = String(newPassword);

    if (!rawOld) {
      res.status(400).json({
        success: false,
        error: { code: "VALIDATION_ERROR", message: "يرجى إدخال كلمة المرور الحالية." },
        requestId: req.id,
      });
      return;
    }

    if (!rawNew) {
      res.status(400).json({
        success: false,
        error: { code: "VALIDATION_ERROR", message: "يرجى إدخال كلمة المرور الجديدة." },
        requestId: req.id,
      });
      return;
    }

    if (rawOld === rawNew) {
      res.status(400).json({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: "كلمة المرور الجديدة يجب أن تكون مختلفة عن كلمة المرور الحالية.",
        },
        requestId: req.id,
      });
      return;
    }

    const compCheck = validatePasswordComplexity(rawNew);
    if (!compCheck.valid) {
      let arReason =
        "كلمة المرور يجب أن تكون 10 خانات على الأقل وتتضمن أحرفاً كبيرة وصغيرة وأرقاماً.";
      if (rawNew.length < 10) {
        arReason = "كلمة المرور يجب أن تتكون من 10 خانات على الأقل.";
      } else if (!/[A-Z]/.test(rawNew)) {
        arReason =
          "كلمة المرور يجب أن تحتوي على حرف كبير إنجليزي واحد على الأقل (A-Z).";
      } else if (!/[a-z]/.test(rawNew)) {
        arReason =
          "كلمة المرور يجب أن تحتوي على حرف صغير إنجليزي واحد على الأقل (a-z).";
      } else if (!/[0-9]/.test(rawNew)) {
        arReason = "كلمة المرور يجب أن تحتوي على رقم واحد على الأقل (0-9).";
      }
      res.status(400).json({
        success: false,
        error: { code: "WEAK_PASSWORD", message: arReason },
        requestId: req.id,
      });
      return;
    }

    const userId = Number(req.user?.userId);
    const rows = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    const user = rows[0];
    if (!user || !user.passwordHash || !user.salt) {
      res.status(404).json({
        success: false,
        error: {
          code: "NOT_FOUND",
          message: "المستخدم غير موجود في قاعدة البيانات.",
        },
        requestId: req.id,
      });
      return;
    }

    const { matches } = verifyPasswordHash(rawOld, user.salt, user.passwordHash);
    if (!matches) {
      res.status(400).json({
        success: false,
        error: { code: "INVALID_PASSWORD", message: "كلمة المرور الحالية غير صحيحة." },
        requestId: req.id,
      });
      return;
    }

    await updateUserPassword(user.id, rawNew);

    await insertAuditLog({
      tenantId: user.tenantId,
      actorId: String(user.id),
      actorName: user.uid,
      action: "CHANGE_PASSWORD",
      resource: "auth",
      details: "Password updated successfully by authenticated user",
      ipAddress: req.ip || "127.0.0.1",
    });

    res.json({ success: true, message: "تم تغيير كلمة المرور بنجاح." });
  } catch (err) {
    next(err);
  }
});

export { authRouter, loginLimiter };
