import { Router } from "express";
import { z } from "zod";
import { eq, and, or, isNull, desc, asc, ne, inArray, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { customers, customerDocuments, companies } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  verifyBranchOwnership,
  verifyCustomerOwnership,
  verifyCompanyOwnership,
} from "../middleware/tenantOwnership.js";
import { normalizeAndValidateDate } from "../services/crExtractionService.js";
import {
  classifyDocumentExpiry,
  runExpiryAudit,
} from "../services/expiryCronService.js";
import {
  readStoredDocumentBuffer,
  sanitizeDownloadMimeType,
  buildContentDispositionAttachment,
} from "../services/documentStorageService.js";

const customerRouter = Router();

const emptyToNull = (val: unknown) =>
  typeof val === "string" && val.trim() === "" ? null : val;

const CustomerSchema = z
  .object({
    branchId: z.preprocess(
      (v) => (v === "" || v === null ? undefined : v),
      z.coerce.number().int().optional().nullable()
    ),
    customerType: z.preprocess(
      (val) => {
        if (typeof val === "string") {
          const u = val.toUpperCase();
          if (u === "COMPANY" || u === "ENTERPRISE" || u === "GOVERNMENT")
            return "COMPANY";
          return "INDIVIDUAL";
        }
        return val;
      },
      z.enum(["INDIVIDUAL", "COMPANY"]).default("INDIVIDUAL")
    ),
    civilId: z.preprocess(
      emptyToNull,
      z.string().max(50).optional().nullable()
    ),
    passportNo: z.preprocess(
      emptyToNull,
      z.string().max(50).optional().nullable()
    ),
    nationality: z.preprocess(
      emptyToNull,
      z.string().default("Omani").optional()
    ),
    fullNameAr: z.preprocess(emptyToNull, z.string().optional().nullable()),
    fullName: z.preprocess(emptyToNull, z.string().optional().nullable()),
    name: z.preprocess(emptyToNull, z.string().optional().nullable()),
    fullNameEn: z.preprocess(emptyToNull, z.string().optional().nullable()),
    phone: z.preprocess(emptyToNull, z.string().optional().nullable()),
    whatsapp: z.preprocess(emptyToNull, z.string().optional().nullable()),
    email: z.preprocess(
      emptyToNull,
      z
        .string()
        .email("صيغة البريد الإلكتروني غير صحيحة")
        .optional()
        .nullable()
    ),
    address: z.preprocess(emptyToNull, z.string().optional().nullable()),
    companyName: z.preprocess(emptyToNull, z.string().optional().nullable()),
    crNumber: z.preprocess(emptyToNull, z.string().optional().nullable()),
    segment: z.preprocess(emptyToNull, z.string().optional().nullable()),
  })
  .passthrough();

const CustomerDocNestedSchema = z.object({
  companyId: z.number().int().optional().nullable(),
  docType: z.string().min(1, "نوع الوثيقة مطلوب"),
  docNumber: z.string().optional().nullable(),
  issueDate: z.string().optional().nullable(),
  expiryDate: z.string().optional().nullable(),
  extractionSource: z.string().optional().nullable(),
  hasNoExpiry: z.boolean().optional().default(false),
  fileUrl: z.string().optional().nullable(),
  originalFileName: z.string().optional().nullable(),
});

customerRouter.get(
  "/",
  requireAuth,
  requirePermission("customers:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, search, includeDeleted, sortOrder } =
        parsePaginationParams(req);

      const conditions = [eq(customers.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(customers.deletedAt));
      }
      if (search) {
        const pattern = `%${search}%`;
        conditions.push(
          or(
            sql`${customers.fullNameAr} ILIKE ${pattern}`,
            sql`COALESCE(${customers.civilId}, '') ILIKE ${pattern}`,
            sql`COALESCE(${customers.phone}, '') ILIKE ${pattern}`,
            sql`COALESCE(${customers.whatsapp}, '') ILIKE ${pattern}`
          )!
        );
      }

      const whereClause = and(...conditions);
      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(customers)
        .where(whereClause);

      const rows = await db
        .select()
        .from(customers)
        .where(whereClause)
        .orderBy(sortOrder === "desc" ? desc(customers.id) : asc(customers.id))
        .limit(limit)
        .offset(offset);

      const companyList = await db
        .select({
          id: companies.id,
          ownerCustomerId: companies.ownerCustomerId,
          name: companies.name,
          taxId: companies.taxId,
          contactPhone: companies.contactPhone,
        })
        .from(companies)
        .where(
          and(eq(companies.tenantId, tenantId), isNull(companies.deletedAt))
        );

      const data = rows.map((c) => {
        const cPhoneDigits = (c.phone || c.whatsapp || "").replace(
          /[^0-9]/g,
          ""
        );
        const last8 = cPhoneDigits.slice(-8);

        const matchedComp = companyList.find((comp) => {
          if (comp.ownerCustomerId && comp.ownerCustomerId === c.id)
            return true;
          if (!comp.contactPhone) return false;
          const compPhoneDigits = comp.contactPhone.replace(/[^0-9]/g, "");
          return (
            compPhoneDigits === cPhoneDigits ||
            (last8 && compPhoneDigits.endsWith(last8)) ||
            (compPhoneDigits.length >= 8 &&
              cPhoneDigits.endsWith(compPhoneDigits.slice(-8)))
          );
        });

        return {
          ...c,
          fullName: c.fullNameAr,
          name: c.fullNameAr,
          companyId: matchedComp ? matchedComp.id : null,
          companyName: matchedComp ? matchedComp.name : null,
          crNumber: matchedComp ? matchedComp.taxId : null,
        };
      });

      res.json({
        success: true,
        data,
        pagination: {
          total: count,
          page,
          limit,
          totalPages: Math.ceil(count / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

customerRouter.post(
  "/",
  requireAuth,
  requirePermission("customers:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = CustomerSchema.parse(req.body);
      await verifyBranchOwnership(tenantId, validated.branchId);

      const resolvedName =
        validated.fullNameAr ||
        validated.fullName ||
        validated.name ||
        "عميل جديد";
      if (validated.civilId) {
        const [existing] = await db
          .select()
          .from(customers)
          .where(
            and(
              eq(customers.tenantId, tenantId),
              eq(customers.civilId, validated.civilId),
              isNull(customers.deletedAt)
            )
          )
          .limit(1);
        if (existing) {
          res.status(409).json({
            success: false,
            error: {
              code: "DUPLICATE_CIVIL_ID",
              message: "يوجد عميل آخر مسجل بنفس الرقم المدني",
              details: {
                civilId: validated.civilId,
                existingCustomerId: existing.id,
              },
            },
            requestId: req.id,
          });
          return;
        }
      }
      const [newCustomer] = await db
        .insert(customers)
        .values({
          tenantId,
          branchId: validated.branchId ?? null,
          customerType: validated.customerType || "INDIVIDUAL",
          civilId: validated.civilId ?? null,
          passportNo: validated.passportNo ?? null,
          nationality: validated.nationality || "Omani",
          fullNameAr: resolvedName,
          fullNameEn: validated.fullNameEn ?? null,
          phone: validated.phone || validated.whatsapp || "",
          whatsapp: validated.whatsapp || validated.phone || null,
          email: validated.email ?? null,
          address: validated.address ?? null,
          createdBy: req.user?.userId
            ? String(req.user.userId)
            : req.user?.username || "system",
        })
        .returning();
      res.status(201).json({ success: true, data: newCustomer });
    } catch (err) {
      next(err);
    }
  }
);

// Nested customer documents routes (#6, #55, #56, #107)
customerRouter.get(
  "/:id/documents",
  requireAuth,
  requirePermission("customers:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const customerId = parseInt(req.params.id, 10);
      if (isNaN(customerId)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      await verifyCustomerOwnership(tenantId, customerId);
      const docs = await db
        .select()
        .from(customerDocuments)
        .where(
          and(
            eq(customerDocuments.customerId, customerId),
            eq(customerDocuments.tenantId, tenantId),
            isNull(customerDocuments.deletedAt)
          )
        )
        .orderBy(desc(customerDocuments.id));
      res.json({ success: true, data: docs });
    } catch (err) {
      next(err);
    }
  }
);

customerRouter.post(
  "/:id/documents",
  requireAuth,
  requirePermission("customers:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const customerId = parseInt(req.params.id, 10);
      if (isNaN(customerId)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      await verifyCustomerOwnership(tenantId, customerId);
      const validated = CustomerDocNestedSchema.parse(req.body);
      await verifyCompanyOwnership(tenantId, validated.companyId);

      const normIssueDate = validated.issueDate
        ? normalizeAndValidateDate(validated.issueDate)
        : null;
      const normExpiryDate = validated.hasNoExpiry
        ? null
        : validated.expiryDate
          ? normalizeAndValidateDate(validated.expiryDate)
          : null;

      const classification = classifyDocumentExpiry({
        expiryDate: validated.expiryDate,
        hasNoExpiry: validated.hasNoExpiry,
      });

      const inserted = await db
        .insert(customerDocuments)
        .values({
          tenantId,
          customerId,
          companyId: validated.companyId ?? null,
          docType: validated.docType,
          docNumber: validated.docNumber ?? null,
          issueDate: normIssueDate ?? null,
          expiryDate: normExpiryDate ?? null,
          rawIssueDate: validated.issueDate ?? null,
          rawExpiryDate: validated.expiryDate ?? null,
          extractionSource: validated.extractionSource || "MANUAL",
          hasNoExpiry: Boolean(validated.hasNoExpiry),
          expiryStatus: classification.status,
          needsReview: classification.needsReview,
          fileUrl: validated.fileUrl ?? null,
          originalFileName: validated.originalFileName ?? null,
          createdBy: String(req.user?.userId || req.user?.username || "System"),
        })
        .returning();

      const newDoc = inserted[0];
      await runExpiryAudit({ tenantId, triggerType: "IMMEDIATE_UPLOAD" });
      res.status(201).json({ success: true, data: newDoc });
    } catch (err) {
      next(err);
    }
  }
);

customerRouter.get(
  "/customer-documents/:id/download",
  requireAuth,
  requirePermission("customers:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف الوثيقة غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const [doc] = await db
        .select()
        .from(customerDocuments)
        .where(
          and(
            eq(customerDocuments.id, id),
            eq(customerDocuments.tenantId, tenantId),
            isNull(customerDocuments.deletedAt)
          )
        )
        .limit(1);

      if (!doc) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "الوثيقة غير موجودة" },
          requestId: req.id,
        });
        return;
      }

      const stored = readStoredDocumentBuffer(doc.storageObjectKey, doc.fileUrl);
      if (!stored) {
        res.status(404).json({
          success: false,
          error: {
            code: "FILE_BINARY_NOT_FOUND",
            message: "الملف الأصلي للوثيقة غير متوفر للتنزيل",
          },
          requestId: req.id,
        });
        return;
      }

      const safeMime = sanitizeDownloadMimeType(stored.mimeType);
      const ext =
        safeMime === "application/pdf"
          ? "pdf"
          : safeMime === "image/png"
            ? "png"
            : safeMime === "image/webp"
              ? "webp"
              : "jpg";
      const rawName =
        doc.originalFileName ||
        `${doc.docType || "document"}_${doc.docNumber || doc.id}.${ext}`;

      res.setHeader("Content-Type", safeMime);
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader(
        "Content-Disposition",
        buildContentDispositionAttachment(rawName, `document.${ext}`)
      );
      res.setHeader("Content-Length", String(stored.buffer.length));
      res.send(stored.buffer);
    } catch (err) {
      next(err);
    }
  }
);

customerRouter.get(
  "/:id",
  requireAuth,
  requirePermission("customers:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const [customer] = await db
        .select()
        .from(customers)
        .where(and(eq(customers.id, id), eq(customers.tenantId, tenantId)))
        .limit(1);
      if (!customer) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "العميل غير موجود" },
          requestId: req.id,
        });
        return;
      }
      const docs = await db
        .select()
        .from(customerDocuments)
        .where(
          and(
            eq(customerDocuments.customerId, id),
            eq(customerDocuments.tenantId, tenantId),
            isNull(customerDocuments.deletedAt)
          )
        );
      res.json({ success: true, data: { ...customer, documents: docs } });
    } catch (err) {
      next(err);
    }
  }
);

customerRouter.put(
  "/:id",
  requireAuth,
  requirePermission("customers:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const validated = CustomerSchema.partial().parse(req.body);
      await verifyBranchOwnership(tenantId, validated.branchId);
      const companyName = validated.companyName;
      const crNumber = validated.crNumber;

      const resolvedName =
        validated.fullNameAr || validated.fullName || validated.name;

      const dbUpdateData: Record<string, unknown> = {};
      if (resolvedName) dbUpdateData.fullNameAr = resolvedName;
      if (validated.fullNameEn !== undefined)
        dbUpdateData.fullNameEn = validated.fullNameEn;
      if (validated.phone !== undefined) dbUpdateData.phone = validated.phone;
      if (validated.whatsapp !== undefined)
        dbUpdateData.whatsapp = validated.whatsapp;
      if (validated.email !== undefined) dbUpdateData.email = validated.email;
      if (validated.civilId !== undefined)
        dbUpdateData.civilId = validated.civilId;
      if (validated.passportNo !== undefined)
        dbUpdateData.passportNo = validated.passportNo;
      if (validated.nationality !== undefined)
        dbUpdateData.nationality = validated.nationality;
      if (validated.address !== undefined)
        dbUpdateData.address = validated.address;
      if (validated.branchId !== undefined)
        dbUpdateData.branchId = validated.branchId;
      if (validated.customerType !== undefined)
        dbUpdateData.customerType = validated.customerType;

      if (
        Object.keys(dbUpdateData).length === 0 &&
        companyName === undefined &&
        crNumber === undefined
      ) {
        res.status(422).json({
          success: false,
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
          requestId: req.id,
        });
        return;
      }

      if (companyName !== undefined || crNumber !== undefined) {
        const [existingComp] = await db
          .select()
          .from(companies)
          .where(
            and(
              eq(companies.tenantId, tenantId),
              eq(companies.ownerCustomerId, id),
              isNull(companies.deletedAt)
            )
          )
          .limit(1);

        if (existingComp) {
          await db
            .update(companies)
            .set({
              ...(companyName !== undefined
                ? { name: companyName || existingComp.name }
                : {}),
              ...(crNumber !== undefined
                ? { taxId: crNumber, normalizedCrNumber: crNumber }
                : {}),
              ...(typeof dbUpdateData.phone === "string"
                ? { contactPhone: dbUpdateData.phone }
                : {}),
              updatedAt: new Date(),
            })
            .where(
              and(
                eq(companies.id, existingComp.id),
                eq(companies.tenantId, tenantId)
              )
            );
        } else if (companyName) {
          await db.insert(companies).values({
            tenantId,
            companyCode: `CR-${crNumber || Date.now().toString().slice(-7)}`,
            name: companyName,
            taxId: crNumber || null,
            normalizedCrNumber: crNumber || null,
            ownerCustomerId: id,
            contactPhone:
              typeof dbUpdateData.phone === "string" ? dbUpdateData.phone : null,
          });
        }
      }

      if (typeof dbUpdateData.civilId === "string" && dbUpdateData.civilId) {
        const [existing] = await db
          .select()
          .from(customers)
          .where(
            and(
              eq(customers.tenantId, tenantId),
              eq(customers.civilId, dbUpdateData.civilId),
              isNull(customers.deletedAt),
              ne(customers.id, id)
            )
          )
          .limit(1);
        if (existing) {
          res.status(409).json({
            success: false,
            error: {
              code: "DUPLICATE_CIVIL_ID",
              message: "يوجد عميل آخر مسجل بنفس الرقم المدني",
            },
            requestId: req.id,
          });
          return;
        }
      }

      let updated;
      if (Object.keys(dbUpdateData).length > 0) {
        const [resCustomer] = await db
          .update(customers)
          .set({ ...dbUpdateData, updatedAt: new Date() })
          .where(and(eq(customers.id, id), eq(customers.tenantId, tenantId)))
          .returning();
        updated = resCustomer;
      } else {
        const [resCustomer] = await db
          .select()
          .from(customers)
          .where(and(eq(customers.id, id), eq(customers.tenantId, tenantId)))
          .limit(1);
        updated = resCustomer;
      }

      if (!updated) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "العميل غير موجود" },
          requestId: req.id,
        });
        return;
      }
      res.json({
        success: true,
        data: {
          ...updated,
          fullName: updated.fullNameAr,
          name: updated.fullNameAr,
          companyName: companyName !== undefined ? companyName : undefined,
          crNumber: crNumber !== undefined ? crNumber : undefined,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

customerRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("customers:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }

      const [deleted] = await db
        .update(customers)
        .set({ deletedAt: new Date(), updatedAt: new Date() })
        .where(
          and(
            eq(customers.id, id),
            eq(customers.tenantId, tenantId),
            isNull(customers.deletedAt)
          )
        )
        .returning();

      if (!deleted) {
        res.status(404).json({
          success: false,
          error: {
            code: "NOT_FOUND",
            message: "العميل غير موجود أو تم حذفه مسبقاً",
          },
          requestId: req.id,
        });
        return;
      }
      res.json({
        success: true,
        message:
          "تم نقل العميل إلى المحذوفات بنجاح مع الحفاظ على أمان المعاملات",
      });
    } catch (err) {
      next(err);
    }
  }
);

customerRouter.post(
  "/bulk-delete",
  requireAuth,
  requirePermission("customers:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { ids } = req.body || {};
      if (!Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({
          success: false,
          error: {
            code: "INVALID_IDS",
            message: "لم يتم تحديد أي عملاء للحذف",
          },
          requestId: req.id,
        });
        return;
      }

      const numericIds = ids
        .map((x: unknown) => {
          if (typeof x === "number") return x;
          if (typeof x === "string") {
            const cleaned = x.replace(/^comp-|^cust-/, "");
            const parsed = parseInt(cleaned, 10);
            return isNaN(parsed) ? null : parsed;
          }
          return null;
        })
        .filter((n): n is number => n !== null);

      if (numericIds.length > 0) {
        await db
          .update(customers)
          .set({ deletedAt: new Date(), updatedAt: new Date() })
          .where(
            and(
              eq(customers.tenantId, tenantId),
              inArray(customers.id, numericIds),
              isNull(customers.deletedAt)
            )
          );
      }

      res.json({
        success: true,
        message: `تم حذف ${numericIds.length} عملاء بنجاح ونقلهم للمحذوفات بأمان`,
        deletedCount: numericIds.length,
      });
    } catch (err) {
      next(err);
    }
  }
);

export { customerRouter };
