import { Router } from "express";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { tenantSettings } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";

const settingsRouter = Router();

const ALLOWED_MODELS = [
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-flash-lite-preview",
] as const;

const SettingsUpdateSchema = z.object({
  aiModel: z.string().min(3).max(80).optional(),
  autoReplyEnabled: z.boolean().optional(),
  humanApprovalMode: z.boolean().optional(),
  aiProcessingConsent: z.boolean().optional(),
  aiProcessingRegion: z.enum(["global", "eu", "us", "me"]).optional(),
  retentionDays: z.number().int().min(1).max(3650).optional(),
  warningDays: z.number().int().min(1).max(365).optional(),
  urgentDays: z.number().int().min(1).max(180).optional(),
});

export async function getOrCreateTenantSettings(tenantId: string) {
  const [existing] = await db
    .select()
    .from(tenantSettings)
    .where(eq(tenantSettings.tenantId, tenantId))
    .limit(1);

  if (existing) {
    return existing;
  }

  const defaultModel = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const defaultConsent = process.env.AI_PROCESSING_CONSENT !== "false";
  const defaultRegion = process.env.AI_PROCESSING_REGION || "global";
  const defaultRetention = parseInt(process.env.AI_RETENTION_DAYS || "365", 10) || 365;

  const [inserted] = await db
    .insert(tenantSettings)
    .values({
      tenantId,
      aiModel: defaultModel,
      autoReplyEnabled: true,
      humanApprovalMode: false,
      aiProcessingConsent: defaultConsent,
      aiProcessingRegion: defaultRegion,
      retentionDays: defaultRetention,
      warningDays: 30,
      urgentDays: 7,
    })
    .onConflictDoNothing()
    .returning();

  if (inserted) return inserted;

  const [fetched] = await db
    .select()
    .from(tenantSettings)
    .where(eq(tenantSettings.tenantId, tenantId))
    .limit(1);
  return fetched!;
}

settingsRouter.get("/", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const settings = await getOrCreateTenantSettings(tenantId);
    res.json({
      success: true,
      data: settings,
      supportedModels: ALLOWED_MODELS,
    });
  } catch (err) {
    next(err);
  }
});

settingsRouter.put(
  "/",
  requireAuth,
  requirePermission("system:manage"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = SettingsUpdateSchema.parse(req.body);
      await getOrCreateTenantSettings(tenantId);

      const [updated] = await db
        .update(tenantSettings)
        .set({
          ...validated,
          updatedAt: new Date(),
        })
        .where(eq(tenantSettings.tenantId, tenantId))
        .returning();

      res.json({
        success: true,
        data: updated,
        supportedModels: ALLOWED_MODELS,
      });
    } catch (err) {
      next(err);
    }
  }
);

export { settingsRouter };
