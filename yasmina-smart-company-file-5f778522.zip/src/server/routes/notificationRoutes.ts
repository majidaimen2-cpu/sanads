import { Router } from "express";
import { eq, and, desc, or } from "drizzle-orm";
import { db } from "../../db/index.js";
import { notifications, expiryJobRuns } from "../../db/schema.js";
import { requireAuth, requirePermission, getRequiredTenantId } from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  discoverAllMonitoredDocuments,
  runExpiryAudit,
  updateMonitoredDocumentExpiry,
  resolveDocTypeAr,
  normalizeDocTypeCode,
} from "../services/expiryCronService.js";

const notificationRouter = Router();

const STAGE_PRIORITY: Record<string, number> = {
  EXPIRED: 1,
  EXPIRING_TODAY: 2,
  EXPIRING_7: 3,
  EXPIRING_30: 4,
  NEEDS_REVIEW: 5,
  INFO: 6,
  NONE: 7,
};

notificationRouter.get(
  "/",
  requireAuth,
  requirePermission("notifications:read"),
  async (req: any, res, next) => {
    try {
      const tenantId = req.user.tenantId;
      const { page, limit, offset } = parsePaginationParams(req);

      const statusFilter = req.query.status
        ? String(req.query.status).trim().toUpperCase()
        : undefined;
      const alertStageFilter = req.query.alertStage
        ? String(req.query.alertStage).trim().toUpperCase()
        : undefined;
      const docTypeFilter = req.query.docType
        ? normalizeDocTypeCode(String(req.query.docType))
        : undefined;
      const companyIdFilter = req.query.companyId
        ? parseInt(String(req.query.companyId), 10)
        : undefined;
      const unreadOnly =
        req.query.unreadOnly === "true" || req.query.unreadOnly === "1";
      const search = req.query.search
        ? String(req.query.search).trim().toLowerCase()
        : undefined;

      const allTenantNotifications = await db
        .select()
        .from(notifications)
        .where(eq(notifications.tenantId, tenantId))
        .orderBy(desc(notifications.id));

      // Compute summary metrics across all delivered tenant notifications
      const deliveredTenantNotifs = allTenantNotifications.filter(
        (n) => (n.deliveryStatus || "DELIVERED") === "DELIVERED",
      );

      const unreadCount = deliveredTenantNotifs.filter(
        (n) => !n.isRead && n.status !== "READ",
      ).length;

      const summary = {
        total: deliveredTenantNotifs.length,
        unreadCount,
        expiredCount: deliveredTenantNotifs.filter(
          (n) => n.alertStage === "EXPIRED",
        ).length,
        expiringTodayCount: deliveredTenantNotifs.filter(
          (n) => n.alertStage === "EXPIRING_TODAY",
        ).length,
        expiring7Count: deliveredTenantNotifs.filter(
          (n) => n.alertStage === "EXPIRING_7",
        ).length,
        expiring30Count: deliveredTenantNotifs.filter(
          (n) => n.alertStage === "EXPIRING_30",
        ).length,
        needsReviewCount: deliveredTenantNotifs.filter(
          (n) => n.alertStage === "NEEDS_REVIEW",
        ).length,
      };

      // Filter rows according to query parameters
      let filtered = deliveredTenantNotifs.filter((n) => {
        if (unreadOnly && (n.isRead || n.status === "READ")) return false;
        if (statusFilter === "READ" && !n.isRead && n.status !== "READ")
          return false;
        if (statusFilter === "UNREAD" && (n.isRead || n.status === "READ"))
          return false;
        if (alertStageFilter && n.alertStage !== alertStageFilter) return false;
        if (docTypeFilter && normalizeDocTypeCode(n.docType) !== docTypeFilter)
          return false;
        if (
          companyIdFilter &&
          !isNaN(companyIdFilter) &&
          n.companyId !== companyIdFilter
        )
          return false;
        if (search) {
          const hay = [
            n.title,
            n.message,
            n.companyName,
            n.ownerName,
            n.docNumber,
            resolveDocTypeAr(n.docType),
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase();
          if (!hay.includes(search)) return false;
        }
        return true;
      });

      // Sort by highest urgency stage first, then by daysRemaining ascending, then newest first
      filtered.sort((a, b) => {
        const rankA = STAGE_PRIORITY[a.alertStage || "INFO"] ?? 6;
        const rankB = STAGE_PRIORITY[b.alertStage || "INFO"] ?? 6;
        if (rankA !== rankB) return rankA - rankB;
        const daysA = a.daysRemaining ?? 999999;
        const daysB = b.daysRemaining ?? 999999;
        if (daysA !== daysB) return daysA - daysB;
        return b.id - a.id;
      });

      const enriched = filtered.map((n) => ({
        ...n,
        docTypeAr: resolveDocTypeAr(n.docType),
        isRead: Boolean(n.isRead || n.status === "READ"),
      }));

      const total = enriched.length;
      const data = enriched.slice(offset, offset + limit);

      res.json({
        data,
        unreadCount,
        summary,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.get(
  "/expiry-monitor",
  requireAuth,
  requirePermission("notifications:read"),
  async (req: any, res, next) => {
    try {
      const tenantId = req.user.tenantId;
      const referenceDate = req.query.referenceDate
        ? String(req.query.referenceDate)
        : undefined;
      const warningDays = req.query.warningDays
        ? parseInt(String(req.query.warningDays), 10)
        : 30;
      const urgentDays = req.query.urgentDays
        ? parseInt(String(req.query.urgentDays), 10)
        : 7;

      const companyIdFilter = req.query.companyId
        ? parseInt(String(req.query.companyId), 10)
        : undefined;
      const docTypeFilter = req.query.docType
        ? normalizeDocTypeCode(String(req.query.docType))
        : undefined;
      const statusFilter = req.query.status
        ? String(req.query.status).trim().toUpperCase()
        : undefined;
      const daysMax =
        req.query.daysMax !== undefined
          ? parseInt(String(req.query.daysMax), 10)
          : undefined;
      const daysMin =
        req.query.daysMin !== undefined
          ? parseInt(String(req.query.daysMin), 10)
          : undefined;
      const search = req.query.search
        ? String(req.query.search).trim().toLowerCase()
        : undefined;

      const allItems = await discoverAllMonitoredDocuments(tenantId, {
        referenceDate,
        warningDays: !isNaN(warningDays) ? warningDays : 30,
        urgentDays: !isNaN(urgentDays) ? urgentDays : 7,
      });

      const summary = {
        totalDocuments: allItems.length,
        expiredCount: allItems.filter((i) => i.status === "EXPIRED").length,
        expiringTodayCount: allItems.filter(
          (i) => i.status === "EXPIRING_TODAY",
        ).length,
        expiring7Count: allItems.filter((i) => i.status === "EXPIRING_7")
          .length,
        expiring30Count: allItems.filter((i) => i.status === "EXPIRING_30")
          .length,
        needsReviewCount: allItems.filter((i) => i.status === "NEEDS_REVIEW")
          .length,
        validCount: allItems.filter((i) => i.status === "VALID").length,
        noExpiryCount: allItems.filter((i) => i.status === "NO_EXPIRY").length,
      };

      const filtered = allItems.filter((item) => {
        if (
          companyIdFilter &&
          !isNaN(companyIdFilter) &&
          item.companyId !== companyIdFilter
        ) {
          return false;
        }
        if (docTypeFilter && item.docTypeCode !== docTypeFilter) {
          return false;
        }
        if (statusFilter && statusFilter !== "ALL") {
          if (statusFilter === "EXPIRING_SOON") {
            if (
              item.status !== "EXPIRING_TODAY" &&
              item.status !== "EXPIRING_7" &&
              item.status !== "EXPIRING_30"
            ) {
              return false;
            }
          } else if (item.status !== statusFilter) {
            return false;
          }
        }
        if (daysMax !== undefined && !isNaN(daysMax)) {
          if (item.daysRemaining === null || item.daysRemaining > daysMax)
            return false;
        }
        if (daysMin !== undefined && !isNaN(daysMin)) {
          if (item.daysRemaining === null || item.daysRemaining < daysMin)
            return false;
        }
        if (search) {
          const hay = [
            item.companyName,
            item.ownerName,
            item.docNumber,
            item.docTypeAr,
            item.statusAr,
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase();
          if (!hay.includes(search)) return false;
        }
        return true;
      });

      res.json({
        data: filtered,
        summary,
      });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.get(
  "/job-runs",
  requireAuth,
  requirePermission("notifications:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const runs = await db
        .select()
        .from(expiryJobRuns)
        .where(
          or(
            eq(expiryJobRuns.tenantId, tenantId),
            eq(expiryJobRuns.tenantId, "ALL")
          )
        )
        .orderBy(desc(expiryJobRuns.id))
        .limit(25);
      res.json({ data: runs });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.post(
  "/run-audit",
  requireAuth,
  requirePermission("notifications:create"),
  async (req: any, res, next) => {
    try {
      const tenantId = req.user.tenantId;
      const result = await runExpiryAudit({
        tenantId,
        referenceDate: req.body?.referenceDate,
        warningDays: req.body?.warningDays,
        urgentDays: req.body?.urgentDays,
        triggerType: "MANUAL",
      });
      res.json({
        success: true,
        result,
      });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.put(
  "/read-all",
  requireAuth,
  requirePermission("notifications:update"),
  async (req: any, res, next) => {
    try {
      const tenantId = req.user.tenantId;
      const actor =
        req.user.displayName ||
        req.user.email ||
        String(req.user.userId || "User");
      const updated = await db
        .update(notifications)
        .set({
          isRead: true,
          status: "READ",
          readAt: new Date(),
          readBy: actor,
        })
        .where(eq(notifications.tenantId, tenantId))
        .returning();

      res.json({
        success: true,
        updatedCount: updated.length,
      });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.put(
  "/:id/read",
  requireAuth,
  requirePermission("notifications:update"),
  async (req: any, res, next) => {
    try {
      const tenantId = req.user.tenantId;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res
          .status(400)
          .json({ error: { code: "INVALID_ID", message: "معرف غير صالح" } });
      }
      const actor =
        req.user.displayName ||
        req.user.email ||
        String(req.user.userId || "User");
      const [updated] = await db
        .update(notifications)
        .set({
          isRead: true,
          status: "READ",
          readAt: new Date(),
          readBy: actor,
        })
        .where(
          and(eq(notifications.id, id), eq(notifications.tenantId, tenantId)),
        )
        .returning();

      if (!updated) {
        return res
          .status(404)
          .json({ error: { code: "NOT_FOUND", message: "الإشعار غير موجود" } });
      }
      res.json({ success: true, data: { ...updated, isRead: true } });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.delete(
  "/",
  requireAuth,
  requirePermission("notifications:delete"),
  async (req: any, res, next) => {
    try {
      const tenantId = req.user.tenantId;
      const readOnly =
        req.query.readOnly === "true" || req.query.readOnly === "1";

      const conditions = [eq(notifications.tenantId, tenantId)];
      if (readOnly) {
        conditions.push(eq(notifications.isRead, true));
      }

      const deleted = await db
        .delete(notifications)
        .where(and(...conditions))
        .returning();

      res.json({
        success: true,
        deletedCount: deleted.length,
        message: readOnly
          ? "تم مسح جميع الإشعارات المقروءة بنجاح"
          : "تم مسح جميع الإشعارات بنجاح",
      });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("notifications:delete"),
  async (req: any, res, next) => {
    try {
      const tenantId = req.user.tenantId;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res
          .status(400)
          .json({ error: { code: "INVALID_ID", message: "معرف غير صالح" } });
      }

      const [deleted] = await db
        .delete(notifications)
        .where(
          and(eq(notifications.id, id), eq(notifications.tenantId, tenantId)),
        )
        .returning();

      if (!deleted) {
        return res
          .status(404)
          .json({
            error: {
              code: "NOT_FOUND",
              message: "الإشعار غير موجود أو تم مسحه مسبقاً",
            },
          });
      }

      res.json({
        success: true,
        message: "تم مسح الإشعار بنجاح",
        data: deleted,
      });
    } catch (err) {
      next(err);
    }
  },
);

notificationRouter.patch(
  "/documents/:sourceEntity/:sourceId/expiry",
  requireAuth,
  requirePermission("customer_documents:update"),
  async (req: any, res) => {
    try {
      const tenantId = req.user.tenantId;
      const sourceEntity = req.params.sourceEntity as
        "companies" | "customer_documents" | "employees" | "contracts";
      const sourceId = String(req.params.sourceId);

      const allowedEntities = [
        "companies",
        "customer_documents",
        "employees",
        "contracts",
      ];
      if (!allowedEntities.includes(sourceEntity)) {
        return res.status(400).json({
          error: { code: "INVALID_ENTITY", message: "نوع الكيان غير مدعوم" },
        });
      }

      const result = await updateMonitoredDocumentExpiry({
        tenantId,
        sourceEntity,
        sourceId,
        expiryDate: req.body?.expiryDate,
        hasNoExpiry: req.body?.hasNoExpiry,
        actorId: String(req.user.userId || req.user.uid || ""),
        actorName: req.user.displayName || req.user.email || "User",
        ipAddress: req.ip || "127.0.0.1",
        referenceDate: req.body?.referenceDate,
      });

      res.json({
        success: true,
        ...result,
      });
    } catch (err: any) {
      res.status(400).json({
        error: {
          code: "EXPIRY_UPDATE_FAILED",
          message: err?.message || "تعذر تحديث تاريخ انتهاء الوثيقة",
        },
      });
    }
  },
);

notificationRouter.post(
  "/sync",
  requireAuth,
  requirePermission("notifications:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const incomingAlerts = Array.isArray(req.body?.alerts)
        ? req.body.alerts
        : [];
      let syncedCount = 0;

      for (const item of incomingAlerts.slice(0, 150)) {
        if (!item || typeof item !== "object") continue;
        const idempotencyKey = String(
          item.idempotencyKey ||
            item.id ||
            `client_alert_${item.title || ""}_${item.date || ""}`,
        ).slice(0, 240);
        if (!idempotencyKey) continue;

        const existing = await db
          .select({ id: notifications.id })
          .from(notifications)
          .where(
            and(
              eq(notifications.tenantId, tenantId),
              eq(notifications.idempotencyKey, idempotencyKey),
            ),
          )
          .limit(1);

        if (existing.length === 0 && (item.title || item.message)) {
          await db.insert(notifications).values({
            tenantId,
            idempotencyKey,
            type: String(item.type || "SYSTEM_ALERT"),
            title: String(item.title || "تنبيه النظام"),
            message: String(item.message || item.description || ""),
            status: item.isRead ? "READ" : "UNREAD",
            isRead: Boolean(item.isRead),
            alertStage: String(
              item.alertStage || item.severity || "INFO",
            ).toUpperCase(),
            deliveryStatus: "DELIVERED",
          });
          syncedCount++;
        }
      }

      const rows = await db
        .select()
        .from(notifications)
        .where(eq(notifications.tenantId, tenantId))
        .orderBy(desc(notifications.id))
        .limit(150);

      res.json({
        success: true,
        syncedCount,
        data: rows,
      });
    } catch (err) {
      next(err);
    }
  },
);

export { notificationRouter };
