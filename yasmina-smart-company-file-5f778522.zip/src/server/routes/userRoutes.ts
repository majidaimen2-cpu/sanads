import { Router } from "express";
import { z } from "zod";
import { eq, and, isNull, desc, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { users } from "../../db/schema.js";
import { insertAuditLog } from "../../db/users.js";
import { requireAuth, requireRole, getRequiredTenantId } from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  hashPasswordPBKDF2,
  validatePasswordComplexity,
  generateSalt,
  verifyPasswordHash,
} from "../auth.js";

const userRouter = Router();

const ROLE_HIERARCHY: Record<string, number> = {
  VIEWER: 10,
  CLERK: 20,
  CASHIER: 30,
  ACCOUNTANT: 40,
  MANAGER: 50,
  ADMIN: 50,
  SUPER_ADMIN: 100,
};

function getRoleRank(role: string): number {
  return ROLE_HIERARCHY[role] ?? 0;
}

const UserCreateSchema = z.object({
  email: z.string().email("صيغة البريد الإلكتروني غير صحيحة"),
  displayName: z.string().min(2, "الاسم مطلوب"),
  role: z.enum([
    "SUPER_ADMIN",
    "MANAGER",
    "ACCOUNTANT",
    "CASHIER",
    "CLERK",
    "VIEWER",
  ]),
  password: z.string().min(10, "كلمة المرور يجب ألا تقل عن 10 خانات"),
  permissions: z.array(z.string()).optional(),
  active: z.boolean().default(true),
});

const UserUpdateSchema = z.object({
  displayName: z.string().min(2).optional(),
  role: z
    .enum([
      "SUPER_ADMIN",
      "MANAGER",
      "ACCOUNTANT",
      "CASHIER",
      "CLERK",
      "VIEWER",
    ])
    .optional(),
  oldPassword: z.string().optional(),
  password: z.string().min(10).optional(),
  permissions: z.array(z.string()).optional(),
  active: z.boolean().optional(),
});

userRouter.get(
  "/",
  requireAuth,
  requireRole("SUPER_ADMIN", "MANAGER"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, includeDeleted } = parsePaginationParams(req);
      const conditions = [eq(users.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(users.deletedAt));
      }

      const whereClause = and(...conditions);
      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(users)
        .where(whereClause);

      const data = await db
        .select({
          id: users.id,
          uid: users.uid,
          email: users.email,
          displayName: users.displayName,
          role: users.role,
          active: users.active,
          mustChangePassword: users.mustChangePassword,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        })
        .from(users)
        .where(whereClause)
        .orderBy(desc(users.id))
        .limit(limit)
        .offset(offset);

      res.json({
        success: true,
        data,
        pagination: {
          total: count,
          page,
          limit,
          totalPages: Math.ceil(count / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

userRouter.post(
  "/",
  requireAuth,
  requireRole("SUPER_ADMIN", "MANAGER"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const callerRole = req.user!.role;
      const validated = UserCreateSchema.parse(req.body);

      // Role hierarchy enforcement (#46)
      if (validated.role === "SUPER_ADMIN" && callerRole !== "SUPER_ADMIN") {
        res.status(403).json({
          success: false,
          error: {
            code: "ROLE_ESCALATION_FORBIDDEN",
            message: "Only SUPER_ADMIN can assign the SUPER_ADMIN role.",
          },
          requestId: req.id,
        });
        return;
      }

      if (getRoleRank(validated.role) > getRoleRank(callerRole)) {
        res.status(403).json({
          success: false,
          error: {
            code: "ROLE_ESCALATION_FORBIDDEN",
            message: "Cannot create a user with a higher role than your own.",
          },
          requestId: req.id,
        });
        return;
      }

      const complexity = validatePasswordComplexity(validated.password);
      if (!complexity.valid) {
        res.status(400).json({
          success: false,
          error: { code: "WEAK_PASSWORD", message: complexity.reason || "Weak password" },
          requestId: req.id,
        });
        return;
      }

      const uid = validated.email.toLowerCase().trim();
      const existing = await db
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.tenantId, tenantId), eq(users.uid, uid)))
        .limit(1);

      if (existing.length > 0) {
        res.status(409).json({
          success: false,
          error: {
            code: "USER_EXISTS",
            message: "اسم المستخدم أو البريد الإلكتروني مسجل مسبقاً",
          },
          requestId: req.id,
        });
        return;
      }

      const salt = generateSalt();
      const hash = hashPasswordPBKDF2(validated.password, salt);
      const [newUser] = await db
        .insert(users)
        .values({
          tenantId,
          uid,
          email: validated.email,
          displayName: validated.displayName,
          role: validated.role,
          passwordHash: hash,
          salt,
          permissions: validated.permissions
            ? JSON.stringify(validated.permissions)
            : null,
          active: validated.active,
          mustChangePassword: true,
          createdBy: req.user!.username,
        })
        .returning({
          id: users.id,
          uid: users.uid,
          email: users.email,
          displayName: users.displayName,
          role: users.role,
          active: users.active,
          createdAt: users.createdAt,
        });

      await insertAuditLog({
        tenantId,
        actorId: String(req.user!.userId),
        actorName: req.user!.username,
        action: "USER_CREATE",
        resource: "users",
        resourceId: String(newUser.id),
        details: `Created user ${newUser.uid} with role ${newUser.role}`,
        ipAddress: req.ip || "127.0.0.1",
      });

      res.status(201).json({ success: true, data: newUser });
    } catch (err) {
      next(err);
    }
  }
);

userRouter.put(
  "/:id",
  requireAuth,
  requireRole("SUPER_ADMIN", "MANAGER"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const caller = req.user!;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }

      const validated = UserUpdateSchema.parse(req.body);
      if (Object.keys(validated).length === 0) {
        res.status(422).json({
          success: false,
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
          requestId: req.id,
        });
        return;
      }

      const [targetUser] = await db
        .select()
        .from(users)
        .where(and(eq(users.id, id), eq(users.tenantId, tenantId)))
        .limit(1);

      if (!targetUser) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المستخدم غير موجود" },
          requestId: req.id,
        });
        return;
      }

      // Cannot modify a user of higher role than caller (#46)
      if (getRoleRank(targetUser.role) > getRoleRank(caller.role)) {
        res.status(403).json({
          success: false,
          error: {
            code: "FORBIDDEN",
            message: "Cannot modify a user with a higher role than your own.",
          },
          requestId: req.id,
        });
        return;
      }

      // Role change rules (#46)
      if (validated.role !== undefined && validated.role !== targetUser.role) {
        if (targetUser.id === caller.userId) {
          res.status(403).json({
            success: false,
            error: {
              code: "SELF_ROLE_MODIFICATION_FORBIDDEN",
              message: "Users cannot modify their own role.",
            },
            requestId: req.id,
          });
          return;
        }
        if (validated.role === "SUPER_ADMIN" && caller.role !== "SUPER_ADMIN") {
          res.status(403).json({
            success: false,
            error: {
              code: "ROLE_ESCALATION_FORBIDDEN",
              message: "Only SUPER_ADMIN can assign the SUPER_ADMIN role.",
            },
            requestId: req.id,
          });
          return;
        }
        if (getRoleRank(validated.role) > getRoleRank(caller.role)) {
          res.status(403).json({
            success: false,
            error: {
              code: "ROLE_ESCALATION_FORBIDDEN",
              message: "Cannot promote a user above your own role.",
            },
            requestId: req.id,
          });
          return;
        }
      }

      const updateData: Record<string, unknown> = { updatedAt: new Date() };
      if (validated.displayName) updateData.displayName = validated.displayName;
      if (validated.role) updateData.role = validated.role;
      if (validated.active !== undefined) updateData.active = validated.active;
      if (validated.permissions) {
        updateData.permissions = JSON.stringify(validated.permissions);
      }

      if (validated.password) {
        const complexity = validatePasswordComplexity(validated.password);
        if (!complexity.valid) {
          res.status(400).json({
            success: false,
            error: { code: "WEAK_PASSWORD", message: complexity.reason || "Weak password" },
            requestId: req.id,
          });
          return;
        }

        // Self password change requires oldPassword; admin resetting another user requires strictly higher role (or SUPER_ADMIN)
        if (targetUser.id === caller.userId) {
          if (!validated.oldPassword || !targetUser.passwordHash || !targetUser.salt) {
            res.status(400).json({
              success: false,
              error: {
                code: "OLD_PASSWORD_REQUIRED",
                message: "Current password (oldPassword) is required to change your own password.",
              },
              requestId: req.id,
            });
            return;
          }
          const { matches } = verifyPasswordHash(
            validated.oldPassword,
            targetUser.salt,
            targetUser.passwordHash
          );
          if (!matches) {
            res.status(400).json({
              success: false,
              error: {
                code: "INVALID_OLD_PASSWORD",
                message: "Current password is incorrect.",
              },
              requestId: req.id,
            });
            return;
          }
        } else if (
          caller.role !== "SUPER_ADMIN" &&
          getRoleRank(targetUser.role) >= getRoleRank(caller.role)
        ) {
          res.status(403).json({
            success: false,
            error: {
              code: "PASSWORD_RESET_FORBIDDEN",
              message: "You can only reset passwords for users with a strictly lower role.",
            },
            requestId: req.id,
          });
          return;
        }

        const salt = generateSalt();
        const hash = hashPasswordPBKDF2(validated.password, salt);
        updateData.passwordHash = hash;
        updateData.salt = salt;
        updateData.tokenVersion = (targetUser.tokenVersion || 1) + 1;
        updateData.activeRefreshJti = null;

        await insertAuditLog({
          tenantId,
          actorId: String(caller.userId),
          actorName: caller.username,
          action: "ADMIN_PASSWORD_RESET",
          resource: "users",
          resourceId: String(targetUser.id),
          details: `Password reset for user ${targetUser.uid} (tokenVersion incremented)`,
          ipAddress: req.ip || "127.0.0.1",
        });
      }

      const [updated] = await db
        .update(users)
        .set(updateData)
        .where(and(eq(users.id, id), eq(users.tenantId, tenantId)))
        .returning({
          id: users.id,
          uid: users.uid,
          email: users.email,
          displayName: users.displayName,
          role: users.role,
          active: users.active,
        });

      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  }
);

userRouter.delete(
  "/:id",
  requireAuth,
  requireRole("SUPER_ADMIN"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      if (id === req.user!.userId) {
        res.status(400).json({
          success: false,
          error: {
            code: "SELF_DELETE_FORBIDDEN",
            message: "Cannot delete your own active account.",
          },
          requestId: req.id,
        });
        return;
      }
      const [deleted] = await db
        .update(users)
        .set({
          deletedAt: new Date(),
          active: false,
          tokenVersion: sql`${users.tokenVersion} + 1`,
          activeRefreshJti: null,
        })
        .where(
          and(
            eq(users.id, id),
            eq(users.tenantId, tenantId),
            isNull(users.deletedAt)
          )
        )
        .returning();
      if (!deleted) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المستخدم غير موجود" },
          requestId: req.id,
        });
        return;
      }
      res.json({
        success: true,
        message: "تم تعطيل وحذف حساب المستخدم بنجاح",
      });
    } catch (err) {
      next(err);
    }
  }
);

export { userRouter };
