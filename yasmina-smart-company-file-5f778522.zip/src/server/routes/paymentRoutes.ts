import { Router } from "express";
import { z } from "zod";
import { eq, and, desc, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { payments } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  verifyBranchOwnership,
  verifyTransactionOwnership,
  verifyInvoiceOwnership,
  verifyCashSessionOwnership,
} from "../middleware/tenantOwnership.js";
import { recordPayment } from "../services/paymentService.js";

const paymentRouter = Router();

const PaymentCreateSchema = z.object({
  branchId: z.number().int().optional().nullable(),
  transactionId: z.number().int({
    message: "معرف المعاملة مطلوب",
  }),
  invoiceId: z.number().int().optional().nullable(),
  method: z.enum(["CASH", "CARD", "BANK", "TRANSFER"]),
  amountBaisa: z
    .number()
    .int()
    .positive("مبلغ الدفع يجب أن يكون أكبر من صفر"),
  cashSessionId: z.number().int().optional().nullable(),
  referenceNo: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

paymentRouter.get(
  "/",
  requireAuth,
  requirePermission("payments:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset } = parsePaginationParams(req);
      const transactionId = req.query.transactionId
        ? parseInt(String(req.query.transactionId), 10)
        : undefined;
      const invoiceId = req.query.invoiceId
        ? parseInt(String(req.query.invoiceId), 10)
        : undefined;
      const cashSessionId = req.query.cashSessionId
        ? parseInt(String(req.query.cashSessionId), 10)
        : undefined;

      const conditions: SQL[] = [eq(payments.tenantId, tenantId)];
      if (transactionId && !isNaN(transactionId)) {
        conditions.push(eq(payments.transactionId, transactionId));
      }
      if (invoiceId && !isNaN(invoiceId)) {
        conditions.push(eq(payments.invoiceId, invoiceId));
      }
      if (cashSessionId && !isNaN(cashSessionId)) {
        conditions.push(eq(payments.cashSessionId, cashSessionId));
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(payments)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(payments)
        .where(whereClause)
        .orderBy(desc(payments.id))
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

paymentRouter.post(
  "/",
  requireAuth,
  requirePermission("payments:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const userId = Number(req.user?.userId) || undefined;
      const validated = PaymentCreateSchema.parse(req.body);

      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyTransactionOwnership(tenantId, validated.transactionId);
      await verifyInvoiceOwnership(tenantId, validated.invoiceId);
      await verifyCashSessionOwnership(tenantId, validated.cashSessionId);

      const result = await recordPayment({
        tenantId,
        userId,
        transactionId: validated.transactionId,
        invoiceId: validated.invoiceId,
        method: validated.method,
        amountBaisa: validated.amountBaisa,
        referenceNo: validated.referenceNo,
        notes: validated.notes,
      });
      res.status(201).json({
        success: true,
        data: result.payment,
        remainingBaisa: result.remainingBaisa,
      });
    } catch (err) {
      next(err);
    }
  },
);

paymentRouter.get(
  "/:id",
  requireAuth,
  requirePermission("payments:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [payment] = await db
        .select()
        .from(payments)
        .where(and(eq(payments.id, id), eq(payments.tenantId, tenantId)))
        .limit(1);
      if (!payment) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "سجل الدفع غير موجود",
          },
        });
      }
      res.json({ data: payment });
    } catch (err) {
      next(err);
    }
  },
);

export { paymentRouter };
