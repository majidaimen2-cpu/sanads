import { Router } from "express";
import { z } from "zod";
import { eq, and, isNull, desc, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { branches } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";

const branchRouter = Router();

const BranchSchema = z.object({
  code: z.string().min(2, "رمز الفرع مطلوب"),
  nameAr: z.string().min(2, "اسم الفرع بالعربية مطلوب"),
  nameEn: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  active: z.boolean().default(true),
});

branchRouter.get(
  "/",
  requireAuth,
  requirePermission("branches:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, includeDeleted } =
        parsePaginationParams(req);
      const conditions: SQL[] = [eq(branches.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(branches.deletedAt));
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(branches)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(branches)
        .where(whereClause)
        .orderBy(desc(branches.id))
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

branchRouter.post(
  "/",
  requireAuth,
  requirePermission("branches:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = BranchSchema.parse(req.body);
      const [newBranch] = await db
        .insert(branches)
        .values({
          tenantId,
          code: validated.code,
          nameAr: validated.nameAr,
          nameEn: validated.nameEn ?? null,
          address: validated.address ?? null,
          phone: validated.phone ?? null,
          active: validated.active,
          createdBy: req.user?.username || "system",
        })
        .returning();
      res.status(201).json({ success: true, data: newBranch });
    } catch (err) {
      next(err);
    }
  },
);

branchRouter.put(
  "/:id",
  requireAuth,
  requirePermission("branches:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = BranchSchema.partial().parse(req.body);
      const [updated] = await db
        .update(branches)
        .set({ ...validated, updatedAt: new Date() })
        .where(and(eq(branches.id, id), eq(branches.tenantId, tenantId)))
        .returning();
      if (!updated) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الفرع غير موجود",
          },
        });
      }
      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  },
);

branchRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("branches:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [deleted] = await db
        .update(branches)
        .set({ deletedAt: new Date(), active: false })
        .where(
          and(
            eq(branches.id, id),
            eq(branches.tenantId, tenantId),
            isNull(branches.deletedAt),
          ),
        )
        .returning();
      if (!deleted) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الفرع غير موجود",
          },
        });
      }
      res.json({
        success: true,
        message: "تم حذف الفرع بنجاح",
      });
    } catch (err) {
      next(err);
    }
  },
);

export { branchRouter };
