import { Router, type Request } from "express";
import { z } from "zod";
import { requireAuth, requirePermission, getRequiredTenantId } from "../middleware/rbac.js";
import { verifyCompanyOwnership } from "../middleware/tenantOwnership.js";
import { DOC_TYPE_CODES } from "../../lib/documentTypes.js";
import {
  canSeeFullIds,
  confirmDocumentMatch,
  getReminderRules,
  ingestAppDocument,
  listCompanyVault,
  listExpiring,
  listInbox,
  moveDocumentToCompany,
  rejectDocument,
  setCompanyClientReminders,
  updateDocumentFields,
  updateReminderRules,
  type Actor,
} from "../services/documentVaultService.js";
import { runReminderCycle } from "../services/reminderService.js";

/**
 * Smart Company File: document vault, confirmation inbox, expiry board and reminder settings.
 * Mounted at /api/vault. Every route is tenant-scoped and permission-gated with the existing
 * customer_documents:* / companies:* keys; reminder rules and the auto-file switch need vault_settings:update.
 */
const documentVaultRouter = Router();

const idParam = z.coerce.number().int().positive();

function actorOf(req: Request): Actor {
  return {
    userId: req.user?.userId ? String(req.user.userId) : String(req.user?.username || "admin"),
    name: String(req.user?.username || "admin"),
  };
}

const CompanyBody = z.object({ companyId: z.number().int().positive() });
const RejectBody = z.object({ reason: z.string().max(300).optional() });
const UploadBody = z.object({
  fileName: z.string().min(1).max(200),
  mimeType: z.string().min(1).max(100),
  data: z.string().min(8),
});
const FieldsBody = z
  .object({
    docTypeCode: z.enum(DOC_TYPE_CODES).optional(),
    docNumber: z.string().max(60).nullable().optional(),
    issueDate: z.string().max(20).nullable().optional(),
    expiryDate: z.string().max(20).nullable().optional(),
    hasNoExpiry: z.boolean().optional(),
    personName: z.string().max(120).nullable().optional(),
    civilNumber: z.string().max(30).nullable().optional(),
    passportNumber: z.string().max(30).nullable().optional(),
  })
  .strict();
const RulesBody = z
  .object({
    rules: z
      .array(
        z.object({
          docTypeCode: z.enum(DOC_TYPE_CODES),
          offsetsDays: z.array(z.number().int().min(0).max(730)).min(1).max(8),
          notifyStaff: z.boolean().optional(),
          notifyClient: z.boolean().optional(),
          active: z.boolean().optional(),
        }),
      )
      .optional(),
    settings: z
      .object({
        autoFileEnabled: z.boolean().optional(),
        autoFileMinScore: z.number().int().min(60).max(100).optional(),
        reminderStaffPhones: z.string().max(300).optional(),
      })
      .optional(),
  })
  .strict();
const ClientRemindersBody = z.object({ enabled: z.boolean(), consentGiven: z.boolean().optional().default(false) });

documentVaultRouter.get(
  "/companies/:companyId/documents",
  requireAuth,
  requirePermission("customer_documents:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const companyId = idParam.parse(req.params.companyId);
      await verifyCompanyOwnership(tenantId, companyId);
      const data = await listCompanyVault(tenantId, companyId, canSeeFullIds(req.user?.role));
      res.json({ success: true, data });
    } catch (err) {
      next(err);
    }
  },
);

documentVaultRouter.post(
  "/companies/:companyId/documents",
  requireAuth,
  requirePermission("customer_documents:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const companyId = idParam.parse(req.params.companyId);
      await verifyCompanyOwnership(tenantId, companyId);
      const body = UploadBody.parse(req.body);
      const buffer = Buffer.from(body.data.replace(/^data:[^;]+;base64,/, ""), "base64");
      const result = await ingestAppDocument({
        tenantId,
        channel: "WEB",
        buffer,
        fileName: body.fileName,
        mimeType: body.mimeType,
        actorName: actorOf(req).name,
        forcedCompanyId: companyId,
      });
      if (!result.ok) {
        return res.status(422).json({
          success: false,
          error: { code: result.errorCode || "UPLOAD_REJECTED", message: result.errorMessage || result.replyMessageText },
        });
      }
      res.status(201).json({
        success: true,
        data: {
          documentId: result.savedDocumentId,
          documentType: result.documentType,
          companyId: result.companyId,
          lane: result.matchLane,
          isDuplicateFile: result.isDuplicateFile,
          versionNumber: result.versionNumber,
          needsReview: result.state === "NEEDS_REVIEW",
          message: result.replyMessageText,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

documentVaultRouter.get("/inbox", requireAuth, requirePermission("customer_documents:read"), async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const data = await listInbox(tenantId, canSeeFullIds(req.user?.role));
    res.json({ success: true, data, count: data.length });
  } catch (err) {
    next(err);
  }
});

documentVaultRouter.post(
  "/documents/:id/confirm-match",
  requireAuth,
  requirePermission("customer_documents:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = idParam.parse(req.params.id);
      const { companyId } = CompanyBody.parse(req.body);
      const doc = await confirmDocumentMatch(tenantId, id, companyId, actorOf(req));
      res.json({ success: true, data: { id: doc.id, companyId: doc.companyId, versionNumber: doc.versionNumber, previousVersionId: doc.previousVersionId, matchLane: doc.matchLane } });
    } catch (err) {
      next(err);
    }
  },
);

documentVaultRouter.post(
  "/documents/:id/move",
  requireAuth,
  requirePermission("customer_documents:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = idParam.parse(req.params.id);
      const { companyId } = CompanyBody.parse(req.body);
      const doc = await moveDocumentToCompany(tenantId, id, companyId, actorOf(req));
      res.json({ success: true, data: { id: doc.id, companyId: doc.companyId, versionNumber: doc.versionNumber, previousVersionId: doc.previousVersionId } });
    } catch (err) {
      next(err);
    }
  },
);

documentVaultRouter.post(
  "/documents/:id/reject",
  requireAuth,
  requirePermission("customer_documents:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = idParam.parse(req.params.id);
      const { reason } = RejectBody.parse(req.body || {});
      const out = await rejectDocument(tenantId, id, actorOf(req), reason);
      res.json({ success: true, data: out });
    } catch (err) {
      next(err);
    }
  },
);

documentVaultRouter.patch(
  "/documents/:id/fields",
  requireAuth,
  requirePermission("customer_documents:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = idParam.parse(req.params.id);
      const edit = FieldsBody.parse(req.body);
      const doc = await updateDocumentFields(tenantId, id, edit, actorOf(req));
      res.json({ success: true, data: { id: doc.id, expiryDate: doc.expiryDate, expiryStatus: doc.expiryStatus, needsReview: doc.needsReview } });
    } catch (err) {
      next(err);
    }
  },
);

documentVaultRouter.get("/expiring", requireAuth, requirePermission("customer_documents:read"), async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const days = z.coerce.number().int().min(1).max(730).default(60).parse(req.query.days ?? 60);
    const data = await listExpiring(tenantId, days, canSeeFullIds(req.user?.role));
    res.json({ success: true, data, count: data.length });
  } catch (err) {
    next(err);
  }
});

documentVaultRouter.get("/reminder-rules", requireAuth, requirePermission("vault_settings:update"), async (req, res, next) => {
  try {
    res.json({ success: true, data: await getReminderRules(getRequiredTenantId(req)) });
  } catch (err) {
    next(err);
  }
});

documentVaultRouter.put("/reminder-rules", requireAuth, requirePermission("vault_settings:update"), async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const body = RulesBody.parse(req.body);
    res.json({ success: true, data: await updateReminderRules(tenantId, body, actorOf(req)) });
  } catch (err) {
    next(err);
  }
});

documentVaultRouter.patch(
  "/companies/:companyId/reminders",
  requireAuth,
  requirePermission("companies:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const companyId = idParam.parse(req.params.companyId);
      await verifyCompanyOwnership(tenantId, companyId);
      const { enabled, consentGiven } = ClientRemindersBody.parse(req.body);
      res.json({ success: true, data: await setCompanyClientReminders(tenantId, companyId, enabled, consentGiven, actorOf(req)) });
    } catch (err) {
      next(err);
    }
  },
);

/** Run one reminder cycle now (queue due reminders and flush the outbox). Same code the 08:00 cron runs. */
documentVaultRouter.post("/reminders/run", requireAuth, requirePermission("vault_settings:update"), async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const body = z
      .object({ referenceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() })
      .parse(req.body || {});
    if (body.referenceDate && process.env.NODE_ENV === "production") {
      return res.status(400).json({ success: false, error: { code: "REFERENCE_DATE_NOT_ALLOWED", message: "referenceDate is only allowed outside production" } });
    }
    const out = await runReminderCycle({ tenantId, referenceDate: body.referenceDate });
    res.json({ success: true, data: out });
  } catch (err) {
    next(err);
  }
});

export { documentVaultRouter };
