import { Router } from "express";
import { z } from "zod";
import { eq, and, desc, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { expenses, cashSessions } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  verifyBranchOwnership,
  verifyCashSessionOwnership,
} from "../middleware/tenantOwnership.js";

const expenseRouter = Router();

const ExpenseCreateSchema = z.object({
  branchId: z.number().int().optional().nullable(),
  cashSessionId: z.number().int().optional().nullable(),
  category: z.string().min(1, "تصنيف المصروف مطلوب"),
  description: z.string().min(2, "بيان المصروف مطلوب"),
  amountBaisa: z
    .number()
    .int()
    .positive("قيمة المصروف يجب أن تكون أكبر من صفر"),
});

const ExpenseUpdateSchema = ExpenseCreateSchema.partial();

expenseRouter.get(
  "/",
  requireAuth,
  requirePermission("expenses:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset } = parsePaginationParams(req);
      const cashSessionId = req.query.cashSessionId
        ? parseInt(String(req.query.cashSessionId), 10)
        : undefined;
      const conditions: SQL[] = [eq(expenses.tenantId, tenantId)];
      if (cashSessionId && !isNaN(cashSessionId)) {
        conditions.push(eq(expenses.cashSessionId, cashSessionId));
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(expenses)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(expenses)
        .where(whereClause)
        .orderBy(desc(expenses.id))
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

expenseRouter.post(
  "/",
  requireAuth,
  requirePermission("expenses:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = ExpenseCreateSchema.parse(req.body);
      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyCashSessionOwnership(tenantId, validated.cashSessionId);

      let sessionId = validated.cashSessionId;
      const numericUserId = Number(req.user?.userId);
      if (!sessionId && !isNaN(numericUserId)) {
        const [openSession] = await db
          .select()
          .from(cashSessions)
          .where(
            and(
              eq(cashSessions.tenantId, tenantId),
              eq(cashSessions.openedBy, numericUserId),
              eq(cashSessions.status, "OPEN"),
            ),
          )
          .limit(1);
        if (openSession) sessionId = openSession.id;
      }
      const [newExpense] = await db
        .insert(expenses)
        .values({
          tenantId,
          branchId: validated.branchId ?? null,
          cashSessionId: sessionId ?? null,
          category: validated.category,
          description: validated.description,
          amountBaisa: validated.amountBaisa,
          createdBy: !isNaN(numericUserId) ? numericUserId : null,
        })
        .returning();
      res.status(201).json({ success: true, data: newExpense });
    } catch (err) {
      next(err);
    }
  },
);

expenseRouter.put(
  "/:id",
  requireAuth,
  requirePermission("expenses:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = ExpenseUpdateSchema.parse(req.body);
      if (Object.keys(validated).length === 0) {
        return res.status(422).json({
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
        });
      }
      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyCashSessionOwnership(tenantId, validated.cashSessionId);

      const [updated] = await db
        .update(expenses)
        .set(validated)
        .where(and(eq(expenses.id, id), eq(expenses.tenantId, tenantId)))
        .returning();
      if (!updated) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "المصروف غير موجود",
          },
        });
      }
      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  },
);

expenseRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("expenses:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [deleted] = await db
        .delete(expenses)
        .where(and(eq(expenses.id, id), eq(expenses.tenantId, tenantId)))
        .returning();
      if (!deleted) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "المصروف غير موجود",
          },
        });
      }
      res.json({
        success: true,
        message: "تم حذف المصروف بنجاح",
      });
    } catch (err) {
      next(err);
    }
  },
);

export { expenseRouter };
