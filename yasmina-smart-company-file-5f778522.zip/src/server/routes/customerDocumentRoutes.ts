import { Router } from "express";
import { z } from "zod";
import { eq, and, isNull, desc } from "drizzle-orm";
import { db } from "../../db/index.js";
import { customerDocuments } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import {
  verifyCustomerOwnership,
  verifyCompanyOwnership,
} from "../middleware/tenantOwnership.js";
import { normalizeAndValidateDate } from "../services/crExtractionService.js";
import {
  classifyDocumentExpiry,
  runExpiryAudit,
  updateMonitoredDocumentExpiry,
} from "../services/expiryCronService.js";
import {
  readStoredDocumentBuffer,
  sanitizeDownloadMimeType,
  buildContentDispositionAttachment,
} from "../services/documentStorageService.js";

const customerDocumentRouter = Router();

const CustomerDocSchema = z.object({
  customerId: z.number().int({ message: "معرف العميل مطلوب" }),
  companyId: z.number().int().optional().nullable(),
  docType: z.string().min(1, "نوع الوثيقة مطلوب"),
  docNumber: z.string().optional().nullable(),
  issueDate: z.string().optional().nullable(),
  expiryDate: z.string().optional().nullable(),
  extractionSource: z.string().optional().nullable(),
  hasNoExpiry: z.boolean().optional().default(false),
  fileUrl: z.string().optional().nullable(),
});

customerDocumentRouter.get(
  "/",
  requireAuth,
  requirePermission("customer_documents:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const customerId = req.query.customerId
        ? parseInt(String(req.query.customerId), 10)
        : undefined;
      const companyId = req.query.companyId
        ? parseInt(String(req.query.companyId), 10)
        : undefined;
      const conditions = [
        eq(customerDocuments.tenantId, tenantId),
        isNull(customerDocuments.deletedAt),
      ];
      if (customerId && !isNaN(customerId)) {
        conditions.push(eq(customerDocuments.customerId, customerId));
      }
      if (companyId && !isNaN(companyId)) {
        conditions.push(eq(customerDocuments.companyId, companyId));
      }
      const rows = await db
        .select()
        .from(customerDocuments)
        .where(and(...conditions))
        .orderBy(desc(customerDocuments.id));
      res.json({ success: true, data: rows });
    } catch (err) {
      next(err);
    }
  }
);

customerDocumentRouter.post(
  "/",
  requireAuth,
  requirePermission("customer_documents:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = CustomerDocSchema.parse(req.body);
      await verifyCustomerOwnership(tenantId, validated.customerId);
      await verifyCompanyOwnership(tenantId, validated.companyId);

      const normIssueDate = validated.issueDate
        ? normalizeAndValidateDate(validated.issueDate)
        : null;
      const normExpiryDate = validated.hasNoExpiry
        ? null
        : validated.expiryDate
          ? normalizeAndValidateDate(validated.expiryDate)
          : null;

      const classification = classifyDocumentExpiry({
        expiryDate: validated.expiryDate,
        hasNoExpiry: validated.hasNoExpiry,
      });

      const [newDoc] = await db
        .insert(customerDocuments)
        .values({
          tenantId,
          customerId: validated.customerId,
          companyId: validated.companyId ?? null,
          docType: validated.docType,
          docNumber: validated.docNumber ?? null,
          issueDate: normIssueDate,
          expiryDate: normExpiryDate,
          rawIssueDate: validated.issueDate ?? null,
          rawExpiryDate: validated.expiryDate ?? null,
          extractionSource: validated.extractionSource || "MANUAL",
          hasNoExpiry: Boolean(validated.hasNoExpiry),
          expiryStatus: classification.status,
          needsReview: classification.needsReview,
          fileUrl: validated.fileUrl ?? null,
          createdBy: String(req.user?.userId || req.user?.username || "System"),
        })
        .returning();

      const auditResult = await runExpiryAudit({
        tenantId,
        triggerType: "IMMEDIATE_UPLOAD",
      });

      res.status(201).json({
        success: true,
        data: newDoc,
        expiryEvaluation: {
          status: classification.status,
          statusAr: classification.statusAr,
          daysRemaining: classification.daysRemaining,
          needsReview: classification.needsReview,
          notificationsCreated: auditResult.notificationsCreated,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

customerDocumentRouter.put(
  "/:id",
  requireAuth,
  requirePermission("customer_documents:update"),
  async (req, res) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }

      const result = await updateMonitoredDocumentExpiry({
        tenantId,
        sourceEntity: "customer_documents",
        sourceId: String(id),
        expiryDate: req.body?.expiryDate,
        hasNoExpiry: req.body?.hasNoExpiry,
        actorId: String(req.user?.userId || req.user?.username || ""),
        actorName: req.user?.username || "User",
        ipAddress: req.ip || "127.0.0.1",
      });

      res.json({
        success: true,
        ...result,
      });
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "تعذر تحديث تاريخ انتهاء الوثيقة";
      res.status(400).json({
        success: false,
        error: {
          code: "INVALID_EXPIRY_UPDATE",
          message,
        },
        requestId: req.id,
      });
    }
  }
);

customerDocumentRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("customer_documents:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const [deleted] = await db
        .update(customerDocuments)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(customerDocuments.id, id),
            eq(customerDocuments.tenantId, tenantId),
            isNull(customerDocuments.deletedAt)
          )
        )
        .returning();
      if (!deleted) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "الوثيقة غير موجودة" },
          requestId: req.id,
        });
        return;
      }
      res.json({ success: true, message: "تم حذف الوثيقة بنجاح" });
    } catch (err) {
      next(err);
    }
  }
);

customerDocumentRouter.get(
  "/:id/download",
  requireAuth,
  requirePermission("customer_documents:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف الوثيقة غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const [doc] = await db
        .select()
        .from(customerDocuments)
        .where(
          and(
            eq(customerDocuments.id, id),
            eq(customerDocuments.tenantId, tenantId),
            isNull(customerDocuments.deletedAt)
          )
        )
        .limit(1);

      if (!doc) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "الوثيقة غير موجودة" },
          requestId: req.id,
        });
        return;
      }

      const stored = readStoredDocumentBuffer(
        doc.storageObjectKey,
        doc.fileUrl
      );
      if (!stored) {
        res.status(404).json({
          success: false,
          error: {
            code: "FILE_BINARY_NOT_FOUND",
            message: "الملف الأصلي للوثيقة غير متوفر للتنزيل",
          },
          requestId: req.id,
        });
        return;
      }

      const safeMime = sanitizeDownloadMimeType(stored.mimeType);
      const ext =
        safeMime === "application/pdf"
          ? "pdf"
          : safeMime === "image/png"
            ? "png"
            : safeMime === "image/webp"
              ? "webp"
              : "jpg";
      const rawName =
        doc.originalFileName ||
        `${doc.docType || "document"}_${doc.docNumber || doc.id}.${ext}`;

      res.setHeader("Content-Type", safeMime);
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader(
        "Content-Disposition",
        buildContentDispositionAttachment(rawName, `document.${ext}`)
      );
      res.setHeader("Content-Length", String(stored.buffer.length));
      res.send(stored.buffer);
    } catch (err) {
      next(err);
    }
  }
);

export { customerDocumentRouter };
