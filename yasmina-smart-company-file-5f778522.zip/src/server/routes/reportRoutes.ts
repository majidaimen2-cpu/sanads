import { Router } from "express";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import {
  getDailyCashReport,
  getVatSummaryReport,
  getExpiringDocsReport,
} from "../services/reportService.js";

const reportRouter = Router();

reportRouter.get(
  "/",
  requireAuth,
  requirePermission("reports:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const [dailyCash, vatSummary, expiringDocs] = await Promise.all([
        getDailyCashReport(tenantId),
        getVatSummaryReport(tenantId),
        getExpiringDocsReport(tenantId, 60),
      ]);
      res.json({
        success: true,
        data: {
          dailyCash,
          vatSummary,
          expiringDocs,
          generatedAt: new Date().toISOString(),
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

reportRouter.get(
  "/daily-cash",
  requireAuth,
  requirePermission("reports:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const date = req.query.date ? String(req.query.date).trim() : undefined;
      const report = await getDailyCashReport(tenantId, date);
      res.json({ success: true, data: report });
    } catch (err) {
      next(err);
    }
  },
);

reportRouter.get(
  "/vat-summary",
  requireAuth,
  requirePermission("reports:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const startDate = req.query.startDate
        ? String(req.query.startDate).trim()
        : undefined;
      const endDate = req.query.endDate
        ? String(req.query.endDate).trim()
        : undefined;
      const report = await getVatSummaryReport(tenantId, startDate, endDate);
      res.json({ success: true, data: report });
    } catch (err) {
      next(err);
    }
  },
);

reportRouter.get(
  "/expiring-docs",
  requireAuth,
  requirePermission("reports:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const daysAhead = req.query.days
        ? parseInt(String(req.query.days), 10)
        : 60;
      const report = await getExpiringDocsReport(
        tenantId,
        isNaN(daysAhead) ? 60 : daysAhead,
      );
      res.json({ success: true, data: report });
    } catch (err) {
      next(err);
    }
  },
);

export { reportRouter };
