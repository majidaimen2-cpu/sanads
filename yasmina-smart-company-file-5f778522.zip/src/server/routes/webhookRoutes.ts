import { Router } from "express";
import crypto from "crypto";
import dns from "dns/promises";
import net from "net";
import rateLimit from "express-rate-limit";
import { and, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { whatsappMessages, notifications, customers } from "../../db/schema.js";
import { processIncomingWhatsAppMediaMessage } from "../services/whatsappDocumentProcessor.js";
import { whatsAppService } from "../services/whatsappService.js";
import { logger } from "../logger.js";

const webhookRouter = Router();

const MAX_WEBHOOK_MEDIA_BYTES = 15 * 1024 * 1024; // 15 MB cap (#54)

const webhookLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  validate: false,
  message: {
    success: false,
    error: {
      code: "WEBHOOK_RATE_LIMIT",
      message: "Too many webhook requests.",
    },
  },
});

interface WebhookKeyEntry {
  keyHash: Buffer;
  tenantId: string;
}

function sha256(value: string): Buffer {
  return crypto.createHash("sha256").update(value).digest();
}

/**
 * Webhook keys are bound to tenants on the server:
 *  - WEBHOOK_TENANT_KEYS="keyA:tenant_a,keyB:tenant_b"  (one key per tenant), and/or
 *  - EVOLUTION_API_KEY (+ optional WEBHOOK_DEFAULT_TENANT_ID, default "default_tenant") for single-tenant installs.
 * No keys configured => the webhook fails closed (503).
 */
export function loadWebhookKeyMap(): WebhookKeyEntry[] {
  const entries: WebhookKeyEntry[] = [];
  const multi = (process.env.WEBHOOK_TENANT_KEYS || "").split(",");
  for (const raw of multi) {
    const item = raw.trim();
    if (!item) continue;
    const idx = item.lastIndexOf(":");
    if (idx <= 0 || idx === item.length - 1) continue;
    const key = item.slice(0, idx).trim();
    const tenant = item.slice(idx + 1).trim();
    if (key && tenant) entries.push({ keyHash: sha256(key), tenantId: tenant });
  }
  const single = process.env.EVOLUTION_API_KEY?.trim();
  if (single) {
    entries.push({
      keyHash: sha256(single),
      tenantId: (process.env.WEBHOOK_DEFAULT_TENANT_ID || "default_tenant").trim() || "default_tenant",
    });
  }
  return entries;
}

function resolveTenantForKey(entries: WebhookKeyEntry[], provided: string): string | null {
  if (!provided) return null;
  const providedHash = sha256(provided);
  let matched: string | null = null;
  for (const e of entries) {
    // constant-time compare of fixed-length digests; evaluate all entries
    if (crypto.timingSafeEqual(providedHash, e.keyHash) && matched === null) {
      matched = e.tenantId;
    }
  }
  return matched;
}

export function isPrivateOrReservedIp(ip: string): boolean {
  const cleanIp = ip.trim().toLowerCase();

  // Handle IPv4-mapped IPv6 addresses (e.g. ::ffff:127.0.0.1 or ::ffff:169.254.169.254)
  if (cleanIp.startsWith("::ffff:")) {
    const v4Part = cleanIp.slice("::ffff:".length);
    if (net.isIPv4(v4Part)) {
      return isPrivateOrReservedIp(v4Part);
    }
  }

  if (net.isIPv4(cleanIp)) {
    const parts = cleanIp.split(".").map((n) => parseInt(n, 10));
    if (parts.length !== 4 || parts.some((n) => isNaN(n) || n < 0 || n > 255)) {
      return true;
    }
    const [a, b] = parts;
    if (a === 0) return true; // 0.0.0.0/8
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 127) return true; // 127.0.0.0/8 loopback
    if (a === 169 && b === 254) return true; // 169.254.0.0/16 link-local & cloud metadata (169.254.169.254)
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 100 && b >= 64 && b <= 127) return true; // 100.64.0.0/10 CGNAT
    if (a >= 224) return true; // Multicast & reserved
    return false;
  }

  if (net.isIPv6(cleanIp)) {
    if (cleanIp === "::1" || cleanIp === "::") return true;
    if (cleanIp.startsWith("fc") || cleanIp.startsWith("fd")) return true; // fc00::/7 Unique Local
    if (
      cleanIp.startsWith("fe8") ||
      cleanIp.startsWith("fe9") ||
      cleanIp.startsWith("fea") ||
      cleanIp.startsWith("feb")
    ) {
      return true; // fe80::/10 Link-Local
    }
    if (cleanIp.startsWith("ff")) return true; // Multicast
    return false;
  }

  return true;
}

export async function validateAndResolveSafeMediaUrl(rawUrl: string): Promise<{
  parsedUrl: URL;
  resolvedAddress: string;
}> {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error("SSRF_BLOCKED: Invalid media URL format");
  }

  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw new Error("SSRF_BLOCKED: Only HTTP/HTTPS media URLs are permitted");
  }

  const hostname = parsed.hostname.replace(/^\[|\]$/g, "").toLowerCase();
  if (
    !hostname ||
    hostname === "localhost" ||
    hostname.endsWith(".local") ||
    hostname.endsWith(".internal") ||
    hostname === "metadata.google.internal"
  ) {
    throw new Error("SSRF_BLOCKED: Local or internal hostname is forbidden");
  }

  if (net.isIP(hostname)) {
    if (isPrivateOrReservedIp(hostname)) {
      throw new Error(`SSRF_BLOCKED: Direct private/reserved IP (${hostname}) is forbidden`);
    }
    return { parsedUrl: parsed, resolvedAddress: hostname };
  }

  const records = await dns.lookup(hostname, { all: true });
  if (!records || records.length === 0) {
    throw new Error("SSRF_BLOCKED: Could not resolve media hostname");
  }

  for (const rec of records) {
    if (isPrivateOrReservedIp(rec.address)) {
      throw new Error(
        `SSRF_BLOCKED: Hostname ${hostname} resolved to private/reserved IP (${rec.address})`
      );
    }
  }

  return { parsedUrl: parsed, resolvedAddress: records[0].address };
}

export async function fetchSafeWebhookMedia(rawUrl: string): Promise<Buffer> {
  const { parsedUrl } = await validateAndResolveSafeMediaUrl(rawUrl);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const resp = await fetch(parsedUrl.toString(), {
      signal: controller.signal,
      redirect: "error", // Disallow open redirects to private IPs
    });

    if (!resp.ok) {
      throw new Error(`HTTP ${resp.status} fetching mediaUrl`);
    }

    const contentLength = parseInt(resp.headers.get("content-length") || "0", 10);
    if (contentLength > MAX_WEBHOOK_MEDIA_BYTES) {
      throw new Error("MEDIA_TOO_LARGE: Content-Length exceeds 15 MB cap");
    }

    if (!resp.body) {
      const ab = await resp.arrayBuffer();
      if (ab.byteLength > MAX_WEBHOOK_MEDIA_BYTES) {
        throw new Error("MEDIA_TOO_LARGE: Payload exceeds 15 MB cap");
      }
      return Buffer.from(ab);
    }

    const reader = resp.body.getReader();
    const chunks: Buffer[] = [];
    let totalBytes = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        totalBytes += value.byteLength;
        if (totalBytes > MAX_WEBHOOK_MEDIA_BYTES) {
          await reader.cancel();
          throw new Error("MEDIA_TOO_LARGE: Stream exceeded 15 MB cap");
        }
        chunks.push(Buffer.from(value));
      }
    }

    return Buffer.concat(chunks);
  } finally {
    clearTimeout(timeout);
  }
}

webhookRouter.post(["/v1/webhook", "/webhook"], webhookLimiter, async (req, res) => {
  const apiKeyHeader = String(
    req.headers["x-api-key"] ||
      req.headers["apikey"] ||
      req.headers["authorization"] ||
      ""
  )
    .replace(/^Bearer\s+/i, "")
    .trim();
  const clientIp = req.ip || req.socket.remoteAddress || "127.0.0.1";

  // Tenant is bound SERVER-SIDE to the API key. The request body is never trusted for tenantId.
  const keyMap = loadWebhookKeyMap();
  if (keyMap.length === 0) {
    res.status(503).json({
      success: false,
      error: {
        code: "WEBHOOK_UNCONFIGURED",
        message: "Webhook API key not configured",
      },
      requestId: req.id,
    });
    return;
  }

  const tenantId = resolveTenantForKey(keyMap, apiKeyHeader);
  if (!tenantId) {
    // Log to Pino instead of inserting into PostgreSQL audit_logs on unauthenticated requests (#54)
    logger.warn({ clientIp, path: req.originalUrl }, "Unauthorized webhook attempt rejected");
    res.status(401).json({
      success: false,
      error: {
        code: "UNAUTHORIZED_WEBHOOK",
        message: "Unauthorized webhook request",
      },
      requestId: req.id,
    });
    return;
  }

  const payload = req.body || {};

  try {
    const data = payload.data || payload;
    const fromMe = Boolean(data?.key?.fromMe ?? data?.fromMe ?? false);
    if (fromMe) {
      res.json({
        success: true,
        status: "ignored_outgoing",
        event: payload.event || "message",
      });
      return;
    }

    const remoteJid = data?.key?.remoteJid || data?.remoteJid || data?.phone || "";
    const phone =
      String(remoteJid)
        .replace(/@.*$/, "")
        .replace(/[^0-9+]/g, "") || "unknown";
    const providerMessageId = String(
      data?.key?.id ||
        data?.messageId ||
        payload?.messageId ||
        `wh_${crypto
          .createHash("sha256")
          .update(JSON.stringify(payload))
          .digest("hex")
          .slice(0, 24)}`
    );
    const instanceId = String(payload.instance || data?.instance || "default-inst");
    const senderName = String(
      data?.pushName || data?.senderName || payload?.senderName || ""
    ).trim();

    const docMsg =
      data?.message?.documentMessage ||
      data?.message?.documentWithCaptionMessage?.message?.documentMessage ||
      null;
    const imgMsg = data?.message?.imageMessage || null;
    const rawBase64 =
      data?.base64 ||
      data?.mediaBase64 ||
      data?.message?.base64 ||
      docMsg?.base64 ||
      imgMsg?.base64 ||
      payload?.base64 ||
      null;
    const mediaUrl =
      data?.mediaUrl || docMsg?.url || imgMsg?.url || payload?.mediaUrl || null;

    if (docMsg || imgMsg || rawBase64 || mediaUrl) {
      const fileName =
        docMsg?.fileName ||
        docMsg?.title ||
        data?.fileName ||
        payload?.fileName ||
        (imgMsg
          ? `whatsapp_image_${providerMessageId}.jpg`
          : `whatsapp_doc_${providerMessageId}.pdf`);
      const declaredMimeType =
        docMsg?.mimetype ||
        imgMsg?.mimetype ||
        data?.mimeType ||
        payload?.mimeType ||
        (imgMsg ? "image/jpeg" : "application/pdf");

      let mediaBuffer: Buffer | null = null;
      if (typeof rawBase64 === "string" && rawBase64.trim().length > 0) {
        const cleaned = rawBase64.replace(/^data:[^;]+;base64,/, "").trim();
        mediaBuffer = Buffer.from(cleaned, "base64");
        if (mediaBuffer.length > MAX_WEBHOOK_MEDIA_BYTES) {
          res.status(413).json({
            success: false,
            error: {
              code: "PAYLOAD_TOO_LARGE",
              message: "Webhook media exceeds 15 MB limit",
            },
            requestId: req.id,
          });
          return;
        }
      }

      const procResult = await processIncomingWhatsAppMediaMessage({
        tenantId,
        instanceId,
        providerMessageId,
        senderPhone: phone,
        senderJid: remoteJid || `${phone}@s.whatsapp.net`,
        senderName: senderName || undefined,
        messageText:
          docMsg?.caption ||
          imgMsg?.caption ||
          data?.message?.conversation ||
          fileName,
        fileName,
        declaredMimeType,
        mediaBuffer,
        mediaDownloadFn:
          !mediaBuffer &&
          typeof mediaUrl === "string" &&
          mediaUrl.startsWith("http")
            ? async () => fetchSafeWebhookMedia(mediaUrl)
            : undefined,
        rawPayload: payload,
        sendWhatsAppReplyFn: async (_recipientJid, replyText) => {
          const chatId = `chat-${phone.replace(/\D/g, "")}`;
          await whatsAppService.sendManualMessage(chatId, replyText);
          return { sentId: `wh_reply_${Date.now()}` };
        },
      });

      res.json({
        success: true,
        status: procResult.state,
        jobId: procResult.jobId,
        correlationId: procResult.correlationId,
        deduplicatedReplay: procResult.deduplicatedReplay,
        companyId: procResult.companyId,
        companyResolution: procResult.companyResolution,
        documentId: procResult.savedDocumentId,
        replyCategory: procResult.replyCategory,
      });
      return;
    }

    const msgText =
      data?.message?.conversation ||
      data?.message?.extendedTextMessage?.text ||
      data?.text ||
      (typeof payload === "string" ? payload : JSON.stringify(payload));

    if (phone !== "unknown" && phone.length >= 7) {
      const [existingMsg] = await db
        .select()
        .from(whatsappMessages)
        .where(
          and(
            eq(whatsappMessages.tenantId, tenantId),
            eq(whatsappMessages.providerMessageId, providerMessageId)
          )
        )
        .limit(1);

      if (!existingMsg) {
        const [cust] = await db
          .select()
          .from(customers)
          .where(and(eq(customers.tenantId, tenantId), eq(customers.phone, phone)))
          .limit(1);
        await db.insert(whatsappMessages).values({
          tenantId,
          providerMessageId,
          instanceId,
          chatId: remoteJid,
          phone,
          senderName: senderName || null,
          direction: "INBOUND",
          messageText:
            typeof msgText === "string" ? msgText : JSON.stringify(msgText),
          status: "DELIVERED",
        });
        await db.insert(notifications).values({
          tenantId,
          type: "WHATSAPP_INBOUND",
          title: cust
            ? `رسالة جديدة من ${cust.fullNameAr}`
            : `رسالة جديدة من ${phone}`,
          message:
            typeof msgText === "string"
              ? msgText.slice(0, 200)
              : "رسالة جديدة عبر الواتساب",
          recipient: phone,
          channel: "whatsapp",
          status: "DELIVERED",
        });
      }
    }
  } catch (procErr) {
    logger.warn({ err: procErr }, "Webhook payload processing notice");
  }
  res.json({
    success: true,
    status: "received",
    event: payload.event || "message",
  });
});

export { webhookRouter };
