import { Router } from "express";
import { z } from "zod";
import { eq, and, isNull, desc, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { contracts } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  verifyBranchOwnership,
  verifyCompanyOwnership,
  verifyCustomerOwnership,
} from "../middleware/tenantOwnership.js";

const contractRouter = Router();

const ContractSchema = z.object({
  branchId: z.number().int().optional().nullable(),
  companyId: z.number().int().optional().nullable(),
  customerId: z.number().int().optional().nullable(),
  title: z.string().min(2, "عنوان العقد مطلوب"),
  contractType: z.string().optional().nullable(),
  status: z
    .enum(["Active", "Expired", "Terminated", "Draft"])
    .default("Active"),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  valueBaisa: z.number().int().default(0),
  fileUrl: z.string().optional().nullable(),
});

contractRouter.get(
  "/",
  requireAuth,
  requirePermission("contracts:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, includeDeleted } =
        parsePaginationParams(req);
      const conditions = [eq(contracts.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(contracts.deletedAt));
      }

      const whereClause = and(...conditions);
      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(contracts)
        .where(whereClause);

      const data = await db
        .select()
        .from(contracts)
        .where(whereClause)
        .orderBy(desc(contracts.id))
        .limit(limit)
        .offset(offset);

      res.json({
        success: true,
        data,
        pagination: {
          total: count,
          page,
          limit,
          totalPages: Math.ceil(count / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

contractRouter.post(
  "/",
  requireAuth,
  requirePermission("contracts:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = ContractSchema.parse(req.body);
      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyCompanyOwnership(tenantId, validated.companyId);
      await verifyCustomerOwnership(tenantId, validated.customerId);

      const [newContract] = await db
        .insert(contracts)
        .values({
          tenantId,
          branchId: validated.branchId,
          companyId: validated.companyId,
          customerId: validated.customerId,
          title: validated.title,
          contractType: validated.contractType,
          status: validated.status,
          startDate: validated.startDate,
          endDate: validated.endDate,
          valueBaisa: validated.valueBaisa,
          fileUrl: validated.fileUrl,
          createdBy: req.user?.userId
            ? String(req.user.userId)
            : req.user?.username,
        })
        .returning();
      res.status(201).json({ success: true, data: newContract });
    } catch (err) {
      next(err);
    }
  }
);

contractRouter.put(
  "/:id",
  requireAuth,
  requirePermission("contracts:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const validated = ContractSchema.partial().parse(req.body);
      if (Object.keys(validated).length === 0) {
        res.status(422).json({
          success: false,
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
          requestId: req.id,
        });
        return;
      }
      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyCompanyOwnership(tenantId, validated.companyId);
      await verifyCustomerOwnership(tenantId, validated.customerId);

      const [updated] = await db
        .update(contracts)
        .set({ ...validated, updatedAt: new Date() })
        .where(and(eq(contracts.id, id), eq(contracts.tenantId, tenantId)))
        .returning();
      if (!updated) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "العقد غير موجود" },
          requestId: req.id,
        });
        return;
      }
      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  }
);

contractRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("contracts:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const [deleted] = await db
        .update(contracts)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(contracts.id, id),
            eq(contracts.tenantId, tenantId),
            isNull(contracts.deletedAt)
          )
        )
        .returning();
      if (!deleted) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "العقد غير موجود" },
          requestId: req.id,
        });
        return;
      }
      res.json({
        success: true,
        message: "تم حذف العقد بنجاح",
      });
    } catch (err) {
      next(err);
    }
  }
);

export { contractRouter };
