import { Router } from "express";
import { z } from "zod";
import { eq, and, isNull, desc, asc, or, ilike, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  transactions,
  transactionSteps,
  transactionFees,
  transactionDocuments,
  services,
} from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  verifyBranchOwnership,
  verifyCustomerOwnership,
  verifyCompanyOwnership,
  verifyServiceOwnership,
  verifyUserOwnership,
} from "../middleware/tenantOwnership.js";
import {
  generateTransactionNumber,
  appendTransactionStep,
} from "../services/transactionService.js";
import { calculateTransactionTotal } from "../../lib/money.js";

const transactionRouter = Router();

const TransactionCreateSchema = z.object({
  branchId: z.number().int().optional().nullable(),
  customerId: z.number().int({
    message: "معرف العميل مطلوب",
  }),
  companyId: z.number().int().optional().nullable(),
  serviceId: z.number().int({
    message: "معرف الخدمة مطلوب",
  }),
  status: z
    .enum([
      "DRAFT",
      "PENDING_GOV",
      "IN_PROGRESS",
      "COMPLETED",
      "CANCELLED",
      "REJECTED",
    ])
    .default("DRAFT"),
  assignedTo: z.number().int().optional().nullable(),
  dueDate: z.string().optional().nullable(),
  govRefNo: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
  govFeeBaisa: z.number().int().optional(),
  officeFeeBaisa: z.number().int().optional(),
  discountBaisa: z.number().int().optional(),
});

const StatusUpdateSchema = z.object({
  status: z.enum([
    "DRAFT",
    "PENDING_GOV",
    "IN_PROGRESS",
    "COMPLETED",
    "CANCELLED",
    "REJECTED",
  ]),
  stepName: z.string().min(1, "اسم الخطوة مطلوب"),
  notes: z.string().optional().nullable(),
});

transactionRouter.get(
  "/",
  requireAuth,
  requirePermission("transactions:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, search, includeDeleted, sortOrder } =
        parsePaginationParams(req);
      const customerId = req.query.customerId
        ? parseInt(String(req.query.customerId), 10)
        : undefined;
      const companyId = req.query.companyId
        ? parseInt(String(req.query.companyId), 10)
        : undefined;
      const status = req.query.status
        ? String(req.query.status).trim()
        : undefined;

      const conditions: SQL[] = [eq(transactions.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(transactions.deletedAt));
      }
      if (customerId && !isNaN(customerId)) {
        conditions.push(eq(transactions.customerId, customerId));
      }
      if (companyId && !isNaN(companyId)) {
        conditions.push(eq(transactions.companyId, companyId));
      }
      if (status) {
        conditions.push(eq(transactions.status, status));
      }
      if (search) {
        const pattern = `%${search}%`;
        const searchCond = or(
          ilike(transactions.number, pattern),
          ilike(transactions.govRefNo, pattern),
          ilike(transactions.notes, pattern),
        );
        if (searchCond) conditions.push(searchCond);
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(transactions)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(transactions)
        .where(whereClause)
        .orderBy(
          sortOrder === "desc" ? desc(transactions.id) : asc(transactions.id),
        )
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

transactionRouter.post(
  "/",
  requireAuth,
  requirePermission("transactions:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = TransactionCreateSchema.parse(req.body);

      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyCustomerOwnership(tenantId, validated.customerId);
      await verifyCompanyOwnership(tenantId, validated.companyId);
      await verifyServiceOwnership(tenantId, validated.serviceId);
      await verifyUserOwnership(tenantId, validated.assignedTo);

      const [serviceRow] = await db
        .select()
        .from(services)
        .where(
          and(
            eq(services.id, validated.serviceId),
            eq(services.tenantId, tenantId),
          ),
        )
        .limit(1);
      if (!serviceRow) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الخدمة غير موجودة",
          },
        });
      }

      const govFee = validated.govFeeBaisa ?? serviceRow.govFeeBaisa;
      const officeFee = validated.officeFeeBaisa ?? serviceRow.officeFeeBaisa;
      const discount = validated.discountBaisa ?? 0;
      const calc = calculateTransactionTotal({
        govFeeBaisa: govFee,
        officeFeeBaisa: officeFee,
        discountBaisa: discount,
      });
      const number = await generateTransactionNumber(tenantId);

      const [newTx] = await db
        .insert(transactions)
        .values({
          tenantId,
          branchId: validated.branchId ?? null,
          number,
          customerId: validated.customerId,
          companyId: validated.companyId ?? null,
          serviceId: validated.serviceId,
          status: validated.status,
          assignedTo: validated.assignedTo ?? null,
          dueDate: validated.dueDate ?? null,
          govRefNo: validated.govRefNo ?? null,
          notes: validated.notes ?? null,
          createdBy: req.user?.userId
            ? String(req.user.userId)
            : req.user?.username || "system",
        })
        .returning();

      await db.insert(transactionFees).values({
        transactionId: newTx.id,
        govFeeBaisa: calc.govFeeBaisa,
        officeFeeBaisa: calc.officeFeeBaisa,
        discountBaisa: calc.discountBaisa,
        vatBaisa: calc.vatBaisa,
        totalBaisa: calc.totalBaisa,
      });

      const numericUserId = Number(req.user?.userId);
      await db.insert(transactionSteps).values({
        transactionId: newTx.id,
        stepName: "إنشاء المعاملة",
        status: newTx.status,
        notes: "تم تسجيل المعاملة في النظام",
        userId: !isNaN(numericUserId) ? numericUserId : null,
      });

      res.status(201).json({ success: true, data: newTx });
    } catch (err) {
      next(err);
    }
  },
);

transactionRouter.get(
  "/:id",
  requireAuth,
  requirePermission("transactions:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [tx] = await db
        .select()
        .from(transactions)
        .where(
          and(eq(transactions.id, id), eq(transactions.tenantId, tenantId)),
        )
        .limit(1);
      if (!tx) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "المعاملة غير موجودة",
          },
        });
      }
      const [fees] = await db
        .select()
        .from(transactionFees)
        .where(eq(transactionFees.transactionId, id))
        .limit(1);
      const steps = await db
        .select()
        .from(transactionSteps)
        .where(eq(transactionSteps.transactionId, id))
        .orderBy(desc(transactionSteps.createdAt));
      const documents = await db
        .select()
        .from(transactionDocuments)
        .where(eq(transactionDocuments.transactionId, id));
      res.json({ data: { ...tx, fees: fees || null, steps, documents } });
    } catch (err) {
      next(err);
    }
  },
);

transactionRouter.post(
  "/:id/status",
  requireAuth,
  requirePermission("transactions:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = StatusUpdateSchema.parse(req.body);
      const numericUserId = Number(req.user?.userId);
      const result = await appendTransactionStep({
        tenantId,
        transactionId: id,
        stepName: validated.stepName,
        status: validated.status,
        notes: validated.notes || undefined,
        userId: !isNaN(numericUserId) ? numericUserId : null,
      });
      res.json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },
);

transactionRouter.get(
  "/:id/steps",
  requireAuth,
  requirePermission("transactions:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [tx] = await db
        .select()
        .from(transactions)
        .where(
          and(eq(transactions.id, id), eq(transactions.tenantId, tenantId)),
        )
        .limit(1);
      if (!tx) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "المعاملة غير موجودة",
          },
        });
      }
      const steps = await db
        .select()
        .from(transactionSteps)
        .where(eq(transactionSteps.transactionId, id))
        .orderBy(desc(transactionSteps.createdAt));
      res.json({ data: steps });
    } catch (err) {
      next(err);
    }
  },
);

transactionRouter.put(
  "/:id",
  requireAuth,
  requirePermission("transactions:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = TransactionCreateSchema.partial().parse(req.body);
      if (Object.keys(validated).length === 0) {
        return res.status(422).json({
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
        });
      }
      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyCustomerOwnership(tenantId, validated.customerId);
      await verifyCompanyOwnership(tenantId, validated.companyId);
      await verifyServiceOwnership(tenantId, validated.serviceId);
      await verifyUserOwnership(tenantId, validated.assignedTo);

      const [updated] = await db
        .update(transactions)
        .set({ ...validated, updatedAt: new Date() })
        .where(
          and(eq(transactions.id, id), eq(transactions.tenantId, tenantId)),
        )
        .returning();
      if (!updated) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "المعاملة غير موجودة",
          },
        });
      }
      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  },
);

transactionRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("transactions:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [deleted] = await db
        .update(transactions)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(transactions.id, id),
            eq(transactions.tenantId, tenantId),
            isNull(transactions.deletedAt),
          ),
        )
        .returning();
      if (!deleted) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "المعاملة غير موجودة",
          },
        });
      }
      res.json({
        success: true,
        message: "تم حذف المعاملة بنجاح",
      });
    } catch (err) {
      next(err);
    }
  },
);

export { transactionRouter };
