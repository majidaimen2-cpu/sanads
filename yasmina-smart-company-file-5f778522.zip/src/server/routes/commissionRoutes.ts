import { Router } from "express";
import { z } from "zod";
import { eq, and, desc, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { commissions } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  verifyEmployeeOwnership,
  verifyTransactionOwnership,
} from "../middleware/tenantOwnership.js";

const commissionRouter = Router();

const CommissionCreateSchema = z.object({
  employeeId: z.number().int({
    message: "معرف الموظف مطلوب",
  }),
  transactionId: z.number().int({
    message: "معرف المعاملة مطلوب",
  }),
  ratePct: z.number().int().min(0).max(100).default(0),
  amountBaisa: z
    .number()
    .int()
    .nonnegative("مبلغ العمولة لا يمكن أن يكون سالباً"),
  status: z.enum(["PENDING", "PAID"]).default("PENDING"),
});

commissionRouter.get(
  "/",
  requireAuth,
  requirePermission("commissions:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset } = parsePaginationParams(req);
      const employeeId = req.query.employeeId
        ? parseInt(String(req.query.employeeId), 10)
        : undefined;
      const status = req.query.status
        ? String(req.query.status).trim()
        : undefined;

      const conditions: SQL[] = [eq(commissions.tenantId, tenantId)];
      if (employeeId && !isNaN(employeeId)) {
        conditions.push(eq(commissions.employeeId, employeeId));
      }
      if (status) {
        conditions.push(eq(commissions.status, status));
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(commissions)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(commissions)
        .where(whereClause)
        .orderBy(desc(commissions.id))
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

commissionRouter.post(
  "/",
  requireAuth,
  requirePermission("commissions:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = CommissionCreateSchema.parse(req.body);
      await verifyEmployeeOwnership(tenantId, validated.employeeId);
      await verifyTransactionOwnership(tenantId, validated.transactionId);

      const [newCommission] = await db
        .insert(commissions)
        .values({
          tenantId,
          employeeId: validated.employeeId,
          transactionId: validated.transactionId,
          ratePct: validated.ratePct,
          amountBaisa: validated.amountBaisa,
          status: validated.status,
        })
        .returning();
      res.status(201).json({ success: true, data: newCommission });
    } catch (err) {
      next(err);
    }
  },
);

commissionRouter.put(
  "/:id",
  requireAuth,
  requirePermission("commissions:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = CommissionCreateSchema.partial().parse(req.body);
      if (Object.keys(validated).length === 0) {
        return res.status(422).json({
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
        });
      }
      await verifyEmployeeOwnership(tenantId, validated.employeeId);
      await verifyTransactionOwnership(tenantId, validated.transactionId);

      const [updated] = await db
        .update(commissions)
        .set(validated)
        .where(and(eq(commissions.id, id), eq(commissions.tenantId, tenantId)))
        .returning();
      if (!updated) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "سجل العمولة غير موجود",
          },
        });
      }
      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  },
);

commissionRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("commissions:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [deleted] = await db
        .delete(commissions)
        .where(and(eq(commissions.id, id), eq(commissions.tenantId, tenantId)))
        .returning();
      if (!deleted) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "سجل العمولة غير موجود",
          },
        });
      }
      res.json({
        success: true,
        message: "تم حذف سجل العمولة بنجاح",
      });
    } catch (err) {
      next(err);
    }
  },
);

export { commissionRouter };
