import path from "path";
import { Router } from "express";
import { z } from "zod";
import { eq, and, or, isNull, desc, asc, inArray, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  companies,
  branches,
  customers,
  customerDocuments,
} from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import { insertAuditLog } from "../../db/users.js";
import { BackupService } from "../services/backupService.js";
import {
  classifyDocumentExpiry,
  runExpiryAudit,
} from "../services/expiryCronService.js";
import { normalizeCrNumber } from "../services/crExtractionService.js";
import {
  readStoredDocumentBuffer,
  storePermanentDocument,
  sanitizeDownloadMimeType,
  buildContentDispositionAttachment,
} from "../services/documentStorageService.js";

const companyRouter = Router();

let companyUpsertChain: Promise<unknown> = Promise.resolve();
function withCompanyUpsertLock<T>(fn: () => Promise<T>): Promise<T> {
  const next = companyUpsertChain.then(fn, fn);
  companyUpsertChain = next.catch(() => {});
  return next;
}

const PROMPT_CONTAMINATION_RE =
  /يرجى فحص وقراءة|استخراج كافة بيانات|تسجيلها مباشرة كشركة|معتمدة في المنظومة|الشركة الرسمية، وتسجيلها/i;

const CompanySchema = z.object({
  id: z.union([z.number(), z.string()]).optional().nullable(),
  branchId: z.number().int().optional().nullable(),
  ownerCustomerId: z.number().int().optional().nullable(),
  companyCode: z.string().min(1).optional(),
  name: z.string().min(1, "اسم المنشأة مطلوب"),
  companyNameEn: z.string().optional().nullable(),
  tradeName: z.string().optional().nullable(),
  crNumber: z.string().optional().nullable(),
  taxId: z.string().optional().nullable(),
  taxCardNumber: z.string().optional().nullable(),
  chamberNumber: z.string().optional().nullable(),
  crExpiryDate: z.string().optional().nullable(),
  crIssueDate: z.string().optional().nullable(),
  licenseNumber: z.string().optional().nullable(),
  licenseExpiryDate: z.string().optional().nullable(),
  crDocumentUrl: z.string().optional().nullable(),
  crDocumentName: z.string().optional().nullable(),
  sector: z.string().optional().nullable(),
  activities: z.unknown().optional(),
  status: z
    .preprocess(
      (val) => {
        if (typeof val !== "string") return "Active";
        const s = val.trim().toLowerCase();
        if (s === "active") return "Active";
        if (s === "pending") return "Pending";
        if (s === "suspended" || s === "compliance_risk") return "Suspended";
        if (s === "expired" || s === "inactive") return "Expired";
        return "Active";
      },
      z.enum(["Active", "Pending", "Suspended", "Expired"])
    )
    .default("Active"),
  city: z.string().optional().nullable(),
  stateCountry: z.string().default("سلطنة عُمان"),
  contactPhone: z.string().optional().nullable(),
  contactEmail: z.preprocess((val) => {
    if (typeof val !== "string" || !val.trim()) return null;
    return val.trim().toLowerCase();
  }, z.string().email("صيغة البريد الإلكتروني غير صحيحة").optional().nullable()),
  capital: z.number().nonnegative().optional().nullable(),
  capitalBaisa: z.number().int().nonnegative().optional().nullable(),
  legalForm: z.string().optional().nullable(),
  revenueMonthlyBaisa: z.number().int().default(0),
  employeesCount: z.number().int().default(0),
  complianceScore: z.number().int().default(100),
});

async function persistCrDocumentIfDataUrl(
  tenantId: string,
  rawUrl: string | null | undefined,
  rawName: string | null | undefined
): Promise<string | null | undefined> {
  if (!rawUrl) return undefined;
  const trimmed = rawUrl.trim();
  // Never overwrite DB column with relative download URLs or external URLs (#66)
  if (
    trimmed.startsWith("indexeddb://") ||
    trimmed.startsWith("/api/") ||
    trimmed.startsWith("http://") ||
    trimmed.startsWith("https://")
  ) {
    return undefined;
  }
  if (trimmed.startsWith("vault://")) {
    return trimmed;
  }
  if (trimmed.startsWith("data:")) {
    const match = trimmed.match(/^data:([^;,]+);base64,(.+)$/s);
    if (match) {
      const mimeType = match[1] || "application/pdf";
      const buf = Buffer.from(match[2], "base64");
      try {
        const stored = await storePermanentDocument({
          buffer: buf,
          tenantId,
          originalFileName: rawName || "commercial_registration.pdf",
          declaredMimeType: mimeType,
        });
        return `vault://${stored.storageObjectKey}`;
      } catch {
        // Fallback if synthetic test fixture data URL does not have full PDF magic bytes
        return trimmed;
      }
    }
  }
  return undefined;
}

function mapCompanyOutput(
  c: Omit<typeof companies.$inferSelect, "crDocumentUrl"> & {
    crDocumentUrl?: string | null;
    hasCrDocument?: boolean;
  }
) {
  const expClass = classifyDocumentExpiry({
    expiryDate: c.crExpiryDate,
    hasNoExpiry: false,
  });
  const hasDoc = Boolean(
    c.hasCrDocument || (c.crDocumentUrl && c.crDocumentUrl.trim().length > 0)
  );
  const effectiveCrNumber = c.normalizedCrNumber || c.taxId || "";
  return {
    ...c,
    id: String(c.id),
    crNumber: effectiveCrNumber,
    taxId: c.taxId || effectiveCrNumber,
    taxCardNumber: c.taxCardNumber || null,
    hasCrDocument: hasDoc,
    crDocumentUrl: hasDoc ? `/api/companies/${c.id}/cr-download` : null,
    capital:
      c.capitalBaisa && c.capitalBaisa > 0 ? c.capitalBaisa / 1000 : null,
    currency: "OMR",
    revenueMonthly: c.revenueMonthlyBaisa ? c.revenueMonthlyBaisa / 1000 : 0,
    crExpiryStatus: expClass.status,
    crExpiryStatusAr: expClass.statusAr,
    crDaysRemaining: expClass.daysRemaining,
    crNeedsReview: expClass.needsReview,
  };
}

companyRouter.get(
  "/",
  requireAuth,
  requirePermission("companies:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, search, includeDeleted, sortOrder } =
        parsePaginationParams(req);

      const conditions = [eq(companies.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(companies.deletedAt));
      }
      if (search) {
        const pattern = `%${search}%`;
        conditions.push(
          or(
            sql`${companies.name} ILIKE ${pattern}`,
            sql`COALESCE(${companies.tradeName}, '') ILIKE ${pattern}`,
            sql`COALESCE(${companies.taxId}, '') ILIKE ${pattern}`,
            sql`COALESCE(${companies.normalizedCrNumber}, '') ILIKE ${pattern}`,
            sql`COALESCE(${companies.contactPhone}, '') ILIKE ${pattern}`
          )!
        );
      }

      const whereClause = and(...conditions);
      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(companies)
        .where(whereClause);

      // Select all columns EXCEPT crDocumentUrl blob; compute hasCrDocument boolean in SQL (#14)
      const rows = await db
        .select({
          id: companies.id,
          tenantId: companies.tenantId,
          branchId: companies.branchId,
          ownerCustomerId: companies.ownerCustomerId,
          companyCode: companies.companyCode,
          name: companies.name,
          companyNameEn: companies.companyNameEn,
          tradeName: companies.tradeName,
          taxId: companies.taxId,
          normalizedCrNumber: companies.normalizedCrNumber,
          nameDiscrepancyFlag: companies.nameDiscrepancyFlag,
          nameDiscrepancyDetails: companies.nameDiscrepancyDetails,
          taxCardNumber: companies.taxCardNumber,
          chamberNumber: companies.chamberNumber,
          crExpiryDate: companies.crExpiryDate,
          crIssueDate: companies.crIssueDate,
          licenseNumber: companies.licenseNumber,
          licenseExpiryDate: companies.licenseExpiryDate,
          crDocumentName: companies.crDocumentName,
          hasCrDocument: sql<boolean>`(${companies.crDocumentUrl} IS NOT NULL AND ${companies.crDocumentUrl} <> '')`,
          sector: companies.sector,
          activities: companies.activities,
          status: companies.status,
          city: companies.city,
          stateCountry: companies.stateCountry,
          contactPhone: companies.contactPhone,
          contactEmail: companies.contactEmail,
          capitalBaisa: companies.capitalBaisa,
          legalForm: companies.legalForm,
          revenueMonthlyBaisa: companies.revenueMonthlyBaisa,
          employeesCount: companies.employeesCount,
          complianceScore: companies.complianceScore,
          createdAt: companies.createdAt,
          updatedAt: companies.updatedAt,
          deletedAt: companies.deletedAt,
          createdBy: companies.createdBy,
          clientRemindersEnabled: companies.clientRemindersEnabled,
          clientReminderConsentAt: companies.clientReminderConsentAt,
        })
        .from(companies)
        .where(whereClause)
        .orderBy(
          ...(sortOrder === "asc"
            ? [asc(companies.id)]
            : [desc(companies.updatedAt), desc(companies.id)])
        )
        .limit(limit)
        .offset(offset);

      const mapped = rows.map((c) => mapCompanyOutput(c));

      res.json({
        success: true,
        data: mapped,
        companies: mapped,
        pagination: {
          total: count,
          page,
          limit,
          totalPages: Math.ceil(count / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

companyRouter.post(
  "/",
  requireAuth,
  requirePermission("companies:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = CompanySchema.parse(req.body);

      const rawCrInput =
        (validated.crNumber && validated.crNumber.trim()) ||
        (validated.taxId && validated.taxId.trim()) ||
        `CR-${Date.now().toString().slice(-7)}`;

      if (
        PROMPT_CONTAMINATION_RE.test(validated.name) ||
        /^CR--?(?:RENEW|MORTGAGED|CERTIFICATE|ACTIVE)$/i.test(rawCrInput)
      ) {
        res.status(422).json({
          success: false,
          error: {
            code: "INVALID_CR_DATA",
            message:
              "بيانات المنشأة أو رقم السجل التجاري غير صالحة (تم رفض نص تلقائي غير معتمد)",
          },
          requestId: req.id,
        });
        return;
      }

      const resultPayload = await withCompanyUpsertLock(async () => {
        let validBranchId: number | null = null;
        if (validated.branchId) {
          const [foundBranch] = await db
            .select({ id: branches.id })
            .from(branches)
            .where(
              and(
                eq(branches.id, validated.branchId),
                eq(branches.tenantId, tenantId)
              )
            )
            .limit(1);
          if (foundBranch) validBranchId = foundBranch.id;
        }

        let validCustomerId: number | null = null;
        if (validated.ownerCustomerId) {
          const [foundCust] = await db
            .select({ id: customers.id })
            .from(customers)
            .where(
              and(
                eq(customers.id, validated.ownerCustomerId),
                eq(customers.tenantId, tenantId)
              )
            )
            .limit(1);
          if (foundCust) validCustomerId = foundCust.id;
        }

        const activitiesJson =
          typeof validated.activities === "object" &&
          validated.activities !== null
            ? JSON.stringify(validated.activities)
            : typeof validated.activities === "string"
              ? validated.activities
              : null;

        const effectiveCapitalBaisa =
          typeof validated.capitalBaisa === "number" &&
          validated.capitalBaisa > 0
            ? validated.capitalBaisa
            : typeof validated.capital === "number" && validated.capital > 0
              ? Math.round(validated.capital * 1000)
              : 0;

        const cleanCrDigits = normalizeCrNumber(rawCrInput);
        const normalizedCr = /^\d{5,10}$/.test(cleanCrDigits)
          ? cleanCrDigits
          : rawCrInput;
        const crPrefixedCode = `CR-${cleanCrDigits || normalizedCr}`;

        // Preserve distinct taxCardNumber vs CR number (#8, #62)
        const distinctTaxCard =
          validated.taxCardNumber !== undefined
            ? validated.taxCardNumber
            : validated.crNumber &&
                validated.taxId &&
                validated.taxId.trim() !== validated.crNumber.trim()
              ? validated.taxId.trim()
              : undefined;

        const storedDocUri = await persistCrDocumentIfDataUrl(
          tenantId,
          validated.crDocumentUrl,
          validated.crDocumentName
        );

        let existingCompany: typeof companies.$inferSelect | null = null;
        let matchedByExplicitId = false;
        const rawId = validated.id || req.body?.id;
        if (rawId) {
          const parsedId =
            typeof rawId === "number" ? rawId : parseInt(String(rawId), 10);
          if (!isNaN(parsedId)) {
            const [byNumId] = await db
              .select()
              .from(companies)
              .where(
                and(
                  eq(companies.id, parsedId),
                  eq(companies.tenantId, tenantId)
                )
              )
              .limit(1);
            if (byNumId) {
              existingCompany = byNumId;
              matchedByExplicitId = true;
            }
          }
        }
        if (!existingCompany && validated.companyCode) {
          const [byCode] = await db
            .select()
            .from(companies)
            .where(
              and(
                eq(companies.companyCode, validated.companyCode.trim()),
                eq(companies.tenantId, tenantId)
              )
            )
            .limit(1);
          if (byCode) existingCompany = byCode;
        }
        if (!existingCompany && rawCrInput) {
          const [byCr] = await db
            .select()
            .from(companies)
            .where(
              and(
                eq(companies.tenantId, tenantId),
                or(
                  ...(cleanCrDigits
                    ? [eq(companies.normalizedCrNumber, cleanCrDigits)]
                    : []),
                  eq(companies.taxId, rawCrInput),
                  eq(companies.taxId, normalizedCr),
                  eq(companies.taxId, crPrefixedCode),
                  eq(companies.companyCode, crPrefixedCode)
                )
              )
            )
            .limit(1);
          if (byCr) existingCompany = byCr;
        }

        if (existingCompany && !matchedByExplicitId && !existingCompany.deletedAt) {
          // Registering a NEW company with a CR number / code that already belongs to an
          // active company must not silently overwrite the existing record.
          const conflict = new Error(
            `يوجد بالفعل شركة مسجلة بنفس رقم السجل التجاري (${existingCompany.name}). لتعديلها استخدم تعديل الشركة بدلاً من إنشاء شركة جديدة.`,
          ) as Error & { status?: number; code?: string; details?: unknown };
          conflict.status = 409;
          conflict.code = "COMPANY_ALREADY_EXISTS";
          conflict.details = {
            existingCompanyId: existingCompany.id,
            existingCompanyName: existingCompany.name,
          };
          throw conflict;
        }

        if (existingCompany) {
          const [updatedCompany] = await db
            .update(companies)
            .set({
              deletedAt: null,
              branchId: validBranchId ?? existingCompany.branchId,
              ownerCustomerId:
                validCustomerId ?? existingCompany.ownerCustomerId,
              name: validated.name,
              companyNameEn:
                validated.companyNameEn !== undefined
                  ? validated.companyNameEn
                  : existingCompany.companyNameEn,
              tradeName: validated.tradeName || validated.name,
              taxId: normalizedCr,
              normalizedCrNumber:
                cleanCrDigits || existingCompany.normalizedCrNumber || null,
              taxCardNumber:
                distinctTaxCard !== undefined
                  ? distinctTaxCard
                  : existingCompany.taxCardNumber,
              chamberNumber:
                validated.chamberNumber !== undefined
                  ? validated.chamberNumber
                  : existingCompany.chamberNumber,
              crExpiryDate:
                validated.crExpiryDate ?? existingCompany.crExpiryDate,
              crIssueDate: validated.crIssueDate ?? existingCompany.crIssueDate,
              licenseNumber:
                validated.licenseNumber ?? existingCompany.licenseNumber,
              licenseExpiryDate:
                validated.licenseExpiryDate ??
                existingCompany.licenseExpiryDate,
              crDocumentUrl:
                storedDocUri !== undefined
                  ? storedDocUri
                  : existingCompany.crDocumentUrl,
              crDocumentName:
                validated.crDocumentName || existingCompany.crDocumentName,
              sector: validated.sector ?? existingCompany.sector,
              activities: activitiesJson ?? existingCompany.activities,
              status: validated.status,
              city: validated.city ?? existingCompany.city,
              stateCountry:
                validated.stateCountry ?? existingCompany.stateCountry,
              contactPhone:
                validated.contactPhone ?? existingCompany.contactPhone,
              contactEmail:
                validated.contactEmail ?? existingCompany.contactEmail,
              capitalBaisa:
                effectiveCapitalBaisa || existingCompany.capitalBaisa || 0,
              legalForm:
                validated.legalForm !== undefined
                  ? validated.legalForm || null
                  : (existingCompany.legalForm ?? null),
              revenueMonthlyBaisa:
                validated.revenueMonthlyBaisa ??
                existingCompany.revenueMonthlyBaisa,
              employeesCount:
                validated.employeesCount ?? existingCompany.employeesCount,
              complianceScore:
                validated.complianceScore ?? existingCompany.complianceScore,
              updatedAt: new Date(),
            })
            .where(
              and(
                eq(companies.id, existingCompany.id),
                eq(companies.tenantId, tenantId)
              )
            )
            .returning();

          try {
            await BackupService.enqueueSyncJob({
              idempotencyKey: `company_upsert_${updatedCompany.id}_${Date.now()}`,
              operationType: "UPSERT_COMPANY",
              entityType: "companies",
              entityId: String(updatedCompany.id),
              payloadSummary: JSON.stringify({
                id: updatedCompany.id,
                taxId: updatedCompany.taxId,
                name: updatedCompany.name,
              }),
            });
          } catch {
            // Non-blocking enqueue notice
          }

          try {
            await runExpiryAudit({ tenantId, triggerType: "IMMEDIATE_UPLOAD" });
          } catch {
            // Non-blocking audit notice
          }

          return { status: 200, data: mapCompanyOutput(updatedCompany) };
        }

        const finalCode = validated.companyCode?.trim() || crPrefixedCode;

        const [newCompany] = await db
          .insert(companies)
          .values({
            tenantId,
            branchId: validBranchId,
            ownerCustomerId: validCustomerId,
            companyCode: finalCode,
            name: validated.name,
            companyNameEn: validated.companyNameEn || null,
            tradeName: validated.tradeName || validated.name,
            taxId: normalizedCr,
            normalizedCrNumber: cleanCrDigits || null,
            taxCardNumber: distinctTaxCard || null,
            chamberNumber: validated.chamberNumber || null,
            crExpiryDate: validated.crExpiryDate,
            crIssueDate: validated.crIssueDate,
            licenseNumber: validated.licenseNumber,
            licenseExpiryDate: validated.licenseExpiryDate,
            crDocumentUrl: storedDocUri ?? null,
            crDocumentName: validated.crDocumentName || null,
            sector: validated.sector,
            activities: activitiesJson,
            status: validated.status,
            city: validated.city,
            stateCountry: validated.stateCountry,
            contactPhone: validated.contactPhone,
            contactEmail: validated.contactEmail,
            capitalBaisa: effectiveCapitalBaisa,
            legalForm: validated.legalForm || null,
            revenueMonthlyBaisa: validated.revenueMonthlyBaisa,
            employeesCount: validated.employeesCount,
            complianceScore: validated.complianceScore,
            createdBy: req.user?.userId
              ? String(req.user.userId)
              : req.user?.username,
          })
          .onConflictDoUpdate({
            target: companies.companyCode,
            set: {
              deletedAt: null,
              name: validated.name,
              companyNameEn: validated.companyNameEn || null,
              tradeName: validated.tradeName || validated.name,
              taxId: normalizedCr,
              normalizedCrNumber: cleanCrDigits || null,
              ...(distinctTaxCard !== undefined
                ? { taxCardNumber: distinctTaxCard }
                : {}),
              chamberNumber: validated.chamberNumber || null,
              crExpiryDate: validated.crExpiryDate,
              crIssueDate: validated.crIssueDate,
              licenseNumber: validated.licenseNumber,
              licenseExpiryDate: validated.licenseExpiryDate,
              ...(storedDocUri !== undefined
                ? { crDocumentUrl: storedDocUri }
                : {}),
              ...(validated.crDocumentName
                ? { crDocumentName: validated.crDocumentName }
                : {}),
              sector: validated.sector,
              activities: activitiesJson,
              status: validated.status,
              city: validated.city,
              stateCountry: validated.stateCountry,
              contactPhone: validated.contactPhone,
              contactEmail: validated.contactEmail,
              capitalBaisa: effectiveCapitalBaisa,
              legalForm: validated.legalForm || null,
              updatedAt: new Date(),
            },
          })
          .returning();

        await insertAuditLog({
          tenantId,
          actorId: req.user?.userId
            ? String(req.user.userId)
            : req.user?.username,
          actorName: req.user?.username,
          action: "CREATE_COMPANY",
          resource: "companies",
          resourceId: String(newCompany.id),
          details: JSON.stringify({
            name: newCompany.name,
            taxId: newCompany.taxId,
          }),
          ipAddress: req.ip || "",
        });

        try {
          await BackupService.enqueueSyncJob({
            idempotencyKey: `company_create_${newCompany.id}_${Date.now()}`,
            operationType: "CREATE_COMPANY",
            entityType: "companies",
            entityId: String(newCompany.id),
            payloadSummary: JSON.stringify({
              id: newCompany.id,
              taxId: newCompany.taxId,
              name: newCompany.name,
            }),
          });
        } catch {
          // Non-blocking enqueue notice
        }

        try {
          await runExpiryAudit({ tenantId, triggerType: "IMMEDIATE_UPLOAD" });
        } catch {
          // Non-blocking audit notice
        }

        return { status: 201, data: mapCompanyOutput(newCompany) };
      });

      res
        .status(resultPayload.status)
        .json({ success: true, data: resultPayload.data });
    } catch (err) {
      next(err);
    }
  }
);

companyRouter.get(
  "/:id",
  requireAuth,
  requirePermission("companies:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const rawParam = String(req.params.id || "").trim();
      let targetId: number | null = null;
      const parsedId = parseInt(rawParam, 10);
      if (!isNaN(parsedId)) {
        targetId = parsedId;
      } else {
        const [found] = await db
          .select({ id: companies.id })
          .from(companies)
          .where(
            and(
              eq(companies.tenantId, tenantId),
              or(
                eq(companies.companyCode, rawParam),
                eq(companies.taxId, rawParam)
              )
            )
          )
          .limit(1);
        if (found) targetId = found.id;
      }
      if (!targetId) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المنشأة غير موجودة" },
          requestId: req.id,
        });
        return;
      }
      const [company] = await db
        .select()
        .from(companies)
        .where(
          and(eq(companies.id, targetId), eq(companies.tenantId, tenantId))
        )
        .limit(1);
      if (!company) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المنشأة غير موجودة" },
          requestId: req.id,
        });
        return;
      }
      res.json({ success: true, data: mapCompanyOutput(company) });
    } catch (err) {
      next(err);
    }
  }
);

companyRouter.put(
  "/:id",
  requireAuth,
  requirePermission("companies:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const rawParam = String(req.params.id || "").trim();
      let id: number | null = null;
      const parsedId = parseInt(rawParam, 10);
      if (!isNaN(parsedId)) {
        id = parsedId;
      } else {
        const [found] = await db
          .select({ id: companies.id })
          .from(companies)
          .where(
            and(
              eq(companies.tenantId, tenantId),
              or(
                eq(companies.companyCode, rawParam),
                eq(companies.taxId, rawParam)
              )
            )
          )
          .limit(1);
        if (found) id = found.id;
      }
      if (!id) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المنشأة غير موجودة" },
          requestId: req.id,
        });
        return;
      }
      const validated = CompanySchema.partial().parse(req.body);
      if (Object.keys(validated).length === 0) {
        res.status(422).json({
          success: false,
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
          requestId: req.id,
        });
        return;
      }
      if (validated.branchId) {
        const [foundBranch] = await db
          .select({ id: branches.id })
          .from(branches)
          .where(
            and(
              eq(branches.id, validated.branchId),
              eq(branches.tenantId, tenantId)
            )
          )
          .limit(1);
        if (!foundBranch) validated.branchId = null;
      }
      if (validated.ownerCustomerId) {
        const [foundCust] = await db
          .select({ id: customers.id })
          .from(customers)
          .where(
            and(
              eq(customers.id, validated.ownerCustomerId),
              eq(customers.tenantId, tenantId)
            )
          )
          .limit(1);
        if (!foundCust) validated.ownerCustomerId = null;
      }
      if (
        validated.capital !== undefined &&
        validated.capital !== null &&
        validated.capitalBaisa === undefined
      ) {
        validated.capitalBaisa = Math.round(validated.capital * 1000);
      }
      delete validated.capital;
      const activitiesJson =
        validated.activities !== undefined
          ? typeof validated.activities === "object"
            ? JSON.stringify(validated.activities)
            : String(validated.activities)
          : undefined;

      // Never overwrite crDocumentUrl with relative /cr-download or indexeddb:// (#66)
      const storedDocUri = await persistCrDocumentIfDataUrl(
        tenantId,
        validated.crDocumentUrl,
        validated.crDocumentName
      );
      delete validated.crDocumentUrl;
      delete validated.crNumber;

      const { id: _ignoreId, activities: _ignoreActivities, capitalBaisa: rawCapBaisa, ...updateFields } = validated;
      const updatedNormCr = updateFields.taxId
        ? normalizeCrNumber(updateFields.taxId) || null
        : undefined;

      const [updated] = await db
        .update(companies)
        .set({
          ...updateFields,
          ...(typeof rawCapBaisa === "number" ? { capitalBaisa: rawCapBaisa } : {}),
          ...(storedDocUri !== undefined
            ? { crDocumentUrl: storedDocUri }
            : {}),
          ...(updatedNormCr !== undefined
            ? { normalizedCrNumber: updatedNormCr }
            : {}),
          deletedAt: null,
          ...(activitiesJson !== undefined
            ? { activities: activitiesJson }
            : {}),
          updatedAt: new Date(),
        })
        .where(and(eq(companies.id, id), eq(companies.tenantId, tenantId)))
        .returning();

      if (!updated) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المنشأة غير موجودة" },
          requestId: req.id,
        });
        return;
      }

      try {
        await BackupService.enqueueSyncJob({
          idempotencyKey: `company_update_${updated.id}_${Date.now()}`,
          operationType: "UPDATE_COMPANY",
          entityType: "companies",
          entityId: String(updated.id),
          payloadSummary: JSON.stringify({
            id: updated.id,
            taxId: updated.taxId,
            name: updated.name,
          }),
        });
      } catch {
        // Non-blocking enqueue notice
      }

      if (
        validated.crExpiryDate !== undefined ||
        validated.licenseExpiryDate !== undefined
      ) {
        await insertAuditLog({
          tenantId,
          actorId: req.user?.userId
            ? String(req.user.userId)
            : req.user?.username,
          actorName: req.user?.username,
          action: "UPDATE_DOCUMENT_EXPIRY",
          resource: "companies",
          resourceId: String(updated.id),
          details: JSON.stringify({
            crExpiryDate: updated.crExpiryDate,
            licenseExpiryDate: updated.licenseExpiryDate,
          }),
          ipAddress: req.ip || "",
        });
      }

      try {
        await runExpiryAudit({ tenantId, triggerType: "DATE_UPDATE" });
      } catch {
        // Non-blocking audit notice
      }

      res.json({ success: true, data: mapCompanyOutput(updated) });
    } catch (err) {
      next(err);
    }
  }
);

companyRouter.post(
  "/bulk-delete",
  requireAuth,
  requirePermission("companies:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const rawIds: unknown[] = Array.isArray(req.body?.ids)
        ? req.body.ids
        : [];
      if (rawIds.length === 0) {
        res.status(400).json({
          success: false,
          error: {
            code: "VALIDATION_ERROR",
            message: "يرجى تحديد شركة واحدة على الأقل للحذف",
          },
          requestId: req.id,
        });
        return;
      }

      const numericIds = rawIds
        .map((v) => parseInt(String(v).trim(), 10))
        .filter((n) => !isNaN(n));
      const stringKeys = rawIds.map((v) => String(v).trim()).filter(Boolean);

      const matchClauses = [];
      if (numericIds.length > 0) {
        matchClauses.push(inArray(companies.id, numericIds));
      }
      if (stringKeys.length > 0) {
        matchClauses.push(inArray(companies.companyCode, stringKeys));
        matchClauses.push(inArray(companies.taxId, stringKeys));
      }

      if (matchClauses.length === 0) {
        res.json({
          success: true,
          deletedCount: 0,
          message: "تم حذف الشركات المحددة بنجاح",
        });
        return;
      }

      const deletedRows = await db
        .update(companies)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(companies.tenantId, tenantId),
            isNull(companies.deletedAt),
            or(...matchClauses)
          )
        )
        .returning({
          id: companies.id,
          name: companies.name,
          taxId: companies.taxId,
        });

      await insertAuditLog({
        tenantId,
        actorId: req.user?.userId
          ? String(req.user.userId)
          : req.user?.username || "admin",
        actorName: req.user?.username || "admin",
        action: "BULK_DELETE_COMPANIES",
        resource: "companies",
        resourceId: deletedRows.map((r) => r.id).join(","),
        details: JSON.stringify({ count: deletedRows.length, ids: rawIds }),
        ipAddress: req.ip || "",
      });

      res.json({
        success: true,
        deletedCount: deletedRows.length,
        message: `تم حذف ${deletedRows.length} شركة بنجاح`,
      });
    } catch (err) {
      next(err);
    }
  }
);

companyRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("companies:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const rawParam = String(req.params.id || "").trim();
      let targetCompany: typeof companies.$inferSelect | null = null;
      const parsedId = parseInt(rawParam, 10);

      if (!isNaN(parsedId)) {
        const [foundById] = await db
          .select()
          .from(companies)
          .where(
            and(eq(companies.tenantId, tenantId), eq(companies.id, parsedId))
          )
          .limit(1);
        if (foundById) targetCompany = foundById;
      }

      if (!targetCompany) {
        const [foundByCodeOrTax] = await db
          .select()
          .from(companies)
          .where(
            and(
              eq(companies.tenantId, tenantId),
              or(
                eq(companies.companyCode, rawParam),
                eq(companies.taxId, rawParam)
              )
            )
          )
          .limit(1);
        if (foundByCodeOrTax) targetCompany = foundByCodeOrTax;
      }

      if (!targetCompany) {
        res.json({
          success: true,
          message: "تم حذف المنشأة بنجاح",
          alreadyDeleted: true,
        });
        return;
      }

      if (targetCompany.deletedAt) {
        res.json({
          success: true,
          message: "المنشأة محذوفة بالفعل مسبقاً",
          alreadyDeleted: true,
        });
        return;
      }

      const [deleted] = await db
        .update(companies)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(companies.id, targetCompany.id),
            eq(companies.tenantId, tenantId),
            isNull(companies.deletedAt)
          )
        )
        .returning();

      await insertAuditLog({
        tenantId,
        actorId: req.user?.userId
          ? String(req.user.userId)
          : req.user?.username,
        actorName: req.user?.username,
        action: "DELETE_COMPANY",
        resource: "companies",
        resourceId: String(targetCompany.id),
        details: JSON.stringify({
          name: targetCompany.name,
          taxId: targetCompany.taxId,
        }),
        ipAddress: req.ip || "",
      });

      try {
        await BackupService.enqueueSyncJob({
          idempotencyKey: `company_delete_${targetCompany.id}_${Date.now()}`,
          operationType: "DELETE_COMPANY",
          entityType: "companies",
          entityId: String(targetCompany.id),
          payloadSummary: JSON.stringify({
            id: targetCompany.id,
            deletedAt: deleted?.deletedAt,
          }),
        });
      } catch {
        // Non-blocking enqueue notice
      }

      res.json({ success: true, message: "تم حذف المنشأة بنجاح" });
    } catch (err) {
      next(err);
    }
  }
);

companyRouter.get(
  "/:id/cr-download",
  requireAuth,
  requirePermission("companies:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const rawParam = String(req.params.id || "").trim();
      const id = parseInt(rawParam, 10);
      let company: typeof companies.$inferSelect | null = null;
      if (!isNaN(id)) {
        const [byId] = await db
          .select()
          .from(companies)
          .where(and(eq(companies.id, id), eq(companies.tenantId, tenantId)))
          .limit(1);
        company = byId || null;
      }
      if (!company) {
        const [byCode] = await db
          .select()
          .from(companies)
          .where(
            and(
              or(
                eq(companies.companyCode, rawParam),
                eq(companies.taxId, rawParam)
              ),
              eq(companies.tenantId, tenantId)
            )
          )
          .limit(1);
        company = byCode || null;
      }
      if (!company) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المنشأة غير موجودة" },
          requestId: req.id,
        });
        return;
      }

      let fileUrl = company.crDocumentUrl;
      let fileName = path.basename(
        company.crDocumentName ||
          `CR_${company.taxId || company.companyCode}.pdf`
      );

      let storageKey: string | null = null;
      const [custDoc] = await db
        .select()
        .from(customerDocuments)
        .where(
          and(
            eq(customerDocuments.companyId, company.id),
            eq(customerDocuments.tenantId, tenantId),
            isNull(customerDocuments.deletedAt)
          )
        )
        .orderBy(desc(customerDocuments.id))
        .limit(1);

      if (custDoc) {
        if (!fileUrl || fileUrl.includes("/cr-download")) {
          fileUrl = custDoc.fileUrl || fileUrl;
        }
        storageKey = custDoc.storageObjectKey || null;
        if (custDoc.originalFileName) {
          fileName = path.basename(custDoc.originalFileName);
        }
      }

      // Read strictly from confined vault or base64 data URL (#9, #55, #56, #105)
      const stored = readStoredDocumentBuffer(storageKey, fileUrl);
      if (stored) {
        const safeMime = sanitizeDownloadMimeType(stored.mimeType);
        res.setHeader("Content-Type", safeMime);
        res.setHeader("X-Content-Type-Options", "nosniff");
        res.setHeader(
          "Content-Disposition",
          buildContentDispositionAttachment(fileName, "CR_Document.pdf")
        );
        res.setHeader("Content-Length", String(stored.buffer.length));
        res.send(stored.buffer);
        return;
      }

      res.status(404).json({
        success: false,
        error: {
          code: "NO_CR_DOCUMENT",
          message: "لا يوجد مستند سجل تجاري محفوظ لهذه المنشأة",
        },
        requestId: req.id,
      });
    } catch (err) {
      next(err);
    }
  }
);

export { companyRouter };
