import { Router } from "express";
import { z } from "zod";
import { eq, and, desc, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { cashSessions, payments, expenses } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import { verifyBranchOwnership } from "../middleware/tenantOwnership.js";
import {
  openCashSession,
  closeCashSession,
} from "../services/cashSessionService.js";

const cashSessionRouter = Router();

const OpenSessionSchema = z.object({
  branchId: z.number().int().optional().nullable(),
  openingBalanceBaisa: z
    .number()
    .int()
    .nonnegative("الرصيد الافتتاحي لا يمكن أن يكون سالباً")
    .default(0),
  notes: z.string().optional().nullable(),
});

const CloseSessionSchema = z.object({
  sessionId: z.number().int().optional(),
  closingBalanceBaisa: z
    .number()
    .int()
    .nonnegative("الرصيد الفعلي عند الإغلاق لا يمكن أن يكون سالباً"),
  notes: z.string().optional().nullable(),
});

cashSessionRouter.get(
  "/",
  requireAuth,
  requirePermission("cash_sessions:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset } = parsePaginationParams(req);
      const status = req.query.status
        ? String(req.query.status).trim()
        : undefined;
      const conditions: SQL[] = [eq(cashSessions.tenantId, tenantId)];
      if (status) {
        conditions.push(eq(cashSessions.status, status));
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(cashSessions)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(cashSessions)
        .where(whereClause)
        .orderBy(desc(cashSessions.id))
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

cashSessionRouter.post(
  "/open",
  requireAuth,
  requirePermission("cash_sessions:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = OpenSessionSchema.parse(req.body);
      await verifyBranchOwnership(tenantId, validated.branchId);
      const numericUserId = Number(req.user?.userId) || 1;
      const session = await openCashSession({
        tenantId,
        branchId: validated.branchId || undefined,
        userId: numericUserId,
        openingBalanceBaisa: validated.openingBalanceBaisa,
        notes: validated.notes || undefined,
      });
      res.status(201).json({ success: true, data: session });
    } catch (err) {
      next(err);
    }
  },
);

cashSessionRouter.post(
  ["/close", "/:id/close"],
  requireAuth,
  requirePermission("cash_sessions:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = CloseSessionSchema.parse(req.body);
      const paramId = req.params.id ? parseInt(req.params.id, 10) : undefined;
      const targetSessionId =
        paramId && !isNaN(paramId) ? paramId : validated.sessionId;
      const numericUserId = Number(req.user?.userId) || 1;
      if (!targetSessionId) {
        const [userOpenSession] = await db
          .select()
          .from(cashSessions)
          .where(
            and(
              eq(cashSessions.tenantId, tenantId),
              eq(cashSessions.openedBy, numericUserId),
              eq(cashSessions.status, "OPEN"),
            ),
          )
          .limit(1);
        if (!userOpenSession) {
          return res.status(400).json({
            error: {
              code: "MISSING_SESSION_ID",
              message: "يرجى تحديد معرف جلسة الصندوق المراد إغلاقها",
            },
          });
        }
        const closed2 = await closeCashSession({
          tenantId,
          sessionId: userOpenSession.id,
          userId: numericUserId,
          closingBalanceBaisa: validated.closingBalanceBaisa,
          notes: validated.notes || undefined,
        });
        return res.json({ success: true, data: closed2 });
      }
      const closed = await closeCashSession({
        tenantId,
        sessionId: targetSessionId,
        userId: numericUserId,
        closingBalanceBaisa: validated.closingBalanceBaisa,
        notes: validated.notes || undefined,
      });
      res.json({ success: true, data: closed });
    } catch (err) {
      next(err);
    }
  },
);

cashSessionRouter.get(
  "/active",
  requireAuth,
  requirePermission("cash_sessions:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const [session] = await db
        .select()
        .from(cashSessions)
        .where(
          and(
            eq(cashSessions.tenantId, tenantId),
            eq(cashSessions.status, "OPEN"),
          ),
        )
        .orderBy(desc(cashSessions.id))
        .limit(1);
      if (!session) {
        return res.json({ success: true, data: null });
      }
      const sessionPayments = await db
        .select()
        .from(payments)
        .where(
          and(
            eq(payments.cashSessionId, session.id),
            eq(payments.tenantId, tenantId),
          ),
        );
      const sessionExpenses = await db
        .select()
        .from(expenses)
        .where(
          and(
            eq(expenses.cashSessionId, session.id),
            eq(expenses.tenantId, tenantId),
          ),
        );
      res.json({
        success: true,
        data: {
          ...session,
          payments: sessionPayments,
          expenses: sessionExpenses,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

cashSessionRouter.get(
  "/:id",
  requireAuth,
  requirePermission("cash_sessions:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res
          .status(400)
          .json({ error: { code: "INVALID_ID", message: "معرف غير صالح" } });
      const [session] = await db
        .select()
        .from(cashSessions)
        .where(
          and(eq(cashSessions.id, id), eq(cashSessions.tenantId, tenantId)),
        )
        .limit(1);
      if (!session) {
        return res.status(404).json({
          error: { code: "NOT_FOUND", message: "جلسة الصندوق غير موجودة" },
        });
      }
      const sessionPayments = await db
        .select()
        .from(payments)
        .where(
          and(eq(payments.cashSessionId, id), eq(payments.tenantId, tenantId)),
        );
      const sessionExpenses = await db
        .select()
        .from(expenses)
        .where(
          and(eq(expenses.cashSessionId, id), eq(expenses.tenantId, tenantId)),
        );
      res.json({
        data: {
          ...session,
          payments: sessionPayments,
          expenses: sessionExpenses,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

export { cashSessionRouter };
