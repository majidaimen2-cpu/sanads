import { Router } from "express";
import { z } from "zod";
import { eq, and, isNull, desc, asc, or, ilike, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { services } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import { verifyBranchOwnership } from "../middleware/tenantOwnership.js";

const serviceRouter = Router();

const ServiceSchema = z.object({
  branchId: z.number().int().optional().nullable(),
  code: z.string().min(2, "رمز الخدمة مطلوب"),
  nameAr: z.string().min(2, "اسم الخدمة بالعربية مطلوب"),
  nameEn: z.string().optional().nullable(),
  authority: z.enum(["MOL", "ROP", "MOCI", "PASI", "MUNICIPALITY", "OTHER"]),
  govFeeBaisa: z.number().int().default(0),
  officeFeeBaisa: z.number().int().default(0),
  vatApplicable: z.boolean().default(true),
  requiredDocuments: z.unknown().optional(),
  slaDays: z.number().int().default(1),
  needsVerification: z.boolean().default(true),
  active: z.boolean().default(true),
});

serviceRouter.get(
  "/",
  requireAuth,
  requirePermission("services:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, search, includeDeleted, sortOrder } =
        parsePaginationParams(req);
      const authority = req.query.authority
        ? String(req.query.authority).trim().toUpperCase()
        : undefined;

      const conditions: SQL[] = [eq(services.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(services.deletedAt));
      }
      if (authority) {
        conditions.push(eq(services.authority, authority));
      }
      if (search) {
        const pattern = `%${search}%`;
        const searchCond = or(
          ilike(services.nameAr, pattern),
          ilike(services.nameEn, pattern),
          ilike(services.code, pattern),
          ilike(services.authority, pattern),
        );
        if (searchCond) conditions.push(searchCond);
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(services)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(services)
        .where(whereClause)
        .orderBy(sortOrder === "desc" ? desc(services.id) : asc(services.id))
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

serviceRouter.post(
  "/",
  requireAuth,
  requirePermission("services:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = ServiceSchema.parse(req.body);
      await verifyBranchOwnership(tenantId, validated.branchId);

      const reqDocsJson =
        typeof validated.requiredDocuments === "object" &&
        validated.requiredDocuments !== null
          ? JSON.stringify(validated.requiredDocuments)
          : typeof validated.requiredDocuments === "string"
            ? validated.requiredDocuments
            : null;

      const [newService] = await db
        .insert(services)
        .values({
          tenantId,
          branchId: validated.branchId ?? null,
          code: validated.code,
          nameAr: validated.nameAr,
          nameEn: validated.nameEn ?? null,
          authority: validated.authority,
          govFeeBaisa: validated.govFeeBaisa,
          officeFeeBaisa: validated.officeFeeBaisa,
          vatApplicable: validated.vatApplicable,
          requiredDocuments: reqDocsJson,
          slaDays: validated.slaDays,
          needsVerification: validated.needsVerification,
          active: validated.active,
          createdBy: req.user?.userId
            ? String(req.user.userId)
            : req.user?.username || "system",
        })
        .returning();
      res.status(201).json({ success: true, data: newService });
    } catch (err) {
      next(err);
    }
  },
);

serviceRouter.get(
  "/:id",
  requireAuth,
  requirePermission("services:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [srv] = await db
        .select()
        .from(services)
        .where(and(eq(services.id, id), eq(services.tenantId, tenantId)))
        .limit(1);
      if (!srv) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الخدمة غير موجودة",
          },
        });
      }
      res.json({ data: srv });
    } catch (err) {
      next(err);
    }
  },
);

serviceRouter.put(
  "/:id",
  requireAuth,
  requirePermission("services:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = ServiceSchema.partial().parse(req.body);
      if (Object.keys(validated).length === 0) {
        return res.status(422).json({
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
        });
      }
      await verifyBranchOwnership(tenantId, validated.branchId);

      const reqDocsJson =
        validated.requiredDocuments !== undefined
          ? typeof validated.requiredDocuments === "object" &&
            validated.requiredDocuments !== null
            ? JSON.stringify(validated.requiredDocuments)
            : typeof validated.requiredDocuments === "string"
              ? validated.requiredDocuments
              : null
          : undefined;

      const { requiredDocuments: _omit, ...restValidated } = validated;
      const [updated] = await db
        .update(services)
        .set({
          ...restValidated,
          ...(reqDocsJson !== undefined
            ? { requiredDocuments: reqDocsJson }
            : {}),
          updatedAt: new Date(),
        })
        .where(and(eq(services.id, id), eq(services.tenantId, tenantId)))
        .returning();
      if (!updated) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الخدمة غير موجودة",
          },
        });
      }
      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  },
);

serviceRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("services:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [deleted] = await db
        .update(services)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(services.id, id),
            eq(services.tenantId, tenantId),
            isNull(services.deletedAt),
          ),
        )
        .returning();
      if (!deleted) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الخدمة غير موجودة",
          },
        });
      }
      res.json({
        success: true,
        message: "تم حذف الخدمة بنجاح",
      });
    } catch (err) {
      next(err);
    }
  },
);

export { serviceRouter };
