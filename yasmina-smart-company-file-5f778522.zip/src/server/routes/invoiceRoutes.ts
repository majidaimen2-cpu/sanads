import { Router } from "express";
import { z } from "zod";
import { eq, and, isNull, desc, ne, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { invoices, payments } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import {
  verifyBranchOwnership,
  verifyTransactionOwnership,
  verifyCustomerOwnership,
} from "../middleware/tenantOwnership.js";
import { createInvoiceForTransaction } from "../services/invoiceService.js";
import { recordPayment } from "../services/paymentService.js";
import { createCreditNote } from "../services/refundService.js";
import { creditNotes } from "../../db/schema.js";

const invoiceRouter = Router();

const InvoiceCreateSchema = z.object({
  branchId: z.number().int().optional().nullable(),
  transactionId: z.number().int({
    message: "معرف المعاملة مطلوب",
  }),
  customerId: z.number().int({
    message: "معرف العميل مطلوب",
  }),
  govFeeBaisa: z.number().int().optional(),
  officeFeeBaisa: z.number().int().optional(),
  discountBaisa: z.number().int().optional(),
  pdfUrl: z.string().optional().nullable(),
});

const InvoiceUpdateSchema = z.object({
  govFeeBaisa: z.number().int().optional(),
  officeFeeBaisa: z.number().int().optional(),
  discountBaisa: z.number().int().optional(),
  pdfUrl: z.string().optional().nullable(),
});

const RefundInvoiceSchema = z.object({
  method: z.enum(["CASH", "CARD", "BANK", "TRANSFER"]),
  amountBaisa: z
    .number()
    .int()
    .positive("مبلغ الاسترداد يجب أن يكون أكبر من صفر")
    .optional(),
  reason: z.string().trim().min(3, "سبب الاسترداد مطلوب"),
  referenceNo: z.string().optional().nullable(),
});

const PayInvoiceSchema = z.object({
  method: z.enum(["CASH", "CARD", "BANK", "TRANSFER"]),
  amountBaisa: z
    .number()
    .int()
    .positive("مبلغ الدفع يجب أن يكون أكبر من صفر")
    .optional(),
  referenceNo: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

invoiceRouter.get(
  "/",
  requireAuth,
  requirePermission("invoices:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, includeDeleted } =
        parsePaginationParams(req);
      const customerId = req.query.customerId
        ? parseInt(String(req.query.customerId), 10)
        : undefined;
      const status = req.query.status
        ? String(req.query.status).trim()
        : undefined;

      const conditions: SQL[] = [eq(invoices.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(invoices.deletedAt));
      }
      if (customerId && !isNaN(customerId)) {
        conditions.push(eq(invoices.customerId, customerId));
      }
      if (status) {
        conditions.push(eq(invoices.status, status));
      }

      const whereClause = and(...conditions);
      const [countRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(invoices)
        .where(whereClause);
      const total = Number(countRow?.count ?? 0);

      const data = await db
        .select()
        .from(invoices)
        .where(whereClause)
        .orderBy(desc(invoices.id))
        .limit(limit)
        .offset(offset);

      res.json({
        data,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

invoiceRouter.post(
  "/",
  requireAuth,
  requirePermission("invoices:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const validated = InvoiceCreateSchema.parse(req.body);

      await verifyBranchOwnership(tenantId, validated.branchId);
      await verifyTransactionOwnership(tenantId, validated.transactionId);
      await verifyCustomerOwnership(tenantId, validated.customerId);

      const [existingInv] = await db
        .select()
        .from(invoices)
        .where(
          and(
            eq(invoices.tenantId, tenantId),
            eq(invoices.transactionId, validated.transactionId),
            isNull(invoices.deletedAt),
            ne(invoices.status, "CANCELLED"),
          ),
        )
        .limit(1);
      if (existingInv) {
        return res.status(409).json({
          error: {
            code: "INVOICE_ALREADY_EXISTS",
            message: "توجد فاتورة نشطة صادرة بالفعل لهذه المعاملة",
            details: {
              existingInvoiceId: existingInv.id,
              invoiceNumber: existingInv.invoiceNumber,
            },
          },
        });
      }
      const invoice = await createInvoiceForTransaction({
        tenantId,
        branchId: validated.branchId || undefined,
        transactionId: validated.transactionId,
        customerId: validated.customerId,
        govFeeBaisa: validated.govFeeBaisa,
        officeFeeBaisa: validated.officeFeeBaisa,
        discountBaisa: validated.discountBaisa,
        pdfUrl: validated.pdfUrl || undefined,
      });
      res.status(201).json({ success: true, data: invoice });
    } catch (err) {
      next(err);
    }
  },
);

invoiceRouter.get(
  "/:id",
  requireAuth,
  requirePermission("invoices:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [invoice] = await db
        .select()
        .from(invoices)
        .where(and(eq(invoices.id, id), eq(invoices.tenantId, tenantId)))
        .limit(1);
      if (!invoice) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الفاتورة غير موجودة",
          },
        });
      }
      const invoicePayments = await db
        .select()
        .from(payments)
        .where(
          and(eq(payments.invoiceId, id), eq(payments.tenantId, tenantId)),
        );
      res.json({ data: { ...invoice, payments: invoicePayments } });
    } catch (err) {
      next(err);
    }
  },
);

invoiceRouter.put(
  "/:id",
  requireAuth,
  requirePermission("invoices:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = InvoiceUpdateSchema.parse(req.body);
      if (Object.keys(validated).length === 0) {
        return res.status(422).json({
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
        });
      }
      const [invoice] = await db
        .select()
        .from(invoices)
        .where(
          and(
            eq(invoices.id, id),
            eq(invoices.tenantId, tenantId),
            isNull(invoices.deletedAt),
          ),
        )
        .limit(1);
      if (!invoice) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الفاتورة غير موجودة",
          },
        });
      }
      if (invoice.status !== "UNPAID") {
        return res.status(400).json({
          error: {
            code: "INVOICE_NOT_EDITABLE",
            message: "لا يمكن تعديل فاتورة سددت جزئياً أو كلياً",
          },
        });
      }
      const existingPayments = await db
        .select()
        .from(payments)
        .where(and(eq(payments.invoiceId, id), eq(payments.tenantId, tenantId)))
        .limit(1);
      if (existingPayments.length > 0) {
        return res.status(400).json({
          error: {
            code: "INVOICE_NOT_EDITABLE",
            message: "توجد عمليات دفع مسجلة على الفاتورة",
          },
        });
      }

      const govFee = validated.govFeeBaisa ?? invoice.govFeeBaisa;
      const officeFee = validated.officeFeeBaisa ?? invoice.officeFeeBaisa;
      const discount = validated.discountBaisa ?? invoice.discountBaisa;
      const vat = Math.round(officeFee * 0.05);
      const total = govFee + officeFee + vat - discount;

      const [updated] = await db
        .update(invoices)
        .set({
          govFeeBaisa: govFee,
          officeFeeBaisa: officeFee,
          discountBaisa: discount,
          vatBaisa: vat,
          totalBaisa: Math.max(0, total),
          pdfUrl:
            validated.pdfUrl !== undefined ? validated.pdfUrl : invoice.pdfUrl,
          updatedAt: new Date(),
        })
        .where(and(eq(invoices.id, id), eq(invoices.tenantId, tenantId)))
        .returning();
      res.json({ success: true, data: updated });
    } catch (err) {
      next(err);
    }
  },
);

invoiceRouter.post(
  "/:id/pay",
  requireAuth,
  requirePermission("payments:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const userId = Number(req.user?.userId) || undefined;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const validated = PayInvoiceSchema.parse(req.body);
      const [invoice] = await db
        .select()
        .from(invoices)
        .where(and(eq(invoices.id, id), eq(invoices.tenantId, tenantId)))
        .limit(1);
      if (!invoice) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الفاتورة غير موجودة",
          },
        });
      }
      const result = await recordPayment({
        tenantId,
        userId,
        transactionId: invoice.transactionId,
        invoiceId: invoice.id,
        method: validated.method,
        amountBaisa: validated.amountBaisa,
        referenceNo: validated.referenceNo,
        notes: validated.notes,
      });
      res.status(200).json({
        success: true,
        data: {
          invoice: result.invoice,
          payment: result.payment,
          remainingBaisa: result.remainingBaisa,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);

invoiceRouter.post(
  "/:id/refund",
  requireAuth,
  requirePermission("payments:refund"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const userId = Number(req.user?.userId) || undefined;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
        });
      const validated = RefundInvoiceSchema.parse(req.body);
      const result = await createCreditNote({
        tenantId,
        userId,
        invoiceId: id,
        amountBaisa: validated.amountBaisa,
        refundMethod: validated.method,
        reason: validated.reason,
        referenceNo: validated.referenceNo,
      });
      res.status(201).json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },
);

invoiceRouter.get(
  "/:id/credit-notes",
  requireAuth,
  requirePermission("invoices:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
        });
      const data = await db
        .select()
        .from(creditNotes)
        .where(and(eq(creditNotes.invoiceId, id), eq(creditNotes.tenantId, tenantId)))
        .orderBy(desc(creditNotes.id));
      res.json({ data });
    } catch (err) {
      next(err);
    }
  },
);

invoiceRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("invoices:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id))
        return res.status(400).json({
          error: {
            code: "INVALID_ID",
            message: "معرف غير صالح",
          },
        });
      const [target] = await db
        .select()
        .from(invoices)
        .where(
          and(
            eq(invoices.id, id),
            eq(invoices.tenantId, tenantId),
            isNull(invoices.deletedAt),
          ),
        )
        .limit(1);
      if (!target) {
        return res.status(404).json({
          error: { code: "NOT_FOUND", message: "الفاتورة غير موجودة" },
        });
      }
      if (target.status === "PAID" || target.status === "PARTIAL" || target.status === "REFUNDED") {
        return res.status(409).json({
          error: {
            code: "INVOICE_HAS_PAYMENTS",
            message:
              "لا يمكن حذف فاتورة مدفوعة أو مدفوعة جزئياً أو مستردة. أصدر إشعاراً دائناً (استرداد) بدلاً من الحذف.",
          },
        });
      }
      // Guard again inside the UPDATE (race-safe): only unpaid/cancelled invoices with no payment rows.
      const [deleted] = await db
        .update(invoices)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(invoices.id, id),
            eq(invoices.tenantId, tenantId),
            isNull(invoices.deletedAt),
            sql`${invoices.status} NOT IN ('PAID','PARTIAL','REFUNDED')`,
            sql`NOT EXISTS (SELECT 1 FROM payments p WHERE p.invoice_id = ${invoices.id})`,
          ),
        )
        .returning();
      if (!deleted) {
        return res.status(404).json({
          error: {
            code: "NOT_FOUND",
            message: "الفاتورة غير موجودة",
          },
        });
      }
      res.json({
        success: true,
        message: "تم حذف الفاتورة بنجاح",
      });
    } catch (err) {
      next(err);
    }
  },
);

export { invoiceRouter };
