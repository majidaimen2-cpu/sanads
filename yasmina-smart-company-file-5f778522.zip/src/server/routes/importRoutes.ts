import { Router } from "express";
import { z } from "zod";
import { db } from "../../db/index.js";
import { companies, customers, services, branches } from "../../db/schema.js";
import {
  requireAuth,
  requireRole,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { normalizeCrNumber } from "../services/crExtractionService.js";
import { logger } from "../logger.js";

const importRouter = Router();

const importPayloadSchema = z.object({
  dryRun: z.boolean().optional().default(true),
  data: z.record(z.string(), z.unknown()),
});

interface RawRecord {
  [key: string]: unknown;
}

function asRecords(val: unknown): RawRecord[] {
  if (!Array.isArray(val)) return [];
  return val.filter(
    (item): item is RawRecord => typeof item === "object" && item !== null,
  );
}

importRouter.post(
  "/legacy",
  requireAuth,
  requireRole("SUPER_ADMIN"),
  async (req, res, next) => {
    try {
      const parseResult = importPayloadSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(422).json({
          error: {
            code: "VALIDATION_ERROR",
            message: "Invalid import payload",
            details: parseResult.error.format(),
          },
        });
      }

      const { dryRun, data } = parseResult.data;
      const tenantId = getRequiredTenantId(req);

      const rawCompanies = asRecords(data.companies);
      const validCompanies = rawCompanies.filter((c) => {
        const hasName = Boolean(
          String(c.name || c.tradeName || "").trim(),
        );
        const normCr = normalizeCrNumber(
          String(c.taxId || c.crNumber || ""),
        );
        return hasName && Boolean(normCr) && !/^0+$/.test(normCr);
      });
      const skippedCompanies = rawCompanies.length - validCompanies.length;

      const rawCustomers = asRecords(data.customers);
      const validCustomers = rawCustomers.filter((cu) => {
        const hasName = Boolean(
          String(cu.fullNameAr || cu.name || "").trim(),
        );
        const hasPhone = Boolean(String(cu.phone || "").trim());
        return hasName && hasPhone;
      });
      const skippedCustomers = rawCustomers.length - validCustomers.length;

      const rawBranches = asRecords(data.branches);
      const rawServices = asRecords(data.services);

      const stats = {
        companies: validCompanies.length,
        skippedInvalidCompanies: skippedCompanies,
        customers: validCustomers.length,
        skippedInvalidCustomers: skippedCustomers,
        employees: asRecords(data.employees).length,
        contracts: asRecords(data.contracts).length,
        services: rawServices.length,
        transactions: asRecords(data.transactions).length,
        invoices: asRecords(data.invoices).length,
        payments: asRecords(data.payments).length,
        expenses: asRecords(data.expenses).length,
        branches: rawBranches.length,
      };

      if (dryRun) {
        return res.json({
          success: true,
          dryRun: true,
          stats,
          message:
            "Dry run completed successfully. Records missing mandatory CR or phone were excluded.",
        });
      }

      await db.transaction(async (tx) => {
        for (const b of rawBranches) {
          if (!b.code || !(b.nameAr || b.name)) continue;
          await tx.insert(branches).values({
            tenantId,
            code: String(b.code).trim(),
            nameAr: String(b.nameAr || b.name).trim(),
            nameEn: b.nameEn ? String(b.nameEn).trim() : null,
            address: b.address ? String(b.address).trim() : null,
            phone: b.phone ? String(b.phone).trim() : null,
            active: b.active !== false,
          });
        }

        for (const c of validCompanies) {
          const normCr = normalizeCrNumber(
            String(c.taxId || c.crNumber || ""),
          );
          const canonicalTaxId = `CR-${normCr}`;
          const capBaisa =
            typeof c.capitalBaisa === "number" && c.capitalBaisa > 0
              ? c.capitalBaisa
              : typeof c.capital === "number" && c.capital > 0
                ? Math.round(c.capital * 1000)
                : 0;

          await tx.insert(companies).values({
            tenantId,
            companyCode: String(
              c.companyCode ||
                `${canonicalTaxId}-${Date.now().toString().slice(-4)}`,
            ),
            name: String(c.name || c.tradeName).trim(),
            tradeName: c.tradeName ? String(c.tradeName).trim() : null,
            taxId: canonicalTaxId,
            normalizedCrNumber: normCr,
            sector: c.sector ? String(c.sector).trim() : null,
            city: c.city ? String(c.city).trim() : null,
            stateCountry: c.stateCountry
              ? String(c.stateCountry).trim()
              : null,
            capitalBaisa: capBaisa,
            legalForm: c.legalForm ? String(c.legalForm).trim() : null,
            crIssueDate: c.crIssueDate ? String(c.crIssueDate) : null,
            crExpiryDate: c.crExpiryDate ? String(c.crExpiryDate) : null,
            revenueMonthlyBaisa: c.revenueMonthly
              ? Number(c.revenueMonthly)
              : 0,
            employeesCount: c.employeesCount ? Number(c.employeesCount) : 0,
            contactPhone: c.contactPhone
              ? String(c.contactPhone).trim()
              : null,
            contactEmail: c.contactEmail
              ? String(c.contactEmail).trim()
              : null,
          });
        }

        for (const cu of validCustomers) {
          await tx.insert(customers).values({
            tenantId,
            fullNameAr: String(cu.fullNameAr || cu.name).trim(),
            phone: String(cu.phone).trim(),
            civilId: cu.civilId ? String(cu.civilId).trim() : null,
            nationality: cu.nationality
              ? String(cu.nationality).trim()
              : "Omani",
            customerType: cu.customerType
              ? String(cu.customerType).trim()
              : "INDIVIDUAL",
          });
        }

        for (const s of rawServices) {
          if (!s.code || !(s.nameAr || s.name)) continue;
          await tx.insert(services).values({
            tenantId,
            code: String(s.code).trim(),
            nameAr: String(s.nameAr || s.name).trim(),
            nameEn: s.nameEn ? String(s.nameEn).trim() : null,
            authority: String(s.authority || "MOCIIP").trim(),
            govFeeBaisa: s.govFeeBaisa ? Number(s.govFeeBaisa) : 0,
            officeFeeBaisa: s.officeFeeBaisa ? Number(s.officeFeeBaisa) : 0,
            vatApplicable: s.vatApplicable !== false,
          });
        }
      });

      res.json({
        success: true,
        dryRun: false,
        stats,
        importedAt: new Date().toISOString(),
        message:
          "Legacy data successfully committed to database without fabricated defaults.",
      });
    } catch (err) {
      logger.error({ err }, "Legacy import error");
      next(err);
    }
  },
);

export { importRouter };
