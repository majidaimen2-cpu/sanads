import { Router } from "express";
import { requestService } from "../services/requestService.js";
import { whatsAppService } from "../services/whatsappService.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";

const requestRouter = Router();

function senderPhoneOnly(phone: string): string {
  return phone.replace(/[^0-9]/g, "");
}

requestRouter.get("/", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const { search, status, priority, serviceType } = req.query;
    const requests = await requestService.getRequests({
      tenantId,
      search: typeof search === "string" ? search : undefined,
      status: typeof status === "string" ? status : undefined,
      priority: typeof priority === "string" ? priority : undefined,
      serviceType: typeof serviceType === "string" ? serviceType : undefined,
    });
    res.json({ success: true, requests, total: requests.length });
  } catch (err) {
    next(err);
  }
});

requestRouter.get("/:id", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const { id } = req.params;
    const item = await requestService.getRequestById(id, tenantId);
    if (!item) {
      res.status(404).json({
        success: false,
        error: { code: "NOT_FOUND", message: "الطلب غير موجود" },
        requestId: req.id,
      });
      return;
    }
    res.json({ success: true, request: item });
  } catch (err) {
    next(err);
  }
});

requestRouter.post("/", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const {
      customerName,
      customerPhone,
      serviceType,
      requestSummary,
      rawMessage,
      priority,
      status,
      notes,
    } = req.body || {};

    if (!customerName || !customerPhone || !requestSummary) {
      res.status(400).json({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: "اسم العميل، رقم الهاتف، وملخص الطلب حقول مطلوبة",
        },
        requestId: req.id,
      });
      return;
    }

    const created = await requestService.saveExtractedRequest({
      tenantId,
      customerName: String(customerName),
      customerPhone: String(customerPhone),
      serviceType: serviceType ? String(serviceType) : "معاملة مكتب سند",
      requestSummary: String(requestSummary),
      rawMessage: rawMessage ? String(rawMessage) : String(requestSummary),
      priority: priority ? String(priority) : "MEDIUM",
      status: status ? String(status) : "NEW",
      notes: notes ? String(notes) : undefined,
    });

    res.status(201).json({ success: true, request: created });
  } catch (err) {
    next(err);
  }
});

requestRouter.patch("/:id", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const { id } = req.params;
    const updates = req.body || {};
    const updated = await requestService.updateRequest(id, updates, tenantId);
    if (!updated) {
      res.status(404).json({
        success: false,
        error: { code: "NOT_FOUND", message: "الطلب غير موجود" },
        requestId: req.id,
      });
      return;
    }
    res.json({ success: true, request: updated });
  } catch (err) {
    next(err);
  }
});

requestRouter.delete("/:id", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const { id } = req.params;
    await requestService.deleteRequest(id, tenantId);
    res.json({ success: true, message: "تم حذف الطلب بنجاح" });
  } catch (err) {
    next(err);
  }
});

requestRouter.post("/:id/convert", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const { id } = req.params;
    const clerkName = req.user?.username || req.body?.clerkName || "موظف سند";
    const result = await requestService.convertToTransaction(
      id,
      String(clerkName),
      tenantId
    );
    res.json({
      success: true,
      message: `تم تحويل الطلب إلى المعاملة الرسمية رقم ${result.transactionNumber}`,
      ...result,
    });
  } catch (err) {
    next(err);
  }
});

requestRouter.post(
  "/simulate-inbound",
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      if (process.env.NODE_ENV === "production") {
        res.status(404).json({
          success: false,
          error: {
            code: "NOT_FOUND",
            message: "Simulation endpoint is disabled in production.",
          },
          requestId: req.id,
        });
        return;
      }

      const tenantId = getRequiredTenantId(req);
      const {
        senderNumber = "+968 9123 7890",
        senderName = "سعيد بن ناصر العامري",
        text = "السلام عليكم ورحمة الله، عندي شركة مقاولات برقم سجل 1084920 وأريد أجدد السجل التجاري وأضيف نشاط مقاولات عامة ونقل، كم الرسوم المطلوبة؟",
      } = req.body || {};

      const jid = `${String(senderNumber).replace(/[^0-9]/g, "")}@s.whatsapp.net`;
      await whatsAppService.processRawWAMessage(
        {
          key: { remoteJid: jid, fromMe: false },
          message: { conversation: String(text) },
          pushName: String(senderName),
        },
        true
      );

      const recent = await requestService.getRequests({
        tenantId,
        search: senderPhoneOnly(String(senderNumber)),
      });
      const latestRequest = recent[0] || null;

      res.json({
        success: true,
        message:
          "تم استقبال الرسالة، وقام نموذج الذكاء الاصطناعي بفهم احتياج الزبون وصياغة الرد البشري وتسجيل الطلب بنجاح",
        createdRequest: latestRequest,
      });
    } catch (err) {
      next(err);
    }
  }
);

requestRouter.post("/analyze", requireAuth, async (req, res, next) => {
  try {
    const tenantId = getRequiredTenantId(req);
    const { message, text, phone, customerPhone, senderName, chatId } =
      req.body || {};
    const msgText = String(message || text || "").trim();
    const senderPhone = String(phone || customerPhone || "+96891234567");
    if (!msgText) {
      res.status(400).json({
        success: false,
        error: { code: "VALIDATION_ERROR", message: "نص الرسالة مطلوب" },
        requestId: req.id,
      });
      return;
    }

    const targetChatId =
      chatId || `chat-${senderPhone.replace(/[^0-9]/g, "")}`;
    const recentHistory = whatsAppService
      .getMessages(targetChatId)
      .slice(-8)
      .map((m) => ({
        fromMe: m.fromMe,
        senderName: m.senderName,
        text: m.text,
        timestamp: m.timestamp,
      }));

    const { humanReply, request } =
      await requestService.analyzeAndProcessCustomerMessage({
        tenantId,
        text: msgText,
        senderName: senderName || "متعامل واتساب",
        senderPhone,
        chatId: targetChatId,
        recentHistory,
      });

    res.json({
      success: true,
      reply: humanReply,
      extractedRequest: request,
    });
  } catch (err) {
    next(err);
  }
});

export { requestRouter };
