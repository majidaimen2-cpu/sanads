import { Router } from "express";
import { desc, eq, and } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  whatsappProcessingJobs,
  whatsappOutbox,
  whatsappMessages,
} from "../../db/schema.js";
import { whatsAppService } from "../services/whatsappService.js";
import {
  processIncomingWhatsAppMediaMessage,
  recoverInterruptedWhatsAppJobs,
} from "../services/whatsappDocumentProcessor.js";
import {
  readStoredDocumentBuffer,
  sanitizeDownloadMimeType,
  buildContentDispositionAttachment,
} from "../services/documentStorageService.js";
import {
  requireAuth,
  requirePermission,
  requireRole,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { getOrCreateTenantSettings } from "./settingsRoutes.js";
import { tenantSettings } from "../../db/schema.js";
import { logger } from "../logger.js";

const evolutionRouter = Router();

// GET /status - Gateway status check
evolutionRouter.get(
  ["/status", "/instance/connectionState/:instanceName"],
  requireAuth,
  requirePermission("whatsapp:read"),
  async (_req, res) => {
    const state = whatsAppService.getState();
    const isConnected = state.status === "connected";
    res.json({
      success: true,
      connectionState: state.connectionState,
      state: isConnected
        ? "open"
        : state.status === "connecting"
          ? "connecting"
          : "close",
      status: state.status,
      connectionAttemptId: state.connectionAttemptId,
      qrSequence: state.qrSequence,
      qrGeneratedAt: state.qrGeneratedAt,
      qrExpiresAt: state.qrExpiresAt,
      base64: isConnected ? null : state.qrCodeDataUrl,
      qrcode: isConnected ? null : state.qrCodeDataUrl,
      phoneNumber: state.phoneNumber,
      profileName: state.profileName,
      hasQr: Boolean(!isConnected && state.qrCodeDataUrl),
      errorCode: state.errorCode,
      error: state.errorMessage,
      totalSyncedChats: state.totalSyncedChats,
      totalSyncedMessages: state.totalSyncedMessages,
      autoReplyEnabled: state.autoReplyEnabled,
    });
  }
);

// POST /reset-session or GET /reset-session - Clear expired sessions and generate fresh QR
evolutionRouter.all(
  [
    "/reset-session",
    "/reset",
    "/instance/reset/:instanceName",
    "/instance/logout/:instanceName",
  ],
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (_req, res, next) => {
    try {
      const qrInfo = await whatsAppService.resetSessionAndGenerateQr();
      const state = whatsAppService.getState();
      const qrData = qrInfo.qrCodeDataUrl || state.qrCodeDataUrl;
      res.json({
        success: true,
        message: "تمت إعادة ضبط جلسة واتساب وتوليد رمز QR جديد بنجاح",
        state: "connecting",
        status: state.status,
        connectionState: state.connectionState,
        qrcode: qrData,
        base64: qrData,
        qrGeneratedAt: state.qrGeneratedAt,
        qrExpiresAt: state.qrExpiresAt,
      });
    } catch (err) {
      logger.error({ err }, "Error resetting WhatsApp session");
      next(err);
    }
  }
);

// GET /qr or /instance/connect/:instanceName - Returns QR Code data URL or connection status
evolutionRouter.get(
  ["/qr", "/instance/connect/:instanceName"],
  requireAuth,
  requirePermission("whatsapp:read"),
  async (req, res, next) => {
    try {
      const forceNew =
        req.query.force === "true" || req.query.refresh === "true";
      let state = whatsAppService.getState();

      if (state.status === "connected" && !forceNew) {
        res.json({
          success: true,
          connectionState: state.connectionState,
          status: "connected",
          state: "open",
          connectionAttemptId: state.connectionAttemptId,
          qrSequence: state.qrSequence,
          qrGeneratedAt: 0,
          qrExpiresAt: 0,
          phoneNumber: state.phoneNumber,
          profileName: state.profileName,
          base64: null,
          qrcode: null,
        });
        return;
      }

      const qrInfo = forceNew
        ? await whatsAppService.resetSessionAndGenerateQr()
        : await whatsAppService.waitForQrCode(12000, false);

      state = whatsAppService.getState();
      const isConnected = state.status === "connected";
      const qrData = isConnected
        ? null
        : qrInfo.qrCodeDataUrl || state.qrCodeDataUrl;

      res.json({
        success: true,
        connectionState: state.connectionState,
        status: state.status,
        state: isConnected ? "open" : "connecting",
        connectionAttemptId: state.connectionAttemptId,
        qrSequence: state.qrSequence,
        qrGeneratedAt: state.qrGeneratedAt,
        qrExpiresAt: state.qrExpiresAt,
        base64: qrData,
        qrcode: qrData,
        phoneNumber: state.phoneNumber,
        profileName: state.profileName,
        errorCode: state.errorCode,
        error: state.errorMessage,
      });
    } catch (err) {
      logger.error({ err }, "Error fetching WhatsApp QR code");
      next(err);
    }
  }
);

// POST /pairing-code - Connect using 8-character phone number code
evolutionRouter.post(
  ["/pairing-code", "/instance/pairing-code/:instanceName"],
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const { phoneNumber } = req.body || {};
      if (!phoneNumber) {
        res.status(400).json({
          success: false,
          error: {
            code: "MISSING_PHONE",
            message: "رقم الهاتف مطلوب لتوليد رمز الاقتران",
          },
          requestId: req.id,
        });
        return;
      }

      const code = await whatsAppService.requestPairingCode(
        String(phoneNumber)
      );
      res.json({
        success: true,
        pairingCode: code,
        message: `تم إنشاء رمز الاقتران بنجاح: ${code}`,
      });
    } catch (err) {
      logger.error({ err }, "Error generating pairing code");
      next(err);
    }
  }
);

// POST /restart - Refresh WhatsApp session and get active QR
evolutionRouter.post(
  ["/restart", "/instance/restart/:instanceName"],
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const forceRestart = Boolean(req.body?.force);
      await whatsAppService.startSession(forceRestart);
      const qrInfo = await whatsAppService.waitForQrCode(12000, false);
      const state = whatsAppService.getState();
      const isConnected = state.status === "connected";
      const qrData = isConnected
        ? null
        : qrInfo.qrCodeDataUrl || state.qrCodeDataUrl;

      res.json({
        success: true,
        connectionState: state.connectionState,
        status: state.status,
        state: isConnected ? "open" : "connecting",
        connectionAttemptId: state.connectionAttemptId,
        qrSequence: state.qrSequence,
        qrGeneratedAt: state.qrGeneratedAt,
        qrExpiresAt: state.qrExpiresAt,
        base64: qrData,
        qrcode: qrData,
        phoneNumber: state.phoneNumber,
        profileName: state.profileName,
        errorCode: state.errorCode,
        error: state.errorMessage,
        message: "تمت إعادة تهيئة جلسة واتساب وتوليد رمز QR جديد بنجاح",
      });
    } catch (err) {
      next(err);
    }
  }
);

// GET /diagnostics - Structured diagnostic logs (no raw secrets or QR payloads)
evolutionRouter.get(
  "/diagnostics",
  requireAuth,
  requirePermission("whatsapp:read"),
  (_req, res) => {
    res.json({
      success: true,
      state: {
        connectionState: whatsAppService.state.connectionState,
        status: whatsAppService.state.status,
        connectionAttemptId: whatsAppService.state.connectionAttemptId,
        qrSequence: whatsAppService.state.qrSequence,
        qrGeneratedAt: whatsAppService.state.qrGeneratedAt,
        hasQr: Boolean(whatsAppService.state.qrCodeDataUrl),
        errorCode: whatsAppService.state.errorCode,
      },
      logs: whatsAppService.getDiagnosticLogs(50),
    });
  }
);

// POST /logout - Disconnect and clear credentials
evolutionRouter.post(
  ["/logout", "/instance/logout/:instanceName"],
  requireAuth,
  requireRole("SUPER_ADMIN", "MANAGER"),
  async (_req, res, next) => {
    try {
      await whatsAppService.logout();
      res.json({
        success: true,
        message: "تم قطع اتصال جلسة واتساب ومسح بيانات الاعتماد بنجاح",
      });
    } catch (err) {
      next(err);
    }
  }
);

// GET /chats - List all chats
evolutionRouter.get(
  ["/chats", "/chat/findChats/:instanceName"],
  requireAuth,
  requirePermission("whatsapp:read"),
  (_req, res) => {
    const chats = whatsAppService.getChats();
    res.json({ success: true, chats });
  }
);

// GET /messages/:chatId - List messages for a chat
evolutionRouter.get(
  ["/messages/:chatId", "/chat/findMessages/:instanceName/:chatId"],
  requireAuth,
  requirePermission("whatsapp:read"),
  (req, res) => {
    const { chatId } = req.params;
    const messages = whatsAppService.getMessages(chatId);
    whatsAppService.markChatAsRead(chatId);
    res.json({ success: true, messages });
  }
);

// POST /chat/:chatId/read - Mark chat as read
evolutionRouter.post(
  "/chat/:chatId/read",
  requireAuth,
  requirePermission("whatsapp:read"),
  (req, res) => {
    const { chatId } = req.params;
    whatsAppService.markChatAsRead(chatId);
    res.json({ success: true, message: "تم تحديث حالة القراءة للمحادثة" });
  }
);

// POST /chat/new - Start new conversation with a phone number
evolutionRouter.post(
  "/chat/new",
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const { phoneNumber, name, initialMessage } = req.body || {};
      const cleanDigits = String(phoneNumber || "").replace(/[^0-9]/g, "");
      if (!cleanDigits || cleanDigits.length < 7) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_PHONE", message: "رقم الهاتف غير صالح" },
          requestId: req.id,
        });
        return;
      }
      const jid = `${cleanDigits}@s.whatsapp.net`;
      const formatted = `+${cleanDigits}`;
      const chat = whatsAppService.upsertChatFromJid(jid, {
        contactName: name || formatted,
        contactNumber: formatted,
        lastMessage: initialMessage || "بدء محادثة جديدة",
        lastMessageTime: new Date().toLocaleTimeString("ar-OM", {
          timeZone: "Asia/Muscat",
          hour: "2-digit",
          minute: "2-digit",
        }),
      });

      if (initialMessage) {
        await whatsAppService.sendManualMessage(
          chat.id,
          String(initialMessage)
        );
      }

      res.json({ success: true, chat });
    } catch (err) {
      next(err);
    }
  }
);

// POST /send - Send manual message from agent to customer with optional media
evolutionRouter.post(
  [
    "/send",
    "/message/sendText/:instanceName",
    "/message/sendMedia/:instanceName",
  ],
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const {
        number,
        text,
        message,
        chatId,
        mediaBase64,
        fileName,
        mimeType,
        clientMessageId,
      } = req.body || {};
      const content = text || message || "";
      const targetChatId =
        chatId ||
        (number ? `chat-${String(number).replace(/[^0-9]/g, "")}` : null);

      if (!targetChatId && !number) {
        res.status(400).json({
          success: false,
          error: {
            code: "MISSING_TARGET",
            message: "chatId or number is required",
          },
          requestId: req.id,
        });
        return;
      }

      let mediaObj:
        | { buffer: Buffer; fileName: string; mimeType: string }
        | undefined;
      if (mediaBase64 && typeof mediaBase64 === "string") {
        const cleanB64 = mediaBase64.replace(/^data:[^;]+;base64,/, "");
        const buf = Buffer.from(cleanB64, "base64");
        if (buf.length > 15 * 1024 * 1024) {
          res.status(413).json({
            success: false,
            error: {
              code: "FILE_TOO_LARGE",
              message: "حجم المرفق يتجاوز الحد الأقصى المسموح به (15 MB).",
            },
            requestId: req.id,
          });
          return;
        }
        mediaObj = {
          buffer: buf,
          fileName: String(fileName || "document.pdf"),
          mimeType: String(mimeType || "application/pdf"),
        };
      }

      const sentMsg = await whatsAppService.sendManualMessage(
        targetChatId || `chat-${String(number).replace(/[^0-9]/g, "")}`,
        String(content),
        mediaObj
      );
      res.json({
        success: Boolean(sentMsg),
        message: sentMsg
          ? {
              ...sentMsg,
              clientMessageId: clientMessageId || undefined,
            }
          : null,
      });
    } catch (err) {
      next(err);
    }
  }
);

// POST /test-incoming - Simulate an incoming WhatsApp message (Disabled in production #17)
evolutionRouter.post(
  "/test-incoming",
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      if (process.env.NODE_ENV === "production") {
        res.status(404).json({
          success: false,
          error: {
            code: "NOT_FOUND",
            message: "Test simulation endpoint is disabled in production.",
          },
          requestId: req.id,
        });
        return;
      }

      const {
        senderNumber = "+968 9876 5432",
        senderName = "سالم المعمري",
        text = "السلام عليكم، أريد تجديد السجل التجاري لمنشأتي ومتابعة الإجراءات",
      } = req.body || {};

      const cleanNum = String(senderNumber).replace(/[^0-9]/g, "");
      const jid = `${cleanNum}@s.whatsapp.net`;

      await whatsAppService.processRawWAMessage(
        {
          key: { remoteJid: jid, fromMe: false },
          message: { conversation: String(text) },
          pushName: String(senderName),
          messageTimestamp: Math.floor(Date.now() / 1000),
        },
        true
      );

      res.json({
        success: true,
        message:
          "تم استلام ومعالجة الرسالة بنجاح وستظهر مباشرة في قائمة المحادثات والشاشة.",
      });
    } catch (err) {
      next(err);
    }
  }
);

// GET /media/:messageId - Stream or download a WhatsApp chat media attachment (#10, #50, #55, #56, #106)
evolutionRouter.get(
  "/media/:messageId",
  requireAuth,
  requirePermission("whatsapp:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const messageId = decodeURIComponent(String(req.params.messageId || ""));
      const fallbackFileName =
        typeof req.query.fileName === "string" ? req.query.fileName : undefined;

      // Verify tenant ownership in DB if a job or message record exists for this providerMessageId (#50)
      const [job] = await db
        .select()
        .from(whatsappProcessingJobs)
        .where(eq(whatsappProcessingJobs.providerMessageId, messageId))
        .limit(1);

      if (job && job.tenantId !== tenantId) {
        res.status(404).json({
          success: false,
          error: {
            code: "NOT_FOUND",
            message: "الملف المرفق غير متوفر للمعاينة",
          },
          requestId: req.id,
        });
        return;
      }

      const [msgRow] = await db
        .select()
        .from(whatsappMessages)
        .where(eq(whatsappMessages.providerMessageId, messageId))
        .limit(1);

      if (msgRow && msgRow.tenantId !== tenantId) {
        res.status(404).json({
          success: false,
          error: {
            code: "NOT_FOUND",
            message: "الملف المرفق غير متوفر للمعاينة",
          },
          requestId: req.id,
        });
        return;
      }

      let media: {
        buffer: Buffer;
        fileName: string;
        mimeType: string;
      } | null = null;

      if (job && job.storageObjectKey) {
        const stored = readStoredDocumentBuffer(job.storageObjectKey, null);
        if (stored) {
          media = {
            buffer: stored.buffer,
            fileName:
              job.originalFileName || fallbackFileName || "document.pdf",
            mimeType: job.mimeType || stored.mimeType,
          };
        }
      }

      if (!media) {
        const localMedia = whatsAppService.getMediaForMessage(
          messageId,
          fallbackFileName
        );
        if (localMedia) {
          media = localMedia;
        }
      }

      if (!media || !Buffer.isBuffer(media.buffer)) {
        res.status(404).json({
          success: false,
          error: {
            code: "NOT_FOUND",
            message: "الملف المرفق غير متوفر للمعاينة",
          },
          requestId: req.id,
        });
        return;
      }

      const safeMime = sanitizeDownloadMimeType(media.mimeType);
      res.setHeader("Content-Type", safeMime);
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Content-Length", String(media.buffer.length));
      res.setHeader(
        "Content-Disposition",
        buildContentDispositionAttachment(media.fileName, "document.pdf")
      );
      res.send(media.buffer);
    } catch (err) {
      next(err);
    }
  }
);

// GET /auto-reply - Get current AI auto-reply state (#28, #44, #106)
evolutionRouter.get(
  ["/auto-reply", "/instance/auto-reply/:instanceName"],
  requireAuth,
  requirePermission("whatsapp:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const settings = await getOrCreateTenantSettings(tenantId);
      res.json({
        success: true,
        autoReplyEnabled: settings.autoReplyEnabled,
        humanApprovalMode: settings.humanApprovalMode,
      });
    } catch (err) {
      next(err);
    }
  }
);

// POST /auto-reply - Toggle AI auto-reply (#28, #44, #106)
evolutionRouter.post(
  ["/auto-reply", "/instance/auto-reply/:instanceName"],
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { enabled, humanApprovalMode } = req.body || {};
      await getOrCreateTenantSettings(tenantId);

      const updates: Record<string, unknown> = { updatedAt: new Date() };
      if (enabled !== undefined) {
        updates.autoReplyEnabled = Boolean(enabled);
        whatsAppService.setAutoReply(Boolean(enabled));
      }
      if (humanApprovalMode !== undefined) {
        updates.humanApprovalMode = Boolean(humanApprovalMode);
      }

      const [updated] = await db
        .update(tenantSettings)
        .set(updates)
        .where(eq(tenantSettings.tenantId, tenantId))
        .returning();

      res.json({
        success: true,
        autoReplyEnabled: updated.autoReplyEnabled,
        humanApprovalMode: updated.humanApprovalMode,
      });
    } catch (err) {
      next(err);
    }
  }
);

// POST /ingest-document - Ingest a WhatsApp document message (PDF or Image) through the autonomous engine
evolutionRouter.post(
  "/ingest-document",
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const {
        providerMessageId,
        senderPhone = "+96891234567",
        senderName = "متعامل واتساب",
        fileName = "document.pdf",
        mimeType = "application/pdf",
        base64Data,
        messageText,
      } = req.body || {};

      if (!base64Data || typeof base64Data !== "string") {
        res.status(400).json({
          success: false,
          error: {
            code: "MISSING_BASE64",
            message: "حقل base64Data مطلوب لمعالجة الوثيقة",
          },
          requestId: req.id,
        });
        return;
      }

      const cleanedBase64 = base64Data
        .replace(/^data:[^;]+;base64,/, "")
        .trim();
      const mediaBuffer = Buffer.from(cleanedBase64, "base64");
      const msgId = String(
        providerMessageId ||
          `wa_api_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
      );

      const result = await processIncomingWhatsAppMediaMessage({
        tenantId,
        providerMessageId: msgId,
        senderPhone: String(senderPhone),
        senderName: String(senderName),
        fileName: String(fileName),
        declaredMimeType: String(mimeType),
        messageText: messageText ? String(messageText) : undefined,
        mediaBuffer,
        sendWhatsAppReplyFn: async () => ({ sentId: `silent-${Date.now()}` }),
      });

      if (result.ok) {
        try {
          whatsAppService.recordIngestedDocumentChatMessage({
            msgId,
            senderPhone: String(senderPhone),
            senderName: String(senderName),
            fileName: String(fileName),
            mimeType: String(mimeType),
            mediaBuffer,
            replyText: undefined,
          });
        } catch (syncErr) {
          logger.warn(
            { err: syncErr },
            "Notice syncing ingested document to WhatsApp chat list"
          );
        }
      }

      res.status(result.ok ? 200 : 422).json({
        success: result.ok,
        data: result,
      });
    } catch (err) {
      next(err);
    }
  }
);

// GET /jobs - List WhatsApp document processing jobs and state transitions
evolutionRouter.get(
  "/jobs",
  requireAuth,
  requirePermission("whatsapp:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const jobs = await db
        .select()
        .from(whatsappProcessingJobs)
        .where(eq(whatsappProcessingJobs.tenantId, tenantId))
        .orderBy(desc(whatsappProcessingJobs.id))
        .limit(100);
      res.json({ success: true, data: jobs });
    } catch (err) {
      next(err);
    }
  }
);

// POST /jobs/:jobId/retry - Retry a failed or pending WhatsApp document job
evolutionRouter.post(
  "/jobs/:jobId/retry",
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { jobId } = req.params;
      const [job] = await db
        .select()
        .from(whatsappProcessingJobs)
        .where(
          and(
            eq(whatsappProcessingJobs.tenantId, tenantId),
            eq(whatsappProcessingJobs.jobId, jobId)
          )
        )
        .limit(1);

      if (!job) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "المهمة غير موجودة" },
          requestId: req.id,
        });
        return;
      }

      const stored = readStoredDocumentBuffer(job.storageObjectKey, null);
      if (!stored) {
        res.status(422).json({
          success: false,
          error: {
            code: "MISSING_SOURCE_FILE",
            message: "الملف الأصلي غير متاح لإعادة المعالجة",
          },
          requestId: req.id,
        });
        return;
      }

      await db
        .update(whatsappProcessingJobs)
        .set({ state: "RETRY_PENDING", lockedByWorker: null, lockedAt: null })
        .where(eq(whatsappProcessingJobs.id, job.id));

      const result = await processIncomingWhatsAppMediaMessage({
        tenantId,
        providerMessageId: job.providerMessageId,
        senderPhone: job.senderPhone,
        senderName: job.senderName || undefined,
        fileName: job.originalFileName || "document.pdf",
        declaredMimeType: job.mimeType || stored.mimeType,
        mediaBuffer: stored.buffer,
      });

      res.json({ success: result.ok, data: result });
    } catch (err) {
      next(err);
    }
  }
);

// POST /jobs/recover - Recover interrupted stale jobs
evolutionRouter.post(
  "/jobs/recover",
  requireAuth,
  requirePermission("whatsapp:manage"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const summary = await recoverInterruptedWhatsAppJobs(tenantId);
      res.json({ success: true, data: summary });
    } catch (err) {
      next(err);
    }
  }
);

// GET /outbox - List WhatsApp reply outbox records
evolutionRouter.get(
  "/outbox",
  requireAuth,
  requirePermission("whatsapp:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const items = await db
        .select()
        .from(whatsappOutbox)
        .where(eq(whatsappOutbox.tenantId, tenantId))
        .orderBy(desc(whatsappOutbox.id))
        .limit(100);
      res.json({ success: true, data: items });
    } catch (err) {
      next(err);
    }
  }
);

export { evolutionRouter };
