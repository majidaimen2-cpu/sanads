import { Router } from "express";
import {
  requireAuth,
  requirePermission,
  requireRole,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { getAuditLogs, insertAuditLog } from "../../db/users.js";
import { BackupService } from "../services/backupService.js";
import { logger } from "../logger.js";

const systemRouter = Router();
const CANDIDATE_MODELS = [
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
];

systemRouter.get(
  "/",
  requireAuth,
  requirePermission("system:manage"),
  (_req, res) => {
    const geminiKey = process.env.GEMINI_API_KEY?.trim();
    const hasGemini = Boolean(geminiKey && geminiKey !== "YOUR_GEMINI_API_KEY");
    res.json({
      success: true,
      status: "ok",
      hasApiKey: hasGemini,
      aiProvider: hasGemini ? "Google Gemini" : "Deterministic Fallback",
      hasCloudSql: Boolean(process.env.SQL_HOST || process.env.DATABASE_URL),
      primaryModel: process.env.GEMINI_MODEL || "gemini-2.5-flash",
      supportedModels: CANDIDATE_MODELS,
      engine: "PostgreSQL 16",
      timestamp: new Date().toISOString(),
    });
  }
);

systemRouter.get(
  "/health",
  requireAuth,
  requirePermission("system:manage"),
  (_req, res) => {
    const geminiKey = process.env.GEMINI_API_KEY?.trim();
    const hasGemini = Boolean(geminiKey && geminiKey !== "YOUR_GEMINI_API_KEY");
    res.json({
      success: true,
      status: "ok",
      hasApiKey: hasGemini,
      aiProvider: hasGemini ? "Google Gemini" : "Deterministic Fallback",
      hasCloudSql: Boolean(process.env.SQL_HOST || process.env.DATABASE_URL),
      primaryModel: process.env.GEMINI_MODEL || "gemini-2.5-flash",
      supportedModels: CANDIDATE_MODELS,
      timestamp: new Date().toISOString(),
    });
  }
);

systemRouter.get(
  "/cloudsql-status",
  requireAuth,
  requirePermission("system:manage"),
  (_req, res) => {
    res.json({
      success: true,
      status: Boolean(process.env.SQL_HOST || process.env.DATABASE_URL)
        ? "configured"
        : "unconfigured",
      engine: "PostgreSQL 16",
    });
  }
);

systemRouter.get(
  "/audit-logs",
  requireAuth,
  requirePermission("audit_logs:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const logs = await getAuditLogs(tenantId, 100);
      res.json({ success: true, logs });
    } catch (err) {
      next(err);
    }
  }
);

systemRouter.get(
  "/backup-health",
  requireAuth,
  requireRole("SUPER_ADMIN", "MANAGER"),
  async (_req, res, next) => {
    try {
      const health = await BackupService.getBackupHealthSummary();
      res.json({ success: true, health });
    } catch (err) {
      next(err);
    }
  }
);

systemRouter.post(
  "/backup",
  requireAuth,
  requireRole("SUPER_ADMIN"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const actorName = req.user?.username || "Admin";
      const triggerType = req.body?.triggerType || "MANUAL";
      const result = await BackupService.createBackupSnapshot(actorName, {
        triggerType,
      });
      await insertAuditLog({
        tenantId,
        actorId: String(req.user?.userId || "admin"),
        actorName,
        action: "DATABASE_BACKUP_CREATED",
        resource: "system",
        resourceId: result.manifest.backupId,
        details: JSON.stringify({
          records: result.manifest.totalRecords,
          durationMs: result.manifest.durationMs,
          encrypted: result.manifest.encryption.enabled,
          cloudLocation: result.manifest.cloudObjectUri,
        }),
      });
      res.status(201).json({ success: true, ...result });
    } catch (err) {
      logger.error({ err }, "Backup creation failed");
      next(err);
    }
  }
);

systemRouter.get(
  "/backups",
  requireAuth,
  requireRole("SUPER_ADMIN", "MANAGER"),
  async (_req, res, next) => {
    try {
      const backups = BackupService.listBackups();
      const health = await BackupService.getBackupHealthSummary();
      res.json({
        success: true,
        backups,
        count: backups.length,
        history: health.recentBackups,
        environment: health.environment,
      });
    } catch (err) {
      next(err);
    }
  }
);

systemRouter.post(
  "/verify-backup",
  requireAuth,
  requireRole("SUPER_ADMIN"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { backupFilePath, backupId } = req.body || {};
      const target = backupFilePath || backupId;
      let resolved = target;
      if (!resolved) {
        const list = BackupService.listBackups();
        if (list.length === 0) {
          res.status(404).json({
            success: false,
            error: {
              code: "NO_BACKUPS_FOUND",
              message: "No backup snapshots found to verify",
            },
            requestId: req.id,
          });
          return;
        }
        resolved = list[0].backupId;
      }
      const verification = BackupService.verifyAndValidateBackup(resolved);
      await insertAuditLog({
        tenantId,
        actorId: String(req.user?.userId || "admin"),
        actorName: req.user?.username || "Admin",
        action: "DATABASE_BACKUP_VERIFIED",
        resource: "system",
        resourceId: String(resolved),
        details: JSON.stringify({
          valid: verification.valid,
          checksumMatches: verification.checksumMatches,
          encryptionVerified: verification.encryptionVerified,
          totalRecords: verification.totalRecords,
        }),
      });
      res.json({ success: verification.valid, verification });
    } catch (err) {
      next(err);
    }
  }
);

systemRouter.post(
  "/restore-test",
  requireAuth,
  requireRole("SUPER_ADMIN"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { backupFilePath, backupId } = req.body || {};
      let target = backupFilePath || backupId;
      if (!target) {
        const list = BackupService.listBackups();
        if (list.length === 0) {
          const snap = await BackupService.createBackupSnapshot(
            req.user?.username || "Admin",
            {
              triggerType: "MANUAL",
            }
          );
          target = snap.manifest.backupId;
        } else {
          target = list[0].backupId;
        }
      }
      const report = await BackupService.testIsolatedRestore(
        target,
        req.user?.username || "Admin"
      );
      await insertAuditLog({
        tenantId,
        actorId: String(req.user?.userId || "admin"),
        actorName: req.user?.username || "Admin",
        action: "ISOLATED_RESTORE_VERIFICATION",
        resource: "system",
        resourceId: report.backupId || "latest",
        details: JSON.stringify({
          success: report.success,
          isolatedSchema: report.isolatedSchemaName,
          tablesRestored: report.tablesRestored,
          recordsRestored: report.recordsRestored,
        }),
      });
      res.json({ success: report.success, report });
    } catch (err) {
      next(err);
    }
  }
);

systemRouter.post(
  "/sync-outbox",
  requireAuth,
  requireRole("SUPER_ADMIN"),
  async (_req, res, next) => {
    try {
      const syncResult = await BackupService.processPendingSyncJobs({
        forceImmediate: true,
      });
      res.json({ success: true, syncResult });
    } catch (err) {
      next(err);
    }
  }
);

export { systemRouter };
