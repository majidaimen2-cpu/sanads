import { Router } from "express";
import { z } from "zod";
import { eq, and, or, isNull, desc, asc, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { employees, companies } from "../../db/schema.js";
import {
  requireAuth,
  requirePermission,
  getRequiredTenantId,
} from "../middleware/rbac.js";
import { parsePaginationParams } from "../middleware/queryHelper.js";
import { verifyBranchOwnership } from "../middleware/tenantOwnership.js";

const employeeRouter = Router();

const EmployeeInputSchema = z.object({
  branchId: z.preprocess((val) => {
    if (val === undefined || val === null || val === "") return null;
    const n = Number(val);
    return isNaN(n) ? null : Math.floor(n);
  }, z.number().int().optional().nullable()),
  companyId: z.preprocess((val) => {
    if (val === undefined || val === null || val === "") return null;
    if (typeof val === "number") return Math.floor(val);
    if (typeof val === "string") {
      const cleaned = val.replace(/\D/g, "");
      const n = parseInt(cleaned || val, 10);
      return isNaN(n) ? null : n;
    }
    return null;
  }, z.number().int().optional().nullable()),
  companyName: z.string().optional().nullable(),
  employeeName: z.string().min(2, "اسم الموظف مطلوب").optional(),
  name: z.string().min(2, "اسم الموظف مطلوب").optional(),
  civilId: z.string().optional().nullable(),
  nationalId: z.string().optional().nullable(),
  laborCardNo: z.string().optional().nullable(),
  licenseNumber: z.string().optional().nullable(),
  licenseExpiryDate: z.string().optional().nullable(),
  licenseFileUrl: z.string().optional().nullable(),
  licenseFileName: z.string().optional().nullable(),
  residenceExpiry: z.string().optional().nullable(),
  passportExpiry: z.string().optional().nullable(),
  passportNo: z.string().optional().nullable(),
  nationality: z.string().default("عُماني"),
  jobTitle: z.string().optional().nullable(),
  role: z.string().optional().nullable(),
  salaryBaisa: z
    .preprocess((val) => {
      if (val === undefined || val === null || val === "") return undefined;
      const n = Number(val);
      return isNaN(n) ? 0 : Math.floor(n);
    }, z.number().int())
    .optional(),
  salary: z
    .preprocess((val) => {
      if (val === undefined || val === null || val === "") return undefined;
      const n = Number(val);
      return isNaN(n) ? 0 : n;
    }, z.number())
    .optional(),
  active: z.boolean().default(true),
});

function normalizeEmployeeInput(raw: unknown) {
  const parsed = EmployeeInputSchema.parse(raw);
  const employeeName = (parsed.employeeName || parsed.name || "").trim();
  if (!employeeName) {
    throw new z.ZodError([
      {
        code: z.ZodIssueCode.custom,
        path: ["employeeName"],
        message: "اسم الموظف مطلوب",
      },
    ]);
  }
  const jobTitle = (parsed.jobTitle || parsed.role || "موظف").trim();
  const civilId = (parsed.civilId || parsed.nationalId || "").trim() || null;
  const laborCardNo =
    (parsed.laborCardNo || parsed.licenseNumber || "").trim() || null;
  const licenseNumber =
    (parsed.licenseNumber || parsed.laborCardNo || "").trim() || null;
  const licenseExpiryDate =
    (parsed.licenseExpiryDate || parsed.residenceExpiry || "").trim() || null;

  let salaryBaisa = 0;
  if (parsed.salaryBaisa !== undefined) {
    salaryBaisa = parsed.salaryBaisa;
  } else if (parsed.salary !== undefined) {
    salaryBaisa = Math.round(Number(parsed.salary) * 1000);
  }

  return {
    branchId: parsed.branchId || null,
    companyId: parsed.companyId || null,
    companyName: parsed.companyName || null,
    employeeName,
    civilId,
    laborCardNo,
    licenseNumber,
    licenseExpiryDate,
    licenseFileUrl: parsed.licenseFileUrl || null,
    licenseFileName: parsed.licenseFileName || null,
    residenceExpiry: parsed.residenceExpiry || null,
    passportExpiry: parsed.passportExpiry || null,
    passportNo: parsed.passportNo || null,
    nationality: parsed.nationality || "عُماني",
    jobTitle,
    salaryBaisa,
    active: parsed.active ?? true,
  };
}

employeeRouter.get(
  "/",
  requireAuth,
  requirePermission("employees:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const { page, limit, offset, search, includeDeleted, sortOrder } =
        parsePaginationParams(req);
      const rawCompId = req.query.companyId
        ? String(req.query.companyId).replace(/\D/g, "")
        : undefined;
      const companyId = rawCompId ? parseInt(rawCompId, 10) : undefined;

      const conditions = [eq(employees.tenantId, tenantId)];
      if (!includeDeleted) {
        conditions.push(isNull(employees.deletedAt));
      }
      if (companyId && !isNaN(companyId)) {
        conditions.push(eq(employees.companyId, companyId));
      }
      if (search) {
        const pattern = `%${search}%`;
        conditions.push(
          or(
            sql`${employees.employeeName} ILIKE ${pattern}`,
            sql`COALESCE(${employees.civilId}, '') ILIKE ${pattern}`,
            sql`COALESCE(${employees.laborCardNo}, '') ILIKE ${pattern}`,
            sql`COALESCE(${employees.licenseNumber}, '') ILIKE ${pattern}`
          )!
        );
      }

      const whereClause = and(...conditions);
      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(employees)
        .where(whereClause);

      const rows = await db
        .select({
          id: employees.id,
          tenantId: employees.tenantId,
          branchId: employees.branchId,
          companyId: employees.companyId,
          companyName: companies.name,
          employeeName: employees.employeeName,
          civilId: employees.civilId,
          laborCardNo: employees.laborCardNo,
          licenseNumber: employees.licenseNumber,
          licenseExpiryDate: employees.licenseExpiryDate,
          licenseFileUrl: employees.licenseFileUrl,
          licenseFileName: employees.licenseFileName,
          residenceExpiry: employees.residenceExpiry,
          passportExpiry: employees.passportExpiry,
          passportNo: employees.passportNo,
          nationality: employees.nationality,
          jobTitle: employees.jobTitle,
          salaryBaisa: employees.salaryBaisa,
          active: employees.active,
          createdAt: employees.createdAt,
          updatedAt: employees.updatedAt,
          deletedAt: employees.deletedAt,
          createdBy: employees.createdBy,
        })
        .from(employees)
        .leftJoin(
          companies,
          and(
            eq(employees.companyId, companies.id),
            eq(companies.tenantId, tenantId)
          )
        )
        .where(whereClause)
        .orderBy(sortOrder === "desc" ? desc(employees.id) : asc(employees.id))
        .limit(limit)
        .offset(offset);

      const data = rows.map((e) => {
        let docs: unknown[] = [];
        if (e.licenseFileUrl && e.licenseFileUrl.startsWith("[")) {
          try {
            docs = JSON.parse(e.licenseFileUrl) as unknown[];
          } catch {
            docs = [];
          }
        } else if (e.licenseFileUrl || e.licenseNumber || e.licenseExpiryDate) {
          docs = [
            {
              id: `doc-emp-${e.id}`,
              employeeId: String(e.id),
              companyId: e.companyId ? String(e.companyId) : "",
              title: e.licenseFileName
                ? e.licenseFileName.replace(/\.[^/.]+$/, "")
                : "ترخيص / بطاقة عمل الموظف",
              type: "labor_card",
              documentNumber: e.licenseNumber || "",
              issueDate: e.createdAt
                ? new Date(e.createdAt).toISOString().split("T")[0]
                : new Date().toISOString().split("T")[0],
              expiryDate: e.licenseExpiryDate || "",
              status:
                e.licenseExpiryDate &&
                new Date(e.licenseExpiryDate) < new Date()
                  ? "expired"
                  : "valid",
              fileName: e.licenseFileName || "license.pdf",
              fileUrl: e.licenseFileUrl || undefined,
              uploadedAt: e.updatedAt
                ? new Date(e.updatedAt).toISOString().split("T")[0]
                : new Date().toISOString().split("T")[0],
            },
          ];
        }
        return {
          ...e,
          name: e.employeeName,
          role: e.jobTitle || "موظف",
          nationalId: e.civilId || e.laborCardNo || "",
          salary: e.salaryBaisa ? e.salaryBaisa / 1000 : 0,
          documents: docs,
        };
      });

      res.json({
        success: true,
        data,
        employees: data,
        pagination: {
          total: count,
          page,
          limit,
          totalPages: Math.ceil(count / limit) || 1,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

employeeRouter.post(
  "/",
  requireAuth,
  requirePermission("employees:create"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const normalized = normalizeEmployeeInput(req.body);
      await verifyBranchOwnership(tenantId, normalized.branchId);

      let finalCompanyId = normalized.companyId;
      let finalCompanyName = normalized.companyName;

      if (finalCompanyId) {
        const [comp] = await db
          .select({ id: companies.id, name: companies.name })
          .from(companies)
          .where(
            and(
              eq(companies.tenantId, tenantId),
              eq(companies.id, finalCompanyId),
              isNull(companies.deletedAt)
            )
          )
          .limit(1);

        if (comp) {
          finalCompanyName = comp.name;
        } else {
          finalCompanyId = null;
        }
      }

      if (!finalCompanyId && normalized.companyName) {
        const [comp] = await db
          .select({ id: companies.id, name: companies.name })
          .from(companies)
          .where(
            and(
              eq(companies.tenantId, tenantId),
              eq(companies.name, normalized.companyName.trim()),
              isNull(companies.deletedAt)
            )
          )
          .limit(1);

        if (comp) {
          finalCompanyId = comp.id;
          finalCompanyName = comp.name;
        }
      }

      const docsArray = Array.isArray(req.body?.documents)
        ? (req.body.documents as Array<Record<string, string>>)
        : null;
      const firstDoc = docsArray && docsArray.length > 0 ? docsArray[0] : null;

      const [newEmp] = await db
        .insert(employees)
        .values({
          tenantId,
          branchId: normalized.branchId,
          companyId: finalCompanyId,
          employeeName: normalized.employeeName,
          civilId: normalized.civilId,
          laborCardNo: normalized.laborCardNo,
          licenseNumber:
            normalized.licenseNumber || firstDoc?.documentNumber || null,
          licenseExpiryDate:
            normalized.licenseExpiryDate || firstDoc?.expiryDate || null,
          licenseFileUrl: docsArray
            ? JSON.stringify(docsArray)
            : normalized.licenseFileUrl,
          licenseFileName:
            normalized.licenseFileName || firstDoc?.fileName || null,
          residenceExpiry: normalized.residenceExpiry,
          passportExpiry: normalized.passportExpiry,
          passportNo: normalized.passportNo,
          nationality: normalized.nationality,
          jobTitle: normalized.jobTitle,
          salaryBaisa: normalized.salaryBaisa,
          active: normalized.active,
          createdBy: req.user?.userId
            ? String(req.user.userId)
            : req.user?.username,
        })
        .returning();

      const responseData = {
        ...newEmp,
        companyName: finalCompanyName || "منشأة عامة",
        name: newEmp.employeeName,
        role: newEmp.jobTitle || "موظف",
        nationalId: newEmp.civilId || newEmp.laborCardNo || "",
        salary: newEmp.salaryBaisa ? newEmp.salaryBaisa / 1000 : 0,
        documents: docsArray || [],
      };

      res
        .status(201)
        .json({ success: true, data: responseData, employee: responseData });
    } catch (err) {
      next(err);
    }
  }
);

employeeRouter.get(
  "/:id",
  requireAuth,
  requirePermission("employees:read"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }

      const [emp] = await db
        .select({
          id: employees.id,
          tenantId: employees.tenantId,
          branchId: employees.branchId,
          companyId: employees.companyId,
          companyName: companies.name,
          employeeName: employees.employeeName,
          civilId: employees.civilId,
          laborCardNo: employees.laborCardNo,
          licenseNumber: employees.licenseNumber,
          licenseExpiryDate: employees.licenseExpiryDate,
          licenseFileUrl: employees.licenseFileUrl,
          licenseFileName: employees.licenseFileName,
          residenceExpiry: employees.residenceExpiry,
          passportExpiry: employees.passportExpiry,
          passportNo: employees.passportNo,
          nationality: employees.nationality,
          jobTitle: employees.jobTitle,
          salaryBaisa: employees.salaryBaisa,
          active: employees.active,
          createdAt: employees.createdAt,
          updatedAt: employees.updatedAt,
          deletedAt: employees.deletedAt,
          createdBy: employees.createdBy,
        })
        .from(employees)
        .leftJoin(
          companies,
          and(
            eq(employees.companyId, companies.id),
            eq(companies.tenantId, tenantId)
          )
        )
        .where(and(eq(employees.id, id), eq(employees.tenantId, tenantId)))
        .limit(1);

      if (!emp) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "الموظف غير موجود" },
          requestId: req.id,
        });
        return;
      }

      let docs: unknown[] = [];
      if (emp.licenseFileUrl && emp.licenseFileUrl.startsWith("[")) {
        try {
          docs = JSON.parse(emp.licenseFileUrl) as unknown[];
        } catch {
          docs = [];
        }
      } else if (
        emp.licenseFileUrl ||
        emp.licenseNumber ||
        emp.licenseExpiryDate
      ) {
        docs = [
          {
            id: `doc-emp-${emp.id}`,
            employeeId: String(emp.id),
            companyId: emp.companyId ? String(emp.companyId) : "",
            title: emp.licenseFileName
              ? emp.licenseFileName.replace(/\.[^/.]+$/, "")
              : "ترخيص / بطاقة عمل الموظف",
            type: "labor_card",
            documentNumber: emp.licenseNumber || "",
            issueDate: emp.createdAt
              ? new Date(emp.createdAt).toISOString().split("T")[0]
              : new Date().toISOString().split("T")[0],
            expiryDate: emp.licenseExpiryDate || "",
            status:
              emp.licenseExpiryDate &&
              new Date(emp.licenseExpiryDate) < new Date()
                ? "expired"
                : "valid",
            fileName: emp.licenseFileName || "license.pdf",
            fileUrl: emp.licenseFileUrl || undefined,
            uploadedAt: emp.updatedAt
              ? new Date(emp.updatedAt).toISOString().split("T")[0]
              : new Date().toISOString().split("T")[0],
          },
        ];
      }

      const responseData = {
        ...emp,
        name: emp.employeeName,
        role: emp.jobTitle || "موظف",
        nationalId: emp.civilId || emp.laborCardNo || "",
        salary: emp.salaryBaisa ? emp.salaryBaisa / 1000 : 0,
        documents: docs,
      };

      res.json({ success: true, data: responseData, employee: responseData });
    } catch (err) {
      next(err);
    }
  }
);

employeeRouter.put(
  "/:id",
  requireAuth,
  requirePermission("employees:update"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }

      if (!req.body || Object.keys(req.body).length === 0) {
        res.status(422).json({
          success: false,
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
          requestId: req.id,
        });
        return;
      }

      const updateData: Record<string, unknown> = {};
      if (req.body.employeeName || req.body.name) {
        updateData.employeeName = String(
          req.body.employeeName || req.body.name
        ).trim();
      }
      if (req.body.jobTitle || req.body.role) {
        updateData.jobTitle = String(req.body.jobTitle || req.body.role).trim();
      }
      if (req.body.civilId || req.body.nationalId) {
        updateData.civilId = String(
          req.body.civilId || req.body.nationalId
        ).trim();
      }
      if (req.body.laborCardNo !== undefined)
        updateData.laborCardNo = req.body.laborCardNo;
      if (req.body.licenseNumber !== undefined)
        updateData.licenseNumber = req.body.licenseNumber;
      if (req.body.licenseExpiryDate !== undefined)
        updateData.licenseExpiryDate = req.body.licenseExpiryDate;
      if (req.body.licenseFileUrl !== undefined)
        updateData.licenseFileUrl = req.body.licenseFileUrl;
      if (req.body.licenseFileName !== undefined)
        updateData.licenseFileName = req.body.licenseFileName;
      if (Array.isArray(req.body.documents)) {
        updateData.licenseFileUrl = JSON.stringify(req.body.documents);
        const firstDoc = req.body.documents[0] as
          | Record<string, string>
          | undefined;
        if (firstDoc) {
          if (firstDoc.documentNumber)
            updateData.licenseNumber = firstDoc.documentNumber;
          if (firstDoc.expiryDate)
            updateData.licenseExpiryDate = firstDoc.expiryDate;
          if (firstDoc.fileName) updateData.licenseFileName = firstDoc.fileName;
        }
      }
      if (req.body.residenceExpiry !== undefined)
        updateData.residenceExpiry = req.body.residenceExpiry;
      if (req.body.passportExpiry !== undefined)
        updateData.passportExpiry = req.body.passportExpiry;
      if (req.body.passportNo !== undefined)
        updateData.passportNo = req.body.passportNo;
      if (req.body.nationality !== undefined)
        updateData.nationality = req.body.nationality;
      if (req.body.active !== undefined)
        updateData.active = Boolean(req.body.active);
      if (req.body.salaryBaisa !== undefined) {
        updateData.salaryBaisa = Number(req.body.salaryBaisa) || 0;
      } else if (req.body.salary !== undefined) {
        updateData.salaryBaisa = Math.round(Number(req.body.salary) * 1000);
      }

      if (req.body.companyId !== undefined) {
        if (req.body.companyId === null || req.body.companyId === "") {
          updateData.companyId = null;
        } else {
          const parsedCompId = parseInt(
            String(req.body.companyId).replace(/\D/g, "") ||
              String(req.body.companyId),
            10
          );
          if (!isNaN(parsedCompId)) {
            const [comp] = await db
              .select({ id: companies.id })
              .from(companies)
              .where(
                and(
                  eq(companies.tenantId, tenantId),
                  eq(companies.id, parsedCompId)
                )
              )
              .limit(1);
            updateData.companyId = comp ? parsedCompId : null;
          } else {
            updateData.companyId = null;
          }
        }
      }

      if (Object.keys(updateData).length === 0) {
        res.status(422).json({
          success: false,
          error: {
            code: "VALIDATION_ERROR",
            message: "لا توجد حقول للتحديث في جسم الطلب",
          },
          requestId: req.id,
        });
        return;
      }

      updateData.updatedAt = new Date();
      const [updated] = await db
        .update(employees)
        .set(updateData)
        .where(and(eq(employees.id, id), eq(employees.tenantId, tenantId)))
        .returning();

      if (!updated) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "الموظف غير موجود" },
          requestId: req.id,
        });
        return;
      }

      let updatedDocs: unknown[] = [];
      if (updated.licenseFileUrl && updated.licenseFileUrl.startsWith("[")) {
        try {
          updatedDocs = JSON.parse(updated.licenseFileUrl) as unknown[];
        } catch {
          updatedDocs = [];
        }
      }

      const responseData = {
        ...updated,
        name: updated.employeeName,
        role: updated.jobTitle || "موظف",
        nationalId: updated.civilId || updated.laborCardNo || "",
        salary: updated.salaryBaisa ? updated.salaryBaisa / 1000 : 0,
        documents: updatedDocs,
      };

      res.json({ success: true, data: responseData, employee: responseData });
    } catch (err) {
      next(err);
    }
  }
);

employeeRouter.delete(
  "/:id",
  requireAuth,
  requirePermission("employees:delete"),
  async (req, res, next) => {
    try {
      const tenantId = getRequiredTenantId(req);
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        res.status(400).json({
          success: false,
          error: { code: "INVALID_ID", message: "معرف غير صالح" },
          requestId: req.id,
        });
        return;
      }

      const [deleted] = await db
        .update(employees)
        .set({ deletedAt: new Date() })
        .where(
          and(
            eq(employees.id, id),
            eq(employees.tenantId, tenantId),
            isNull(employees.deletedAt)
          )
        )
        .returning();

      if (!deleted) {
        res.status(404).json({
          success: false,
          error: { code: "NOT_FOUND", message: "الموظف غير موجود" },
          requestId: req.id,
        });
        return;
      }

      res.json({ success: true, message: "تم حذف الموظف بنجاح" });
    } catch (err) {
      next(err);
    }
  }
);

export { employeeRouter };
