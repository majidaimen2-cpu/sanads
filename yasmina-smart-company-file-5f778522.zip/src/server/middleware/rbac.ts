import type { Request, Response, NextFunction } from "express";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { users } from "../../db/schema.js";
import { verifyAccessToken } from "../auth.js";
import { hasPermission } from "../permissions.js";

export function getRequiredTenantId(req: Request): string {
  const tenantId = req.user?.tenantId?.trim();
  if (!tenantId) {
    const err = new Error("Missing tenant context in authenticated session") as Error & {
      status?: number;
      code?: string;
    };
    err.status = 401;
    err.code = "MISSING_TENANT_CONTEXT";
    throw err;
  }
  return tenantId;
}

export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    let token: string | undefined;
    let isCookieAuth = false;

    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const rawToken = authHeader.substring(7).trim();
      if (rawToken && rawToken !== "null" && rawToken !== "undefined") {
        token = rawToken;
      }
    } else if (
      req.cookies &&
      (req.cookies.accessToken || req.cookies.yasmina_auth_token_v1 || req.cookies.token)
    ) {
      token = String(
        req.cookies.accessToken || req.cookies.yasmina_auth_token_v1 || req.cookies.token
      );
      isCookieAuth = true;
    }

    if (!token) {
      res.status(401).json({
        success: false,
        error: {
          code: "UNAUTHORIZED",
          message: "Unauthorized: Authentication required",
        },
        requestId: req.id,
      });
      return;
    }

    // CSRF Origin check for state-changing requests authenticated via cookies (#22)
    if (
      isCookieAuth &&
      req.method !== "GET" &&
      req.method !== "HEAD" &&
      req.method !== "OPTIONS"
    ) {
      const originHeader = req.headers.origin;
      if (originHeader) {
        const allowedOrigins = (process.env.CORS_ORIGINS || "http://localhost:3000")
          .split(",")
          .map((o) => o.trim())
          .filter(Boolean);
        const hostOrigin = `${req.protocol}://${req.get("host") || ""}`;
        if (!allowedOrigins.includes(originHeader) && originHeader !== hostOrigin) {
          res.status(403).json({
            success: false,
            error: {
              code: "CSRF_ORIGIN_MISMATCH",
              message: "Forbidden: Cross-origin cookie request blocked",
            },
            requestId: req.id,
          });
          return;
        }
      }
    }

    const payload = await verifyAccessToken(token);
    if (!payload || !payload.tenantId) {
      res.status(401).json({
        success: false,
        error: {
          code: "INVALID_TOKEN",
          message: "Unauthorized: Invalid or expired access token",
        },
        requestId: req.id,
      });
      return;
    }

    // Verify user is still active and tokenVersion matches DB
    const [dbUser] = await db
      .select({
        id: users.id,
        active: users.active,
        tokenVersion: users.tokenVersion,
        role: users.role,
        tenantId: users.tenantId,
        uid: users.uid,
      })
      .from(users)
      .where(eq(users.id, payload.userId))
      .limit(1);

    if (dbUser) {
      if (!dbUser.active || dbUser.tokenVersion !== payload.tokenVersion) {
        res.status(401).json({
          success: false,
          error: {
            code: "SESSION_REVOKED",
            message: "Unauthorized: Session has been revoked or user deactivated",
          },
          requestId: req.id,
        });
        return;
      }
      req.user = {
        userId: dbUser.id,
        username: dbUser.uid,
        role: dbUser.role,
        tenantId: dbUser.tenantId,
        tokenVersion: dbUser.tokenVersion,
        typ: "access",
      };
    } else {
      // Fail closed: a validly signed token for a user that no longer exists must not authenticate.
      res.status(401).json({
        success: false,
        error: {
          code: "SESSION_REVOKED",
          message: "Unauthorized: User account no longer exists",
        },
        requestId: req.id,
      });
      return;
    }

    next();
  } catch (err) {
    next(err);
  }
}

export function requireRole(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({
        success: false,
        error: {
          code: "UNAUTHORIZED",
          message: "Unauthorized: Authentication required",
        },
        requestId: req.id,
      });
      return;
    }
    if (allowedRoles.includes("SUPER_ADMIN") && req.user.role === "SUPER_ADMIN") {
      next();
      return;
    }
    if (!allowedRoles.includes(req.user.role)) {
      res.status(403).json({
        success: false,
        error: {
          code: "FORBIDDEN",
          message: `Forbidden: Role '${req.user.role}' does not have access to this resource`,
        },
        requestId: req.id,
      });
      return;
    }
    next();
  };
}

export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({
        success: false,
        error: {
          code: "UNAUTHORIZED",
          message: "Unauthorized: Authentication required",
        },
        requestId: req.id,
      });
      return;
    }
    if (!hasPermission(req.user.role, permission)) {
      res.status(403).json({
        success: false,
        error: {
          code: "FORBIDDEN",
          message: `Forbidden: Missing required permission '${permission}'`,
        },
        requestId: req.id,
      });
      return;
    }
    next();
  };
}
