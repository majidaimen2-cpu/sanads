import { eq, and, isNull } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  branches,
  companies,
  customers,
  employees,
  services,
  transactions,
  invoices,
  cashSessions,
  users,
} from "../../db/schema.js";

function createInvalidReferenceError(field: string, id: number | string): Error {
  const err = new Error(`Referenced ${field} (${id}) does not exist in this tenant`) as Error & {
    status?: number;
    code?: string;
  };
  err.status = 422;
  err.code = "INVALID_TENANT_REFERENCE";
  return err;
}

export async function verifyBranchOwnership(
  tenantId: string,
  branchId?: number | null
): Promise<void> {
  if (!branchId) return;
  const [row] = await db
    .select({ id: branches.id })
    .from(branches)
    .where(
      and(eq(branches.id, branchId), eq(branches.tenantId, tenantId), isNull(branches.deletedAt))
    )
    .limit(1);
  if (!row) throw createInvalidReferenceError("branchId", branchId);
}

export async function verifyCompanyOwnership(
  tenantId: string,
  companyId?: number | null
): Promise<void> {
  if (!companyId) return;
  const [row] = await db
    .select({ id: companies.id })
    .from(companies)
    .where(
      and(eq(companies.id, companyId), eq(companies.tenantId, tenantId), isNull(companies.deletedAt))
    )
    .limit(1);
  if (!row) throw createInvalidReferenceError("companyId", companyId);
}

export async function verifyCustomerOwnership(
  tenantId: string,
  customerId?: number | null
): Promise<void> {
  if (!customerId) return;
  const [row] = await db
    .select({ id: customers.id })
    .from(customers)
    .where(
      and(eq(customers.id, customerId), eq(customers.tenantId, tenantId), isNull(customers.deletedAt))
    )
    .limit(1);
  if (!row) throw createInvalidReferenceError("customerId", customerId);
}

export async function verifyEmployeeOwnership(
  tenantId: string,
  employeeId?: number | null
): Promise<void> {
  if (!employeeId) return;
  const [row] = await db
    .select({ id: employees.id })
    .from(employees)
    .where(
      and(eq(employees.id, employeeId), eq(employees.tenantId, tenantId), isNull(employees.deletedAt))
    )
    .limit(1);
  if (!row) throw createInvalidReferenceError("employeeId", employeeId);
}

export async function verifyServiceOwnership(
  tenantId: string,
  serviceId?: number | null
): Promise<void> {
  if (!serviceId) return;
  const [row] = await db
    .select({ id: services.id })
    .from(services)
    .where(
      and(eq(services.id, serviceId), eq(services.tenantId, tenantId), isNull(services.deletedAt))
    )
    .limit(1);
  if (!row) throw createInvalidReferenceError("serviceId", serviceId);
}

export async function verifyTransactionOwnership(
  tenantId: string,
  transactionId?: number | null
): Promise<void> {
  if (!transactionId) return;
  const [row] = await db
    .select({ id: transactions.id })
    .from(transactions)
    .where(
      and(
        eq(transactions.id, transactionId),
        eq(transactions.tenantId, tenantId),
        isNull(transactions.deletedAt)
      )
    )
    .limit(1);
  if (!row) throw createInvalidReferenceError("transactionId", transactionId);
}

export async function verifyInvoiceOwnership(
  tenantId: string,
  invoiceId?: number | null
): Promise<void> {
  if (!invoiceId) return;
  const [row] = await db
    .select({ id: invoices.id })
    .from(invoices)
    .where(
      and(eq(invoices.id, invoiceId), eq(invoices.tenantId, tenantId), isNull(invoices.deletedAt))
    )
    .limit(1);
  if (!row) throw createInvalidReferenceError("invoiceId", invoiceId);
}

export async function verifyCashSessionOwnership(
  tenantId: string,
  cashSessionId?: number | null
): Promise<void> {
  if (!cashSessionId) return;
  const [row] = await db
    .select({ id: cashSessions.id })
    .from(cashSessions)
    .where(and(eq(cashSessions.id, cashSessionId), eq(cashSessions.tenantId, tenantId)))
    .limit(1);
  if (!row) throw createInvalidReferenceError("cashSessionId", cashSessionId);
}

export async function verifyUserOwnership(
  tenantId: string,
  userId?: number | null
): Promise<void> {
  if (!userId) return;
  const [row] = await db
    .select({ id: users.id })
    .from(users)
    .where(and(eq(users.id, userId), eq(users.tenantId, tenantId), isNull(users.deletedAt)))
    .limit(1);
  if (!row) throw createInvalidReferenceError("userId", userId);
}
