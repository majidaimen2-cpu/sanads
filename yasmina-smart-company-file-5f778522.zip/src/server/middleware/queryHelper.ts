import type { Request } from "express";
import { normalizeArabicText } from "../../lib/arabicNormalizer.js";

export function parsePaginationParams(req: Request) {
  const query = req.query || {};
  let page = parseInt(String(query.page || "1"), 10);
  if (isNaN(page) || page < 1) page = 1;
  let limit = parseInt(String(query.limit || "500"), 10);
  if (isNaN(limit) || limit < 1) limit = 500;
  if (limit > 1000) limit = 1000;
  const offset = (page - 1) * limit;
  const search =
    typeof query.search === "string" ? query.search.trim() : undefined;
  const normalizedSearch = search ? normalizeArabicText(search) : undefined;
  const sortBy =
    typeof query.sortBy === "string" ? query.sortBy.trim() : undefined;
  const sortOrder: "asc" | "desc" = query.sortOrder === "asc" ? "asc" : "desc";
  let includeDeleted = false;
  if (query.include_deleted === "true" || query.includeDeleted === "true") {
    if (req.user?.role === "SUPER_ADMIN" || req.user?.role === "MANAGER") {
      includeDeleted = true;
    }
  }
  return {
    page,
    limit,
    offset,
    search,
    normalizedSearch,
    sortBy,
    sortOrder,
    includeDeleted,
  };
}
