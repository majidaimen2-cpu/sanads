import type { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";
import crypto from "crypto";
import { logger } from "../logger.js";

interface HttpErrorLike {
  code?: string;
  detail?: string;
  details?: Record<string, unknown>;
  type?: string;
  status?: number;
  statusCode?: number;
  message?: string;
  stack?: string;
  cause?: {
    code?: string;
    detail?: string;
  };
}

export function requestIdMiddleware(req: Request, res: Response, next: NextFunction): void {
  const headerId = req.headers["x-request-id"];
  const reqId = (Array.isArray(headerId) ? headerId[0] : headerId) || crypto.randomUUID();
  req.id = reqId;
  res.setHeader("X-Request-Id", reqId);
  next();
}

export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction): Response {
  const headerId = req.headers["x-request-id"];
  const requestId = req.id || (Array.isArray(headerId) ? headerId[0] : headerId) || crypto.randomUUID();
  const httpErr = (err && typeof err === "object" ? err : {}) as HttpErrorLike;
  const pgCode = httpErr.code || httpErr.cause?.code;

  logger.error(
    {
      err,
      requestId,
      method: req.method,
      path: req.originalUrl,
    },
    "Unhandled request error"
  );

  if (err instanceof ZodError) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of err.issues) {
      const path = issue.path.join(".") || "root";
      fieldErrors[path] = issue.message;
    }
    return res.status(422).json({
      success: false,
      error: {
        code: "VALIDATION_ERROR",
        message: "بيانات الإدخال غير صالحة (Validation failed)",
        details: fieldErrors,
      },
      requestId,
    });
  }

  if (httpErr.type === "entity.too.large" || httpErr.status === 413) {
    return res.status(413).json({
      success: false,
      error: {
        code: "PAYLOAD_TOO_LARGE",
        message: "حجم الطلب يتجاوز الحد المسموح (Payload Too Large)",
      },
      requestId,
    });
  }

  if (pgCode === "23503") {
    return res.status(422).json({
      success: false,
      error: {
        code: "INVALID_REFERENCE",
        message: "العنصر المرجعي غير موجود في قاعدة البيانات (Invalid Reference)",
      },
      requestId,
    });
  }

  if (pgCode === "23505") {
    return res.status(409).json({
      success: false,
      error: {
        code: "DUPLICATE",
        message: "السجل موجود مسبقاً في قاعدة البيانات (Duplicate Record)",
      },
      requestId,
    });
  }

  if (pgCode === "23514") {
    return res.status(422).json({
      success: false,
      error: {
        code: "CHECK_VIOLATION",
        message: "بيانات غير صالحة تخالف شروط قاعدة البيانات (Check Constraint Violation)",
      },
      requestId,
    });
  }

  const status =
    typeof httpErr.status === "number"
      ? httpErr.status
      : typeof httpErr.statusCode === "number"
        ? httpErr.statusCode
        : 500;

  const code =
    httpErr.code && typeof httpErr.code === "string" && !/^\d+$/.test(httpErr.code)
      ? httpErr.code
      : status === 404
        ? "NOT_FOUND"
        : status === 403
          ? "FORBIDDEN"
          : status === 401
            ? "UNAUTHORIZED"
            : status === 400
              ? "BAD_REQUEST"
              : "INTERNAL_SERVER_ERROR";

  // Never leak raw err.message on 500 Internal Server Errors (#53)
  const message =
    status < 500 && httpErr.message && !httpErr.message.includes("Failed query:")
      ? httpErr.message
      : "حدث خطأ في الخادم الداخلي";

  return res.status(status).json({
    success: false,
    error: {
      code,
      message,
      ...(status < 500 && httpErr.details ? { details: httpErr.details } : {}),
    },
    requestId,
  });
}
