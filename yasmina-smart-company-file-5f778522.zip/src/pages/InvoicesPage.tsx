import React, { useEffect, useState } from 'react';
import { FileText, Coins, Search, CheckCircle2, Clock, Plus, ExternalLink, Printer } from 'lucide-react';
import { YasminaApi } from '../lib/api';

export const InvoicesPage: React.FC = () => {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadInvoices();
  }, []);

  const loadInvoices = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/invoices', {
        headers: YasminaApi.getAuthHeaders(),
      }).catch(() => null);

      if (res && res.ok) {
        const body = await res.json();
        if (body.data && Array.isArray(body.data)) {
          setInvoices(body.data);
          return;
        }
      }

      // Sample fallback invoices
      setInvoices([
        {
          id: 1,
          invoiceNumber: 'INV-2026-000101',
          customerName: 'سالم بن عبد الله البوسعيدي',
          totalBaisa: 38000,
          status: 'PAID',
          issuedAt: '2026-10-24',
        },
        {
          id: 2,
          invoiceNumber: 'INV-2026-000102',
          customerName: 'مؤسسة النور الذهبي ش.م.م',
          totalBaisa: 62500,
          status: 'PAID',
          issuedAt: '2026-10-23',
        },
        {
          id: 3,
          invoiceNumber: 'INV-2026-000103',
          customerName: 'شركة واحة مسقط للتقنية',
          totalBaisa: 15750,
          status: 'UNPAID',
          issuedAt: '2026-10-22',
        },
      ]);
    } catch (err) {
      console.warn('Error loading invoices:', err);
    } finally {
      setLoading(false);
    }
  };

  const filtered = invoices.filter((inv) => {
    const s = searchQuery.toLowerCase().trim();
    return (
      !s ||
      inv.invoiceNumber?.toLowerCase().includes(s) ||
      inv.customerName?.toLowerCase().includes(s) ||
      inv.status?.toLowerCase().includes(s)
    );
  });

  return (
    <div className="space-y-6 pb-12" dir="rtl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-100">سجل الفواتير والدفع الإلكتروني (Invoices & Payments)</h1>
            <p className="text-xs text-slate-400 mt-0.5">
              فواتير ضريبة القيمة المضافة (VAT 5%)، أتعاب مكتب سند، وإيصالات التحصيل.
            </p>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="بحث برقم الفاتورة أو العميل..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase text-[11px]">
              <tr>
                <th className="p-4">رقم الفاتورة</th>
                <th className="p-4">العميل / المنشأة</th>
                <th className="p-4">المبلغ الإجمالي (ر.ع)</th>
                <th className="p-4">حالة السداد</th>
                <th className="p-4">تاريخ الإصدار</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {filtered.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-800/40 transition">
                  <td className="p-4 font-mono font-bold text-emerald-400">{inv.invoiceNumber}</td>
                  <td className="p-4 font-semibold text-slate-100">{inv.customerName || 'عميل مكتب سند'}</td>
                  <td className="p-4 font-bold text-amber-400">
                    {((inv.totalBaisa || 0) / 1000).toFixed(3)} ر.ع
                  </td>
                  <td className="p-4">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        inv.status === 'PAID'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {inv.status === 'PAID' ? 'تم السداد' : 'غير مسددة'}
                    </span>
                  </td>
                  <td className="p-4 text-slate-400">
                    {typeof inv.issuedAt === 'string' ? inv.issuedAt.slice(0, 10) : '2026-10-24'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
