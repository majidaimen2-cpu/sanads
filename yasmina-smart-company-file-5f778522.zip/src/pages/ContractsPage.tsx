import React, { useEffect, useState, useRef } from 'react';
import {
  FileText,
  Search,
  Plus,
  Building2,
  X,
  Download,
  UploadCloud,
  FileCheck2,
  Eye,
} from 'lucide-react';
import { Contract, Company } from '../types';
import { YasminaApi } from '../lib/api';

export const ContractsPage: React.FC = () => {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<{ url: string; name: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState<Partial<Contract> & { fileUrl?: string; fileName?: string }>({
    title: '',
    companyId: '',
    companyName: '',
    type: 'عقد تقديم خدمات سند سنوي',
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    value: 600,
    status: 'Active',
    fileUrl: '',
    fileName: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      setCompanies(YasminaApi.getCompanies());
      const localContracts = YasminaApi.getContracts();
      const res = await fetch('/api/contracts', {
        headers: YasminaApi.getAuthHeaders(),
      }).catch(() => null);

      if (res && res.ok) {
        const body = await res.json();
        if (body.data && Array.isArray(body.data) && body.data.length > 0) {
          setContracts(body.data);
          return;
        }
      }
      setContracts(localContracts);
    } catch (err) {
      console.warn('Error loading contracts:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setFormData((prev) => ({
        ...prev,
        fileUrl: String(reader.result || ''),
        fileName: file.name,
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title?.trim()) return;

    try {
      const selectedComp = companies.find((c) => c.id === formData.companyId);
      const newContract: Contract = {
        id: `ctr-${Date.now()}`,
        title: formData.title.trim(),
        companyId: formData.companyId || '',
        companyName: selectedComp?.name || formData.companyName || 'منشأة عامة',
        type: formData.type || 'عقد تقديم خدمات سند سنوي',
        startDate: formData.startDate || new Date().toISOString().split('T')[0],
        endDate: formData.endDate || '',
        value: Number(formData.value) || 0,
        status: formData.status || 'Active',
        ...(formData.fileUrl ? { fileUrl: formData.fileUrl, fileName: formData.fileName } : {}),
      } as any;

      YasminaApi.saveContract(newContract);

      await fetch('/api/contracts', {
        method: 'POST',
        headers: YasminaApi.getAuthHeaders(),
        body: JSON.stringify(newContract),
      }).catch(() => null);

      setShowAddModal(false);
      setFormData({
        title: '',
        companyId: '',
        companyName: '',
        type: 'عقد تقديم خدمات سند سنوي',
        startDate: new Date().toISOString().split('T')[0],
        endDate: '',
        value: 600,
        status: 'Active',
        fileUrl: '',
        fileName: '',
      });
      await loadData();
    } catch (err) {
      console.error('Error saving contract:', err);
    }
  };

  const filtered = contracts.filter((c) => {
    const s = searchQuery.toLowerCase().trim();
    return (
      !s ||
      c.title.toLowerCase().includes(s) ||
      (c.companyName && c.companyName.toLowerCase().includes(s)) ||
      (c.type && c.type.toLowerCase().includes(s))
    );
  });

  return (
    <div className="space-y-6 pb-12" dir="rtl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-purple-500/10 text-purple-400 rounded-xl border border-purple-500/20">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-100">سجل العقود والاتفاقيات (Contracts & Agreements)</h1>
            <p className="text-xs text-slate-400 mt-0.5">
              عقود تخليص المعاملات الشهرية والسنوية المبرمة مع الشركات والجهات الحكومية مع حفظ النسخة الأصلية للعقد.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs transition shadow-md cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إبرام عقد جديد</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="بحث في العقود والاتفاقيات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="text-center py-12 bg-slate-900/50 rounded-2xl border border-slate-800">
          <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-3" />
          <p className="text-slate-400 text-xs">جاري تحميل العقود...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 bg-slate-900/50 rounded-2xl border border-slate-800">
          <FileText className="w-12 h-12 text-slate-600 mx-auto mb-2" />
          <p className="text-slate-200 font-bold text-sm">لا توجد عقود مسجلة</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((ctr: any) => (
            <div key={ctr.id} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3 shadow-md flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-slate-100 text-sm">{ctr.title}</h3>
                    <p className="text-xs text-emerald-400 font-medium flex items-center gap-1 mt-0.5">
                      <Building2 className="w-3.5 h-3.5" />
                      {ctr.companyName || 'منشأة عامة'}
                    </p>
                  </div>
                  <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full text-[10px] font-bold">
                    {ctr.status || 'Active'}
                  </span>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl text-xs space-y-1 text-slate-300">
                  <p>
                    <strong>نوع العقد:</strong> {ctr.type || 'خدمات سند'}
                  </p>
                  <p>
                    <strong>القيمة:</strong>{' '}
                    <span className="text-amber-400 font-bold">{ctr.value ? `${ctr.value} ر.ع` : 'حسب المعاملة'}</span>
                  </p>
                  <p>
                    <strong>تاريخ البدء:</strong> {ctr.startDate || '—'}
                  </p>
                  <p>
                    <strong>تاريخ الانتهاء:</strong> {ctr.endDate || '—'}
                  </p>
                </div>
              </div>

              {ctr.fileUrl && (
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setPreviewDoc({ url: ctr.fileUrl, name: ctr.fileName || `${ctr.title}.pdf` })}
                    className="flex items-center gap-1 text-xs text-slate-300 hover:text-emerald-400 transition"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>معاينة العقد</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => YasminaApi.downloadOriginalFile(ctr.fileUrl, ctr.fileName || `${ctr.title}.pdf`)}
                    className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>تحميل العقد الأصلي</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Add Contract Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm">إبرام عقد خدمات جديد</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">عنوان العقد *:</label>
                <input
                  type="text"
                  required
                  value={formData.title || ''}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="مثال: عقد خدمات سند سنوي - شركة الأفق"
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">المنشأة الطرف الثاني:</label>
                <select
                  value={formData.companyId || ''}
                  onChange={(e) => setFormData({ ...formData, companyId: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 px-3 py-2 rounded-xl text-xs"
                >
                  <option value="">اختر المنشأة...</option>
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">القيمة الإجمالية (ر.ع):</label>
                  <input
                    type="number"
                    value={formData.value || 0}
                    onChange={(e) => setFormData({ ...formData, value: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 text-amber-400 font-bold px-3 py-2 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">تاريخ الانتهاء:</label>
                  <input
                    type="date"
                    value={formData.endDate || ''}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">نسخة العقد الأصلية (PDF أو صورة):</label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/pdf,image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
                {formData.fileUrl ? (
                  <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/30 p-2.5 rounded-xl">
                    <span className="text-emerald-300 truncate flex items-center gap-1.5">
                      <FileCheck2 className="w-4 h-4 shrink-0" />
                      {formData.fileName}
                    </span>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, fileUrl: '', fileName: '' })}
                      className="text-rose-400 hover:text-rose-300"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full border border-dashed border-slate-700 hover:border-emerald-500/50 p-3 rounded-xl flex items-center justify-center gap-2 text-slate-300 transition"
                  >
                    <UploadCloud className="w-4 h-4 text-emerald-400" />
                    <span>إرفاق ملف العقد الأصلي</span>
                  </button>
                )}
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs"
                >
                  إلغاء
                </button>
                <button type="submit" className="px-4 py-2 bg-purple-600 text-white font-bold rounded-xl text-xs cursor-pointer">
                  حفظ العقد
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <h3 className="font-bold text-slate-100 text-sm">{previewDoc.name}</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => YasminaApi.downloadOriginalFile(previewDoc.url, previewDoc.name)}
                  className="px-3 py-1.5 bg-emerald-500 text-slate-950 rounded-xl text-xs font-bold flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تحميل الأصلي</span>
                </button>
                <button onClick={() => setPreviewDoc(null)} className="text-slate-400 hover:text-white p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-slate-950/50 min-h-[400px]">
              {previewDoc.url.startsWith('data:application/pdf') ? (
                <iframe src={previewDoc.url} title="Contract PDF" className="w-full h-[520px] rounded-xl border border-slate-800" />
              ) : (
                <img src={previewDoc.url} alt={previewDoc.name} className="max-h-[520px] max-w-full object-contain rounded-xl" />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
