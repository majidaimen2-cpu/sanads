import React, { useEffect, useState, useRef } from 'react';
import {
  Building2,
  Plus,
  Search,
  Filter,
  Phone,
  Mail,
  MapPin,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ExternalLink,
  Edit,
  Trash2,
  ShieldCheck,
  Users,
  Coins,
  FileText,
  MessageSquare,
  Sparkles,
  RefreshCw,
  Eye,
  X,
  Check,
  Download,
  UploadCloud,
  FileCheck2,
  FileSpreadsheet
} from 'lucide-react';
import { Company, CompanyStatus, Employee, Contract, Transaction } from '../types';
import { YasminaApi } from '../lib/api';

interface CompaniesPageProps {
  onNavigateToWhatsApp?: (phone: string) => void;
  onNavigateToTransactions?: (companyId?: string) => void;
  onNavigateToEmployees?: (companyId?: string) => void;
}

export const CompaniesPage: React.FC<CompaniesPageProps> = ({
  onNavigateToWhatsApp,
  onNavigateToTransactions,
  onNavigateToEmployees,
}) => {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);

  // Document Lightbox Preview
  const [previewDoc, setPreviewDoc] = useState<{ url: string; name: string; companyName: string } | null>(null);

  // Form state
  const [formData, setFormData] = useState<Partial<Company>>({
    name: '',
    companyNameEn: '',
    tradeName: '',
    taxId: '',
    taxCardNumber: '',
    chamberNumber: '',
    capital: undefined,
    legalForm: '',
    sector: '',
    status: 'active',
    city: 'مسقط',
    stateCountry: 'سلطنة عُمان',
    ownerName: '',
    contactPhone: '+968',
    contactEmail: '',
    crExpiryDate: '',
    crIssueDate: '',
    licenseNumber: '',
    licenseExpiryDate: '',
    crDocumentUrl: '',
    crDocumentName: '',
    employeesCount: 0,
    revenueMonthly: 0,
  });

  const [saving, setSaving] = useState(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const crFileInputRef = useRef<HTMLInputElement>(null);

  const [isExtractingAnyDoc, setIsExtractingAnyDoc] = useState(false);
  const quickAnyDocInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadCompanies();

    const handleUpdate = () => loadCompanies();
    window.addEventListener('yasmina_company_updated', handleUpdate);
    window.addEventListener('atendai_company_updated', handleUpdate);

    return () => {
      window.removeEventListener('yasmina_company_updated', handleUpdate);
      window.removeEventListener('atendai_company_updated', handleUpdate);
    };
  }, []);

  const loadCompanies = async () => {
    setLoading(true);
    try {
      // 1. Load from local store
      const localList = YasminaApi.getCompanies();
      setCompanies(localList);

      // 2. Fetch fresh PostgreSQL records from backend and merge preserving local file URLs
      const res = await fetch('/api/companies', {
        headers: YasminaApi.getAuthHeaders(),
      }).catch(() => null);

      if (res && res.ok) {
        const body = await res.json();
        const incoming = body.data || body.companies;
        if (incoming && Array.isArray(incoming) && incoming.length > 0) {
          const map = new Map<string, Company>();
          for (const lc of localList) {
            if (lc && lc.id) map.set(String(lc.id), lc);
          }
          for (const c of incoming) {
            const existing = map.get(String(c.id)) || localList.find((x) => x.taxId === c.taxId);
            const norm: Company = {
              ...(existing || {}),
              ...c,
              id: String(c.id),
              capital:
                c.capital !== undefined && c.capital !== null
                  ? c.capital
                  : c.capitalBaisa
                  ? c.capitalBaisa / 1000
                  : existing?.capital,
              capitalBaisa:
                c.capitalBaisa ??
                (c.capital ? Math.round(c.capital * 1000) : existing?.capitalBaisa || 0),
              legalForm: c.legalForm || existing?.legalForm || undefined,
              taxCardNumber: c.taxCardNumber || existing?.taxCardNumber || null,
              chamberNumber: c.chamberNumber || existing?.chamberNumber || null,
              companyNameEn: c.companyNameEn || existing?.companyNameEn || null,
              crDocumentUrl: c.crDocumentUrl || existing?.crDocumentUrl || null,
              crDocumentName: c.crDocumentName || existing?.crDocumentName || null,
            };
            map.set(norm.id, norm);
          }
          const merged = Array.from(map.values());
          setCompanies(merged);
        }
      }
    } catch (err) {
      console.warn('Error loading companies:', err);
    } finally {
      setLoading(false);
    }
  };

  const notifySuccess = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(null), 4000);
  };

  const handleDownloadCrFile = (comp: Company) => {
    if (!comp.crDocumentUrl) {
      notifySuccess('⚠️ لا يوجد ملف سجل تجاري محفوظ لهذه المنشأة.');
      return;
    }
    const safeName = comp.crDocumentName || `سجل_تجاري_${comp.taxId || comp.name}.pdf`;

    if (comp.crDocumentUrl.startsWith('data:')) {
      YasminaApi.downloadOriginalFile(comp.crDocumentUrl, safeName);
    } else {
      const link = document.createElement('a');
      link.href = `/api/companies/${encodeURIComponent(comp.id)}/cr-download`;
      link.download = safeName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleQuickAnyDocUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) {
      notifySuccess('⚠️ حجم الملف كبير جداً. الحد الأقصى المسموح به هو 15 ميغابايت.');
      return;
    }

    setIsExtractingAnyDoc(true);
    try {
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('تعذر قراءة الملف المرفق'));
        reader.readAsDataURL(file);
      });

      const response = await YasminaApi.uploadAndExtractCrDocument({
        name: file.name,
        mimeType: file.type || 'application/pdf',
        data: base64Data,
      });

      const ext = response.extraction;
      const dup = response.duplicateCheck;
      const f = ext?.fields || {};

      const extractedName = f.companyNameAr?.normalized || '';
      const extractedCr = f.crNumber?.normalized || '';
      const extractedCap =
        f.capitalOmr?.normalized !== null && f.capitalOmr?.normalized !== undefined
          ? Number(f.capitalOmr.normalized)
          : undefined;

      // Always open the Review & Confirm modal pre-populated with extracted CR fields before saving
      setSelectedCompany(dup?.isDuplicate && dup?.existingCompany ? dup.existingCompany : null);
      setFormData({
        name: extractedName || f.companyNameEn?.normalized || '',
        companyNameEn: f.companyNameEn?.normalized || '',
        tradeName: f.tradeName?.normalized || extractedName || '',
        taxId: extractedCr || '',
        taxCardNumber: f.taxCardNumber?.normalized || '',
        chamberNumber: f.chamberNumber?.normalized || '',
        capital: extractedCap,
        legalForm: f.legalForm?.normalized || '',
        sector: f.sector?.normalized || '',
        status: f.registrationStatus?.normalized && /ملغ|منته|موقوف|inactive|expired/i.test(String(f.registrationStatus.normalized)) ? 'suspended' : 'active',
        city: f.city?.normalized || f.governorate?.normalized || '',
        stateCountry: 'سلطنة عُمان',
        ownerName: f.ownerOrManagerName?.normalized || '',
        contactPhone: f.contactPhone?.normalized || '',
        contactEmail: f.contactEmail?.normalized || '',
        crExpiryDate: f.expiryDate?.normalized || '',
        crIssueDate: f.issueDate?.normalized || '',
        licenseNumber: f.licenseNumber?.normalized || '',
        licenseExpiryDate: f.licenseExpiryDate?.normalized || '',
        crDocumentUrl: base64Data,
        crDocumentName: file.name,
        employeesCount: 0,
        revenueMonthly: 0,
      });
      setShowAddModal(true);
      notifySuccess(
        extractedName && extractedCr
          ? `✅ تم استخراج بيانات السجل التجاري لشركة "${extractedName}" بنجاح — يرجى مراجعة البيانات وتأكيد التسجيل.`
          : '📄 تم إرفاق المستند الأصلي واستخراج البيانات المتاحة — يرجى مراجعة وإكمال الحقول وتأكيد التسجيل.'
      );
    } catch (err: any) {
      notifySuccess(`⚠️ ${err?.message || 'تعذر الفحص التلقائي، يرجى التسجيل يدوياً'}`);
    } finally {
      setIsExtractingAnyDoc(false);
      if (quickAnyDocInputRef.current) quickAnyDocInputRef.current.value = '';
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      notifySuccess('⚠️ حجم الملف كبير جداً. الحد الأقصى المسموح به هو 15 ميغابايت.');
      return;
    }

    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.readAsDataURL(file);
    });

    setFormData((prev) => ({
      ...prev,
      crDocumentUrl: base64Data,
      crDocumentName: file.name,
    }));

    // Also run fast AnyDoc extraction in the background to auto-fill any blank fields in the modal
    try {
      setIsExtractingAnyDoc(true);
      const response = await YasminaApi.uploadAndExtractCrDocument({
        name: file.name,
        mimeType: file.type || 'application/pdf',
        data: base64Data,
      });
      const f = response?.extraction?.fields || {};
      setFormData((prev) => ({
        ...prev,
        crDocumentUrl: base64Data,
        crDocumentName: file.name,
        name: prev.name || f.companyNameAr?.normalized || '',
        companyNameEn: prev.companyNameEn || f.companyNameEn?.normalized || '',
        tradeName: prev.tradeName || f.tradeName?.normalized || f.companyNameAr?.normalized || '',
        taxId: prev.taxId || f.crNumber?.normalized || '',
        taxCardNumber: prev.taxCardNumber || f.taxCardNumber?.normalized || '',
        chamberNumber: prev.chamberNumber || f.chamberNumber?.normalized || '',
        capital:
          prev.capital !== undefined
            ? prev.capital
            : f.capitalOmr?.normalized !== null && f.capitalOmr?.normalized !== undefined
            ? Number(f.capitalOmr.normalized)
            : undefined,
        legalForm: f.legalForm?.normalized || prev.legalForm || 'شركة ذات مسؤولية محدودة (ش.م.م)',
        crExpiryDate: prev.crExpiryDate || f.expiryDate?.normalized || '',
        crIssueDate: prev.crIssueDate || f.issueDate?.normalized || '',
        ownerName: prev.ownerName || f.ownerOrManagerName?.normalized || '',
        contactPhone:
          prev.contactPhone && prev.contactPhone !== '+968'
            ? prev.contactPhone
            : f.contactPhone?.normalized || '+968',
      }));
    } catch (_) {
      // Keep original file attached even if OCR/PDF extraction is skipped
    } finally {
      setIsExtractingAnyDoc(false);
    }
  };

  const handleRemoveCrFile = () => {
    setFormData((prev) => ({
      ...prev,
      crDocumentUrl: '',
      crDocumentName: '',
    }));
    if (crFileInputRef.current) {
      crFileInputRef.current.value = '';
    }
  };

  const handleOpenAdd = () => {
    setSelectedCompany(null);
    setFormData({
      name: '',
      companyNameEn: '',
      tradeName: '',
      taxId: '',
      taxCardNumber: '',
      chamberNumber: '',
      capital: undefined,
      legalForm: 'شركة ذات مسؤولية محدودة (ش.م.م)',
      sector: 'خدمات تجارية واستشارات',
      status: 'active',
      city: 'مسقط',
      stateCountry: 'سلطنة عُمان',
      ownerName: '',
      contactPhone: '+968',
      contactEmail: '',
      crExpiryDate: '',
      crIssueDate: '',
      licenseNumber: '',
      licenseExpiryDate: '',
      crDocumentUrl: '',
      crDocumentName: '',
      employeesCount: 0,
      revenueMonthly: 0,
    });
    setShowAddModal(true);
  };

  const handleOpenEdit = (comp: Company) => {
    setSelectedCompany(comp);
    setFormData({
      name: comp.name,
      companyNameEn: comp.companyNameEn || '',
      tradeName: comp.tradeName || '',
      taxId: comp.taxId,
      taxCardNumber: comp.taxCardNumber || '',
      chamberNumber: comp.chamberNumber || '',
      capital: comp.capital,
      legalForm: comp.legalForm || 'غير محدد',
      sector: comp.sector || '',
      status: comp.status,
      city: comp.city || 'مسقط',
      stateCountry: comp.stateCountry || 'سلطنة عُمان',
      ownerName: comp.ownerName || '',
      contactPhone: comp.contactPhone || '+968',
      contactEmail: comp.contactEmail || '',
      crExpiryDate: comp.crExpiryDate || '',
      crIssueDate: comp.crIssueDate || '',
      licenseNumber: comp.licenseNumber || '',
      licenseExpiryDate: comp.licenseExpiryDate || '',
      crDocumentUrl: comp.crDocumentUrl || '',
      crDocumentName: comp.crDocumentName || '',
      employeesCount: comp.employeesCount || 0,
      revenueMonthly: comp.revenueMonthly || 0,
    });
    setShowEditModal(true);
  };

  const handleOpenDetails = (comp: Company) => {
    setSelectedCompany(comp);
    setShowDetailsModal(true);
  };

  const handleOpenDelete = (comp: Company) => {
    setSelectedCompany(comp);
    setShowDeleteModal(true);
  };

  const handleSaveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim() || !formData.taxId?.trim()) return;

    setSaving(true);
    try {
      const isEditing = Boolean(selectedCompany?.id);
      const targetId = isEditing ? selectedCompany!.id : `comp-${Date.now()}`;
      const cap = formData.capital !== undefined && formData.capital !== null ? Number(formData.capital) : undefined;

      const companyPayload: Company = {
        id: targetId,
        name: formData.name.trim(),
        companyNameEn: formData.companyNameEn?.trim() || null,
        tradeName: formData.tradeName?.trim() || formData.name.trim(),
        taxId: formData.taxId.trim(),
        taxCardNumber: formData.taxCardNumber?.trim() || null,
        chamberNumber: formData.chamberNumber?.trim() || null,
        sector: formData.sector || '',
        status: (formData.status as CompanyStatus) || 'active',
        revenueMonthly: Number(formData.revenueMonthly) || 0,
        currency: 'OMR',
        employeesCount: Number(formData.employeesCount) || 0,
        city: formData.city || 'مسقط',
        stateCountry: formData.stateCountry || 'سلطنة عُمان',
        whatsappConnected: Boolean(formData.whatsappConnected),
        complianceScore: Number(formData.complianceScore) || 100,
        createdDate: formData.createdDate || new Date().toISOString().split('T')[0],
        contactEmail: formData.contactEmail || '',
        contactPhone: formData.contactPhone || '+968',
        ownerName: formData.ownerName || '',
        capital: cap,
        capitalBaisa: cap ? Math.round(cap * 1000) : 0,
        legalForm: formData.legalForm || undefined,
        documentsCount: formData.documentsCount || 1,
        activeContractsCount: formData.activeContractsCount || 0,
        crExpiryDate: formData.crExpiryDate,
        crIssueDate: formData.crIssueDate,
        licenseNumber: formData.licenseNumber,
        licenseExpiryDate: formData.licenseExpiryDate,
        crDocumentUrl: formData.crDocumentUrl || null,
        crDocumentName: formData.crDocumentName || null,
      };

      // 1. Save in local API and trigger events
      YasminaApi.saveCompany(companyPayload);

      // 2. Post to backend DB
      await fetch(isEditing ? `/api/companies/${encodeURIComponent(targetId)}` : '/api/companies', {
        method: isEditing ? 'PUT' : 'POST',
        headers: YasminaApi.getAuthHeaders(),
        body: JSON.stringify(isEditing ? { ...companyPayload, id: targetId } : companyPayload),
      }).catch((err) => console.warn('Backend DB post notice:', err));

      setShowAddModal(false);
      setShowEditModal(false);
      notifySuccess(isEditing ? 'تم تحديث بيانات المنشأة ومستند السجل بنجاح' : 'تم تسجيل المنشأة وحفظ السجل التجاري الأصلي بنجاح');
      await loadCompanies();
    } catch (err) {
      console.error('Error saving company:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!selectedCompany) return;
    setSaving(true);
    try {
      YasminaApi.deleteCompany(selectedCompany.id);

      await fetch(`/api/companies/${encodeURIComponent(selectedCompany.id)}`, {
        method: 'DELETE',
        headers: YasminaApi.getAuthHeaders(),
      }).catch(() => null);

      setShowDeleteModal(false);
      notifySuccess(`تم حذف المنشأة "${selectedCompany.name}"`);
      await loadCompanies();
    } catch (err) {
      console.error('Error deleting company:', err);
    } finally {
      setSaving(false);
    }
  };

  const calculateDaysRemaining = (expiryDateStr?: string) => {
    if (!expiryDateStr) return { days: null, isExpired: false, isWarning: false };
    const exp = new Date(expiryDateStr);
    const now = new Date();
    const diffTime = exp.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return {
      days: diffDays,
      isExpired: diffDays < 0,
      isWarning: diffDays >= 0 && diffDays <= 30,
    };
  };

  const filteredCompanies = companies.filter((c) => {
    const s = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !s ||
      c.name.toLowerCase().includes(s) ||
      c.taxId.toLowerCase().includes(s) ||
      (c.tradeName && c.tradeName.toLowerCase().includes(s)) ||
      (c.taxCardNumber && c.taxCardNumber.toLowerCase().includes(s)) ||
      (c.chamberNumber && c.chamberNumber.toLowerCase().includes(s)) ||
      (c.companyNameEn && c.companyNameEn.toLowerCase().includes(s)) ||
      (c.city && c.city.toLowerCase().includes(s));

    if (!matchesSearch) return false;
    if (statusFilter !== 'all' && c.status !== statusFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-12" dir="rtl">
      {/* Toast Notification */}
      {actionSuccessMsg && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 backdrop-blur-md animate-fade-in text-sm font-semibold">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              سجل المنشآت والشركات التجارية
              <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded-full font-mono border border-slate-700">
                {companies.length} منشأة
              </span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              إدارة بيانات الشركات، أرقام السجلات التجارية (CR)، وحفظ وتنزيل شهادات السجل التجاري الأصلية المرفوعة بدقة 100%.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            ref={quickAnyDocInputRef}
            type="file"
            accept="application/pdf,image/*"
            onChange={handleQuickAnyDocUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => quickAnyDocInputRef.current?.click()}
            disabled={isExtractingAnyDoc}
            className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 border border-emerald-500/40 text-emerald-300 font-bold px-4 py-2.5 rounded-xl text-xs transition shadow-md cursor-pointer disabled:opacity-50"
          >
            {isExtractingAnyDoc ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                <span>جاري فحص السجل وتسجيل الشركة...</span>
              </>
            ) : (
              <>
                <UploadCloud className="w-4 h-4 text-emerald-400" />
                <span>رفع وفحص السجل التجاري تلقائياً (AnyDoc)</span>
              </>
            )}
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs transition shadow-md cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل منشأة جديدة</span>
          </button>
        </div>
      </div>

      {/* Filters and Controls */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="بحث بالاسم، رقم السجل (CR)، البطاقة الضريبية..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="all">كافة الحالات</option>
              <option value="active">نشطة</option>
              <option value="pending">قيد الإجراء</option>
              <option value="compliance_risk">مخاطر امتثال</option>
            </select>
          </div>

          {/* Toggle View Mode */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-0.5">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                viewMode === 'grid' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              بطاقات
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                viewMode === 'table' ? 'bg-slate-800 text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              جدول
            </button>
          </div>
        </div>
      </div>

      {/* Companies Content */}
      {loading ? (
        <div className="text-center py-16 bg-slate-900/50 rounded-2xl border border-slate-800">
          <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto mb-3" />
          <p className="text-slate-400 text-sm">جاري تحميل سجلات المنشآت والشركات...</p>
        </div>
      ) : filteredCompanies.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/50 rounded-2xl border border-slate-800 space-y-3">
          <Building2 className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-slate-200 font-bold text-lg">لم يتم العثور على أي منشآت مطابقة</h3>
          <p className="text-slate-400 text-xs">جرب تغيير معايير البحث أو إضافة منشأة جديدة.</p>
        </div>
      ) : viewMode === 'grid' ? (
        /* Grid View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCompanies.map((comp) => {
            const crCheck = calculateDaysRemaining(comp.crExpiryDate);
            const licCheck = calculateDaysRemaining(comp.licenseExpiryDate);

            return (
              <div
                key={comp.id}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-5 shadow-lg transition flex flex-col justify-between"
              >
                <div>
                  {/* Top Row */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center font-bold text-emerald-400 text-sm">
                        {comp.name.slice(0, 2)}
                      </div>
                      <div className="overflow-hidden">
                        <h3 className="font-bold text-slate-100 text-sm truncate" title={comp.name}>
                          {comp.name}
                        </h3>
                        {comp.companyNameEn && (
                          <p className="text-[11px] text-slate-400 font-mono truncate" title={comp.companyNameEn}>
                            {comp.companyNameEn}
                          </p>
                        )}
                        <p className="text-[11px] text-emerald-400 font-semibold mt-0.5 truncate block" title={comp.legalForm || 'غير محدد'}>
                          {comp.legalForm || 'غير محدد'}
                        </p>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                        comp.status === 'active'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : comp.status === 'compliance_risk'
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                          : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      }`}
                    >
                      {comp.status === 'active' ? 'نشطة' : comp.status === 'compliance_risk' ? 'مخاطر امتثال' : 'معلقة'}
                    </span>
                  </div>

                  {/* Badges Grid */}
                  <div className="grid grid-cols-2 gap-2 mt-4 text-xs overflow-hidden">
                    {/* CR Number */}
                    <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80 min-w-0 overflow-hidden">
                      <span className="text-[10px] text-slate-400 block font-medium truncate">رقم السجل التجاري (CR):</span>
                      <span className="font-mono font-bold text-slate-200 text-xs mt-0.5 block truncate" title={comp.taxId}>{comp.taxId}</span>
                    </div>

                    {/* Capital */}
                    <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80 min-w-0 overflow-hidden">
                      <span className="text-[10px] text-slate-400 block font-medium truncate">رأس المال المصرح:</span>
                      <span className="font-bold text-amber-400 text-xs mt-0.5 block truncate" title={`${(Number(comp.capital) || 0).toLocaleString()} ر.ع`}>
                        {(Number(comp.capital) || 0).toLocaleString()} ر.ع
                      </span>
                    </div>

                    {/* Tax Card Number */}
                    <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80 min-w-0 overflow-hidden">
                      <span className="text-[10px] text-slate-400 block font-medium truncate">البطاقة الضريبية:</span>
                      <span className="font-mono font-bold text-slate-200 text-xs mt-0.5 block truncate" title={comp.taxCardNumber || 'غير مسجل'}>
                        {comp.taxCardNumber || 'غير مسجل'}
                      </span>
                    </div>

                    {/* Chamber Number */}
                    <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80 min-w-0 overflow-hidden">
                      <span className="text-[10px] text-slate-400 block font-medium truncate">انتساب الغرفة:</span>
                      <span className="font-mono font-bold text-slate-200 text-xs mt-0.5 block truncate" title={comp.chamberNumber || 'غير مسجل'}>
                        {comp.chamberNumber || 'غير مسجل'}
                      </span>
                    </div>
                  </div>

                  {/* Original CR Document Action Bar */}
                  {comp.crDocumentUrl ? (
                    <div className="mt-3 flex items-center justify-between bg-emerald-950/40 border border-emerald-500/30 p-2.5 rounded-xl text-xs">
                      <div className="flex items-center gap-1.5 overflow-hidden">
                        <FileCheck2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span className="text-emerald-300 font-semibold truncate max-w-[150px]" title={comp.crDocumentName || 'شهادة السجل التجاري'}>
                          {comp.crDocumentName || 'شهادة السجل التجاري'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => setPreviewDoc({ url: comp.crDocumentUrl!, name: comp.crDocumentName || 'شهادة السجل', companyName: comp.name })}
                          className="p-1.5 text-emerald-400 hover:text-emerald-200 hover:bg-emerald-500/20 rounded-lg transition"
                          title="معاينة السجل"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDownloadCrFile(comp)}
                          className="flex items-center gap-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-2.5 py-1 rounded-lg text-[11px] font-bold transition shadow-sm cursor-pointer"
                          title="تحميل الملف الأصلي كما رُفع تماماً"
                        >
                          <Download className="w-3 h-3" />
                          <span>تحميل الأصلي</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-3 text-[11px] text-slate-500 bg-slate-950/40 p-2 rounded-xl border border-slate-800/50 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-slate-600" />
                      <span>لا يوجد ملف سجل تجاري مرفوع</span>
                    </div>
                  )}

                  {/* Expiry Dates Alert Box */}
                  <div className="mt-3 space-y-1.5 text-xs bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/50 min-w-0 overflow-hidden">
                    {comp.crExpiryDate ? (
                      <div className="flex items-center justify-between text-[11px] gap-2 min-w-0">
                        <span className="text-slate-400 flex items-center gap-1 shrink-0">
                          <Calendar className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span>انتهاء السجل (CR):</span>
                        </span>
                        <span
                          className={`font-semibold shrink-0 text-left truncate ${
                            crCheck.isExpired
                              ? 'text-rose-400'
                              : crCheck.isWarning
                              ? 'text-amber-400'
                              : 'text-slate-300'
                          }`}
                        >
                          {comp.crExpiryDate}
                          {crCheck.days !== null && (
                            <span className="text-[10px] mr-1 opacity-80">
                              ({crCheck.isExpired ? 'منتهي' : `متبقي ${crCheck.days} يوم`})
                            </span>
                          )}
                        </span>
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-500">تاريخ انتهاء السجل: غير مسجل</p>
                    )}

                    {comp.licenseExpiryDate && (
                      <div className="flex items-center justify-between text-[11px] gap-2 min-w-0">
                        <span className="text-slate-400 flex items-center gap-1 shrink-0">
                          <Building2 className="w-3 h-3 text-cyan-400 shrink-0" />
                          <span>انتهاء الترخيص البلدي:</span>
                        </span>
                        <span
                          className={`font-semibold shrink-0 text-left truncate ${
                            licCheck.isExpired
                              ? 'text-rose-400'
                              : licCheck.isWarning
                              ? 'text-amber-400'
                              : 'text-slate-300'
                          }`}
                        >
                          {comp.licenseExpiryDate}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Contact Info */}
                  <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-400 min-w-0 overflow-hidden">
                    {comp.city && (
                      <span className="flex items-center gap-1 truncate max-w-[140px]" title={comp.city}>
                        <MapPin className="w-3 h-3 text-emerald-400 shrink-0" />
                        <span className="truncate">{comp.city}</span>
                      </span>
                    )}
                    {comp.contactPhone && (
                      <a
                        href={`https://wa.me/${comp.contactPhone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-mono truncate"
                      >
                        <Phone className="w-3 h-3 shrink-0" />
                        <span className="truncate">{comp.contactPhone}</span>
                      </a>
                    )}
                  </div>
                </div>

                {/* Footer Controls */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2 mt-4">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleOpenDetails(comp)}
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition text-xs font-semibold flex items-center gap-1"
                      title="عرض تفاصيل المنشأة"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>تفاصيل</span>
                    </button>
                    <button
                      onClick={() => handleOpenEdit(comp)}
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-xl transition text-xs font-semibold flex items-center gap-1"
                      title="تعديل المنشأة"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>تعديل</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {comp.contactPhone && onNavigateToWhatsApp && (
                      <button
                        onClick={() => onNavigateToWhatsApp(comp.contactPhone)}
                        className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm"
                        title="محادثة واتساب"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>واتساب</span>
                      </button>
                    )}
                    <button
                      onClick={() => handleOpenDelete(comp)}
                      className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition"
                      title="حذف المنشأة"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase text-[11px]">
                <tr>
                  <th className="p-4">المنشأة</th>
                  <th className="p-4">رقم السجل (CR)</th>
                  <th className="p-4">شهادة السجل (CR)</th>
                  <th className="p-4">رأس المال (ر.ع)</th>
                  <th className="p-4">الشكل القانوني</th>
                  <th className="p-4">انتهاء السجل (CR)</th>
                  <th className="p-4">العمال</th>
                  <th className="p-4">الحالة</th>
                  <th className="p-4 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                {filteredCompanies.map((comp) => {
                  const crCheck = calculateDaysRemaining(comp.crExpiryDate);
                  return (
                    <tr key={comp.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-4">
                        <p className="font-bold text-slate-100 text-sm">{comp.name}</p>
                        <p className="text-[11px] text-slate-400">{comp.tradeName || comp.city}</p>
                      </td>
                      <td className="p-4 font-mono font-bold text-slate-200">{comp.taxId}</td>

                      {/* CR Document Download & Preview Column */}
                      <td className="p-4">
                        {comp.crDocumentUrl ? (
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleDownloadCrFile(comp)}
                              className="flex items-center gap-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition"
                              title="تنزيل الملف الأصلي كما رُفع تماماً"
                            >
                              <Download className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="max-w-[110px] truncate">{comp.crDocumentName || 'تحميل السجل'}</span>
                            </button>
                            <button
                              onClick={() => setPreviewDoc({ url: comp.crDocumentUrl!, name: comp.crDocumentName || 'شهادة السجل', companyName: comp.name })}
                              className="p-1.5 text-slate-400 hover:text-emerald-300 hover:bg-slate-800 rounded-lg transition"
                              title="معاينة السجل"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span className="text-slate-500 text-[11px] bg-slate-950 px-2 py-1 rounded-md border border-slate-800">
                            غير مرفق
                          </span>
                        )}
                      </td>

                      <td className="p-4 font-bold text-amber-400 font-mono">
                        {(Number(comp.capital) || 0).toLocaleString()} ر.ع
                      </td>
                      <td className="p-4 text-slate-300">{comp.legalForm || 'غير محدد'}</td>
                      <td className="p-4">
                        <span
                          className={`font-semibold ${
                            crCheck.isExpired ? 'text-rose-400 font-bold' : crCheck.isWarning ? 'text-amber-400' : 'text-slate-300'
                          }`}
                        >
                          {comp.crExpiryDate || 'غير مسجل'}
                        </span>
                      </td>
                      <td className="p-4 font-bold text-cyan-400">{comp.employeesCount || 0}</td>
                      <td className="p-4">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                            comp.status === 'active'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                          }`}
                        >
                          {comp.status === 'active' ? 'نشطة' : 'معلقة'}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleOpenDetails(comp)}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition"
                            title="تفاصيل"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEdit(comp)}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-lg transition"
                            title="تعديل"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenDelete(comp)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg transition"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Company Modal */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-400" />
                <span>{showEditModal ? 'تعديل بيانات المنشأة ومستند السجل' : 'تسجيل منشأة جديدة مع شهادة السجل'}</span>
              </h3>
              <button
                type="button"
                onClick={() => {
                  setShowAddModal(false);
                  setShowEditModal(false);
                }}
                className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* Company Name */}
                <div className="sm:col-span-2">
                  <label htmlFor="comp-form-name" className="text-xs font-semibold text-slate-300 block mb-1">
                    اسم المنشأة بالعربية <span className="text-rose-400">*</span>:
                  </label>
                  <input
                    id="comp-form-name"
                    type="text"
                    required
                    value={formData.name || ''}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="اسم الشركة كما هو مسجل في السجل التجاري"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* CR File Upload Zone */}
                <div className="sm:col-span-2 bg-slate-950/70 border border-emerald-500/30 rounded-xl p-3.5 space-y-2">
                  <label className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                    <FileCheck2 className="w-4 h-4 text-emerald-400" />
                    <span>شهادة السجل التجاري الأصلية (PDF أو صورة):</span>
                  </label>

                  {formData.crDocumentUrl ? (
                    <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/40 p-2.5 rounded-xl">
                      <div className="flex items-center gap-2 overflow-hidden">
                        <FileCheck2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span className="text-emerald-200 font-medium text-xs truncate max-w-[280px]">
                          {formData.crDocumentName || 'شهادة السجل التجاري المحفوظة'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            setPreviewDoc({
                              url: formData.crDocumentUrl!,
                              name: formData.crDocumentName || 'شهادة السجل',
                              companyName: formData.name || 'المنشأة',
                            })
                          }
                          className="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 rounded-lg text-[11px] transition flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" />
                          <span>معاينة</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleRemoveCrFile}
                          className="p-1 hover:bg-rose-500/20 text-rose-400 rounded-lg transition"
                          title="إزالة المرفق"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div
                      onClick={() => crFileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-700 hover:border-emerald-500/50 hover:bg-slate-900/50 p-4 rounded-xl text-center cursor-pointer transition space-y-1"
                    >
                      <UploadCloud className="w-6 h-6 text-emerald-400 mx-auto" />
                      <p className="text-xs text-slate-200 font-semibold">
                        انقر هنا لرفع شهادة السجل التجاري الأصلية أو اسحب الملف
                      </p>
                      <p className="text-[10px] text-slate-500">
                        يحتفظ النظام بالملف الأصلي كما هو تماماً (PDF وصور JPG/PNG حتى 15 ميغابايت)
                      </p>
                    </div>
                  )}

                  <input
                    ref={crFileInputRef}
                    type="file"
                    accept="application/pdf,image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </div>

                {/* CR Number */}
                <div>
                  <label htmlFor="comp-form-tax-id" className="text-xs font-semibold text-slate-300 block mb-1">
                    رقم السجل التجاري (CR) <span className="text-rose-400">*</span>:
                  </label>
                  <input
                    id="comp-form-tax-id"
                    type="text"
                    required
                    value={formData.taxId || ''}
                    onChange={(e) => setFormData({ ...formData, taxId: e.target.value })}
                    placeholder="مثال: 1084920 أو CR-1084920"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 font-mono px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Capital */}
                <div>
                  <label htmlFor="comp-form-capital" className="text-xs font-semibold text-slate-300 block mb-1">رأس المال (بالريال العماني):</label>
                  <input
                    id="comp-form-capital"
                    type="number"
                    value={formData.capital ?? ''}
                    onChange={(e) => setFormData({ ...formData, capital: e.target.value === '' ? undefined : Number(e.target.value) })}
                    placeholder="0"
                    className="w-full bg-slate-950 border border-slate-800 text-amber-400 font-bold px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Expiry Dates */}
                <div>
                  <label htmlFor="comp-form-cr-expiry-date" className="text-xs font-semibold text-slate-300 block mb-1">تاريخ انتهاء السجل التجاري (CR):</label>
                  <input
                    id="comp-form-cr-expiry-date"
                    type="date"
                    value={formData.crExpiryDate || ''}
                    onChange={(e) => setFormData({ ...formData, crExpiryDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label htmlFor="comp-form-legal-form" className="text-xs font-semibold text-slate-300 block mb-1">الشكل القانوني:</label>
                  <select
                    id="comp-form-legal-form"
                    value={formData.legalForm || ''}
                    onChange={(e) => setFormData({ ...formData, legalForm: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  >
                    <option value="">غير محدد</option>
                    <option value="شركة ذات مسؤولية محدودة (ش.م.م)">شركة ذات مسؤولية محدودة (ش.م.م)</option>
                    <option value="شركة الشخص الواحد (ش.ش.و)">شركة الشخص الواحد (ش.ش.و)</option>
                    <option value="مؤسسة فردية">مؤسسة فردية</option>
                    <option value="شركة تضامنية">شركة تضامنية</option>
                    <option value="فرع شركة أجنبية">فرع شركة أجنبية</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="comp-form-tax-card" className="text-xs font-semibold text-slate-300 block mb-1">
                    البطاقة الضريبية:
                  </label>
                  <input
                    id="comp-form-tax-card"
                    type="text"
                    value={formData.taxCardNumber || ''}
                    onChange={(e) => setFormData({ ...formData, taxCardNumber: e.target.value })}
                    placeholder="رقم البطاقة الضريبية"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 font-mono px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label htmlFor="comp-form-chamber-number" className="text-xs font-semibold text-slate-300 block mb-1">
                    رقم انتساب الغرفة:
                  </label>
                  <input
                    id="comp-form-chamber-number"
                    type="text"
                    value={formData.chamberNumber || ''}
                    onChange={(e) => setFormData({ ...formData, chamberNumber: e.target.value })}
                    placeholder="رقم شهادة الغرفة"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 font-mono px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label htmlFor="comp-form-owner-name" className="text-xs font-semibold text-slate-300 block mb-1">اسم المالك أو المفوض:</label>
                  <input
                    id="comp-form-owner-name"
                    type="text"
                    value={formData.ownerName || ''}
                    onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                    placeholder="اسم صاحب المنشأة"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label htmlFor="comp-form-contact-phone" className="text-xs font-semibold text-slate-300 block mb-1">رقم هاتف التواصل والواتساب:</label>
                  <input
                    id="comp-form-contact-phone"
                    type="text"
                    value={formData.contactPhone || ''}
                    onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                    placeholder="+968 9XXXXXXX"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3.5 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setShowEditModal(false);
                  }}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold rounded-xl text-xs shadow-lg transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {saving ? (
                    <>
                      <div className="animate-spin w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full" />
                      <span>جاري الحفظ في قاعدة البيانات...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{showEditModal ? 'حفظ التعديلات' : 'تسجيل المنشأة'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Company Details Modal */}
      {showDetailsModal && selectedCompany && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-100 text-base">{selectedCompany.name}</h3>
                  <p className="text-xs text-slate-400 font-mono">{selectedCompany.taxId}</p>
                </div>
              </div>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* CR Document Dedicated Download Banner */}
            <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/40">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl">
                    <FileCheck2 className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-slate-400 text-xs block font-medium">مستند السجل التجاري الأصلي:</span>
                    <span className="font-bold text-slate-100 text-sm mt-0.5 block">
                      {selectedCompany.crDocumentName || (selectedCompany.crDocumentUrl ? 'شهادة السجل التجاري المحفوظة' : 'لا يوجد مستند مرفق')}
                    </span>
                  </div>
                </div>

                {selectedCompany.crDocumentUrl && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() =>
                        setPreviewDoc({
                          url: selectedCompany.crDocumentUrl!,
                          name: selectedCompany.crDocumentName || 'شهادة السجل',
                          companyName: selectedCompany.name,
                        })
                      }
                      className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Eye className="w-4 h-4 text-emerald-400" />
                      <span>معاينة المستند</span>
                    </button>
                    <button
                      onClick={() => handleDownloadCrFile(selectedCompany)}
                      className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-md cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>تحميل الملف الأصلي</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block font-medium">الاسم التجاري:</span>
                <span className="font-bold text-slate-100 mt-1 block">{selectedCompany.tradeName || selectedCompany.name}</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block font-medium">الشكل القانوني:</span>
                <span className="font-bold text-emerald-400 mt-1 block">
                  {selectedCompany.legalForm || 'غير محدد'}
                </span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block font-medium">رأس المال المصرح به:</span>
                <span className="font-bold text-amber-400 mt-1 block text-sm">
                  {(Number(selectedCompany.capital) || 0).toLocaleString()} ر.ع
                </span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block font-medium">تاريخ انتهاء السجل التجاري (CR):</span>
                <span className="font-bold text-slate-200 mt-1 block">{selectedCompany.crExpiryDate || 'غير مسجل'}</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block font-medium">المالك / المفوض بالتوقيع:</span>
                <span className="font-bold text-slate-100 mt-1 block">{selectedCompany.ownerName || 'غير مسجل'}</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block font-medium">رقم الهاتف والتواصل:</span>
                <span className="font-bold text-emerald-400 font-mono mt-1 block">{selectedCompany.contactPhone || 'غير مسجل'}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {selectedCompany.contactPhone && onNavigateToWhatsApp && (
                  <button
                    onClick={() => {
                      setShowDetailsModal(false);
                      onNavigateToWhatsApp(selectedCompany.contactPhone);
                    }}
                    className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-sm"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    مراسلة المنشأة عبر الواتساب
                  </button>
                )}
                {onNavigateToTransactions && (
                  <button
                    onClick={() => {
                      setShowDetailsModal(false);
                      onNavigateToTransactions(selectedCompany.id);
                    }}
                    className="flex items-center gap-1.5 bg-purple-600 hover:bg-purple-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-sm"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    معاملات المنشأة
                  </button>
                )}
              </div>

              <button
                onClick={() => setShowDetailsModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && selectedCompany && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-3 bg-rose-500/10 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-100 text-base">تأكيد حذف المنشأة</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              هل أنت متأكد من حذف المنشأة <strong>"{selectedCompany.name}"</strong> (السجل التجاري:{' '}
              <span className="font-mono text-emerald-400">{selectedCompany.taxId}</span>)؟ سيتم حذف كافة السجلات المرتبطة بها
              من قاعدة البيانات.
            </p>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
              >
                تراجع
              </button>
              <button
                onClick={handleDeleteConfirm}
                disabled={saving}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs transition shadow-md disabled:opacity-50"
              >
                {saving ? 'جاري الحذف...' : 'تأكيد الحذف'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Document Lightbox / Viewer Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                  <FileCheck2 className="w-4 h-4 text-emerald-400" />
                  <span>شهادة السجل التجاري - {previewDoc.companyName}</span>
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">{previewDoc.name}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => YasminaApi.downloadOriginalFile(previewDoc.url, previewDoc.name)}
                  className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition flex items-center gap-1.5 text-xs font-bold cursor-pointer"
                  title="تحميل الملف الأصلي"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل الملف الأصلي</span>
                </button>
                <button
                  onClick={() => setPreviewDoc(null)}
                  className="p-2 text-slate-400 hover:text-slate-100 rounded-xl hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-slate-950/50 min-h-[400px]">
              {previewDoc.url.startsWith('data:application/pdf') || previewDoc.url.endsWith('.pdf') ? (
                <iframe
                  src={previewDoc.url}
                  title="PDF Viewer"
                  className="w-full h-[550px] rounded-xl border border-slate-800"
                />
              ) : (
                <img
                  src={previewDoc.url}
                  alt={previewDoc.name}
                  className="max-h-[550px] max-w-full object-contain rounded-xl shadow-lg border border-slate-800"
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
