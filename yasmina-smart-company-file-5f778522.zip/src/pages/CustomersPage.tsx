import React, { useEffect, useState } from 'react';
import {
  Users,
  Phone,
  Building2,
  Search,
  Plus,
  X,
  CheckCircle2,
  Trash2,
  CheckSquare,
  Square,
  AlertTriangle,
  RefreshCw,
  Pencil,
} from 'lucide-react';
import { YasminaApi } from '../lib/api';

interface CustomerRecord {
  id: string;
  numericId?: number;
  name: string;
  phone: string;
  cr: string;
  companyName?: string | null;
  companyId?: number | null;
  total: number;
  city?: string;
  customerType?: string;
}

export const CustomersPage: React.FC = () => {
  const [customers, setCustomers] = useState<CustomerRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '+968', cr: '' });
  const [toast, setToast] = useState<{ message: string; type?: 'success' | 'error' } | null>(null);

  // Edit customer modal state
  const [editModal, setEditModal] = useState<{
    open: boolean;
    customer: CustomerRecord | null;
  }>({
    open: false,
    customer: null,
  });
  const [editFormData, setEditFormData] = useState({
    name: '',
    phone: '',
    cr: '',
    companyName: '',
    customerType: 'INDIVIDUAL',
  });
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Delete confirmation modal state
  const [confirmDeleteModal, setConfirmDeleteModal] = useState<{
    open: boolean;
    ids: string[];
    title: string;
    description: string;
  }>({
    open: false,
    ids: [],
    title: '',
    description: '',
  });
  const [isDeleting, setIsDeleting] = useState(false);

  const promptEditCustomer = (customer: CustomerRecord) => {
    setEditModal({ open: true, customer });
    setEditFormData({
      name: customer.name,
      phone: customer.phone,
      cr: customer.cr === '—' ? '' : customer.cr,
      companyName: customer.companyName || '',
      customerType: customer.customerType || 'INDIVIDUAL',
    });
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal.customer || !editFormData.name.trim()) return;
    setIsSavingEdit(true);
    try {
      const target = editModal.customer;
      const numId = target.numericId;

      if (numId) {
        const res = await fetch(`/api/customers/${numId}`, {
          method: 'PUT',
          headers: {
            ...YasminaApi.getAuthHeaders(),
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            fullNameAr: editFormData.name.trim(),
            phone: editFormData.phone.trim(),
            whatsapp: editFormData.phone.trim(),
            civilId: editFormData.cr.trim() || undefined,
            companyName: editFormData.companyName.trim() || undefined,
            crNumber: editFormData.cr.trim() || undefined,
            customerType: editFormData.customerType as 'INDIVIDUAL' | 'COMPANY',
          }),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          showToast(errData?.error?.message || 'فشل تحديث بيانات العميل', 'error');
          setIsSavingEdit(false);
          return;
        }
      }

      // Update in state
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === target.id
            ? {
                ...c,
                name: editFormData.name.trim(),
                phone: editFormData.phone.trim(),
                cr: editFormData.cr.trim() || '—',
                companyName: editFormData.companyName.trim() || null,
                customerType: editFormData.customerType,
              }
            : c
        )
      );

      setEditModal({ open: false, customer: null });
      showToast('تم تحديث بيانات العميل بنجاح');
      loadCustomers();
    } catch (_) {
      showToast('حدث خطأ أثناء تعديل بيانات العميل', 'error');
    } finally {
      setIsSavingEdit(false);
    }
  };

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const loadCustomers = async () => {
    setLoading(true);
    const map = new Map<string, CustomerRecord>();

    // 1. Fetch from /api/customers (backend PostgreSQL)
    try {
      const res = await fetch('/api/customers', {
        headers: YasminaApi.getAuthHeaders(),
      });
      if (res.ok) {
        const body = await res.json();
        const rows = body.data || body.customers || [];
        if (Array.isArray(rows)) {
          for (const r of rows) {
            const key = String(r.id);
            map.set(key, {
              id: key,
              numericId: typeof r.id === 'number' ? r.id : parseInt(String(r.id), 10) || undefined,
              name: r.fullNameAr || r.fullName || r.name || 'عميل مكتب سند',
              phone: r.phone || r.whatsapp || '+968',
              cr: r.crNumber || r.civilId || '—',
              companyName: r.companyName || null,
              companyId: r.companyId || null,
              total: Number(r.transactionsCount) || 1,
              customerType: r.customerType || 'INDIVIDUAL',
            });
          }
        }
      }
    } catch (_) {}

    // 2. Supplement from registered companies if not already represented
    try {
      const companies = YasminaApi.getCompanies();
      for (const c of companies) {
        const matchingCust = Array.from(map.values()).find((cust) => {
          if (cust.numericId && c.ownerCustomerId === cust.numericId) return true;
          const cPhone = (c.contactPhone || '').replace(/[^0-9]/g, '');
          const custPhone = cust.phone.replace(/[^0-9]/g, '');
          return cPhone && custPhone && (cPhone === custPhone || custPhone.endsWith(cPhone.slice(-8)));
        });

        if (matchingCust) {
          if (!matchingCust.companyName) {
            matchingCust.companyName = c.name;
          }
        } else {
          const compKey = `comp-${c.id}`;
          map.set(compKey, {
            id: compKey,
            numericId: typeof c.id === 'number' ? c.id : undefined,
            name: c.ownerName ? c.ownerName : c.name,
            phone: c.contactPhone || '+96890000000',
            cr: c.taxId || '—',
            companyName: c.name,
            companyId: typeof c.id === 'number' ? c.id : undefined,
            total: c.documentsCount || 1,
            city: c.city,
            customerType: 'COMPANY',
          });
        }
      }
    } catch (_) {}

    setCustomers(Array.from(map.values()));
    setLoading(false);
  };

  useEffect(() => {
    loadCustomers();
    window.addEventListener('yasmina_company_updated', loadCustomers);
    return () => window.removeEventListener('yasmina_company_updated', loadCustomers);
  }, []);

  const handleAddCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;
    try {
      const res = await fetch('/api/customers', {
        method: 'POST',
        headers: {
          ...YasminaApi.getAuthHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fullNameAr: formData.name.trim(),
          phone: formData.phone.trim(),
          whatsapp: formData.phone.trim(),
          civilId: formData.cr.trim() || undefined,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        showToast(errJson?.error?.message || 'فشل في حفظ العميل', 'error');
        return;
      }

      setShowAddModal(false);
      setFormData({ name: '', phone: '+968', cr: '' });
      showToast('تمت إضافة العميل بنجاح');
      loadCustomers();
    } catch (_) {
      showToast('حدث خطأ أثناء الاتصال بالخادم', 'error');
    }
  };

  // Selection helpers
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    if (selectedIds.size === filtered.length && filtered.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((c) => c.id)));
    }
  };

  const clearSelection = () => {
    setSelectedIds(new Set());
  };

  // Trigger individual deletion
  const promptDeleteSingle = (customer: CustomerRecord) => {
    setConfirmDeleteModal({
      open: true,
      ids: [customer.id],
      title: `حذف العميل "${customer.name}"`,
      description: 'سيتم نقل العميل إلى المحذوفات بأمان، مع الإبقاء على الفواتير والمعاملات السابقة محفوظة في النظام.',
    });
  };

  // Trigger bulk deletion
  const promptDeleteBulk = () => {
    if (selectedIds.size === 0) return;
    setConfirmDeleteModal({
      open: true,
      ids: Array.from(selectedIds),
      title: `حذف ${selectedIds.size} عملاء محددين`,
      description: `هل أنت متأكد من رغبتك في حذف ${selectedIds.size} من العملاء المحددين؟ سيتم نقلهم إلى المحذوفات بأمان مع الحفاظ على جميع المعاملات والفواتير المرتبطة بهم دون أي فقدان للبيانات.`,
    });
  };

  // Execute deletion
  const executeDelete = async () => {
    if (confirmDeleteModal.ids.length === 0) return;
    setIsDeleting(true);
    try {
      const targetIds = confirmDeleteModal.ids;
      const res = await fetch('/api/customers/bulk-delete', {
        method: 'POST',
        headers: {
          ...YasminaApi.getAuthHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ids: targetIds }),
      });

      if (res.ok) {
        showToast(
          targetIds.length === 1
            ? 'تم حذف العميل بنجاح ونقله للمحذوفات بأمان'
            : `تم حذف ${targetIds.length} عملاء بنجاح ونقلهم للمحذوفات بأمان`
        );
        setSelectedIds((prev) => {
          const next = new Set(prev);
          targetIds.forEach((id) => next.delete(id));
          return next;
        });
        setConfirmDeleteModal({ open: false, ids: [], title: '', description: '' });
        await loadCustomers();
      } else {
        const errData = await res.json().catch(() => ({}));
        showToast(errData?.error?.message || 'تعذر إتمام عملية الحذف', 'error');
      }
    } catch (_) {
      showToast('حدث خطأ أثناء حذف العميل', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const filtered = customers.filter((c) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      !q ||
      c.name.toLowerCase().includes(q) ||
      c.phone.toLowerCase().includes(q) ||
      c.cr.toLowerCase().includes(q) ||
      (c.companyName && c.companyName.toLowerCase().includes(q))
    );
  });

  const isAllSelected = filtered.length > 0 && filtered.every((c) => selectedIds.has(c.id));

  return (
    <div className="space-y-6 pb-16" dir="rtl">
      {/* Toast notification */}
      {toast && (
        <div
          className={`fixed top-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold border transition ${
            toast.type === 'error'
              ? 'bg-rose-950/95 border-rose-500/50 text-rose-200'
              : 'bg-emerald-950/95 border-emerald-500/50 text-emerald-200'
          }`}
        >
          {toast.type === 'error' ? (
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Users className="w-6 h-6 text-emerald-400" />
            دليل الزبائن وإدارة العملاء (Customer Directory)
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            سجل العملاء والمؤسسات المسجلة في مكتب سند مع إمكانية التحديد والحذف والربط الآلي مع واتساب
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadCustomers}
            disabled={loading}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium px-3.5 py-2.5 rounded-xl text-xs transition cursor-pointer border border-slate-700/50"
            title="تحديث البيانات"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-emerald-400' : ''}`} />
            <span>تحديث</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs transition shadow-md cursor-pointer hover:brightness-105"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة عميل جديد</span>
          </button>
        </div>
      </div>

      {/* Action / Search Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 shadow-md">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="بحث بالاسم أو الهاتف أو السجل التجاري..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end">
          {filtered.length > 0 && (
            <button
              onClick={handleSelectAll}
              className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 px-3 py-2 rounded-xl border border-slate-700/60 transition cursor-pointer"
            >
              {isAllSelected ? (
                <CheckSquare className="w-4 h-4 text-emerald-400" />
              ) : (
                <Square className="w-4 h-4 text-slate-400" />
              )}
              <span>{isAllSelected ? 'إلغاء تحديد الكل' : 'تحديد الكل'}</span>
            </button>
          )}

          <div className="text-xs text-slate-400 bg-slate-950/60 px-3 py-2 rounded-xl border border-slate-800">
            إجمالي العملاء: <span className="font-bold text-slate-200">{filtered.length}</span>
          </div>
        </div>
      </div>

      {/* Floating / Sticky Bulk Action Bar when items selected */}
      {selectedIds.size > 0 && (
        <div className="bg-gradient-to-r from-slate-900 via-rose-950/40 to-slate-900 border border-rose-500/40 p-4 rounded-2xl flex items-center justify-between gap-4 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-xs">
              {selectedIds.size}
            </div>
            <div>
              <p className="text-xs font-bold text-slate-100">
                تم تحديد <span className="text-rose-400">{selectedIds.size}</span> من العملاء
              </p>
              <p className="text-[11px] text-slate-400">يمكنك مسح العملاء المحددين دفعة واحدة بأمان</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={clearSelection}
              className="px-3 py-2 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition cursor-pointer"
            >
              إلغاء التحديد
            </button>

            <button
              onClick={promptDeleteBulk}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-xl shadow-lg transition cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>حذف العملاء المحددين ({selectedIds.size})</span>
            </button>
          </div>
        </div>
      )}

      {/* Customers Grid */}
      {filtered.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-12 text-center space-y-3">
          <Users className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-slate-300">لا يوجد عملاء مطابقون للبحث</h3>
          <p className="text-xs text-slate-500">
            {searchQuery ? 'جرب البحث بكلمة أخرى أو برقم هاتف مختلف' : 'لم يتم تسجيل أي عملاء بعد في النظام'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => {
            const isSelected = selectedIds.has(c.id);
            return (
              <div
                key={c.id}
                className={`relative bg-slate-900 border transition rounded-2xl p-5 space-y-3 shadow-lg ${
                  isSelected
                    ? 'border-emerald-500/80 bg-slate-900/90 ring-2 ring-emerald-500/20'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Top Row: Checkbox + Avatar + Name + Individual Delete */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 overflow-hidden">
                    {/* Multi-select Checkbox */}
                    <button
                      type="button"
                      onClick={() => handleToggleSelect(c.id)}
                      className="mt-1 shrink-0 text-slate-400 hover:text-emerald-400 transition cursor-pointer"
                      title={isSelected ? 'إلغاء تحديد' : 'تحديد العميل'}
                    >
                      {isSelected ? (
                        <CheckSquare className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <Square className="w-5 h-5 text-slate-500 hover:text-slate-300" />
                      )}
                    </button>

                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                      {c.name.charAt(0)}
                    </div>

                    <div className="overflow-hidden space-y-0.5">
                      <h3 className="font-bold text-slate-100 text-sm truncate" title={c.name}>
                        {c.name}
                      </h3>
                      <p className="text-xs text-slate-400 font-mono tracking-wide">{c.phone}</p>

                      {/* Distinctive Commercial Registration Badge under Name */}
                      {c.companyName ? (
                        <div
                          className="mt-1.5 flex items-center gap-1.5 text-xs text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2.5 py-1 rounded-lg w-fit font-semibold shadow-sm"
                          title={`مربوط بالسجل التجاري: ${c.companyName}`}
                        >
                          <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span className="truncate max-w-[200px]">السجل التجاري: {c.companyName}</span>
                        </div>
                      ) : (
                        <div className="mt-1 flex items-center gap-1 text-[11px] text-slate-500">
                          <span>عميل فردي (بدون سجل تجاري مرتبط)</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Card Actions: Edit & Delete */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => promptEditCustomer(c)}
                      className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition cursor-pointer"
                      title="تعديل بيانات العميل"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => promptDeleteSingle(c)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition cursor-pointer"
                      title="حذف العميل"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Details Box */}
                <div className="bg-slate-950/80 border border-slate-800/80 p-3 rounded-xl text-xs space-y-1.5 text-slate-300">
                  <p className="flex items-center justify-between">
                    <span className="text-slate-400">رقم السجل / الهوية:</span>
                    <span className="font-mono font-medium text-slate-200">{c.cr}</span>
                  </p>
                  <p className="flex items-center justify-between">
                    <span className="text-slate-400">عدد المعاملات:</span>
                    <span className="font-bold text-emerald-400">{c.total} معاملات</span>
                  </p>
                  {c.city && (
                    <p className="flex items-center justify-between">
                      <span className="text-slate-400">المدينة / المنطقة:</span>
                      <span className="text-slate-200">{c.city}</span>
                    </p>
                  )}
                </div>

                {/* Card Footer: WhatsApp + Edit Action */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                  <a
                    href={`https://wa.me/${c.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 flex items-center justify-center gap-1.5 bg-slate-800/90 hover:bg-slate-800 text-emerald-400 border border-emerald-500/20 hover:border-emerald-500/40 p-2.5 rounded-xl text-xs font-bold transition shadow-sm"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>تواصل عبر واتساب</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => promptEditCustomer(c)}
                    className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0"
                    title="تعديل بيانات العميل"
                  >
                    <Pencil className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تعديل</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Confirmation Modal for Safe Soft-Delete */}
      {confirmDeleteModal.open && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <span>{confirmDeleteModal.title}</span>
              </div>
              <button
                onClick={() => setConfirmDeleteModal({ open: false, ids: [], title: '', description: '' })}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{confirmDeleteModal.description}</p>

            <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-[11px] text-slate-400 space-y-1">
              <p className="font-semibold text-emerald-400">✓ حماية المعاملات والسجلات مفعلة:</p>
              <p>لن يتم حذف أي معاملات أو فواتير مسجلة مسبقاً، بل ستبقى محفوظة بأمان في النظام.</p>
            </div>

            <div className="pt-2 flex justify-end gap-2 text-xs">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setConfirmDeleteModal({ open: false, ids: [], title: '', description: '' })}
                className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 rounded-xl transition cursor-pointer"
              >
                إلغاء
              </button>

              <button
                type="button"
                disabled={isDeleting}
                onClick={executeDelete}
                className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl transition cursor-pointer shadow-lg disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>جاري الحذف...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>تأكيد الحذف</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm">تسجيل عميل جديد</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddCustomer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم العميل *:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: سالم بن عبد الله أو شركة مسقط للتجارة"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">رقم الهاتف *:</label>
                <input
                  type="text"
                  required
                  placeholder="+968 9123 4567"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">رقم السجل التجاري / الرقم المدني:</label>
                <input
                  type="text"
                  placeholder="مثال: 1029384"
                  value={formData.cr}
                  onChange={(e) => setFormData({ ...formData, cr: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-2 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl hover:bg-emerald-400 transition"
                >
                  حفظ العميل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Customer Modal */}
      {editModal.open && editModal.customer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <Pencil className="w-4 h-4 text-emerald-400" />
                <span>تعديل بيانات العميل</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditModal({ open: false, customer: null })}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم العميل / المسؤول *:</label>
                <input
                  type="text"
                  required
                  value={editFormData.name}
                  onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  placeholder="مثال: أحمد بن سالم الحارثي"
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">رقم الهاتف *:</label>
                <input
                  type="text"
                  required
                  value={editFormData.phone}
                  onChange={(e) => setEditFormData({ ...editFormData, phone: e.target.value })}
                  placeholder="+968 9123 4567"
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">الرقم المدني / رقم السجل التجاري (CR):</label>
                <input
                  type="text"
                  value={editFormData.cr}
                  onChange={(e) => setEditFormData({ ...editFormData, cr: e.target.value })}
                  placeholder="مثال: 1029384"
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم السجل التجاري / المنشأة المرتبطة:</label>
                <input
                  type="text"
                  value={editFormData.companyName}
                  onChange={(e) => setEditFormData({ ...editFormData, companyName: e.target.value })}
                  placeholder="مثال: شركة مسقط للخدمات والتجارة"
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">نوع العميل / التصنيف:</label>
                <select
                  value={editFormData.customerType}
                  onChange={(e) => setEditFormData({ ...editFormData, customerType: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl focus:outline-none focus:border-emerald-500"
                >
                  <option value="INDIVIDUAL">فردي (Individual)</option>
                  <option value="COMPANY">مؤسسة / شركة (Company)</option>
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditModal({ open: false, customer: null })}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSavingEdit}
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl transition cursor-pointer shadow-md disabled:opacity-50 flex items-center gap-1.5"
                >
                  {isSavingEdit ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>جاري الحفظ...</span>
                    </>
                  ) : (
                    <span>حفظ التعديلات</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
