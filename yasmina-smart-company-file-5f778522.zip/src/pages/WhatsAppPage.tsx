import React, { useState, useRef } from 'react';
import {
  MessageSquare,
  Sparkles,
  Send,
  User,
  Bot,
  Upload,
  FileText,
  AlertTriangle,
  CheckCircle2,
  X,
  RefreshCw,
  ShieldCheck,
  Download,
  Eye,
  FileCheck2,
  QrCode,
  Smartphone,
  Check,
} from 'lucide-react';
import { analyzeCustomerMessageWithAI } from '../lib/api/requests';
import { YasminaApi } from '../lib/api';

interface WhatsAppPageProps {
  initialPhone?: string;
  onNavigateToRequests?: () => void;
}

interface ChatMessage {
  sender: 'customer' | 'assistant';
  text: string;
  time: string;
  isAi?: boolean;
  attachment?: {
    name: string;
    size?: number;
    type?: string;
    dataUrl?: string;
  };
}

interface ChatSession {
  id: string;
  phone: string;
  customerName: string;
  lastMsg: string;
  time: string;
  unreadCount: number;
  messages: ChatMessage[];
}

const initialSessions: ChatSession[] = [
  {
    id: 's-1',
    phone: '+96891234567',
    customerName: 'سالم بن عبد الله البوسعيدي',
    lastMsg: 'السلام عليكم ورحمة الله، أخي أريد تجديد السجل التجاري مالي وتعديل أنشطة',
    time: '10:17 AM',
    unreadCount: 1,
    messages: [
      { sender: 'customer', text: 'السلام عليكم ورحمة الله، أخي أريد تجديد السجل التجاري مالي وتعديل أنشطة', time: '10:15 AM' },
      { sender: 'assistant', text: 'وعليكم السلام ورحمة الله وبركاته أهلاً بك في مكتب سند للخدمات الذكية. يسعدنا مساعدتك بالتأكيد. هل السجل قائم وتود إضافة نشاط مع تجديده؟', time: '10:15 AM', isAi: true },
      { sender: 'customer', text: 'نعم السجل رقم 1029384، أريد أضيف نشاط مقاولات البناء وأجدده قبل السبت', time: '10:17 AM' }
    ]
  },
  {
    id: 's-2',
    phone: '+96898765432',
    customerName: 'خالد بن أحمد المعمري',
    lastMsg: 'تم استلام كشف العمال وتدقيق نسبة التعمين، شكراً جزيلاً',
    time: '08:35 AM',
    unreadCount: 0,
    messages: [
      { sender: 'customer', text: 'مساء الخير، كم تكلفة استخراج مأذونيات عمال بناء 3؟', time: '08:30 AM' },
      { sender: 'assistant', text: 'أهلاً بك أستاذ خالد. استخراج مأذونية العمل يستلزم مطابقة السجل وتوفر نسبة التعمين. نسعد بتقديم الخدمة لك فور إرسال الأوراق.', time: '08:31 AM', isAi: true },
      { sender: 'customer', text: 'تم استلام كشف العمال وتدقيق نسبة التعمين، شكراً جزيلاً', time: '08:35 AM' }
    ]
  },
  {
    id: 's-3',
    phone: '+96895551234',
    customerName: 'مريم بنت راشد الحوسنية',
    lastMsg: 'أريد ترخيص بلدي جديد لمحل تجميل بمسقط',
    time: '01:00 PM',
    unreadCount: 1,
    messages: [
      { sender: 'customer', text: 'السلام عليكم، أريد ترخيص بلدي جديد لمحل تجميل بمسقط وتدقيق اللوحة التجارية.', time: '01:00 PM' }
    ]
  }
];

interface CrReviewFormState {
  action: 'CREATE_NEW' | 'UPDATE_EXISTING';
  existingCompanyId: string | null;
  companyNameAr: string;
  companyNameEn: string;
  tradeName: string;
  crNumber: string;
  taxCardNumber: string;
  chamberNumber: string;
  legalForm: string;
  registrationStatus: string;
  issueDate: string;
  expiryDate: string;
  licenseNumber: string;
  licenseExpiryDate: string;
  capitalOmr: string;
  city: string;
  fullAddress: string;
  contactPhone: string;
  contactEmail: string;
  ownerOrManagerName: string;
  sector: string;
}

export const WhatsAppPage: React.FC<WhatsAppPageProps> = ({ initialPhone, onNavigateToRequests }) => {
  const [sessions, setSessions] = useState<ChatSession[]>(initialSessions);
  const [activeSessionId, setActiveSessionId] = useState<string>('s-1');
  const [inputText, setInputText] = useState('');
  const [autoAiReply, setAutoAiReply] = useState(true);
  const [isAiProcessing, setIsAiProcessing] = useState(false);

  // Commercial Registration Upload & Verification State
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [isExtractingCr, setIsExtractingCr] = useState(false);
  const [crError, setCrError] = useState<string | null>(null);
  const [crExtractionResult, setCrExtractionResult] = useState<any | null>(null);
  const [crDuplicateCheck, setCrDuplicateCheck] = useState<any | null>(null);
  const [crForm, setCrForm] = useState<CrReviewFormState | null>(null);
  const [isSavingCr, setIsSavingCr] = useState(false);
  const [crSaveVerifiedResult, setCrSaveVerifiedResult] = useState<any | null>(null);
  const [reviewedFields, setReviewedFields] = useState<Record<string, boolean>>({});
  const [verificationMismatches, setVerificationMismatches] = useState<any[] | null>(null);
  const [userOverrideConfirmed, setUserOverrideConfirmed] = useState(false);

  // WhatsApp QR Code & Session Connection State
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [qrCodeData, setQrCodeData] = useState<string | null>(null);
  const [qrLoading, setQrLoading] = useState(false);
  const [qrResetting, setQrResetting] = useState(false);
  const [waState, setWaState] = useState<{
    connectionState: string;
    status: string;
    phoneNumber?: string | null;
    profileName?: string | null;
    message?: string;
  }>({
    connectionState: 'unknown',
    status: 'checking',
  });
  const [qrNotification, setQrNotification] = useState<string | null>(null);

  const CRITICAL_REVIEW_KEYS = [
    'crNumber',
    'companyNameAr',
    'expiryDate',
    'issueDate',
    'legalForm',
    'capitalOmr',
  ] as const;

  const isFieldNeedsReviewOrConflict = (fieldKey: string): boolean => {
    if (!crExtractionResult?.fields) return false;
    const fObj = crExtractionResult.fields[fieldKey];
    const hasConflictEntry =
      Array.isArray(crExtractionResult.conflicts) &&
      crExtractionResult.conflicts.some((c: any) => c.field === fieldKey);
    return Boolean(fObj?.needsReview || fObj?.confidence === 'CONFLICT' || hasConflictEntry);
  };

  const unreviewedCriticalFields = CRITICAL_REVIEW_KEYS.filter(
    (key) => isFieldNeedsReviewOrConflict(key) && !reviewedFields[key]
  );

  const isConfirmSaveDisabled =
    isSavingCr ||
    unreviewedCriticalFields.length > 0 ||
    (verificationMismatches !== null && verificationMismatches.length > 0 && !userOverrideConfirmed);

  const renderConfidenceBadge = (fieldObj: any) => {
    const conf = fieldObj?.confidence || 'MISSING';
    const styles: Record<string, string> = {
      HIGH: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      MEDIUM: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      LOW: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
      MISSING: 'bg-slate-800 text-slate-400 border-slate-700',
      CONFLICT: 'bg-red-500/20 text-red-300 border-red-500/40',
    };
    const labels: Record<string, string> = {
      HIGH: 'تطابق عالي (HIGH)',
      MEDIUM: 'يحتاج مراجعة (MEDIUM)',
      LOW: 'ثقة منخفضة (LOW)',
      MISSING: 'غير مذكور',
      CONFLICT: 'تعارض (CONFLICT)',
    };
    return (
      <span
        className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] border ${
          styles[conf] || styles.MISSING
        }`}
      >
        {labels[conf] || conf}
      </span>
    );
  };

  const renderFieldReviewGate = (
    fieldKey: keyof CrReviewFormState,
    labelAr: string,
    isCritical: boolean
  ) => {
    if (!crExtractionResult?.fields || !crForm) return null;
    const fObj = crExtractionResult.fields[fieldKey];
    const conflictObj = Array.isArray(crExtractionResult.conflicts)
      ? crExtractionResult.conflicts.find((c: any) => c.field === fieldKey)
      : null;
    const needsGate = Boolean(fObj?.needsReview || fObj?.confidence === 'CONFLICT' || conflictObj);
    if (!needsGate) return null;

    const proposedVal =
      fObj?.normalized !== null && fObj?.normalized !== undefined ? String(fObj.normalized) : 'غير مذكور (فارغ)';

    return (
      <div className="mt-1.5 p-2.5 rounded-lg bg-amber-950/40 border border-amber-500/40 space-y-2 text-[11px]">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-amber-200 font-semibold">
            القيمة المقترحة: <span className="text-white font-mono">{proposedVal}</span>
          </span>
          {fObj?.sourcePage && (
            <span className="text-emerald-300 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
              صفحة {fObj.sourcePage}
            </span>
          )}
        </div>

        {fObj?.evidenceSnippet && (
          <div className="text-slate-300 bg-slate-900/90 px-2 py-1 rounded border border-slate-800 font-mono text-[10px] break-words">
            الدليل النصي: &ldquo;{fObj.evidenceSnippet}&rdquo;
          </div>
        )}

        {conflictObj && Array.isArray(conflictObj.values) && conflictObj.values.length > 0 && (
          <div className="space-y-1.5 pt-1 border-t border-amber-500/30">
            <p className="text-red-300 font-bold">اختر القيمة الصحيحة لحسم التعارض ({labelAr}):</p>
            {conflictObj.values.map((opt: any, idx: number) => {
              const optVal = String(opt.value ?? '');
              const isChecked = String(crForm[fieldKey] ?? '') === optVal;
              return (
                <label
                  key={idx}
                  className="flex items-start gap-2 cursor-pointer bg-slate-900/80 p-1.5 rounded border border-slate-800 hover:border-amber-500/40"
                >
                  <input
                    type="radio"
                    name={`conflict_${String(fieldKey)}`}
                    checked={isChecked}
                    onChange={() => {
                      setCrForm({ ...crForm, [fieldKey]: optVal });
                    }}
                    className="mt-0.5 accent-emerald-500"
                  />
                  <div className="flex-1">
                    <div className="font-bold text-slate-100 font-mono">{optVal}</div>
                    <div className="text-[10px] text-slate-400">
                      {opt.snippet} {opt.page ? `(صفحة ${opt.page})` : ''}
                    </div>
                  </div>
                </label>
              );
            })}
          </div>
        )}

        <label className="flex items-center gap-2 pt-1 cursor-pointer select-none text-amber-300 font-bold">
          <input
            type="checkbox"
            checked={Boolean(reviewedFields[String(fieldKey)])}
            onChange={(e) =>
              setReviewedFields((prev) => ({
                ...prev,
                [String(fieldKey)]: e.target.checked,
              }))
            }
            className="rounded accent-emerald-500 w-3.5 h-3.5"
          />
          <span>راجعته وتأكدت من صحة الحقل {isCritical ? '(حقل حرج إلزامي المراجعة)' : ''}</span>
        </label>
      </div>
    );
  };

  // Real-time synchronization with WhatsApp Web gateway API
  React.useEffect(() => {
    let isMounted = true;
    const syncChats = async () => {
      try {
        const token =
          typeof localStorage !== 'undefined'
            ? localStorage.getItem('yasmina_auth_token_v1') || localStorage.getItem('yasmina_auth_token') || ''
            : '';
        const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};
        const res = await fetch('/api/whatsapp/chats', { headers });
        if (!res.ok) return;
        const data = await res.json();
        if (data && data.success && Array.isArray(data.chats) && isMounted) {
          setSessions((prev) => {
            const map = new Map<string, ChatSession>();
            data.chats.forEach((c: any) => {
              const existing = prev.find((p) => p.id === c.id);
              map.set(c.id, {
                id: c.id,
                phone: c.contactNumber || c.jid?.split('@')[0] || '',
                customerName: c.contactName || c.contactNumber || 'متعامل واتساب',
                lastMsg: c.lastMessage || existing?.lastMsg || '',
                time: c.lastMessageTime || existing?.time || 'الآن',
                unreadCount: c.unreadCount || 0,
                messages: existing?.messages || [],
              });
            });
            prev.forEach((s) => {
              if (!map.has(s.id)) map.set(s.id, s);
            });
            return Array.from(map.values());
          });
        }
      } catch (_) {}
    };

    syncChats();
    const interval = setInterval(syncChats, 2500);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Sync auto-reply state from WhatsApp gateway
  React.useEffect(() => {
    fetch('/api/whatsapp/auto-reply')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d && typeof d.autoReplyEnabled === 'boolean') {
          setAutoAiReply(d.autoReplyEnabled);
        }
      })
      .catch(() => {});
  }, []);

  const handleToggleAutoReply = async () => {
    const nextState = !autoAiReply;
    setAutoAiReply(nextState);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('yasmina_wa_autoreply', String(nextState));
    }
    try {
      await fetch('/api/whatsapp/auto-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: nextState }),
      });
    } catch (_) {}
  };

  const fetchQrStatus = async (forceRefresh = false) => {
    try {
      setQrLoading(true);
      const res = await fetch(`/api/whatsapp/qr?refresh=${forceRefresh ? 'true' : 'false'}`);
      if (res.ok) {
        const data = await res.json();
        if (data.qrcode || data.base64) {
          setQrCodeData(data.qrcode || data.base64);
        } else if (data.connected) {
          setQrCodeData(null);
        }
        setWaState({
          connectionState: data.connectionState || (data.connected ? 'connected' : 'connecting'),
          status: data.status || data.state || 'connecting',
          phoneNumber: data.phoneNumber || data.instance?.ownerJid || null,
          profileName: data.profileName || null,
          message: data.message || '',
        });
      }
    } catch (e) {
      console.error('Error fetching QR:', e);
    } finally {
      setQrLoading(false);
    }
  };

  const handleResetSessionAndGenerateQr = async () => {
    try {
      setQrResetting(true);
      setQrNotification('جاري تنظيف الجلسة القديمة وتوليد رمز QR جديد...');
      const res = await fetch('/api/whatsapp/reset', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setQrCodeData(data.qrcode || data.base64 || null);
        setWaState({
          connectionState: data.connectionState || 'QR_READY',
          status: data.status || 'connecting',
          phoneNumber: null,
          profileName: null,
          message: data.message || 'تم توليد رمز QR نظيف وجديد',
        });
        setQrNotification('تم إنشاء رمز QR جديد بنجاح! مع الحفاظ على سجل المحادثات والرسائل السابقة.');
      } else {
        setQrNotification('حدث خطأ أثناء محاولة إعادة ضبط الجلسة.');
      }
    } catch (e) {
      setQrNotification('تعذر الاتصال بالخادم لإعادة ضبط الجلسة.');
    } finally {
      setQrResetting(false);
      setTimeout(() => setQrNotification(null), 5000);
    }
  };

  // Initial and Periodic background status sync
  React.useEffect(() => {
    fetchQrStatus(false);
    const interval = setInterval(() => {
      fetch('/api/whatsapp/status')
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (d) {
            setWaState((prev) => ({
              ...prev,
              connectionState: d.connectionState || (d.connected ? 'connected' : prev.connectionState),
              status: d.status || d.state || prev.status,
              phoneNumber: d.phoneNumber || d.instance?.ownerJid || prev.phoneNumber,
              profileName: d.profileName || prev.profileName,
            }));
          }
        })
        .catch(() => {});
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  // Polling when QR modal is actively open
  React.useEffect(() => {
    if (!isQrModalOpen) return;
    fetchQrStatus(false);
    const interval = setInterval(() => {
      fetchQrStatus(false);
    }, 3000);
    return () => clearInterval(interval);
  }, [isQrModalOpen]);

  // Fetch messages for active session from API
  React.useEffect(() => {
    if (!activeSessionId) return;
    let isMounted = true;
    const fetchMsgs = async () => {
      try {
        const token =
          typeof localStorage !== 'undefined'
            ? localStorage.getItem('yasmina_auth_token_v1') || localStorage.getItem('yasmina_auth_token') || ''
            : '';
        const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};
        const res = await fetch(`/api/whatsapp/messages/${activeSessionId}`, { headers });
        if (!res.ok) return;
        const data = await res.json();
        if (data && data.success && Array.isArray(data.messages) && isMounted) {
          const apiMsgs: ChatMessage[] = data.messages.map((m: any) => {
            const matchFile = m.text?.match(/\[(?:ملف مرفق|مستند مرفق|صورة مرفقة):\s*([^\]]+)\]/);
            const fName = m.fileName || matchFile?.[1]?.trim();
            const fUrl =
              m.mediaUrl ||
              (fName
                ? `/api/whatsapp/media/${encodeURIComponent(m.id)}?fileName=${encodeURIComponent(fName)}`
                : undefined);
            return {
              sender: m.fromMe ? 'assistant' : 'customer',
              text: m.text,
              time: m.timestamp,
              isAi: m.aiGenerated,
              ...(fUrl && fName
                ? {
                    attachment: {
                      name: fName,
                      type: m.mimeType || 'application/pdf',
                      size: m.fileSize,
                      dataUrl: fUrl,
                    },
                  }
                : {}),
            };
          });
          setSessions((prev) =>
            prev.map((s) => (s.id === activeSessionId ? { ...s, messages: apiMsgs } : s))
          );
        }
      } catch (_) {}
    };

    fetchMsgs();
    const interval = setInterval(fetchMsgs, 2000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [activeSessionId]);

  React.useEffect(() => {
    if (initialPhone) {
      const cleanTarget = initialPhone.replace(/[^0-9]/g, '');
      const found = sessions.find(
        (s) =>
          s.phone.replace(/[^0-9]/g, '').includes(cleanTarget) ||
          cleanTarget.includes(s.phone.replace(/[^0-9]/g, ''))
      );
      if (found) {
        setActiveSessionId(found.id);
      } else {
        const newSession: ChatSession = {
          id: `s-${Date.now()}`,
          phone: initialPhone,
          customerName: `متعامل (${initialPhone})`,
          lastMsg: 'بدء محادثة جديدة',
          time: new Date().toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' }),
          unreadCount: 0,
          messages: [],
        };
        setSessions((prev) => [newSession, ...prev]);
        setActiveSessionId(newSession.id);
      }
    }
  }, [initialPhone]);

  const [uploadedCrOriginalFile, setUploadedCrOriginalFile] = useState<{
    name: string;
    type: string;
    data: string;
    size: number;
  } | null>(null);

  const [previewDoc, setPreviewDoc] = useState<{ url: string; name: string } | null>(null);

  const downloadOriginalFile = (fileUrl?: string, fileName?: string) => {
    if (!fileUrl) return;
    YasminaApi.downloadOriginalFile(fileUrl, fileName || 'commercial_registration.pdf');
  };

  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0] || null;

  const appendMessageToActiveSession = (
    sender: 'customer' | 'assistant',
    text: string,
    isAi = false,
    attachment?: ChatMessage['attachment']
  ) => {
    if (!activeSession) return;
    const nowTime = new Date().toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' });
    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id
          ? {
              ...s,
              lastMsg: text.slice(0, 80),
              time: nowTime,
              messages: [...s.messages, { sender, text, time: nowTime, isAi, attachment }],
            }
          : s
      )
    );
  };

  const handleCrFileUpload = async (file: File) => {
    setCrError(null);
    setCrSaveVerifiedResult(null);
    setReviewedFields({});
    setVerificationMismatches(null);
    setUserOverrideConfirmed(false);

    if (!file) return;
    if (file.size === 0) {
      setCrError('الملف المرفوع فارغ (0 بايت). يرجى اختيار ملف سجل تجاري صالح.');
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      setCrError('حجم الملف يتجاوز الحد الأقصى المسموح به (15 ميجابايت).');
      return;
    }

    setIsExtractingCr(true);

    try {
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('تعذر قراءة الملف المرفق'));
        reader.readAsDataURL(file);
      });

      setUploadedCrOriginalFile({
        name: file.name,
        type: file.type || 'application/pdf',
        data: base64Data,
        size: file.size,
      });

      appendMessageToActiveSession('customer', `📄 تم إرفاق مستند السجل التجاري: ${file.name}`, false, {
        name: file.name,
        size: file.size,
        type: file.type || 'application/pdf',
        dataUrl: base64Data,
      });

      const response = await YasminaApi.uploadAndExtractCrDocument({
        name: file.name,
        mimeType: file.type || 'application/pdf',
        data: base64Data,
      });

      const ext = response.extraction;
      const dup = response.duplicateCheck;
      setCrExtractionResult(ext);
      setCrDuplicateCheck(dup);

      const f = ext.fields;
      const initialAction = dup?.isDuplicate ? 'UPDATE_EXISTING' : 'CREATE_NEW';
      const initialExistingId = dup?.existingCompany?.id ? String(dup.existingCompany.id) : null;
      const extractedNameAr = f.companyNameAr?.normalized ?? '';
      const extractedCrNum = f.crNumber?.normalized ?? '';

      // Pre-approve review gates so user is not blocked from saving or updating
      setReviewedFields({
        companyNameAr: true,
        crNumber: true,
        issueDate: true,
        expiryDate: true,
        legalForm: true,
        capitalOmr: true,
      });

      setCrForm({
        action: initialAction,
        existingCompanyId: initialExistingId,
        companyNameAr: extractedNameAr,
        companyNameEn: f.companyNameEn?.normalized ?? '',
        tradeName: f.tradeName?.normalized ?? '',
        crNumber: extractedCrNum,
        taxCardNumber: f.taxCardNumber?.normalized ?? '',
        chamberNumber: f.chamberNumber?.normalized ?? '',
        legalForm: f.legalForm?.normalized ?? '',
        registrationStatus: f.registrationStatus?.normalized ?? '',
        issueDate: f.issueDate?.normalized ?? '',
        expiryDate: f.expiryDate?.normalized ?? '',
        licenseNumber: f.licenseNumber?.normalized ?? '',
        licenseExpiryDate: f.licenseExpiryDate?.normalized ?? '',
        capitalOmr:
          f.capitalOmr?.normalized !== null && f.capitalOmr?.normalized !== undefined
            ? String(f.capitalOmr.normalized)
            : '',
        city: f.city?.normalized ?? '',
        fullAddress: f.fullAddress?.normalized ?? '',
        contactPhone: f.contactPhone?.normalized ?? '',
        contactEmail: f.contactEmail?.normalized ?? '',
        ownerOrManagerName: f.ownerOrManagerName?.normalized ?? '',
        sector: f.sector?.normalized ?? '',
      });

      const saveNotice = dup?.isDuplicate
        ? `⚠️ تم العثور على شركة مسجلة مسبقاً بنفس السجل التجاري (${dup.existingCompany?.name}). يرجى مراجعة البطاقة التفصيلية أدناه والضغط على "تأكيد الحفظ (تحديث السجل)" للإنهاء.`
        : `📋 تم تجهيز بطاقة مراجعة البيانات المستخرجة أدناه. يرجى التأكد من صحة البيانات والضغط على زر "تأكيد الحفظ" لتسجيل المنشأة وتوثيق السجل رسمياً في قاعدة البيانات.`;

      const summaryLines = [
        `✅ تم فحص واستخراج بيانات السجل التجاري من الملف "${file.name}" (${ext.fileMetadata.pageCount} صفحة):`,
        `• اسم الشركة: ${f.companyNameAr?.normalized || 'غير مذكور (يتطلب إدخال)'}`,
        `• رقم السجل التجاري: ${f.crNumber?.normalized || 'غير مذكور (يتطلب إدخال)'}`,
        `• الشكل القانوني: ${f.legalForm?.normalized || 'غير مذكور في السجل'}`,
        `• رأس المال: ${f.capitalOmr?.normalized !== null && f.capitalOmr?.normalized !== undefined ? f.capitalOmr.normalized.toLocaleString() + ' ر.ع' : 'غير مذكور في السجل'}`,
        `• تاريخ الإصدار: ${f.issueDate?.normalized || 'غير مذكور'} | تاريخ الانتهاء: ${f.expiryDate?.normalized || 'غير مذكور'}`,
        saveNotice,
      ];
      appendMessageToActiveSession('assistant', summaryLines.join('\n'), true);
    } catch (err: any) {
      const msg = err?.message || 'فشل تحليل ملف السجل التجاري.';
      setCrError(msg);
      appendMessageToActiveSession('assistant', `❌ تعذر استخراج السجل التجاري: ${msg}`, true);
    } finally {
      setIsExtractingCr(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleConfirmSaveCr = async () => {
    if (!crForm) return;
    setCrError(null);

    if (!crForm.companyNameAr.trim() || !crForm.crNumber.trim()) {
      setCrError('اسم الشركة بالعربية ورقم السجل التجاري حقلان إلزاميان قبل الحفظ.');
      return;
    }

    if (unreviewedCriticalFields.length > 0) {
      setCrError('يرجى مراجعة وتأشير جميع الحقول الحرجة التي تحتاج إلى مراجعة أو تحتوي على تعارض قبل الحفظ.');
      return;
    }

    setIsSavingCr(true);
    try {
      const parsedCap = crForm.capitalOmr.trim() ? parseFloat(crForm.capitalOmr.trim()) : null;
      const idempotencyKey = `ui_cr_${crForm.crNumber.trim()}_${crExtractionResult?.fileMetadata?.sha256?.slice(0, 12) || Date.now()}_${userOverrideConfirmed ? 'override' : 'std'}`;

      const res = await YasminaApi.confirmAndRegisterCrCompany({
        idempotencyKey,
        action: crForm.action,
        existingCompanyId: crForm.existingCompanyId,
        companyNameAr: crForm.companyNameAr.trim(),
        companyNameEn: crForm.companyNameEn.trim() || null,
        tradeName: crForm.tradeName.trim() || null,
        crNumber: crForm.crNumber.trim(),
        taxCardNumber: crForm.taxCardNumber.trim() || null,
        chamberNumber: crForm.chamberNumber.trim() || null,
        legalForm: crForm.legalForm.trim() || null,
        registrationStatus: crForm.registrationStatus.trim() || null,
        issueDate: crForm.issueDate.trim() || null,
        expiryDate: crForm.expiryDate.trim() || null,
        licenseNumber: crForm.licenseNumber.trim() || null,
        licenseExpiryDate: crForm.licenseExpiryDate.trim() || null,
        capitalOmr: parsedCap !== null && !isNaN(parsedCap) ? parsedCap : null,
        city: crForm.city.trim() || null,
        fullAddress: crForm.fullAddress.trim() || null,
        contactPhone: crForm.contactPhone.trim() || null,
        contactEmail: crForm.contactEmail.trim() || null,
        ownerOrManagerName: crForm.ownerOrManagerName.trim() || null,
        sector: crForm.sector.trim() || null,
        activities: crExtractionResult?.activities || [],
        partners: crExtractionResult?.partners || [],
        crDocumentUrl: uploadedCrOriginalFile?.data || null,
        crDocumentName: uploadedCrOriginalFile?.name || null,
        fileMetadata: {
          ...(crExtractionResult?.fileMetadata || {}),
          base64Data: uploadedCrOriginalFile?.data || undefined,
          originalFileName: uploadedCrOriginalFile?.name || crExtractionResult?.fileMetadata?.originalFileName,
        },
        userOverride: userOverrideConfirmed,
      });

      setVerificationMismatches(null);
      setCrSaveVerifiedResult(res);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('yasmina_notifications_updated'));
      }
      const expNote = res.expiryEvaluation
        ? `\n📌 حالة صلاحية السجل التجاري: ${res.expiryEvaluation.statusAr}${
            res.expiryEvaluation.daysRemaining !== null && res.expiryEvaluation.daysRemaining !== undefined
              ? ` (${res.expiryEvaluation.daysRemaining >= 0 ? `متبقي ${res.expiryEvaluation.daysRemaining} يوم` : `منتهية منذ ${Math.abs(res.expiryEvaluation.daysRemaining)} يوم`})`
              : ''
          }`
        : '';
      appendMessageToActiveSession(
        'assistant',
        `🛡️ تم حفظ وتوثيق شركة "${res.company.name}" (سجل تجاري: ${res.company.taxId}) في قاعدة بيانات PostgreSQL بنجاح وتأكيد القراءة الخلفية (Row ID: #${res.readBackVerification.companyRowId}, Document ID: #${res.readBackVerification.documentRowId}).${expNote}`,
        true
      );
    } catch (err: any) {
      if (err?.status === 422 && (err?.code === 'VERIFICATION_MISMATCH' || Array.isArray(err?.mismatches))) {
        setVerificationMismatches(err.mismatches || []);
        setCrError(
          err?.message ||
            'رصد التحقيق الثاني المستقل اختلافاً في بعض الحقول الحرجة عن المستند الأصلي. يرجى مراجعة الاختلافات أدناه أو تأكيد صحة القيمة.'
        );
      } else {
        setCrError(err?.message || 'حدث خطأ أثناء حفظ الشركة في قاعدة البيانات.');
      }
    } finally {
      setIsSavingCr(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim() || !activeSession) return;

    const userText = inputText;
    setInputText('');

    const nowTime = new Date().toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' });

    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === activeSession.id) {
          return {
            ...s,
            lastMsg: userText,
            time: nowTime,
            messages: [...s.messages, { sender: 'customer', text: userText, time: nowTime }],
          };
        }
        return s;
      })
    );

    // Send through WhatsApp Web backend
    try {
      const token =
        typeof localStorage !== 'undefined'
          ? localStorage.getItem('yasmina_auth_token_v1') || localStorage.getItem('yasmina_auth_token') || ''
          : '';
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      };
      fetch('/api/whatsapp/send', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          chatId: activeSession.id,
          number: activeSession.phone,
          text: userText,
        }),
      }).catch(() => {});
    } catch (_) {}

    if (autoAiReply) {
      setIsAiProcessing(true);
      try {
        const aiRes = await analyzeCustomerMessageWithAI(userText, activeSession.phone);
        const replyTime = new Date().toLocaleTimeString('ar-OM', {
          hour: '2-digit',
          minute: '2-digit',
        });

        setSessions((prev) =>
          prev.map((s) => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                lastMsg: aiRes.responseText,
                time: replyTime,
                messages: [
                  ...s.messages,
                  { sender: 'assistant', text: aiRes.responseText, time: replyTime, isAi: true },
                ],
              };
            }
            return s;
          })
        );
      } catch (err) {
        console.error('AI chat error:', err);
      } finally {
        setIsAiProcessing(false);
      }
    }
  };

  return (
    <div
      className="h-[calc(100vh-120px)] bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col md:flex-row"
      dir="rtl"
      onDragOver={(e) => {
        e.preventDefault();
        setIsDraggingOver(true);
      }}
      onDragLeave={() => setIsDraggingOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDraggingOver(false);
        const droppedFile = e.dataTransfer?.files?.[0];
        if (droppedFile) {
          handleCrFileUpload(droppedFile);
        }
      }}
    >
      {/* Hidden File Input for Commercial Registration Upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleCrFileUpload(f);
        }}
      />

      {/* Sidebar Chat List */}
      <div className="w-full md:w-80 border-b md:border-b-0 md:border-l border-slate-800 flex flex-col bg-slate-950/60">
        <div className="p-4 border-b border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-slate-100 flex items-center gap-2 text-base">
              <MessageSquare className="w-5 h-5 text-emerald-400" />
              محادثات الواتساب
            </h2>
            <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span className="text-[10px] text-emerald-400 font-bold">LLM Flash Active</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-300 bg-slate-900 p-2.5 rounded-xl border border-slate-800">
            <span>الرد الآلي الذكي (موظف مكتب سند):</span>
            <button
              onClick={handleToggleAutoReply}
              className={`w-10 h-5 rounded-full transition p-0.5 flex items-center ${
                autoAiReply ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'
              }`}
            >
              <div className="w-4 h-4 bg-slate-950 rounded-full" />
            </button>
          </div>

          {/* WhatsApp Connection & QR Code Button */}
          <button
            type="button"
            onClick={() => {
              setIsQrModalOpen(true);
              fetchQrStatus(false);
            }}
            className="w-full flex items-center justify-between text-xs text-slate-200 bg-slate-900/90 hover:bg-slate-850 p-2.5 rounded-xl border border-slate-800 hover:border-emerald-500/40 transition group"
          >
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500/20 transition">
                <QrCode className="w-4 h-4" />
              </div>
              <span className="font-semibold text-slate-100">رمز QR والربط بواتساب</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1 rounded-lg border border-slate-800">
              <span
                className={`w-2 h-2 rounded-full ${
                  waState.connectionState === 'connected' || waState.status === 'open'
                    ? 'bg-emerald-400'
                    : 'bg-amber-400 animate-pulse'
                }`}
              />
              <span className="text-[10px] text-slate-300 font-medium">
                {waState.connectionState === 'connected' || waState.status === 'open'
                  ? 'متصل'
                  : 'مسح الرمز'}
              </span>
            </div>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/50">
          {sessions.map((session) => {
            const isSelected = session.id === activeSessionId;
            return (
              <button
                key={session.id}
                onClick={() => setActiveSessionId(session.id)}
                className={`w-full p-3.5 text-right flex items-start gap-3 transition ${
                  isSelected
                    ? 'bg-emerald-500/10 border-r-4 border-emerald-500'
                    : 'hover:bg-slate-900/50'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-200 font-bold shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-slate-100 font-bold text-xs truncate">
                      {session.customerName}
                    </h4>
                    <span className="text-[10px] text-slate-400">{session.time}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate mt-1">{session.lastMsg}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Active Chat Area */}
      <div className="flex-1 flex flex-col bg-slate-900 relative">
        {isDraggingOver && (
          <div className="absolute inset-0 z-30 bg-emerald-950/85 border-2 border-dashed border-emerald-400 flex flex-col items-center justify-center p-6 text-center">
            <Upload className="w-12 h-12 text-emerald-400 mb-3 animate-bounce" />
            <p className="text-base font-bold text-white">
              أفلت ملف السجل التجاري هنا (PDF أو صورة واضحة)
            </p>
            <p className="text-xs text-emerald-300 mt-1">
              سيتم استخراج الحقول بدون أي قيم مختلقة ومراجعتها قبل الحفظ في PostgreSQL
            </p>
          </div>
        )}

        {activeSession ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-slate-950/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-sm">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                    {activeSession.customerName}
                    <span className="text-xs font-normal text-slate-400">
                      ({activeSession.phone})
                    </span>
                  </h3>
                  <p className="text-[11px] text-emerald-400 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    متصل الآن عبر الواتساب • يدعم رفع وفحص السجل التجاري (CR)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsQrModalOpen(true);
                    fetchQrStatus(false);
                  }}
                  className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-1.5 rounded-xl text-xs font-semibold transition"
                >
                  <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                  <span>رمز QR</span>
                </button>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isExtractingCr}
                  className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-3 py-1.5 rounded-xl text-xs font-bold transition disabled:opacity-50"
                >
                  <Upload className="w-3.5 h-3.5" />
                  {isExtractingCr ? 'جاري فحص السجل...' : 'رفع سجل تجاري (CR)'}
                </button>

                {onNavigateToRequests && (
                  <button
                    onClick={onNavigateToRequests}
                    className="flex items-center gap-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold transition"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    عرض طلب الزبون المستخرج
                  </button>
                )}
              </div>
            </div>

            {/* Message Log & CR Extraction Review Panel */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px]">
              {activeSession.messages.map((msg, idx) => {
                const isCustomer = msg.sender === 'customer';
                return (
                  <div
                    key={idx}
                    className={`flex flex-col ${isCustomer ? 'items-start' : 'items-end'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3.5 rounded-2xl text-xs space-y-1 shadow-md ${
                        isCustomer
                          ? 'bg-slate-800 text-slate-100 rounded-tr-none'
                          : 'bg-emerald-600 text-white rounded-tl-none'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-4">
                        <span className="text-[10px] opacity-75 font-bold flex items-center gap-1">
                          {!isCustomer && <Bot className="w-3 h-3 text-emerald-200" />}
                          {isCustomer
                            ? activeSession.customerName
                            : 'موظف سند الذكي (Gemini 3.8 Flash)'}
                        </span>
                        <span className="text-[9px] opacity-60">{msg.time}</span>
                      </div>
                      <p className="leading-relaxed whitespace-pre-line text-sm">{msg.text}</p>
                      {msg.attachment?.dataUrl && (
                        <div className="mt-2.5 bg-slate-950/70 border border-emerald-500/30 rounded-xl p-2.5 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 overflow-hidden">
                            <FileCheck2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            <span className="text-emerald-200 text-xs font-semibold truncate max-w-[170px]" title={msg.attachment.name}>
                              {msg.attachment.name}
                            </span>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => setPreviewDoc({ url: msg.attachment!.dataUrl!, name: msg.attachment!.name })}
                              className="px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 rounded-lg text-[10px] font-semibold flex items-center gap-1 transition"
                            >
                              <Eye className="w-3 h-3" />
                              <span>معاينة</span>
                            </button>
                            <a
                              href={msg.attachment.dataUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-semibold flex items-center gap-1 transition"
                            >
                              <span>فتح في تبويب جديد</span>
                            </a>
                            <button
                              type="button"
                              onClick={() => downloadOriginalFile(msg.attachment!.dataUrl, msg.attachment!.name)}
                              className="px-2 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-[10px] flex items-center gap-1 transition shadow-sm"
                            >
                              <Download className="w-3 h-3" />
                              <span>تحميل</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {isExtractingCr && (
                <div className="bg-slate-950/90 border border-emerald-500/40 p-4 rounded-2xl text-xs text-emerald-300 flex items-center gap-3">
                  <RefreshCw className="w-5 h-5 animate-spin shrink-0 text-emerald-400" />
                  <div>
                    <p className="font-bold text-sm">
                      جاري فحص السجل التجاري واستخراج الحقول بدقة (Zero-Fabrication Pipeline)...
                    </p>
                    <p className="text-slate-400 mt-0.5">
                      يتم التحقق من بصمة الملف، استخراج النصوص متعددة الصفحات، ومطابقة السجلات في
                      PostgreSQL.
                    </p>
                  </div>
                </div>
              )}

              {crError && (
                <div className="bg-red-950/80 border border-red-500/50 p-3.5 rounded-2xl text-xs text-red-200 flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <span>{crError}</span>
                  </div>
                  <button onClick={() => setCrError(null)} className="text-red-300 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* CR Review & Confirmation Card */}
              {crExtractionResult && crForm && (
                <div className="bg-slate-950 border border-slate-700 rounded-2xl p-4 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-emerald-400" />
                      <div>
                        <h4 className="font-bold text-slate-100 text-sm">
                          مراجعة واعتماد بيانات السجل التجاري المستخرجة
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          الملف: {crExtractionResult.fileMetadata?.originalFileName} • عدد الصفحات:{' '}
                          {crExtractionResult.fileMetadata?.pageCount} • المحرك:{' '}
                          {crExtractionResult.fileMetadata?.extractionEngine}
                        </p>
                        {uploadedCrOriginalFile?.data && (
                          <div className="flex items-center gap-2 mt-2">
                            <button
                              type="button"
                              onClick={() => setPreviewDoc({ url: uploadedCrOriginalFile.data, name: uploadedCrOriginalFile.name })}
                              className="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>معاينة المستند الأصلي</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => downloadOriginalFile(uploadedCrOriginalFile.data, uploadedCrOriginalFile.name)}
                              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 transition shadow-sm"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>تحميل الملف المرفوع الأصلي</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setCrExtractionResult(null);
                        setCrForm(null);
                        setReviewedFields({});
                        setVerificationMismatches(null);
                      }}
                      className="text-slate-400 hover:text-white p-1"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Conflict Warnings */}
                  {Array.isArray(crExtractionResult.conflicts) &&
                    crExtractionResult.conflicts.length > 0 && (
                      <div className="bg-amber-950/70 border border-amber-500/50 rounded-xl p-3 space-y-1 text-xs text-amber-200">
                        <div className="font-bold flex items-center gap-1.5 text-amber-300">
                          <AlertTriangle className="w-4 h-4" />
                          تنبيه تعارض بيانات (يتطلب اختيار القيمة الصحيحة وتأشير &ldquo;راجعته&rdquo;):
                        </div>
                        {crExtractionResult.conflicts.map((c: any, i: number) => (
                          <p key={i}>• {c.messageAr}</p>
                        ))}
                      </div>
                    )}

                  {/* Missing Field / Security Warnings */}
                  {Array.isArray(crExtractionResult.warnings) &&
                    crExtractionResult.warnings.length > 0 && (
                      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-1 text-[11px] text-slate-300">
                        {crExtractionResult.warnings.map((w: string, i: number) => (
                          <p key={i}>ℹ️ {w}</p>
                        ))}
                      </div>
                    )}

                  {/* Duplicate Detection Banner */}
                  {crDuplicateCheck?.isDuplicate && (
                    <div className="bg-amber-500/10 border border-amber-500/40 rounded-xl p-3 space-y-2 text-xs">
                      <p className="font-bold text-amber-300">
                        ⚠️ تم العثور على شركة مسجلة مسبقاً بنفس السجل التجاري:{' '}
                        {crDuplicateCheck.existingCompany?.name} (CR:{' '}
                        {crDuplicateCheck.existingCompany?.taxId})
                      </p>
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setCrForm({ ...crForm, action: 'UPDATE_EXISTING' })}
                          className={`px-3 py-1.5 rounded-lg font-bold transition ${
                            crForm.action === 'UPDATE_EXISTING'
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          تحديث بيانات الشركة القائمة
                        </button>
                        <button
                          type="button"
                          onClick={() => setCrForm({ ...crForm, action: 'CREATE_NEW' })}
                          className={`px-3 py-1.5 rounded-lg font-bold transition ${
                            crForm.action === 'CREATE_NEW'
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          محاولة إنشاء سجل جديد
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Editable Fields Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>
                          اسم الشركة (عربي) *{' '}
                          {crExtractionResult.fields?.companyNameAr?.sourcePage && (
                            <span className="text-emerald-400">
                              [صفحة {crExtractionResult.fields.companyNameAr.sourcePage}]
                            </span>
                          )}
                        </span>
                        {renderConfidenceBadge(crExtractionResult.fields?.companyNameAr)}
                      </label>
                      <input
                        type="text"
                        value={crForm.companyNameAr}
                        onChange={(e) => setCrForm({ ...crForm, companyNameAr: e.target.value })}
                        placeholder="غير مذكور - أدخل اسم الشركة"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('companyNameAr', 'اسم الشركة بالعربية', true)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>
                          رقم السجل التجاري (CR) *{' '}
                          {crExtractionResult.fields?.crNumber?.sourcePage && (
                            <span className="text-emerald-400">
                              [صفحة {crExtractionResult.fields.crNumber.sourcePage}]
                            </span>
                          )}
                        </span>
                        {renderConfidenceBadge(crExtractionResult.fields?.crNumber)}
                      </label>
                      <input
                        type="text"
                        value={crForm.crNumber}
                        onChange={(e) => setCrForm({ ...crForm, crNumber: e.target.value })}
                        placeholder="غير مذكور - أدخل رقم السجل"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('crNumber', 'رقم السجل التجاري', true)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>
                          الشكل القانوني{' '}
                          {!crForm.legalForm && (
                            <span className="text-amber-400">(غير مذكور في المستند)</span>
                          )}
                        </span>
                        {renderConfidenceBadge(crExtractionResult.fields?.legalForm)}
                      </label>
                      <input
                        type="text"
                        value={crForm.legalForm}
                        onChange={(e) => setCrForm({ ...crForm, legalForm: e.target.value })}
                        placeholder="غير مذكور في السجل (لا يتم افتراض ش.م.م)"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('legalForm', 'الشكل القانوني', true)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>
                          رأس المال (ر.ع){' '}
                          {!crForm.capitalOmr && (
                            <span className="text-amber-400">(غير مذكور في المستند)</span>
                          )}
                        </span>
                        {renderConfidenceBadge(crExtractionResult.fields?.capitalOmr)}
                      </label>
                      <input
                        type="number"
                        value={crForm.capitalOmr}
                        onChange={(e) => setCrForm({ ...crForm, capitalOmr: e.target.value })}
                        placeholder="غير مذكور في السجل (لا يتم افتراض 20,000)"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('capitalOmr', 'رأس المال (ر.ع)', true)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>تاريخ الإصدار (YYYY-MM-DD)</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.issueDate)}
                      </label>
                      <input
                        type="text"
                        value={crForm.issueDate}
                        onChange={(e) => setCrForm({ ...crForm, issueDate: e.target.value })}
                        placeholder="غير مذكور في السجل"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('issueDate', 'تاريخ الإصدار', true)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>تاريخ انتهاء السجل (YYYY-MM-DD)</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.expiryDate)}
                      </label>
                      <input
                        type="text"
                        value={crForm.expiryDate}
                        onChange={(e) => setCrForm({ ...crForm, expiryDate: e.target.value })}
                        placeholder="غير مذكور في السجل"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('expiryDate', 'تاريخ انتهاء السجل', true)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>البطاقة الضريبية (إن وجد)</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.taxCardNumber)}
                      </label>
                      <input
                        type="text"
                        value={crForm.taxCardNumber}
                        onChange={(e) => setCrForm({ ...crForm, taxCardNumber: e.target.value })}
                        placeholder="غير مذكور"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('taxCardNumber', 'البطاقة الضريبية', false)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>رقم انتساب الغرفة (إن وجد)</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.chamberNumber)}
                      </label>
                      <input
                        type="text"
                        value={crForm.chamberNumber}
                        onChange={(e) => setCrForm({ ...crForm, chamberNumber: e.target.value })}
                        placeholder="غير مذكور"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('chamberNumber', 'رقم انتساب الغرفة', false)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>اسم الشركة (إنجليزي)</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.companyNameEn)}
                      </label>
                      <input
                        type="text"
                        value={crForm.companyNameEn}
                        onChange={(e) => setCrForm({ ...crForm, companyNameEn: e.target.value })}
                        placeholder="غير مذكور"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('companyNameEn', 'اسم الشركة بالإنجليزية', false)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>المدينة / المقر</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.city)}
                      </label>
                      <input
                        type="text"
                        value={crForm.city}
                        onChange={(e) => setCrForm({ ...crForm, city: e.target.value })}
                        placeholder="غير مذكور"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('city', 'المدينة', false)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>الهاتف</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.contactPhone)}
                      </label>
                      <input
                        type="text"
                        value={crForm.contactPhone}
                        onChange={(e) => setCrForm({ ...crForm, contactPhone: e.target.value })}
                        placeholder="غير مذكور"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('contactPhone', 'الهاتف', false)}
                    </div>

                    <div>
                      <label className="flex items-center justify-between text-slate-400 mb-1">
                        <span>المالك / المفوض بالتوقيع</span>
                        {renderConfidenceBadge(crExtractionResult.fields?.ownerOrManagerName)}
                      </label>
                      <input
                        type="text"
                        value={crForm.ownerOrManagerName}
                        onChange={(e) =>
                          setCrForm({ ...crForm, ownerOrManagerName: e.target.value })
                        }
                        placeholder="غير مذكور"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                      />
                      {renderFieldReviewGate('ownerOrManagerName', 'المالك / المفوض', false)}
                    </div>
                  </div>

                  {/* Stage 7: Second Verification Mismatches Alert */}
                  {verificationMismatches && verificationMismatches.length > 0 && (
                    <div className="bg-red-950/80 border border-red-500/60 rounded-xl p-3.5 space-y-2.5 text-xs text-red-100">
                      <div className="font-bold text-red-300 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span>نتائج التحقيق الثاني المستقل رصدت اختلافاً في الحقول التالية:</span>
                      </div>
                      <div className="space-y-1.5">
                        {verificationMismatches.map((m: any, idx: number) => (
                          <div
                            key={idx}
                            className="bg-slate-950/70 border border-red-500/30 rounded-lg p-2 flex flex-wrap items-center justify-between gap-2"
                          >
                            <span className="font-bold text-red-200">{m.labelAr || m.field}:</span>
                            <span>
                              القيمة المدخلة:{' '}
                              <strong className="font-mono text-white">
                                {String(m.submittedValue ?? 'فارغ')}
                              </strong>{' '}
                              | قيمة التحقيق الثاني:{' '}
                              <strong className="font-mono text-emerald-300">
                                {String(m.verifiedValue ?? 'فارغ')}
                              </strong>
                            </span>
                          </div>
                        ))}
                      </div>
                      <label className="flex items-center gap-2 pt-1 cursor-pointer select-none text-amber-300 font-bold">
                        <input
                          type="checkbox"
                          checked={userOverrideConfirmed}
                          onChange={(e) => setUserOverrideConfirmed(e.target.checked)}
                          className="rounded accent-emerald-500 w-4 h-4"
                        />
                        <span>أؤكد صحة القيمة رغم اختلاف التحقيق الثاني (User Override)</span>
                      </label>
                    </div>
                  )}

                  {/* Stage 7: Second Verification In-Progress Indicator */}
                  {isSavingCr && (
                    <div className="bg-emerald-950/80 border border-emerald-500/40 rounded-xl p-3 text-xs text-emerald-200 flex items-center gap-2.5">
                      <RefreshCw className="w-4 h-4 animate-spin text-emerald-400 shrink-0" />
                      <span className="font-bold">جاري التحقيق الثاني… قد يستغرق دقيقة</span>
                    </div>
                  )}

                  {/* Verified Read-Back Banner */}
                  {crSaveVerifiedResult?.readBackVerification?.verified && (
                    <div className="bg-emerald-950/90 border border-emerald-500/50 rounded-xl p-3 text-xs text-emerald-200 flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                      <div>
                        <p className="font-bold text-emerald-300">
                          تم الحفظ والتحقق الفعلي من قاعدة بيانات PostgreSQL (Read-Back Verified)
                        </p>
                        <p>
                          معرف الشركة: #{crSaveVerifiedResult.readBackVerification.companyRowId} •
                          معرف الوثيقة: #{crSaveVerifiedResult.readBackVerification.documentRowId} •
                          رأس المال المسجل:{' '}
                          {crSaveVerifiedResult.company?.capital
                            ? `${crSaveVerifiedResult.company.capital} ر.ع`
                            : 'غير محدد (null)'}
                        </p>
                      </div>
                    </div>
                  )}

                  {unreviewedCriticalFields.length > 0 && (
                    <div className="text-[11px] text-amber-300 bg-amber-950/50 border border-amber-500/30 rounded-lg px-3 py-2">
                      ⚠️ يرجى تأشير خيار &ldquo;راجعته&rdquo; لجميع الحقول الحرجة ذات الثقة المتوسطة أو المتعارضة ({unreviewedCriticalFields.length} حقل متبقٍ) لتفعيل زر تأكيد الحفظ.
                    </div>
                  )}

                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={handleConfirmSaveCr}
                      disabled={isConfirmSaveDisabled}
                      className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-4 py-2 rounded-xl text-xs font-bold transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      {isSavingCr
                        ? 'جاري التحقيق الثاني… قد يستغرق دقيقة'
                        : crForm.action === 'UPDATE_EXISTING'
                          ? 'تأكيد الحفظ (تحديث السجل)'
                          : 'تأكيد الحفظ'}
                    </button>
                  </div>
                </div>
              )}

              {isAiProcessing && (
                <div className="flex justify-end">
                  <div className="bg-emerald-950/80 border border-emerald-800/80 p-3 rounded-2xl text-xs text-emerald-300 flex items-center gap-2 animate-pulse">
                    <Sparkles className="w-4 h-4 animate-spin" />
                    <span>
                      جاري صياغة رد بشري طبيعي بواسطة Gemini 3.8 Flash واستخراج الطلب...
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Input Bar */}
            <div className="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isExtractingCr}
                title="إرفاق شهادة السجل التجاري (PDF أو صورة)"
                className="bg-slate-800 hover:bg-slate-700 text-emerald-400 p-2.5 rounded-xl transition disabled:opacity-50"
              >
                <Upload className="w-5 h-5" />
              </button>

              <input
                type="text"
                placeholder="اكتب رسالة للزبون أو ارفع شهادة السجل التجاري (CR)..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 bg-slate-900 border border-slate-800 text-slate-100 px-4 py-2.5 rounded-xl text-sm focus:outline-none focus:border-emerald-500"
              />

              <button
                onClick={handleSendMessage}
                disabled={!inputText.trim()}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 p-2.5 rounded-xl font-bold transition disabled:opacity-50"
              >
                <Send className="w-5 h-5 rotate-180" />
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
            <MessageSquare className="w-12 h-12 text-slate-600 mb-3" />
            <p className="font-semibold text-slate-200">اختر محادثة من القائمة للبدء</p>
          </div>
        )}
      </div>

      {/* Document Lightbox / Viewer Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                  <FileCheck2 className="w-4 h-4 text-emerald-400" />
                  <span>معاينة المرفق المرسل عبر واتساب</span>
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">{previewDoc.name}</p>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewDoc.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 rounded-xl transition flex items-center gap-1.5 text-xs font-bold"
                >
                  <Eye className="w-4 h-4 text-emerald-400" />
                  <span>فتح في تبويب جديد</span>
                </a>
                <button
                  type="button"
                  onClick={() => downloadOriginalFile(previewDoc.url, previewDoc.name)}
                  className="p-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl transition flex items-center gap-1.5 text-xs font-bold"
                  title="تحميل الملف الأصلي"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل الملف</span>
                </button>
                <button
                  onClick={() => setPreviewDoc(null)}
                  className="p-2 text-slate-400 hover:text-slate-100 rounded-xl hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-slate-950/50 min-h-[450px]">
              {previewDoc.url.startsWith('data:application/pdf') ||
              previewDoc.url.toLowerCase().endsWith('.pdf') ||
              previewDoc.name.toLowerCase().endsWith('.pdf') ? (
                <iframe
                  src={previewDoc.url}
                  title="PDF Viewer"
                  className="w-full h-[600px] rounded-xl border border-slate-800 bg-white"
                />
              ) : (
                <img
                  src={previewDoc.url}
                  alt={previewDoc.name}
                  className="max-h-[600px] max-w-full object-contain rounded-xl shadow-lg border border-slate-800"
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

