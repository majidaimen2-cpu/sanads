import React, { useEffect, useState } from 'react';
import {
  Sparkles,
  Search,
  Filter,
  Phone,
  MessageSquare,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  ArrowRightLeft,
  ChevronRight,
  FileText,
  User,
  ExternalLink,
  Plus,
  Zap,
  Send,
  ListChecks,
  Tag,
  Calendar,
  Check
} from 'lucide-react';
import { CustomerRequest, RequestPriority, RequestStatus } from '../types';
import { analyzeCustomerMessageWithAI, fetchCustomerRequests, updateRequestStatus } from '../lib/api/requests';

interface CustomerRequestsPageProps {
  onConvertToTransaction?: (req: CustomerRequest) => void;
  onNavigateToWhatsApp?: (phone: string) => void;
}

export const CustomerRequestsPage: React.FC<CustomerRequestsPageProps> = ({
  onConvertToTransaction,
  onNavigateToWhatsApp
}) => {
  const [requests, setRequests] = useState<CustomerRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [selectedRequest, setSelectedRequest] = useState<CustomerRequest | null>(null);
  const [showLogModal, setShowLogModal] = useState(false);

  // AI Live Simulator State
  const [showAiModal, setShowAiModal] = useState(false);
  const [simMessage, setSimMessage] = useState('السلام عليكم، أود تجديد السجل التجاري لشركتي وإضافة نشاط مقاولات وتعديل عنوان المحل بمسقط، كم التكلفة وما هي الأوراق المطلوبة؟');
  const [simPhone, setSimPhone] = useState('+96899887766');
  const [simAnalyzing, setSimAnalyzing] = useState(false);
  const [simResult, setSimResult] = useState<{ responseText: string; extractedRequest: CustomerRequest } | null>(null);

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    setLoading(true);
    const data = await fetchCustomerRequests();
    setRequests(data);
    setLoading(false);
  };

  const handleStatusChange = async (id: string, newStatus: RequestStatus) => {
    const updated = await updateRequestStatus(id, newStatus);
    if (updated) {
      setRequests(prev => prev.map(r => r.id === id ? updated : r));
    }
  };

  const handleSimulateAi = async () => {
    if (!simMessage.trim()) return;
    setSimAnalyzing(true);
    setSimResult(null);
    try {
      const res = await analyzeCustomerMessageWithAI(simMessage, simPhone);
      setSimResult(res);
      await loadRequests();
    } catch (err) {
      console.error('Simulation error:', err);
    } finally {
      setSimAnalyzing(false);
    }
  };

  const filteredRequests = requests.filter(r => {
    const matchesSearch =
      r.customerPhone.includes(searchQuery) ||
      (r.customerName && r.customerName.includes(searchQuery)) ||
      r.serviceCategory.includes(searchQuery) ||
      r.extractedIntent.includes(searchQuery);

    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || r.priority === priorityFilter;

    return matchesSearch && matchesStatus && matchesPriority;
  });

  // Calculate statistics
  const totalCount = requests.length;
  const pendingCount = requests.filter(r => r.status === 'pending').length;
  const convertedCount = requests.filter(r => r.status === 'converted').length;
  const highPriorityCount = requests.filter(r => r.priority === 'high' && r.status !== 'completed').length;

  const getStatusBadge = (status: RequestStatus) => {
    switch (status) {
      case 'pending':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20"><Clock className="w-3.5 h-3.5" /> قيد الانتظار</span>;
      case 'in_progress':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20"><Clock className="w-3.5 h-3.5" /> قيد المعالجة</span>;
      case 'completed':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20"><CheckCircle2 className="w-3.5 h-3.5" /> مكتمل</span>;
      case 'converted':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20"><ArrowRightLeft className="w-3.5 h-3.5" /> محول لمعاملة</span>;
      case 'cancelled':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20"><XCircle className="w-3.5 h-3.5" /> ملغي</span>;
      default:
        return null;
    }
  };

  const getPriorityBadge = (priority: RequestPriority) => {
    switch (priority) {
      case 'high':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-medium bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20">عالية جدًا</span>;
      case 'medium':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-medium bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">متوسطة</span>;
      case 'low':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-medium bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20">منخفضة</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 pb-12" dir="rtl">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-emerald-900 via-teal-800 to-cyan-900 p-6 rounded-2xl text-white shadow-xl">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-xl backdrop-blur-md border border-white/20">
              <Sparkles className="w-7 h-7 text-emerald-300" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">طلبات واستفسارات الزباين الذكية (AI Requests)</h1>
              <p className="text-emerald-100 text-sm mt-1">
                نظام تحليلي ذكي بـ Gemini 3.8 Flash يفهم احتياجات العملاء من الواتساب ويستخرج المطلوب بدقة إنسانية
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAiModal(true)}
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-4 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-emerald-900/40 transition duration-200"
          >
            <Zap className="w-4 h-4 fill-current" />
            تجربة المحلل الذكي (Live AI Simulator)
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 dark:bg-slate-900/80 border border-slate-800 p-5 rounded-2xl shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-400">إجمالي الطلبات المستخرجة</p>
            <p className="text-2xl font-bold text-slate-100 mt-1">{totalCount}</p>
          </div>
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <FileText className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-400">طلبات قيد المعالجة والتواصل</p>
            <p className="text-2xl font-bold text-amber-400 mt-1">{pendingCount}</p>
          </div>
          <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-400">طلبات مرتفعة الأهمية</p>
            <p className="text-2xl font-bold text-red-400 mt-1">{highPriorityCount}</p>
          </div>
          <div className="p-3 bg-red-500/10 text-red-400 rounded-xl">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-400">تحولت إلى معاملات رسمية</p>
            <p className="text-2xl font-bold text-purple-400 mt-1">{convertedCount}</p>
          </div>
          <div className="p-3 bg-purple-500/10 text-purple-400 rounded-xl">
            <ArrowRightLeft className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl shadow-sm flex flex-col md:flex-row items-center gap-4 justify-between">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="ابحث برقم الهاتف، اسم الزبون، أو الخدمة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2 rounded-xl text-sm focus:outline-none focus:border-emerald-500 transition"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs text-slate-400 font-medium">الحالة:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="all">كل الحالات</option>
              <option value="pending">قيد الانتظار</option>
              <option value="in_progress">قيد المعالجة</option>
              <option value="completed">مكتمل</option>
              <option value="converted">محول لمعاملة</option>
              <option value="cancelled">ملغي</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">الأولوية:</span>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="all">كل الأولويات</option>
              <option value="high">عالية جدًا</option>
              <option value="medium">متوسطة</option>
              <option value="low">منخفضة</option>
            </select>
          </div>
        </div>
      </div>

      {/* Requests List */}
      {loading ? (
        <div className="text-center py-12 bg-slate-900/50 rounded-2xl border border-slate-800">
          <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto mb-3"></div>
          <p className="text-slate-400 text-sm">جاري جلب الطلبات المحللة بالذكاء الاصطناعي...</p>
        </div>
      ) : filteredRequests.length === 0 ? (
        <div className="text-center py-12 bg-slate-900/50 rounded-2xl border border-slate-800">
          <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-slate-200 font-semibold text-lg">لا توجد طلبات تطابق بحثك</h3>
          <p className="text-slate-400 text-sm mt-1">تأكد من اختيار التصفية المناسبة أو جرب إدخال رسالة جديدة عبر المحلل الذكي</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredRequests.map((req) => (
            <div
              key={req.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 transition-all shadow-md group"
            >
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                {/* Right Side Info */}
                <div className="space-y-3 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg">
                      {req.serviceCategory}
                    </span>
                    {req.serviceSubType && (
                      <span className="text-xs text-slate-400 bg-slate-800 px-2.5 py-1 rounded-lg">
                        {req.serviceSubType}
                      </span>
                    )}
                    {getStatusBadge(req.status)}
                    {getPriorityBadge(req.priority)}
                  </div>

                  <div className="flex items-center gap-3 min-w-0 overflow-hidden">
                    <div className="p-2 bg-slate-800 rounded-xl text-slate-300 shrink-0">
                      <User className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1 overflow-hidden">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-slate-100 font-bold text-base truncate max-w-full" title={req.customerName || 'زبون الواتساب'}>
                          {req.customerName || 'زبون الواتساب'}
                        </span>
                        <a
                          href={`https://wa.me/${req.customerPhone.replace(/[^0-9]/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-emerald-400 hover:text-emerald-300 text-xs font-normal flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 shrink-0"
                        >
                          <Phone className="w-3 h-3" />
                          <span className="font-mono">{req.customerPhone}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1 truncate">
                        <Calendar className="w-3 h-3 shrink-0" />
                        <span className="truncate">تاريخ الاستخراج: {new Date(req.createdAt).toLocaleString('ar-OM')}</span>
                      </p>
                    </div>
                  </div>

                  {/* AI Extracted Intent Box */}
                  <div className="bg-slate-950/70 border border-slate-800/80 p-3.5 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>فهم الذكاء الاصطناعي للطلب (LLM Extracted Intent):</span>
                    </div>
                    <p className="text-sm text-slate-200 font-medium leading-relaxed">
                      {req.extractedIntent}
                    </p>
                  </div>

                  {/* Requirement Checklist */}
                  {req.requirementChecklist && req.requirementChecklist.length > 0 && (
                    <div className="space-y-1.5">
                      <p className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                        <ListChecks className="w-3.5 h-3.5 text-cyan-400" />
                        المستندات والمتطلبات المستخرجة تلقائياً للبدء:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {req.requirementChecklist.map((item, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center gap-1 text-xs text-slate-300 bg-slate-800/80 border border-slate-700 px-2.5 py-1 rounded-lg"
                          >
                            <Check className="w-3 h-3 text-emerald-400" />
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {req.notes && (
                    <p className="text-xs text-amber-300/80 bg-amber-500/10 border border-amber-500/20 p-2 rounded-lg">
                      <strong>ملاحظة:</strong> {req.notes}
                    </p>
                  )}
                </div>

                {/* Left Side Action Controls */}
                <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-2 border-t lg:border-t-0 border-slate-800 pt-3 lg:pt-0 min-w-[200px]">
                  {/* Status Dropdown */}
                  <div className="w-full">
                    <label className="text-[10px] text-slate-400 block mb-1">تحديث حالة الطلب:</label>
                    <select
                      value={req.status}
                      onChange={(e) => handleStatusChange(req.id, e.target.value as RequestStatus)}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-emerald-500"
                    >
                      <option value="pending">قيد الانتظار</option>
                      <option value="in_progress">قيد المعالجة</option>
                      <option value="completed">مكتمل</option>
                      <option value="converted">محول لمعاملة</option>
                      <option value="cancelled">إلغاء</option>
                    </select>
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 lg:grid-cols-1 gap-2 w-full mt-1">
                    {onConvertToTransaction && req.status !== 'converted' && (
                      <button
                        onClick={() => {
                          handleStatusChange(req.id, 'converted');
                          onConvertToTransaction(req);
                        }}
                        className="flex items-center justify-center gap-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs px-3 py-2 rounded-xl font-medium transition shadow-sm"
                      >
                        <ArrowRightLeft className="w-3.5 h-3.5" />
                        تحويل لمعاملة
                      </button>
                    )}

                    {onNavigateToWhatsApp && (
                      <button
                        onClick={() => onNavigateToWhatsApp(req.customerPhone)}
                        className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-3 py-2 rounded-xl font-medium transition shadow-sm"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        فتح المحادثة
                      </button>
                    )}

                    {req.fullRawConversation && req.fullRawConversation.length > 0 && (
                      <button
                        onClick={() => {
                          setSelectedRequest(req);
                          setShowLogModal(true);
                        }}
                        className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-2 rounded-xl transition col-span-2 lg:col-span-1"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        سجل الحوار
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* AI Live Simulator Modal */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/10 rounded-xl text-emerald-400">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-100">محلل واتساب الذكي (Gemini 3.8 Flash)</h3>
                  <p className="text-xs text-slate-400">اكتب أي رسالة واتساب من زبون لاختبار الفهم البشري والاستخراج التلقائي</p>
                </div>
              </div>
              <button
                onClick={() => setShowAiModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm font-bold bg-slate-800 p-1.5 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">رقم هاتف الزبون:</label>
                <input
                  type="text"
                  value={simPhone}
                  onChange={(e) => setSimPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">رسالة الواتساب الواردة من الزبون:</label>
                <textarea
                  rows={4}
                  value={simMessage}
                  onChange={(e) => setSimMessage(e.target.value)}
                  placeholder="أدخل رسالة الزبون بالعمانية أو العربية..."
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 p-3 rounded-xl text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                onClick={handleSimulateAi}
                disabled={simAnalyzing || !simMessage.trim()}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white py-3 rounded-xl font-bold text-sm shadow-lg disabled:opacity-50 transition"
              >
                {simAnalyzing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                    <span>جاري التحليل واستخراج الطلب بـ Gemini 3.8 Flash...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>تحليل الرسالة وتخزين الطلب تلقائياً</span>
                  </>
                )}
              </button>

              {simResult && (
                <div className="space-y-4 pt-2 border-t border-slate-800">
                  <div className="bg-emerald-950/40 border border-emerald-800/60 p-4 rounded-xl space-y-2">
                    <p className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <MessageSquare className="w-4 h-4" />
                      رد الموديل الذكي على الزبون (Human-like AI Response):
                    </p>
                    <p className="text-sm text-slate-100 whitespace-pre-line leading-relaxed">
                      {simResult.responseText}
                    </p>
                  </div>

                  <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
                    <p className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                      <FileText className="w-4 h-4" />
                      الطلب المستخرج والتصنيف المستحضر (Extracted Structure):
                    </p>
                    <div className="text-xs space-y-1 text-slate-300">
                      <p><strong>تصنيف الخدمة:</strong> {simResult.extractedRequest.serviceCategory}</p>
                      <p><strong>الفهم الدقيق:</strong> {simResult.extractedRequest.extractedIntent}</p>
                      <p><strong>الأولوية:</strong> {simResult.extractedRequest.priority}</p>
                      <p><strong>قائمة المستندات:</strong> {simResult.extractedRequest.requirementChecklist.join(' • ')}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Conversation Log Modal */}
      {showLogModal && selectedRequest && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg max-h-[80vh] flex flex-col p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-base">سجل حوار الواتساب ({selectedRequest.customerPhone})</h3>
              <button
                onClick={() => setShowLogModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm font-bold bg-slate-800 p-1.5 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 p-2 bg-slate-950/50 rounded-xl">
              {selectedRequest.fullRawConversation?.map((msg, index) => (
                <div
                  key={index}
                  className={`flex flex-col ${msg.role === 'customer' ? 'items-start' : 'items-end'}`}
                >
                  <div
                    className={`max-w-[85%] p-3 rounded-2xl text-xs space-y-1 ${
                      msg.role === 'customer'
                        ? 'bg-slate-800 text-slate-200 rounded-tr-none'
                        : 'bg-emerald-600 text-white rounded-tl-none'
                    }`}
                  >
                    <p className="text-[10px] opacity-75 font-semibold">
                      {msg.role === 'customer' ? selectedRequest.customerName || 'الزبون' : 'المساعد الذكي'}
                    </p>
                    <p className="leading-relaxed">{msg.text}</p>
                    <p className="text-[9px] opacity-60 text-left">{msg.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
