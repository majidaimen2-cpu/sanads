import React, { useEffect, useState, useRef } from 'react';
import {
  Users,
  Search,
  Plus,
  Filter,
  Building2,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  FileText,
  UploadCloud,
  Eye,
  Download,
  Trash2,
  Edit,
  X,
  FileSpreadsheet,
  AlertCircle,
  FileCheck2,
  IdCard,
  Briefcase
} from 'lucide-react';
import { Employee, Company } from '../types';
import { YasminaApi } from '../lib/api';

interface EmployeesPageProps {
  initialCompanyId?: string;
  onNavigateToWhatsApp?: (phone: string) => void;
}

export const EmployeesPage: React.FC<EmployeesPageProps> = ({ initialCompanyId }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [companyFilter, setCompanyFilter] = useState<string>(initialCompanyId || 'all');
  
  // Modal states
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Document viewer modal
  const [previewDoc, setPreviewDoc] = useState<{ url: string; name: string; employeeName: string } | null>(null);
  const [confirmDeleteEmp, setConfirmDeleteEmp] = useState<Employee | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<Employee>>({
    name: '',
    civilId: '',
    laborCardNo: '',
    licenseNumber: '',
    licenseExpiryDate: '',
    licenseFileUrl: '',
    licenseFileName: '',
    companyId: '',
    companyName: '',
    jobTitle: 'موظف عام',
    salary: 350,
    nationality: 'عُماني',
    residenceExpiry: '',
    passportExpiry: '',
    active: true,
  });

  const [saving, setSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // 1. Fetch live companies from PostgreSQL API first
      let loadedCompanies: Company[] = [];
      try {
        const compRes = await fetch('/api/companies?limit=100', {
          headers: YasminaApi.getAuthHeaders(),
        });
        if (compRes.ok) {
          const compBody = await compRes.json();
          if (compBody.data && Array.isArray(compBody.data)) {
            loadedCompanies = compBody.data;
          }
        }
      } catch (e) {
        console.warn('API companies fetch failed, falling back to local store:', e);
      }

      if (loadedCompanies.length === 0) {
        loadedCompanies = YasminaApi.getCompanies();
      }
      setCompanies(loadedCompanies);

      // 2. Fetch live employees from PostgreSQL API
      const res = await fetch('/api/employees?limit=200', {
        headers: YasminaApi.getAuthHeaders(),
      }).catch(() => null);

      if (res && res.ok) {
        const body = await res.json();
        if (body.data && Array.isArray(body.data)) {
          setEmployees(body.data);
          return;
        }
      }

      // Local fallback
      const emps = YasminaApi.getEmployees();
      setEmployees(emps);
    } catch (err) {
      console.warn('Failed to load employees:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenAddModal = () => {
    setModalMode('add');
    setEditingId(null);
    setErrorMessage(null);
    setFormData({
      name: '',
      civilId: '',
      laborCardNo: '',
      licenseNumber: '',
      licenseExpiryDate: '',
      licenseFileUrl: '',
      licenseFileName: '',
      companyId: companies.length > 0 ? String(companies[0].id) : '',
      companyName: companies.length > 0 ? companies[0].name : '',
      jobTitle: 'موظف عام',
      salary: 350,
      nationality: 'عُماني',
      residenceExpiry: '',
      passportExpiry: '',
      active: true,
    });
    setShowModal(true);
  };

  const handleOpenEditModal = (emp: Employee) => {
    setModalMode('edit');
    setEditingId(emp.id);
    setErrorMessage(null);
    setFormData({
      name: emp.name || (emp as any).employeeName || '',
      civilId: emp.civilId || emp.nationalId || '',
      laborCardNo: emp.laborCardNo || '',
      licenseNumber: emp.licenseNumber || emp.laborCardNo || '',
      licenseExpiryDate: emp.licenseExpiryDate || '',
      licenseFileUrl: emp.licenseFileUrl || '',
      licenseFileName: emp.licenseFileName || '',
      companyId: emp.companyId ? String(emp.companyId) : '',
      companyName: emp.companyName || '',
      jobTitle: emp.jobTitle || emp.role || 'موظف',
      salary: emp.salary ?? 350,
      nationality: emp.nationality || 'عُماني',
      residenceExpiry: emp.residenceExpiry || '',
      passportExpiry: emp.passportExpiry || '',
      active: emp.active !== false,
    });
    setShowModal(true);
  };

  // Handle license file upload and conversion to Base64
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit: 10MB
    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage('حجم الملف كبير جداً. الحد الأقصى هو 10 ميغابايت');
      return;
    }

    setErrorMessage(null);
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setFormData((prev) => ({
        ...prev,
        licenseFileUrl: result,
        licenseFileName: file.name,
      }));
    };
    reader.onerror = () => {
      setErrorMessage('تعذر قراءة الملف، يرجى المحاولة مرة أخرى');
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveFile = () => {
    setFormData((prev) => ({
      ...prev,
      licenseFileUrl: '',
      licenseFileName: '',
    }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim()) {
      setErrorMessage('يرجى إدخال اسم الموظف');
      return;
    }

    setSaving(true);
    setErrorMessage(null);

    try {
      const selectedComp = companies.find((c) => String(c.id) === String(formData.companyId));
      const payload = {
        name: formData.name.trim(),
        employeeName: formData.name.trim(),
        companyId: formData.companyId ? formData.companyId : null,
        companyName: selectedComp?.name || formData.companyName || null,
        civilId: formData.civilId?.trim() || null,
        nationalId: formData.civilId?.trim() || null,
        laborCardNo: formData.laborCardNo?.trim() || formData.licenseNumber?.trim() || null,
        licenseNumber: formData.licenseNumber?.trim() || formData.laborCardNo?.trim() || null,
        licenseExpiryDate: formData.licenseExpiryDate?.trim() || null,
        licenseFileUrl: formData.licenseFileUrl || null,
        licenseFileName: formData.licenseFileName || null,
        jobTitle: formData.jobTitle?.trim() || 'موظف',
        salary: Number(formData.salary) || 0,
        nationality: formData.nationality?.trim() || 'عُماني',
        residenceExpiry: formData.residenceExpiry?.trim() || null,
        passportExpiry: formData.passportExpiry?.trim() || null,
        active: formData.active ?? true,
      };

      const url = modalMode === 'edit' && editingId ? `/api/employees/${editingId}` : '/api/employees';
      const method = modalMode === 'edit' ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...YasminaApi.getAuthHeaders(),
        },
        body: JSON.stringify(payload),
      });

      const responseBody = await res.json().catch(() => null);

      if (!res.ok) {
        const errorMsg =
          responseBody?.error?.message ||
          responseBody?.message ||
          'فشل في حفظ بيانات الموظف والترخيص';
        setErrorMessage(errorMsg);
        setSaving(false);
        return;
      }

      setShowModal(false);
      setSuccessToast(
        modalMode === 'edit' ? 'تم تحديث بيانات الموظف والترخيص بنجاح' : 'تم إضافة الموظف وحفظ الترخيص الأصلي بنجاح'
      );
      setTimeout(() => setSuccessToast(null), 4000);
      await loadData();
    } catch (err: any) {
      console.error('Error saving employee:', err);
      setErrorMessage(err.message || 'حدث خطأ غير متوقع أثناء الحفظ');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (emp: Employee) => {
    try {
      const res = await fetch(`/api/employees/${emp.id}`, {
        method: 'DELETE',
        headers: YasminaApi.getAuthHeaders(),
      });

      if (res.ok) {
        setSuccessToast(`تم حذف الموظف "${emp.name}"`);
        setTimeout(() => setSuccessToast(null), 3000);
        setConfirmDeleteEmp(null);
        await loadData();
      } else {
        setErrorMessage('فشل حذف الموظف، يرجى المحاولة مرة أخرى');
      }
    } catch (err) {
      console.error('Failed to delete employee:', err);
    }
  };

  const getExpiryStatus = (dateStr?: string) => {
    if (!dateStr) return null;
    const expiry = new Date(dateStr);
    const now = new Date();
    const diffDays = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { text: `منتهي منذ ${Math.abs(diffDays)} يوم`, color: 'bg-rose-500/15 text-rose-400 border-rose-500/30' };
    }
    if (diffDays <= 30) {
      return { text: `ينتهي خلال ${diffDays} يوم`, color: 'bg-amber-500/15 text-amber-400 border-amber-500/30' };
    }
    return { text: 'ساري الصلاحية', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' };
  };

  const filtered = employees.filter((e) => {
    const s = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !s ||
      (e.name && e.name.toLowerCase().includes(s)) ||
      (e.civilId && e.civilId.includes(s)) ||
      (e.laborCardNo && e.laborCardNo.includes(s)) ||
      (e.licenseNumber && e.licenseNumber.includes(s)) ||
      (e.companyName && e.companyName.toLowerCase().includes(s)) ||
      (e.jobTitle && e.jobTitle.toLowerCase().includes(s));

    if (!matchesSearch) return false;
    if (companyFilter !== 'all' && String(e.companyId) !== String(companyFilter)) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-12" dir="rtl">
      {/* Success Notification Toast */}
      {successToast && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 backdrop-blur-md animate-fade-in text-sm font-semibold">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/20 shadow-inner">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              سجل القوى العاملة وتراخيص العمل
              <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded-full font-mono border border-slate-700">
                {employees.length} موظف
              </span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              إدارة بيانات العمال، تراخيص وبطاقات العمل، حفظ ملفات التراخيص (PDF / صور)، ومتابعة صلاحية الإقامات.
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs transition shadow-lg shadow-emerald-500/10 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة موظف مع الترخيص</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="بحث بالاسم، الرقم المدني، رقم الترخيص، المنشأة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2.5 rounded-xl text-xs focus:outline-none focus:border-emerald-500 transition"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <span className="text-xs text-slate-400 font-medium whitespace-nowrap">تصفية حسب المنشأة:</span>
          <select
            value={companyFilter}
            onChange={(e) => setCompanyFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
          >
            <option value="all">كافة المنشآت ({companies.length})</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} {c.taxId ? `(${c.taxId})` : ''}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="text-center py-16 bg-slate-900/50 rounded-2xl border border-slate-800">
          <div className="animate-spin w-8 h-8 border-4 border-cyan-500 border-t-transparent rounded-full mx-auto mb-3" />
          <p className="text-slate-400 text-xs">جاري تحميل بيانات الموظفين والتراخيص المرفقة...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
          <Users className="w-12 h-12 text-slate-600 mx-auto mb-2" />
          <p className="text-slate-200 font-bold text-sm">لا توجد سجلات عمال مطابقة</p>
          <p className="text-slate-400 text-xs max-w-sm mx-auto">
            يمكنك إضافة عامل جديد وتوثيق ترخيص العمل أو بطاقة العمل مع إرفاق المستند (PDF أو صورة).
          </p>
          <button
            onClick={handleOpenAddModal}
            className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30 px-4 py-2 rounded-xl text-xs font-semibold transition mt-2"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة أول موظف الآن</span>
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase text-[11px]">
                <tr>
                  <th className="p-4">اسم الموظف / الوظيفة</th>
                  <th className="p-4">المنشأة التابع لها</th>
                  <th className="p-4">الرقم المدني</th>
                  <th className="p-4">رقم وترخيص العمل</th>
                  <th className="p-4">مستند الترخيص المرفق</th>
                  <th className="p-4">الراتب (ر.ع)</th>
                  <th className="p-4">انتهاء الإقامة</th>
                  <th className="p-4 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                {filtered.map((emp) => {
                  const licStatus = getExpiryStatus(emp.licenseExpiryDate);
                  const hasLicenseDoc = Boolean(emp.licenseFileUrl);

                  return (
                    <tr key={emp.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-4">
                        <div className="font-bold text-slate-100 flex items-center gap-1.5">
                          <span>{emp.name}</span>
                          {emp.active === false && (
                            <span className="text-[10px] bg-rose-500/20 text-rose-400 px-1.5 py-0.5 rounded">متوقف</span>
                          )}
                        </div>
                        <div className="text-[11px] text-cyan-400 mt-0.5 flex items-center gap-1">
                          <Briefcase className="w-3 h-3" />
                          <span>{emp.jobTitle || emp.role || 'موظف'}</span>
                          <span className="text-slate-500">•</span>
                          <span className="text-slate-400">{emp.nationality || 'عُماني'}</span>
                        </div>
                      </td>

                      <td className="p-4">
                        <div className="text-emerald-400 font-semibold flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 shrink-0" />
                          <span>{emp.companyName || 'منشأة عامة'}</span>
                        </div>
                      </td>

                      <td className="p-4">
                        <div className="font-mono font-bold text-slate-300">
                          {emp.civilId || emp.nationalId || '—'}
                        </div>
                        {emp.laborCardNo && emp.laborCardNo !== emp.licenseNumber && (
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            بطاقة: {emp.laborCardNo}
                          </div>
                        )}
                      </td>

                      <td className="p-4">
                        {emp.licenseNumber ? (
                          <div>
                            <div className="font-mono font-bold text-amber-300 flex items-center gap-1">
                              <IdCard className="w-3.5 h-3.5" />
                              <span>{emp.licenseNumber}</span>
                            </div>
                            {emp.licenseExpiryDate && (
                              <div className="mt-1 flex items-center gap-1.5">
                                <span className="text-[10px] text-slate-400">{emp.licenseExpiryDate}</span>
                                {licStatus && (
                                  <span
                                    className={`text-[9px] px-1.5 py-0.2 rounded-md font-semibold border ${licStatus.color}`}
                                  >
                                    {licStatus.text}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-500 italic">غير مسجل</span>
                        )}
                      </td>

                      {/* License Document Attachment */}
                      <td className="p-4">
                        {hasLicenseDoc ? (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                YasminaApi.downloadOriginalFile(
                                  emp.licenseFileUrl!,
                                  emp.licenseFileName || `ترخيص_${emp.name}.pdf`
                                )
                              }
                              className="flex items-center gap-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition cursor-pointer"
                              title="تحميل الملف الأصلي كما رُفع تماماً"
                            >
                              <Download className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="max-w-[110px] truncate">
                                {emp.licenseFileName || 'تحميل الأصلي'}
                              </span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setPreviewDoc({
                                  url: emp.licenseFileUrl!,
                                  name: emp.licenseFileName || 'ترخيص عمل',
                                  employeeName: emp.name,
                                })
                              }
                              className="p-1.5 text-slate-400 hover:text-emerald-300 hover:bg-slate-800 rounded-lg transition cursor-pointer"
                              title="معاينة ملف الترخيص المرفوع"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-500 bg-slate-950 px-2 py-1 rounded-md border border-slate-800">
                            <FileText className="w-3 h-3 text-slate-600" />
                            <span>لا يوجد مرفق</span>
                          </span>
                        )}
                      </td>

                      <td className="p-4 font-bold text-amber-400 font-mono">
                        {emp.salary ? `${Number(emp.salary).toFixed(3)} ر.ع` : '—'}
                      </td>

                      <td className="p-4">
                        {emp.residenceExpiry ? (
                          <span className="font-semibold text-slate-300 font-mono text-[11px]">
                            {emp.residenceExpiry}
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[11px]">غير محدد</span>
                        )}
                      </td>

                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleOpenEditModal(emp)}
                            className="p-1.5 bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-400 rounded-lg transition border border-slate-700/60"
                            title="تعديل الموظف والترخيص"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setConfirmDeleteEmp(emp)}
                            className="p-1.5 bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400 rounded-lg transition border border-slate-700/60"
                            title="حذف الموظف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl p-6 shadow-2xl space-y-4 my-8 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-400" />
                <span>{modalMode === 'edit' ? 'تعديل بيانات الموظف والترخيص' : 'إضافة موظف جديد وتوثيق الترخيص'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-200 p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Error Banner */}
            {errorMessage && (
              <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 p-3 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              {/* Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="col-span-full">
                  <label className="text-slate-300 font-semibold block mb-1">اسم العامل / الموظف *:</label>
                  <input
                    type="text"
                    required
                    value={formData.name || ''}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="الاسم الرباعي للموظف"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">المنشأة التابع لها:</label>
                  <select
                    value={formData.companyId || ''}
                    onChange={(e) => {
                      const compId = e.target.value;
                      const c = companies.find((comp) => String(comp.id) === compId);
                      setFormData({
                        ...formData,
                        companyId: compId,
                        companyName: c?.name || '',
                      });
                    }}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  >
                    <option value="">منشأة عامة / غير محددة</option>
                    {companies.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.taxId ? `(${c.taxId})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">المسمى الوظيفي:</label>
                  <input
                    type="text"
                    value={formData.jobTitle || ''}
                    onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
                    placeholder="مثال: مهندس، مندوب، سائق..."
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">الرقم المدني:</label>
                  <input
                    type="text"
                    value={formData.civilId || ''}
                    onChange={(e) => setFormData({ ...formData, civilId: e.target.value })}
                    placeholder="الرقم المدني العُماني"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-xs font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">الجنسية:</label>
                  <input
                    type="text"
                    value={formData.nationality || ''}
                    onChange={(e) => setFormData({ ...formData, nationality: e.target.value })}
                    placeholder="عُماني، هندي، بنغلاديشي..."
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* License Details Section */}
              <div className="bg-slate-950/70 border border-cyan-500/20 rounded-xl p-3.5 space-y-3">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs pb-1 border-b border-slate-800">
                  <IdCard className="w-4 h-4" />
                  <span>بيانات ترخيص / بطاقة العمل</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">
                      رقم ترخيص / تصريح العمل (Labor Card / License No):
                    </label>
                    <input
                      type="text"
                      value={formData.licenseNumber || ''}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          licenseNumber: e.target.value,
                          laborCardNo: e.target.value,
                        })
                      }
                      placeholder="مثال: LC-2024-98412"
                      className="w-full bg-slate-900 border border-slate-700 text-slate-100 px-3 py-2 rounded-xl text-xs font-mono focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">تاريخ انتهاء الترخيص:</label>
                    <input
                      type="date"
                      value={formData.licenseExpiryDate || ''}
                      onChange={(e) => setFormData({ ...formData, licenseExpiryDate: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 text-slate-100 px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                {/* Upload License Document */}
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    مستند أو صورة ترخيص العمل (PDF أو صورة):
                  </label>

                  {formData.licenseFileUrl ? (
                    <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/30 p-2.5 rounded-xl">
                      <div className="flex items-center gap-2 overflow-hidden">
                        <FileCheck2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span className="text-emerald-200 font-medium text-xs truncate max-w-[260px]">
                          {formData.licenseFileName || 'ملف الترخيص المحفوظ'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            setPreviewDoc({
                              url: formData.licenseFileUrl!,
                              name: formData.licenseFileName || 'ترخيص عمل',
                              employeeName: formData.name || 'الموظف',
                            })
                          }
                          className="px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 rounded-lg text-[11px] transition flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" />
                          <span>معاينة</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleRemoveFile}
                          className="p-1 hover:bg-rose-500/20 text-rose-400 rounded-lg transition"
                          title="حذف المرفق"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-700 hover:border-cyan-500/50 hover:bg-slate-900/50 p-4 rounded-xl text-center cursor-pointer transition space-y-1"
                    >
                      <UploadCloud className="w-6 h-6 text-slate-400 mx-auto" />
                      <p className="text-xs text-slate-200 font-semibold">
                        انقر هنا لرفع ترخيص العمل أو اسحب الملف
                      </p>
                      <p className="text-[10px] text-slate-500">
                        يدعم ملفات PDF وصور JPG/PNG حتى 10 ميغابايت
                      </p>
                    </div>
                  )}

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="application/pdf,image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Salary & Residencies */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">الراتب الأساسي (ر.ع):</label>
                  <input
                    type="number"
                    step="0.001"
                    value={formData.salary ?? 350}
                    onChange={(e) => setFormData({ ...formData, salary: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 text-amber-400 font-bold px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">تاريخ انتهاء الإقامة:</label>
                  <input
                    type="date"
                    value={formData.residenceExpiry || ''}
                    onChange={(e) => setFormData({ ...formData, residenceExpiry: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold rounded-xl text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
                >
                  {saving ? 'جاري الحفظ...' : modalMode === 'edit' ? 'حفظ التعديلات' : 'حفظ الموظف والترخيص'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Document Lightbox / Viewer Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                  <FileCheck2 className="w-4 h-4 text-emerald-400" />
                  <span>مستند ترخيص العمل - {previewDoc.employeeName}</span>
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">{previewDoc.name}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => YasminaApi.downloadOriginalFile(previewDoc.url, previewDoc.name)}
                  className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition flex items-center gap-1.5 text-xs font-bold cursor-pointer"
                  title="تحميل الملف الأصلي"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل الملف الأصلي</span>
                </button>
                <button
                  onClick={() => setPreviewDoc(null)}
                  className="p-2 text-slate-400 hover:text-slate-100 rounded-xl hover:bg-slate-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Viewer Content */}
            <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-slate-950/50 min-h-[400px]">
              {previewDoc.url.startsWith('data:application/pdf') || previewDoc.url.endsWith('.pdf') ? (
                <iframe
                  src={previewDoc.url}
                  title="PDF Viewer"
                  className="w-full h-[550px] rounded-xl border border-slate-800"
                />
              ) : (
                <img
                  src={previewDoc.url}
                  alt={previewDoc.name}
                  className="max-h-[550px] max-w-full object-contain rounded-xl shadow-lg border border-slate-800"
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDeleteEmp && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-3 bg-rose-500/10 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-100 text-base">تأكيد حذف الموظف</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              هل أنت متأكد من رغبتك في حذف الموظف <strong>&ldquo;{confirmDeleteEmp.name}&rdquo;</strong>؟
            </p>
            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmDeleteEmp(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => handleDelete(confirmDeleteEmp)}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs transition shadow-md"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
