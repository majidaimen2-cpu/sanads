import React, { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, XCircle, Clock, Inbox, Bell, FileWarning } from 'lucide-react';
import { vaultApi, VaultDocument, ReminderRule, ReminderSettings } from '../lib/api/vault';

type Tab = 'inbox' | 'expiring' | 'settings';

const laneLabel: Record<string, string> = {
  CONFIRM: 'بحاجة لتأكيدك',
  UNMATCHED: 'لم يتم العثور على شركة',
  AUTO: 'تم الحفظ تلقائياً',
  MANUAL: 'تم الحفظ يدوياً',
};

/** Confirmation inbox, expiry board and reminder settings for the Smart Company File. */
export const DocumentInboxPage: React.FC = () => {
  const [tab, setTab] = useState<Tab>('inbox');
  const [inbox, setInbox] = useState<VaultDocument[]>([]);
  const [expiring, setExpiring] = useState<VaultDocument[]>([]);
  const [rules, setRules] = useState<ReminderRule[]>([]);
  const [settings, setSettings] = useState<ReminderSettings | null>(null);
  const [days, setDays] = useState(60);
  const [busy, setBusy] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      if (tab === 'inbox') setInbox((await vaultApi.inbox()).data);
      if (tab === 'expiring') setExpiring((await vaultApi.expiring(days)).data);
      if (tab === 'settings') {
        const r = (await vaultApi.getRules()).data;
        setRules(r.rules);
        setSettings(r.settings);
      }
    } catch (e: any) {
      setError(e?.message || 'تعذر تحميل البيانات');
    }
  }, [tab, days]);

  useEffect(() => {
    load();
  }, [load]);

  const act = async (docId: number, fn: () => Promise<unknown>, okMsg: string) => {
    setBusy(docId);
    setError(null);
    try {
      await fn();
      setNotice(okMsg);
      await load();
    } catch (e: any) {
      setError(e?.message || 'فشلت العملية');
    } finally {
      setBusy(null);
    }
  };

  const saveSettings = async () => {
    if (!settings) return;
    try {
      await vaultApi.saveRules({ settings, rules });
      setNotice('تم حفظ الإعدادات');
    } catch (e: any) {
      setError(e?.message || 'تعذر الحفظ');
    }
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex gap-2">
        {([
          ['inbox', 'صندوق التأكيد', <Inbox key="i" className="w-4 h-4" />],
          ['expiring', 'الوثائق القريبة من الانتهاء', <Clock key="e" className="w-4 h-4" />],
          ['settings', 'التذكيرات والإعدادات', <Bell key="s" className="w-4 h-4" />],
        ] as [Tab, string, React.ReactNode][]).map(([id, label, icon]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm border ${
              tab === id ? 'bg-emerald-600 border-emerald-500 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'
            }`}
          >
            {icon}
            {label}
          </button>
        ))}
      </div>

      {error && <div className="p-3 rounded-xl bg-rose-950 border border-rose-800 text-rose-200 text-sm">{error}</div>}
      {notice && !error && <div className="p-3 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-200 text-sm">{notice}</div>}

      {tab === 'inbox' && (
        <div className="space-y-3">
          {inbox.length === 0 && <div className="p-8 text-center text-slate-400">لا توجد وثائق بانتظار التأكيد</div>}
          {inbox.map((d) => (
            <div key={d.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="font-bold">{d.labelAr}</div>
                  <div className="text-xs text-slate-400">
                    {d.originalFileName} · {d.sourceChannel} · {d.senderPhone || 'تطبيق'}
                  </div>
                </div>
                <span className="text-xs px-2 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-800">
                  {laneLabel[d.matchLane || 'CONFIRM']}
                </span>
              </div>
              <div className="text-sm text-slate-300 grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div>الرقم: {d.docNumber || '-'}</div>
                <div>الإصدار: {d.issueDate || '-'}</div>
                <div>الانتهاء: {d.expiryDate || '-'}</div>
                <div>الثقة: {d.extractionConfidence ?? ''}</div>
              </div>
              {d.needsReview && (
                <div className="flex items-center gap-2 text-amber-300 text-xs">
                  <FileWarning className="w-4 h-4" /> بعض الحقول تحتاج مراجعة قبل الاعتماد
                </div>
              )}
              <div className="space-y-2">
                {(d.candidates || []).length === 0 && <div className="text-xs text-slate-400">لا توجد شركة مقترحة</div>}
                {(d.candidates || []).map((c) => (
                  <div key={c.companyId} className="flex flex-wrap items-center justify-between gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800">
                    <div>
                      <div className="text-sm font-semibold">{c.companyName}</div>
                      <div className="text-xs text-slate-400">
                        نسبة التطابق {c.score}% · {c.reasons.map((r) => r.detail).join('، ')}
                      </div>
                    </div>
                    <button
                      disabled={busy === d.id}
                      onClick={() => act(d.id, () => vaultApi.confirm(d.id, c.companyId), 'تم حفظ الوثيقة في ملف الشركة')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs disabled:opacity-50"
                    >
                      <CheckCircle2 className="w-4 h-4" /> تأكيد
                    </button>
                  </div>
                ))}
              </div>
              <button
                disabled={busy === d.id}
                onClick={() => act(d.id, () => vaultApi.reject(d.id), 'تم رفض الوثيقة')}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 text-rose-300 text-xs disabled:opacity-50"
              >
                <XCircle className="w-4 h-4" /> ليست لأي شركة / رفض
              </button>
            </div>
          ))}
        </div>
      )}

      {tab === 'expiring' && (
        <div className="space-y-3">
          <label className="text-sm text-slate-300">
            خلال{' '}
            <select value={days} onChange={(e) => setDays(Number(e.target.value))} className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1">
              {[30, 60, 90, 180, 365].map((n) => (
                <option key={n} value={n}>{n} يوم</option>
              ))}
            </select>
          </label>
          {expiring.length === 0 && <div className="p-8 text-center text-slate-400">لا توجد وثائق تنتهي في هذه الفترة</div>}
          {expiring.map((d) => (
            <div key={d.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-sm">
              <div>
                <div className="font-semibold">{d.companyName}</div>
                <div className="text-xs text-slate-400">{d.labelAr}</div>
              </div>
              <div className="text-amber-300">{d.expiryDate}</div>
            </div>
          ))}
        </div>
      )}

      {tab === 'settings' && settings && (
        <div className="space-y-4 p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={settings.autoFileEnabled}
              onChange={(e) => setSettings({ ...settings, autoFileEnabled: e.target.checked })}
            />
            السماح بالحفظ التلقائي عند التطابق الكامل (الافتراضي: مغلق، كل وثيقة تمر على التأكيد)
          </label>
          <label className="block text-sm">
            أرقام الموظفين لاستلام التذكيرات (مفصولة بفاصلة)
            <input
              value={settings.reminderStaffPhones}
              onChange={(e) => setSettings({ ...settings, reminderStaffPhones: e.target.value })}
              className="mt-1 w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2"
              dir="ltr"
            />
          </label>
          <div className="space-y-2">
            {rules.map((r, i) => (
              <div key={r.docTypeCode} className="flex flex-wrap items-center gap-3 text-sm">
                <span className="w-44">{r.labelAr}</span>
                <input
                  dir="ltr"
                  className="w-40 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1"
                  value={r.offsetsDays.join(',')}
                  onChange={(e) => {
                    const offsets = e.target.value.split(',').map((x) => parseInt(x.trim(), 10)).filter((n) => Number.isFinite(n) && n >= 0);
                    setRules(rules.map((x, j) => (j === i ? { ...x, offsetsDays: offsets.length ? offsets : x.offsetsDays } : x)));
                  }}
                />
                <label><input type="checkbox" checked={r.active} onChange={(e) => setRules(rules.map((x, j) => (j === i ? { ...x, active: e.target.checked } : x)))} /> فعّال</label>
                <label><input type="checkbox" checked={r.notifyClient} onChange={(e) => setRules(rules.map((x, j) => (j === i ? { ...x, notifyClient: e.target.checked } : x)))} /> تذكير العميل</label>
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-400">تذكيرات العميل لا تُرسل إلا للشركات التي فعّلتها وسجّلت موافقتها، ولا تُرسل بين الثامنة مساءً والتاسعة صباحاً.</p>
          <button onClick={saveSettings} className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm">حفظ</button>
        </div>
      )}
    </div>
  );
};
