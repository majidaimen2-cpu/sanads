import React, { useEffect, useState } from 'react';
import { FileCheck, Search, Filter, Building2, Coins, Clock, ExternalLink } from 'lucide-react';
import { ServiceItem } from '../types';
import { YasminaApi } from '../lib/api';

export const ServicesPage: React.FC = () => {
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [authorityFilter, setAuthorityFilter] = useState('all');

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/services', {
        headers: YasminaApi.getAuthHeaders(),
      }).catch(() => null);

      if (res && res.ok) {
        const body = await res.json();
        if (body.data && Array.isArray(body.data)) {
          const mapped = body.data.map((s: any) => ({
            id: String(s.id),
            code: s.code,
            nameAr: s.nameAr || s.name,
            nameEn: s.nameEn,
            authority: s.authority,
            govFeeOmaR: (s.govFeeBaisa || 0) / 1000,
            officeFeeOmaR: (s.officeFeeBaisa || 0) / 1000,
            active: s.active !== false,
          }));
          setServices(mapped);
          return;
        }
      }
      setServices(YasminaApi.getServices());
    } catch (err) {
      console.warn('Error loading services:', err);
    } finally {
      setLoading(false);
    }
  };

  const filtered = services.filter((s) => {
    const q = searchQuery.toLowerCase().trim();
    const matches = !q || s.nameAr.toLowerCase().includes(q) || s.code.toLowerCase().includes(q) || s.authority.toLowerCase().includes(q);
    if (!matches) return false;
    if (authorityFilter !== 'all' && s.authority !== authorityFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-12" dir="rtl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
            <FileCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-100">دليل الخدمات الحكومية والرسوم (Government Services)</h1>
            <p className="text-xs text-slate-400 mt-0.5">
              قائمة الخدمات الرسمية المعتمدة لوزارات العمل، التجارة والصناعة (استثمر بسهولة)، وشرطة عُمان السلطانية.
            </p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="بحث في الخدمات الحكومية..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2 rounded-xl text-xs focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">الجهة:</span>
          <select
            value={authorityFilter}
            onChange={(e) => setAuthorityFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded-xl text-xs"
          >
            <option value="all">كافة الجهات الحكومية</option>
            <option value="MOCI">وزارة التجارة والصناعة (استثمر بسهولة)</option>
            <option value="MOL">وزارة العمل</option>
            <option value="ROP">شرطة عُمان السلطانية</option>
            <option value="MUNICIPALITY">البلديات والتراخيص</option>
          </select>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((srv) => (
          <div key={srv.id} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3 shadow-md">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                  {srv.code}
                </span>
                <h3 className="font-bold text-slate-100 text-sm mt-1.5">{srv.nameAr}</h3>
              </div>
              <span className="text-[10px] text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded-full font-bold">
                {srv.authority}
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl text-xs space-y-1.5 text-slate-300">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">الرسوم الحكومية:</span>
                <span className="font-bold text-slate-200">
                  {srv.govFeeOmaR !== undefined ? `${srv.govFeeOmaR.toFixed(3)} ر.ع` : 'حسب البوابة'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">أتعاب مكتب سند:</span>
                <span className="font-bold text-emerald-400">
                  {srv.officeFeeOmaR !== undefined ? `${srv.officeFeeOmaR.toFixed(3)} ر.ع` : '3.000 ر.ع'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
