import React, { useState, useEffect } from 'react';
import {
  Settings,
  User,
  Lock,
  ShieldCheck,
  KeyRound,
  Eye,
  EyeOff,
  Check,
  Save,
  AlertCircle,
  Sparkles,
  RefreshCw,
  BadgeCheck,
} from 'lucide-react';
import { YasminaApi } from '../lib/api';
import { UserUser } from '../types';

export const SettingsPage: React.FC = () => {
  // Current user state
  const [currentUser, setCurrentUser] = useState<UserUser | null>(() => YasminaApi.getCurrentUser());
  const [loadingProfile, setLoadingProfile] = useState(false);

  // AI & Automation Settings
  const [model, setModel] = useState('gemini-3.8-flash');
  const [autoReply, setAutoReply] = useState(true);
  const [aiSaved, setAiSaved] = useState(false);

  // Username form state
  const [newUsername, setNewUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [usernamePassword, setUsernamePassword] = useState('');
  const [showUsernamePass, setShowUsernamePass] = useState(false);
  const [usernameLoading, setUsernameLoading] = useState(false);
  const [usernameSuccess, setUsernameSuccess] = useState<string | null>(null);
  const [usernameError, setUsernameError] = useState<string | null>(null);

  // Password form state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showOldPass, setShowOldPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  // Fetch latest profile from DB on mount
  useEffect(() => {
    let mounted = true;
    const fetchLatest = async () => {
      setLoadingProfile(true);
      const res = await YasminaApi.getProfile();
      if (mounted && res.success && res.user) {
        setCurrentUser(res.user);
        setNewUsername(res.user.username || '');
        setDisplayName(res.user.displayName || res.user.name || '');
      }
      setLoadingProfile(false);
    };

    fetchLatest();

    fetch('/api/whatsapp/auto-reply')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (mounted && d && typeof d.autoReplyEnabled === 'boolean') {
          setAutoReply(d.autoReplyEnabled);
        }
      })
      .catch(() => {});

    const onUserUpdated = (e: any) => {
      if (e.detail) {
        setCurrentUser(e.detail);
        setNewUsername(e.detail.username || '');
        setDisplayName(e.detail.displayName || e.detail.name || '');
      }
    };

    window.addEventListener('yasmina_user_updated', onUserUpdated);
    return () => {
      mounted = false;
      window.removeEventListener('yasmina_user_updated', onUserUpdated);
    };
  }, []);

  // Password requirements live checks
  const ruleLength = newPassword.length >= 10;
  const ruleUpper = /[A-Z]/.test(newPassword);
  const ruleLower = /[a-z]/.test(newPassword);
  const ruleNumber = /[0-9]/.test(newPassword);
  const ruleMatch = newPassword.length > 0 && newPassword === confirmPassword;
  const isPasswordValid = ruleLength && ruleUpper && ruleLower && ruleNumber && ruleMatch;

  // Handle Username update
  const handleUpdateUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    setUsernameError(null);
    setUsernameSuccess(null);

    const cleanUser = newUsername.trim().toLowerCase();
    const cleanDisplay = displayName.trim();

    if (!cleanUser) {
      setUsernameError('يرجى كتابة اسم المستخدم الجديد.');
      return;
    }

    if (cleanUser.length < 3 || cleanUser.length > 32) {
      setUsernameError('اسم المستخدم يجب أن يتكون من 3 إلى 32 حرفاً.');
      return;
    }

    if (!/^[a-zA-Z0-9_.-]+$/.test(cleanUser)) {
      setUsernameError('اسم المستخدم يجب أن يحتوي على أحرف إنجليزية وأرقام وعلامات (_ . -) فقط بدون مسافات.');
      return;
    }

    if (!usernamePassword) {
      setUsernameError('يرجى إدخال كلمة المرور الحالية لتأكيد التغيير لأمان حسابك.');
      return;
    }

    setUsernameLoading(true);
    try {
      const res = await YasminaApi.changeUsername(cleanUser, cleanDisplay, usernamePassword);
      if (res.success && res.user) {
        setUsernameSuccess(res.message || 'تم تحديث اسم المستخدم والبيانات الشخصية بنجاح.');
        setUsernamePassword('');
        setCurrentUser(res.user);
        setTimeout(() => setUsernameSuccess(null), 5000);
      } else {
        setUsernameError(res.error || 'فشل تحديث اسم المستخدم. يرجى التحقق من كلمة المرور.');
      }
    } catch (err: any) {
      setUsernameError(err?.message || 'حدث خطأ في الاتصال بالخادم.');
    } finally {
      setUsernameLoading(false);
    }
  };

  // Handle Password update
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    setPasswordSuccess(null);

    if (!oldPassword) {
      setPasswordError('يرجى إدخال كلمة المرور الحالية.');
      return;
    }

    if (!newPassword) {
      setPasswordError('يرجى إدخال كلمة المرور الجديدة.');
      return;
    }

    if (!isPasswordValid) {
      if (!ruleMatch) {
        setPasswordError('كلمتا المرور الجديدة والتأكيد غير متطابقتين.');
      } else {
        setPasswordError('يرجى استيفاء جميع شروط قوة كلمة المرور الموضحة أدناه.');
      }
      return;
    }

    if (oldPassword === newPassword) {
      setPasswordError('كلمة المرور الجديدة يجب أن تكون مختلفة عن كلمة المرور الحالية.');
      return;
    }

    setPasswordLoading(true);
    try {
      const res = await YasminaApi.changePassword(oldPassword, newPassword);
      if (res.success) {
        setPasswordSuccess(res.message || 'تم تغيير كلمة المرور بنجاح.');
        setOldPassword('');
        setNewPassword('');
        setConfirmPassword('');
        setTimeout(() => setPasswordSuccess(null), 5000);
      } else {
        setPasswordError(res.error || 'فشل تغيير كلمة المرور. تحقق من كلمة المرور الحالية.');
      }
    } catch (err: any) {
      setPasswordError(err?.message || 'تعذر الاتصال بالخادم لتحديث كلمة المرور.');
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleSaveAi = async () => {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('yasmina_wa_autoreply', String(autoReply));
      }
      await fetch('/api/whatsapp/auto-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: autoReply }),
      });
    } catch (_) {}
    setAiSaved(true);
    setTimeout(() => setAiSaved(false), 2500);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto pb-16" dir="rtl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2.5">
          <Settings className="w-7 h-7 text-emerald-400" />
          <span>الإعدادات وإدارة الحساب (Account & Settings)</span>
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          إدارة اسم المستخدم وكلمة المرور وحماية بيانات حساب مكتب سند وإعدادات الذكاء الاصطناعي
        </p>
      </div>

      {/* User Info Overview Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/30 border border-slate-800 rounded-2xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold text-xl shadow-inner">
              {currentUser?.name ? currentUser.name.charAt(0) : 'س'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-100 text-lg">
                  {currentUser?.displayName || currentUser?.name || 'مكتب سند المعتمد'}
                </h3>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  <BadgeCheck className="w-3.5 h-3.5" />
                  {currentUser?.role === 'SUPER_ADMIN'
                    ? 'مسؤول النظام (Super Admin)'
                    : currentUser?.role === 'MANAGER'
                    ? 'مدير فرع'
                    : 'موظف خدمة عملاء'}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                اسم المستخدم الحالي: <span className="text-emerald-400 font-bold">@{currentUser?.username || 'admin'}</span>
                {currentUser?.email && <span className="mr-3 text-slate-500">| {currentUser.email}</span>}
              </p>
            </div>
          </div>

          <div className="text-left flex items-center gap-2">
            <button
              onClick={async () => {
                setLoadingProfile(true);
                const res = await YasminaApi.getProfile();
                if (res.user) setCurrentUser(res.user);
                setLoadingProfile(false);
              }}
              disabled={loadingProfile}
              className="text-xs text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700/60 transition flex items-center gap-1.5"
              title="تحديث البيانات"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingProfile ? 'animate-spin text-emerald-400' : ''}`} />
              <span>تحديث الحالة</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Sections: Username & Password */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 1: Change Username */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 pb-4 border-b border-slate-800 mb-5">
              <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-100">تغيير اسم المستخدم (Username)</h2>
                <p className="text-xs text-slate-400">تحديث المعرف المستخدم لتسجيل الدخول والاسم الظاهر</p>
              </div>
            </div>

            {usernameSuccess && (
              <div className="mb-4 p-3.5 bg-emerald-950/50 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{usernameSuccess}</span>
              </div>
            )}

            {usernameError && (
              <div className="mb-4 p-3.5 bg-red-950/50 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                <span>{usernameError}</span>
              </div>
            )}

            <form id="username-form" onSubmit={handleUpdateUsername} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  اسم المستخدم الجديد (Username):
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))}
                    placeholder="مثال: sanad_admin"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-slate-100 px-3.5 py-2.5 rounded-xl text-sm font-mono dir-ltr text-right transition"
                    required
                  />
                  <span className="absolute left-3 top-2.5 text-xs text-slate-500 font-mono">@</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  أحرف إنجليزية وأرقام و (_ . -) بدون مسافات (3-32 حرفاً).
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  الاسم الظاهر في النظام (Display Name):
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="مثال: مكتب سند - فرع مسقط"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-slate-100 px-3.5 py-2.5 rounded-xl text-sm transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  كلمة المرور الحالية لتأكيد الهوية:
                </label>
                <div className="relative">
                  <input
                    type={showUsernamePass ? 'text' : 'password'}
                    value={usernamePassword}
                    onChange={(e) => setUsernamePassword(e.target.value)}
                    placeholder="أدخل كلمة المرور الحالية للموافقة"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-slate-100 px-3.5 py-2.5 rounded-xl text-sm transition pl-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowUsernamePass(!showUsernamePass)}
                    className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-200 transition"
                  >
                    {showUsernamePass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </form>
          </div>

          <div className="pt-5 mt-5 border-t border-slate-800/80">
            <button
              type="submit"
              form="username-form"
              disabled={usernameLoading || !newUsername.trim() || !usernamePassword}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold px-4 py-2.5 rounded-xl text-sm transition shadow-sm"
            >
              {usernameLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>جاري تحديث اسم المستخدم...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>حفظ اسم المستخدم الجديد</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Section 2: Change Password */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 pb-4 border-b border-slate-800 mb-5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-100">تغيير الرقم السري (Password)</h2>
                <p className="text-xs text-slate-400">تشفير وحماية الحساب بكلمة مرور جديدة قوية</p>
              </div>
            </div>

            {passwordSuccess && (
              <div className="mb-4 p-3.5 bg-emerald-950/50 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{passwordSuccess}</span>
              </div>
            )}

            {passwordError && (
              <div className="mb-4 p-3.5 bg-red-950/50 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                <span>{passwordError}</span>
              </div>
            )}

            <form id="password-form" onSubmit={handleUpdatePassword} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  كلمة المرور الحالية:
                </label>
                <div className="relative">
                  <input
                    type={showOldPass ? 'text' : 'password'}
                    value={oldPassword}
                    onChange={(e) => setOldPassword(e.target.value)}
                    placeholder="كلمة المرور الحالية"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-slate-100 px-3.5 py-2.5 rounded-xl text-sm transition pl-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowOldPass(!showOldPass)}
                    className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-200 transition"
                  >
                    {showOldPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  كلمة المرور الجديدة:
                </label>
                <div className="relative">
                  <input
                    type={showNewPass ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="كلمة المرور الجديدة (10 خانات فأكثر)"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-slate-100 px-3.5 py-2.5 rounded-xl text-sm transition pl-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPass(!showNewPass)}
                    className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-200 transition"
                  >
                    {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  تأكيد كلمة المرور الجديدة:
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPass ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="أعد إدخال كلمة المرور الجديدة"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-slate-100 px-3.5 py-2.5 rounded-xl text-sm transition pl-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPass(!showConfirmPass)}
                    className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-200 transition"
                  >
                    {showConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Password strength checklist */}
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 space-y-1.5 text-[11px]">
                <p className="font-semibold text-slate-400 mb-1">شروط الأمان المطلوبة:</p>
                <div className="grid grid-cols-2 gap-1.5">
                  <div className={`flex items-center gap-1.5 ${ruleLength ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] ${ruleLength ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800'}`}>
                      {ruleLength ? '✓' : '•'}
                    </div>
                    <span>10 خانات على الأقل</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${ruleUpper ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] ${ruleUpper ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800'}`}>
                      {ruleUpper ? '✓' : '•'}
                    </div>
                    <span>حرف كبير (A-Z)</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${ruleLower ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] ${ruleLower ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800'}`}>
                      {ruleLower ? '✓' : '•'}
                    </div>
                    <span>حرف صغير (a-z)</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${ruleNumber ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] ${ruleNumber ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800'}`}>
                      {ruleNumber ? '✓' : '•'}
                    </div>
                    <span>رقم واحد على الأقل (0-9)</span>
                  </div>
                </div>
                {newPassword && confirmPassword && (
                  <div className={`pt-1 border-t border-slate-800/60 flex items-center gap-1.5 ${ruleMatch ? 'text-emerald-400' : 'text-red-400'}`}>
                    <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] ${ruleMatch ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20'}`}>
                      {ruleMatch ? '✓' : '✗'}
                    </div>
                    <span>{ruleMatch ? 'كلمتا المرور متطابقتان' : 'كلمتا المرور غير متطابقتين'}</span>
                  </div>
                )}
              </div>
            </form>
          </div>

          <div className="pt-5 mt-5 border-t border-slate-800/80">
            <button
              type="submit"
              form="password-form"
              disabled={passwordLoading || !oldPassword || !isPasswordValid}
              className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-sm transition shadow-sm"
            >
              {passwordLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>جاري تحديث كلمة المرور...</span>
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>تحديث كلمة المرور</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Section 3: AI & Automation System Settings */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-5">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-800">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">إعدادات الذكاء الاصطناعي والموديل الذكي (AI Engine)</h2>
            <p className="text-xs text-slate-400">ضبط محرك Gemini 3.8 Flash لاستخراج بيانات السجلات والرد الآلي على استفسارات المراجعين</p>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 block">نموذج الذكاء الاصطناعي (AI Model):</label>
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 p-3 rounded-xl text-sm focus:outline-none focus:border-emerald-500"
          >
            <option value="gemini-3.8-flash">Gemini 3.8 Flash (موصى به - أسرع دقة واستخراج للمستندات السجلات التجاري)</option>
            <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (محرك سريع مساند)</option>
          </select>
        </div>

        <div className="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div>
            <p className="font-bold text-slate-200 text-sm">الرد البشري التلقائي على الواتساب</p>
            <p className="text-xs text-slate-400 mt-0.5">
              إرسال ردود إنسانية لطيفة واستخراج المعاملات فوراً في تبويب "الطلبات"
            </p>
          </div>
          <button
            onClick={async () => {
              const nextVal = !autoReply;
              setAutoReply(nextVal);
              if (typeof localStorage !== 'undefined') {
                localStorage.setItem('yasmina_wa_autoreply', String(nextVal));
              }
              try {
                await fetch('/api/whatsapp/auto-reply', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ enabled: nextVal }),
                });
              } catch (_) {}
            }}
            className={`w-12 h-6 rounded-full transition p-1 flex items-center ${
              autoReply ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'
            }`}
          >
            <div className="w-4 h-4 bg-slate-950 rounded-full" />
          </button>
        </div>

        <button
          onClick={handleSaveAi}
          className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-5 py-2.5 rounded-xl text-sm transition border border-slate-700"
        >
          {aiSaved ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400">تم حفظ إعدادات النظام بنجاح</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>حفظ إعدادات النظام</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
