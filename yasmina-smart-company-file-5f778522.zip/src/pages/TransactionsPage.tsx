import React, { useEffect, useState } from 'react';
import { FileText, Plus, Search, X } from 'lucide-react';
import { Transaction } from '../types';
import { YasminaApi } from '../lib/api';

const DEFAULT_TXS: Transaction[] = [
  {
    id: 'txn-101',
    title: 'تجديد سجل تجاري فرع مسقط',
    customerName: 'سالم بن عبد الله البوسعيدي',
    customerPhone: '+96891234567',
    serviceType: 'إستثمر بسهولة',
    portalName: 'Invest Easy Portal',
    status: 'submitted',
    priority: 'high',
    feeOmaR: 35.0,
    createdAt: '2026-10-22',
  },
  {
    id: 'txn-102',
    title: 'طلب مأذونية قوى عاملة (3 عمال)',
    customerName: 'خالد بن أحمد المعمري',
    customerPhone: '+96898765432',
    serviceType: 'وزارة العمل',
    portalName: 'Ministry of Labour',
    status: 'under_review',
    priority: 'high',
    feeOmaR: 601.0,
    createdAt: '2026-10-21',
  },
  {
    id: 'txn-103',
    title: 'إصدار ترخيص بلدي لمحل تجميل',
    customerName: 'مريم بنت راشد الحوسنية',
    customerPhone: '+96895551234',
    serviceType: 'بلديتي',
    portalName: 'Baladiyeti Portal',
    status: 'draft',
    priority: 'medium',
    feeOmaR: 45.0,
    createdAt: '2026-10-20',
  },
];

export const TransactionsPage: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>(DEFAULT_TXS);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    customerName: '',
    customerPhone: '+968',
    serviceType: 'إستثمر بسهولة',
    feeOmaR: 25,
    status: 'submitted',
  });

  const loadTransactions = async () => {
    try {
      const localTxs = YasminaApi.getTransactions();
      const res = await fetch('/api/transactions', {
        headers: YasminaApi.getAuthHeaders(),
      }).catch(() => null);

      const map = new Map<string, Transaction>();
      for (const lt of localTxs) {
        if (lt && lt.id) map.set(String(lt.id), lt);
      }

      if (res && res.ok) {
        const body = await res.json();
        const rows = body.data || body.transactions || [];
        if (Array.isArray(rows)) {
          for (const r of rows) {
            const id = String(r.number || r.id);
            map.set(id, {
              id,
              title: r.notes || r.serviceName || `معاملة رقم ${id}`,
              customerName: r.customerName || 'مراجع مكتب سند',
              customerPhone: r.customerPhone || '+968',
              serviceType: r.serviceCategory || 'بوابة حكومية',
              portalName: 'Gov Portal',
              status:
                r.status === 'COMPLETED'
                  ? 'completed'
                  : r.status === 'IN_PROGRESS'
                  ? 'under_review'
                  : 'submitted',
              priority: r.priority === 'URGENT' ? 'high' : 'medium',
              feeOmaR: r.totalBaisa ? r.totalBaisa / 1000 : Number(r.feeOmaR || 20),
              createdAt:
                typeof r.createdAt === 'string'
                  ? r.createdAt.slice(0, 10)
                  : new Date().toISOString().slice(0, 10),
            });
          }
        }
      }

      if (map.size > 0) {
        setTransactions(Array.from(map.values()));
      }
    } catch (_) {}
  };

  useEffect(() => {
    loadTransactions();
  }, []);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;
    const newTx: Transaction = {
      id: `YAS-${new Date().getFullYear()}-${String(transactions.length + 104).padStart(4, '0')}`,
      title: formData.title.trim(),
      customerName: formData.customerName.trim() || 'عميل مكتب سند',
      customerPhone: formData.customerPhone.trim(),
      serviceType: formData.serviceType,
      portalName: 'Oman Gov Portal',
      status: formData.status as any,
      priority: 'high',
      feeOmaR: Number(formData.feeOmaR) || 0,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    YasminaApi.saveTransaction(newTx);
    setTransactions((prev) => [newTx, ...prev]);
    setShowAddModal(false);
    setFormData({
      title: '',
      customerName: '',
      customerPhone: '+968',
      serviceType: 'إستثمر بسهولة',
      feeOmaR: 25,
      status: 'submitted',
    });
  };

  const filtered = transactions.filter((t) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      !q ||
      String(t.id).toLowerCase().includes(q) ||
      (t.title && t.title.toLowerCase().includes(q)) ||
      (t.customerName && t.customerName.toLowerCase().includes(q)) ||
      (t.serviceType && t.serviceType.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 pb-12" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <FileText className="w-6 h-6 text-emerald-400" />
            جدول ومتابعة المعاملات الحكومية (Transactions)
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            تتبع المعاملات المحولة من طلبات الواتساب وحالة مراجعتها في البوابات الرسمية
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs transition shadow-md cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>تسجيل معاملة جديدة</span>
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="ابحث برقم المعاملة أو اسم الزبون..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-100 pr-10 pl-4 py-2 rounded-xl text-sm focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase text-[11px]">
              <tr>
                <th className="p-4">رقم المعاملة</th>
                <th className="p-4">اسم المعاملة والزبون</th>
                <th className="p-4">الجهة الحكومية</th>
                <th className="p-4">الرسوم (ر.ع)</th>
                <th className="p-4">حالة المعاملة</th>
                <th className="p-4">التاريخ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {filtered.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-4 font-mono font-bold text-emerald-400">{t.id}</td>
                  <td className="p-4">
                    <p className="font-bold text-slate-100 text-sm">{t.title}</p>
                    <p className="text-[11px] text-slate-400">
                      {t.customerName} {t.customerPhone ? `(${t.customerPhone})` : ''}
                    </p>
                  </td>
                  <td className="p-4 font-semibold text-cyan-400">{t.serviceType || 'خدمات سند'}</td>
                  <td className="p-4 font-bold text-amber-400">{Number(t.feeOmaR || 0).toFixed(3)} ر.ع</td>
                  <td className="p-4">
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full font-semibold">
                      {t.status === 'submitted'
                        ? 'مقدمة للبوابة'
                        : t.status === 'under_review'
                        ? 'قيد التدقيق'
                        : t.status === 'completed'
                        ? 'منجزة'
                        : 'مسودة'}
                    </span>
                  </td>
                  <td className="p-4 text-slate-400">{t.createdAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm">تسجيل معاملة حكومية جديدة</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">مسمى المعاملة *:</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="مثال: تجديد سجل تجاري / إصدار ترخيص بلدي"
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم الزبون / المنشأة:</label>
                <input
                  type="text"
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 px-3 py-2 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">الجهة الحكومية:</label>
                  <select
                    value={formData.serviceType}
                    onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 px-3 py-2 rounded-xl"
                  >
                    <option value="إستثمر بسهولة">إستثمر بسهولة</option>
                    <option value="وزارة العمل">وزارة العمل</option>
                    <option value="بلديتي">بلديتي</option>
                    <option value="شرطة عمان السلطانية">شرطة عمان السلطانية</option>
                    <option value="جهاز الضرائب">جهاز الضرائب</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">الرسوم (ر.ع):</label>
                  <input
                    type="number"
                    step="0.001"
                    value={formData.feeOmaR}
                    onChange={(e) => setFormData({ ...formData, feeOmaR: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 text-amber-400 font-bold px-3 py-2 rounded-xl"
                  />
                </div>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  إلغاء
                </button>
                <button type="submit" className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl">
                  حفظ المعاملة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
