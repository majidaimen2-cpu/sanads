import React, { useState, useEffect } from 'react';
import { NavigationTab, CustomerRequest } from './types';
import { Sidebar } from './components/navigation/Sidebar';
import { Navbar } from './components/navigation/Navbar';
import { MobileBottomNav } from './components/navigation/MobileBottomNav';
import { BreadcrumbBar } from './components/navigation/BreadcrumbBar';
import { CompaniesPage } from './pages/CompaniesPage';
import { CustomerRequestsPage } from './pages/CustomerRequestsPage';
import { WhatsAppPage } from './pages/WhatsAppPage';
import { DashboardPage } from './pages/DashboardPage';
import { TransactionsPage } from './pages/TransactionsPage';
import { EmployeesPage } from './pages/EmployeesPage';
import { ContractsPage } from './pages/ContractsPage';
import { ServicesPage } from './pages/ServicesPage';
import { InvoicesPage } from './pages/InvoicesPage';
import { CustomersPage } from './pages/CustomersPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { SettingsPage } from './pages/SettingsPage';
import { DocumentInboxPage } from './pages/DocumentInboxPage';

export const App: React.FC = () => {
  // Read initial tab from URL hash, e.g. #companies
  const getTabFromHash = (): NavigationTab => {
    if (typeof window !== 'undefined') {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      const validTabs: NavigationTab[] = [
        'dashboard',
        'companies',
        'documents',
        'requests',
        'whatsapp',
        'transactions',
        'employees',
        'contracts',
        'services',
        'invoices',
        'customers',
        'analytics',
        'settings',
      ];
      if (validTabs.includes(hash as NavigationTab)) {
        return hash as NavigationTab;
      }
    }
    return 'companies';
  };

  const [activeTab, setActiveTabState] = useState<NavigationTab>(getTabFromHash);
  const [selectedWhatsAppPhone, setSelectedWhatsAppPhone] = useState<string>('');
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | undefined>();

  const setActiveTab = (tab: NavigationTab) => {
    setActiveTabState(tab);
    if (typeof window !== 'undefined') {
      window.location.hash = tab;
    }
  };

  // Sync state on hash change (e.g. user visits or clicks #companies)
  useEffect(() => {
    const handleHashChange = () => {
      const current = getTabFromHash();
      setActiveTabState(current);
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigateToWhatsApp = (phone: string) => {
    setSelectedWhatsAppPhone(phone);
    setActiveTab('whatsapp');
  };

  const handleConvertToTransaction = (_req: CustomerRequest) => {
    setActiveTab('transactions');
  };

  const handleNavigateToCompanyTransactions = (companyId?: string) => {
    setSelectedCompanyId(companyId);
    setActiveTab('transactions');
  };

  const handleNavigateToCompanyEmployees = (companyId?: string) => {
    setSelectedCompanyId(companyId);
    setActiveTab('employees');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row font-sans" dir="rtl">
      {/* Sidebar Navigation */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} requestCount={4} />

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} pendingRequestsCount={2} />
        <BreadcrumbBar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 p-4 sm:p-6 overflow-y-auto mb-16 md:mb-0">
          {activeTab === 'companies' && (
            <CompaniesPage
              onNavigateToWhatsApp={handleNavigateToWhatsApp}
              onNavigateToTransactions={handleNavigateToCompanyTransactions}
              onNavigateToEmployees={handleNavigateToCompanyEmployees}
            />
          )}

          {activeTab === 'documents' && <DocumentInboxPage />}

          {activeTab === 'dashboard' && <DashboardPage setActiveTab={setActiveTab} />}

          {activeTab === 'requests' && (
            <CustomerRequestsPage
              onConvertToTransaction={handleConvertToTransaction}
              onNavigateToWhatsApp={handleNavigateToWhatsApp}
            />
          )}

          {activeTab === 'whatsapp' && (
            <WhatsAppPage
              initialPhone={selectedWhatsAppPhone}
              onNavigateToRequests={() => setActiveTab('requests')}
            />
          )}

          {activeTab === 'transactions' && <TransactionsPage />}
          {activeTab === 'employees' && <EmployeesPage initialCompanyId={selectedCompanyId} onNavigateToWhatsApp={handleNavigateToWhatsApp} />}
          {activeTab === 'contracts' && <ContractsPage />}
          {activeTab === 'services' && <ServicesPage />}
          {activeTab === 'invoices' && <InvoicesPage />}
          {activeTab === 'customers' && <CustomersPage />}
          {activeTab === 'analytics' && <AnalyticsPage />}
          {activeTab === 'settings' && <SettingsPage />}
        </main>

        <MobileBottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>
    </div>
  );
};

export default App;
