import React from 'react';
import { ChevronLeft, Home } from 'lucide-react';
import { NavigationTab } from '../../types';

interface BreadcrumbBarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
}

export const BreadcrumbBar: React.FC<BreadcrumbBarProps> = ({ activeTab, setActiveTab }) => {
  const getTabTitle = (tab: NavigationTab) => {
    switch (tab) {
      case 'dashboard': return 'لوحة التحكم الرئيسية';
      case 'companies': return 'سجل المنشآت والشركات والسجلات التجارية (CR)';
      case 'documents': return 'صندوق الوثائق الذكي وتأكيد الملفات';
      case 'requests': return 'الطلبات والاستفسارات المستخرجة بالذكاء الاصطناعي (AI Requests)';
      case 'whatsapp': return 'إدارة محادثات الواتساب والرد الذكي';
      case 'transactions': return 'سجل المعاملات الحكومية ومتابعة البوابات';
      case 'employees': return 'سجل القوى العاملة والعمالة المسجلة';
      case 'contracts': return 'العقود والاتفاقيات الحكومية والتجارية';
      case 'services': return 'دليل الخدمات الحكومية والرسوم المعتمدة';
      case 'invoices': return 'سجل الفواتير والتحصيل الإلكتروني (VAT 5%)';
      case 'customers': return 'دليل المتعاملين';
      case 'analytics': return 'التقارير والإحصائيات والأداء';
      case 'settings': return 'إدارة الحساب والأمان • تغيير الرقم السري واسم المستخدم';
      default: return 'الرئيسية';
    }
  };

  return (
    <div className="flex items-center gap-2 text-xs text-slate-400 py-3 px-6 bg-slate-950/40 border-b border-slate-800/60">
      <button onClick={() => setActiveTab('dashboard')} className="hover:text-emerald-400 flex items-center gap-1">
        <Home className="w-3.5 h-3.5" />
        <span>الرئيسية</span>
      </button>
      <ChevronLeft className="w-3.5 h-3.5 opacity-50" />
      <span className="text-slate-200 font-semibold">{getTabTitle(activeTab)}</span>
    </div>
  );
};
