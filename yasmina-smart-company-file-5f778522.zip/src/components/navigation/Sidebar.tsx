import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Sparkles,
  MessageSquare,
  FileText,
  Users,
  BarChart3,
  Settings,
  Coins,
  ShieldCheck,
  FileCheck,
  Briefcase,
  ExternalLink,
  Inbox
} from 'lucide-react';
import { NavigationTab } from '../../types';

interface SidebarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  requestCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, requestCount = 4 }) => {
  const navItems: { id: NavigationTab; label: string; icon: React.ReactNode; badge?: string | number; isAi?: boolean }[] = [
    { id: 'dashboard', label: 'لوحة التحكم', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'companies', label: 'المنشآت والشركات', icon: <Building2 className="w-5 h-5 text-emerald-400" /> },
    { id: 'documents', label: 'صندوق الوثائق', icon: <Inbox className="w-5 h-5 text-amber-400" /> },
    { id: 'requests', label: 'طلبات الواتساب', icon: <Sparkles className="w-5 h-5 text-cyan-400" />, badge: requestCount, isAi: true },
    { id: 'whatsapp', label: 'محادثات الواتساب', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'transactions', label: 'المعاملات الحكومية', icon: <FileText className="w-5 h-5" /> },
    { id: 'employees', label: 'القوى العاملة والعمال', icon: <Users className="w-5 h-5" /> },
    { id: 'contracts', label: 'العقود والاتفاقيات', icon: <ShieldCheck className="w-5 h-5" /> },
    { id: 'services', label: 'الخدمات الحكومية', icon: <FileCheck className="w-5 h-5" /> },
    { id: 'invoices', label: 'الفواتير والمالية', icon: <Coins className="w-5 h-5" /> },
    { id: 'customers', label: 'دليل المتعاملين', icon: <Briefcase className="w-5 h-5" /> },
    { id: 'analytics', label: 'التقارير والإحصائيات', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'settings', label: 'الإعدادات وتغيير الرمز', icon: <Settings className="w-5 h-5 text-emerald-400" /> }
  ];

  return (
    <aside className="w-64 bg-slate-900 border-l border-slate-800 text-slate-200 hidden md:flex flex-col justify-between h-screen sticky top-0 z-30 select-none">
      {/* Brand Header */}
      <div>
        <div className="p-5 border-b border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-emerald-500/20">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-slate-100 text-base leading-tight">مركز سند الذكي</h1>
            <p className="text-[11px] text-emerald-400 font-medium">سلطنة عمان • Sanad Portal</p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="p-3 space-y-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition duration-150 ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-slate-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  {item.icon}
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      isActive
                        ? 'bg-slate-950 text-emerald-400'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {item.isAi ? `AI ${item.badge}` : item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* External Portals Section */}
      <div className="p-4 border-t border-slate-800 space-y-2">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2">بوابات سند الحكومية</p>
        <div className="space-y-1 text-xs">
          <a
            href="https://investeasy.om"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <span>إستثمر سهولة</span>
            <ExternalLink className="w-3 h-3" />
          </a>
          <a
            href="https://mol.gov.om"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <span>وزارة العمل</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </aside>
  );
};
