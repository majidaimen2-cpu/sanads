import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Bell,
  Sun,
  Moon,
  Building2,
  CheckCheck,
  AlertTriangle,
  Clock,
  FileWarning,
  ExternalLink,
  Check,
  RefreshCw,
  Calendar,
  X,
  KeyRound,
  Trash2,
} from 'lucide-react';
import { NavigationTab } from '../../types';
import { useTheme } from '../../context/ThemeContext';
import { YasminaApi } from '../../lib/api';

interface NavbarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  pendingRequestsCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  pendingRequestsCount = 2,
}) => {
  const { isDark, toggleTheme } = useTheme();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeView, setActiveView] = useState<'notifications' | 'monitor'>('notifications');
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [summary, setSummary] = useState<any>({
    total: 0,
    unreadCount: 0,
    expiredCount: 0,
    expiringTodayCount: 0,
    expiring7Count: 0,
    expiring30Count: 0,
    needsReviewCount: 0,
  });
  const [monitorItems, setMonitorItems] = useState<any[]>([]);
  const [monitorSummary, setMonitorSummary] = useState<any>(null);
  const [stageFilter, setStageFilter] = useState<string>('ALL');
  const [docTypeFilter, setDocTypeFilter] = useState<string>('ALL');
  const [searchText, setSearchText] = useState<string>('');
  const [loadingNotifs, setLoadingNotifs] = useState<boolean>(false);
  const [editingItemKey, setEditingItemKey] = useState<string | null>(null);
  const [editExpiryValue, setEditExpiryValue] = useState<string>('');
  const [editHasNoExpiry, setEditHasNoExpiry] = useState<boolean>(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(() => YasminaApi.getCurrentUser());

  useEffect(() => {
    const onUserUpdate = (e: any) => {
      if (e.detail) {
        setCurrentUser(e.detail);
      }
    };
    window.addEventListener('yasmina_user_updated', onUserUpdate);
    return () => window.removeEventListener('yasmina_user_updated', onUserUpdate);
  }, []);

  const dropdownRef = useRef<HTMLDivElement>(null);

  const loadNotificationsData = async () => {
    try {
      setLoadingNotifs(true);
      const [notifRes, monitorRes] = await Promise.all([
        YasminaApi.fetchServerNotifications().catch(() => null),
        YasminaApi.fetchExpiryMonitorItems().catch(() => null),
      ]);

      if (notifRes) {
        setNotifications(Array.isArray(notifRes.data) ? notifRes.data : []);
        setUnreadCount(typeof notifRes.unreadCount === 'number' ? notifRes.unreadCount : 0);
        if (notifRes.summary) setSummary(notifRes.summary);
      }
      if (monitorRes) {
        setMonitorItems(Array.isArray(monitorRes.data) ? monitorRes.data : []);
        if (monitorRes.summary) setMonitorSummary(monitorRes.summary);
      }
    } finally {
      setLoadingNotifs(false);
    }
  };

  useEffect(() => {
    loadNotificationsData();
    const interval = setInterval(loadNotificationsData, 30000);
    const onRefresh = () => loadNotificationsData();
    window.addEventListener('yasmina_notifications_updated', onRefresh);
    window.addEventListener('yasmina_company_updated', onRefresh);
    window.addEventListener('atendai_company_updated', onRefresh);
    return () => {
      clearInterval(interval);
      window.removeEventListener('yasmina_notifications_updated', onRefresh);
      window.removeEventListener('yasmina_company_updated', onRefresh);
      window.removeEventListener('atendai_company_updated', onRefresh);
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    if (dropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [dropdownOpen]);

  const handleMarkRead = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    await YasminaApi.markServerNotificationRead(id);
    await loadNotificationsData();
  };

  const handleMarkAllRead = async () => {
    await YasminaApi.markAllServerNotificationsRead();
    await loadNotificationsData();
  };

  const handleDeleteNotification = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    await YasminaApi.deleteServerNotification(id);
    await loadNotificationsData();
  };

  const handleClearAllNotifications = async (readOnly = false) => {
    if (readOnly) {
      setNotifications((prev) => prev.filter((n) => !n.isRead));
    } else {
      setNotifications([]);
    }
    await YasminaApi.clearAllServerNotifications(readOnly);
    await loadNotificationsData();
  };

  const handleSaveManualExpiry = async (item: any) => {
    setEditError(null);
    try {
      await YasminaApi.updateServerDocumentExpiry({
        sourceEntity: item.sourceEntity,
        sourceId: String(item.sourceId),
        expiryDate: editHasNoExpiry ? null : editExpiryValue,
        hasNoExpiry: editHasNoExpiry,
      });
      setEditingItemKey(null);
      await loadNotificationsData();
    } catch (err: any) {
      setEditError(err?.message || 'تاريخ غير صالح');
    }
  };

  const getStageBadge = (stage: string, daysRemaining: number | null) => {
    if (stage === 'EXPIRED') {
      return (
        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/40">
          منتهية {daysRemaining !== null ? `(منذ ${Math.abs(daysRemaining)} يوم)` : ''}
        </span>
      );
    }
    if (stage === 'EXPIRING_TODAY') {
      return (
        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-500/20 text-orange-300 border border-orange-500/40">
          تنتهي اليوم
        </span>
      );
    }
    if (stage === 'EXPIRING_7') {
      return (
        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
          تنتهي قريبًا جدًا ({daysRemaining} أيام)
        </span>
      );
    }
    if (stage === 'EXPIRING_30') {
      return (
        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-yellow-500/20 text-yellow-300 border border-yellow-500/40">
          قربت تنتهي ({daysRemaining} يوم)
        </span>
      );
    }
    if (stage === 'NEEDS_REVIEW') {
      return (
        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
          تحتاج إلى مراجعة
        </span>
      );
    }
    if (stage === 'NO_EXPIRY') {
      return (
        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40">
          دائمة / بلا انتهاء
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
        سارية {daysRemaining !== null ? `(${daysRemaining} يوم)` : ''}
      </span>
    );
  };

  const filteredNotifications = notifications.filter((n) => {
    if (stageFilter === 'UNREAD' && n.isRead) return false;
    if (stageFilter === 'EXPIRED' && n.alertStage !== 'EXPIRED') return false;
    if (
      stageFilter === 'EXPIRING_SOON' &&
      n.alertStage !== 'EXPIRING_TODAY' &&
      n.alertStage !== 'EXPIRING_7' &&
      n.alertStage !== 'EXPIRING_30'
    ) {
      return false;
    }
    if (stageFilter === 'NEEDS_REVIEW' && n.alertStage !== 'NEEDS_REVIEW') return false;
    if (docTypeFilter !== 'ALL' && n.docType !== docTypeFilter) return false;
    if (searchText.trim()) {
      const q = searchText.trim().toLowerCase();
      const hay = `${n.companyName || ''} ${n.ownerName || ''} ${n.docNumber || ''} ${n.title || ''}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  const filteredMonitorItems = monitorItems.filter((item) => {
    if (stageFilter === 'EXPIRED' && item.status !== 'EXPIRED') return false;
    if (
      stageFilter === 'EXPIRING_SOON' &&
      item.status !== 'EXPIRING_TODAY' &&
      item.status !== 'EXPIRING_7' &&
      item.status !== 'EXPIRING_30'
    ) {
      return false;
    }
    if (stageFilter === 'NEEDS_REVIEW' && item.status !== 'NEEDS_REVIEW') return false;
    if (docTypeFilter !== 'ALL' && item.docTypeCode !== docTypeFilter) return false;
    if (searchText.trim()) {
      const q = searchText.trim().toLowerCase();
      const hay = `${item.companyName || ''} ${item.ownerName || ''} ${item.docNumber || ''} ${item.docTypeAr || ''}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Right Search & Quick AI Action */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setActiveTab('companies')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition border ${
            activeTab === 'companies'
              ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
          }`}
        >
          <Building2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>المنشآت والسجلات (CR)</span>
        </button>

        <button
          onClick={() => setActiveTab('requests')}
          className="flex items-center gap-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold transition"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">طلبات الواتساب AI</span>
          {pendingRequestsCount > 0 && (
            <span className="bg-emerald-500 text-slate-950 font-black px-1.5 py-0.2 rounded-full text-[10px]">
              {pendingRequestsCount} جديد
            </span>
          )}
        </button>
      </div>

      {/* Left User & Controls */}
      <div className="flex items-center gap-3">
        <button
          onClick={toggleTheme}
          className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition"
          title="تغيير المظهر"
        >
          {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-300" />}
        </button>

        {/* Notification Bell & Expiry Monitoring Drawer */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => {
              setDropdownOpen((prev) => !prev);
              if (!dropdownOpen) loadNotificationsData();
            }}
            className="relative p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl transition"
            title="إشعارات ومراقبة انتهاء صلاحية الوثائق"
            data-testid="notification-bell-button"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span
                data-testid="notification-unread-badge"
                className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-red-500 text-white text-[10px] font-black rounded-full flex items-center justify-center shadow"
              >
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </button>

          {dropdownOpen && (
            <div className="absolute left-0 mt-2 w-[380px] sm:w-[460px] max-h-[82vh] bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50">
              {/* Header */}
              <div className="p-3.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-emerald-400" />
                  <div>
                    <h3 className="text-xs font-bold text-white">
                      مركز إشعارات ومراقبة انتهاء الوثائق
                    </h3>
                    <p className="text-[10px] text-slate-400">
                      توقيت مسقط (Asia/Muscat) • غير مقروء: {unreadCount}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={loadNotificationsData}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
                    title="تحديث الآن"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loadingNotifs ? 'animate-spin text-emerald-400' : ''}`} />
                  </button>
                  {unreadCount > 0 && (
                    <button
                      onClick={handleMarkAllRead}
                      className="flex items-center gap-1 px-2 py-1 text-[10px] font-bold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 rounded-lg transition"
                      title="تعليم جميع الإشعارات كمقروءة"
                    >
                      <CheckCheck className="w-3 h-3" />
                      <span>قراءة الكل</span>
                    </button>
                  )}
                  {notifications.length > 0 && (
                    <button
                      onClick={() => handleClearAllNotifications(false)}
                      className="flex items-center gap-1 px-2 py-1 text-[10px] font-bold bg-red-500/15 hover:bg-red-500/25 text-red-300 border border-red-500/30 rounded-lg transition"
                      title="مسح جميع الإشعارات"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>مسح الكل</span>
                    </button>
                  )}
                  <button
                    onClick={() => setDropdownOpen(false)}
                    className="p-1 text-slate-400 hover:text-white rounded-lg"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Quick KPI Counters */}
              <div className="grid grid-cols-4 gap-1.5 p-2.5 bg-slate-900/90 border-b border-slate-800 text-center">
                <button
                  onClick={() => setStageFilter(stageFilter === 'EXPIRED' ? 'ALL' : 'EXPIRED')}
                  className={`p-1.5 rounded-xl border text-center transition ${
                    stageFilter === 'EXPIRED'
                      ? 'bg-red-500/20 border-red-500/50'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-black text-red-400">
                    {monitorSummary?.expiredCount ?? summary.expiredCount ?? 0}
                  </div>
                  <div className="text-[10px] text-slate-400">منتهية</div>
                </button>
                <button
                  onClick={() => setStageFilter(stageFilter === 'EXPIRING_SOON' ? 'ALL' : 'EXPIRING_SOON')}
                  className={`p-1.5 rounded-xl border text-center transition ${
                    stageFilter === 'EXPIRING_SOON'
                      ? 'bg-amber-500/20 border-amber-500/50'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-black text-amber-400">
                    {(monitorSummary?.expiringTodayCount ?? 0) +
                      (monitorSummary?.expiring7Count ?? 0) +
                      (monitorSummary?.expiring30Count ?? 0)}
                  </div>
                  <div className="text-[10px] text-slate-400">قربت تنتهي</div>
                </button>
                <button
                  onClick={() => setStageFilter(stageFilter === 'NEEDS_REVIEW' ? 'ALL' : 'NEEDS_REVIEW')}
                  className={`p-1.5 rounded-xl border text-center transition ${
                    stageFilter === 'NEEDS_REVIEW'
                      ? 'bg-purple-500/20 border-purple-500/50'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-black text-purple-400">
                    {monitorSummary?.needsReviewCount ?? summary.needsReviewCount ?? 0}
                  </div>
                  <div className="text-[10px] text-slate-400">تحتاج مراجعة</div>
                </button>
                <button
                  onClick={() => setStageFilter('ALL')}
                  className={`p-1.5 rounded-xl border text-center transition ${
                    stageFilter === 'ALL'
                      ? 'bg-emerald-500/20 border-emerald-500/50'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-black text-emerald-400">
                    {monitorSummary?.validCount ?? 0}
                  </div>
                  <div className="text-[10px] text-slate-400">سارية</div>
                </button>
              </div>

              {/* View Switcher & Filters */}
              <div className="p-2.5 bg-slate-950/50 border-b border-slate-800 space-y-2">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setActiveView('notifications')}
                    className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition ${
                      activeView === 'notifications'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    الإشعارات ({notifications.length})
                  </button>
                  <button
                    onClick={() => setActiveView('monitor')}
                    className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition ${
                      activeView === 'monitor'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    جدول مراقبة الوثائق ({monitorItems.length})
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    placeholder="بحث بالشركة، المالك، أو رقم الوثيقة..."
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-[11px] text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                  <select
                    value={docTypeFilter}
                    onChange={(e) => setDocTypeFilter(e.target.value)}
                    className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-[11px] text-slate-200"
                  >
                    <option value="ALL">كل الوثائق</option>
                    <option value="CR">السجل التجاري</option>
                    <option value="COMMERCIAL_LICENSE">الترخيص التجاري/البلدي</option>
                    <option value="TAX_CARD">البطاقة الضريبية</option>
                    <option value="RESIDENCE_CARD">بطاقة الإقامة/الهوية</option>
                    <option value="PASSPORT">جواز السفر</option>
                    <option value="LABOR_PERMIT">تصريح العمل</option>
                    <option value="LEASE_CONTRACT">عقد الإيجار</option>
                  </select>
                </div>
              </div>

              {/* List Body */}
              <div className="overflow-y-auto max-h-[380px] divide-y divide-slate-800/80">
                {activeView === 'notifications' ? (
                  filteredNotifications.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs">
                      لا توجد إشعارات مطابقة للفلتر المحدد حالياً.
                    </div>
                  ) : (
                    filteredNotifications.map((notif) => (
                      <div
                        key={notif.id}
                        onClick={() => {
                          setActiveTab('companies');
                          setDropdownOpen(false);
                        }}
                        className={`p-3 hover:bg-slate-800/60 transition cursor-pointer ${
                          !notif.isRead ? 'bg-slate-900/90 border-r-2 border-emerald-400' : 'opacity-75'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {getStageBadge(notif.alertStage, notif.daysRemaining)}
                            <span className="text-[10px] text-slate-400 font-mono">
                              {notif.docTypeAr || notif.docType} #{notif.docNumber || '-'}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            {!notif.isRead && (
                              <button
                                onClick={(e) => handleMarkRead(notif.id, e)}
                                className="px-2 py-0.5 bg-slate-800 hover:bg-emerald-500/20 text-emerald-400 rounded text-[10px] font-semibold flex items-center gap-1 transition"
                                title="تعليم كمقروء"
                              >
                                <Check className="w-3 h-3" />
                                <span>مقروء</span>
                              </button>
                            )}
                            <button
                              onClick={(e) => handleDeleteNotification(notif.id, e)}
                              className="p-1 text-slate-500 hover:text-red-400 hover:bg-red-500/20 rounded transition"
                              title="مسح هذا الإشعار"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <p className="text-xs font-bold text-slate-100 mt-1.5">{notif.title}</p>
                        <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                          {notif.message}
                        </p>

                        <div className="flex items-center justify-between mt-2 text-[10px] text-slate-400">
                          <span>
                            الشركة: <strong className="text-slate-200">{notif.companyName || '-'}</strong> • المالك:{' '}
                            <strong className="text-slate-200">{notif.ownerName || '-'}</strong>
                          </span>
                          <span className="font-mono text-amber-300">
                            {notif.expiryDate ? `الانتهاء: ${notif.expiryDate}` : 'بدون تاريخ واضح'}
                          </span>
                        </div>
                      </div>
                    ))
                  )
                ) : filteredMonitorItems.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs">
                    لا توجد وثائق مطابقة للبحث.
                  </div>
                ) : (
                  filteredMonitorItems.map((item) => (
                    <div key={item.key} className="p-3 hover:bg-slate-800/50 transition">
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span>{item.companyName}</span>
                            <span className="text-[10px] text-slate-400 font-normal">
                              ({item.ownerName})
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-300 mt-0.5">
                            {item.docTypeAr} • رقم: <span className="font-mono">{item.docNumber}</span>
                          </div>
                        </div>
                        {getStageBadge(item.status, item.daysRemaining)}
                      </div>

                      <div className="flex items-center justify-between mt-2 text-[10px] text-slate-400">
                        <span>
                          تاريخ الانتهاء:{' '}
                          <strong className="text-slate-200 font-mono">
                            {item.hasNoExpiry
                              ? 'دائمة (لا تنتهي)'
                              : item.expiryDate || 'غير محدد (تحتاج مراجعة)'}
                          </strong>
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setEditingItemKey(item.key);
                              setEditExpiryValue(item.expiryDate || '');
                              setEditHasNoExpiry(Boolean(item.hasNoExpiry));
                              setEditError(null);
                            }}
                            className="text-emerald-400 hover:underline flex items-center gap-1"
                          >
                            <Calendar className="w-3 h-3" />
                            <span>تعديل التاريخ</span>
                          </button>
                          <button
                            onClick={() => {
                              setActiveTab('companies');
                              setDropdownOpen(false);
                            }}
                            className="text-sky-400 hover:underline flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>فتح</span>
                          </button>
                        </div>
                      </div>

                      {editingItemKey === item.key && (
                        <div className="mt-2 p-2 bg-slate-950 rounded-lg border border-slate-700 space-y-2">
                          <div className="flex items-center gap-2">
                            <input
                              type="date"
                              disabled={editHasNoExpiry}
                              value={editExpiryValue}
                              onChange={(e) => setEditExpiryValue(e.target.value)}
                              className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white flex-1"
                            />
                            <label className="flex items-center gap-1 text-[10px] text-slate-300">
                              <input
                                type="checkbox"
                                checked={editHasNoExpiry}
                                onChange={(e) => setEditHasNoExpiry(e.target.checked)}
                              />
                              <span>وثيقة دائمة</span>
                            </label>
                          </div>
                          {editError && <p className="text-[10px] text-red-400">{editError}</p>}
                          <div className="flex justify-end gap-1.5">
                            <button
                              onClick={() => setEditingItemKey(null)}
                              className="px-2 py-1 text-[10px] bg-slate-800 text-slate-300 rounded"
                            >
                              إلغاء
                            </button>
                            <button
                              onClick={() => handleSaveManualExpiry(item)}
                              className="px-2.5 py-1 text-[10px] font-bold bg-emerald-500 text-slate-950 rounded"
                            >
                              حفظ وإعادة الفحص
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <div className="h-6 w-[1px] bg-slate-800" />

        <button
          onClick={() => setActiveTab('settings')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition shadow-sm cursor-pointer"
          title="الانتقال إلى صفحة تغيير كلمة المرور واسم المستخدم"
        >
          <KeyRound className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">تغيير الرمز واليوزر</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className="flex items-center gap-2.5 px-2 py-1 -mr-2 rounded-xl hover:bg-slate-800/60 transition group text-right cursor-pointer"
          title="إدارة الحساب والإعدادات (تغيير اسم المستخدم والرقم السري)"
        >
          <div className="w-8 h-8 rounded-full bg-emerald-600 group-hover:bg-emerald-500 text-white font-bold flex items-center justify-center text-xs shadow-inner transition">
            {currentUser?.name ? currentUser.name.charAt(0) : 'س'}
          </div>
          <div className="hidden sm:block text-right">
            <p className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 transition leading-none">
              {currentUser?.displayName || currentUser?.name || 'مكتب سند - مسقط'}
            </p>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {currentUser?.username ? `@${currentUser.username}` : 'موظف الاستقبال والمتابعة'}
            </p>
          </div>
        </button>
      </div>
    </header>
  );
};
