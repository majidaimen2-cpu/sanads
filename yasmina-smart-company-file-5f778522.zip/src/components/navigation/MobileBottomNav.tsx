import React from 'react';
import { LayoutDashboard, Sparkles, MessageSquare, FileText, Settings, Building2, Inbox } from 'lucide-react';
import { NavigationTab } from '../../types';

interface MobileBottomNavProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ activeTab, setActiveTab }) => {
  const items: { id: NavigationTab; label: string; icon: React.ReactNode }[] = [
    { id: 'companies', label: 'المنشآت', icon: <Building2 className="w-5 h-5" /> },
    { id: 'documents', label: 'الوثائق', icon: <Inbox className="w-5 h-5" /> },
    { id: 'dashboard', label: 'الرئيسية', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'requests', label: 'الطلبات', icon: <Sparkles className="w-5 h-5 text-emerald-400" /> },
    { id: 'whatsapp', label: 'الواتساب', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'transactions', label: 'المعاملات', icon: <FileText className="w-5 h-5" /> },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 px-3 py-2 flex items-center justify-around z-40">
      {items.map((item) => {
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center gap-1 p-1.5 rounded-xl transition ${
              isActive ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            {item.icon}
            <span className="text-[10px]">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
};
