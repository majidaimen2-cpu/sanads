import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Upload, FileText, Download } from 'lucide-react';
import { vaultApi, fileToBase64, VaultDocument } from '../lib/api/vault';

/**
 * Per-company document vault. Drop it into the company details view:
 *   <CompanyVaultPanel companyId={Number(company.id)} />
 * Shows the latest version of every document, expiry state, and lets staff upload a document straight to this company.
 */
export const CompanyVaultPanel: React.FC<{ companyId: number }> = ({ companyId }) => {
  const [docs, setDocs] = useState<VaultDocument[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      setDocs((await vaultApi.companyDocuments(companyId)).data);
    } catch (e: any) {
      setError(e?.message || 'تعذر تحميل الوثائق');
    }
  }, [companyId]);
  useEffect(() => {
    load();
  }, [load]);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      await vaultApi.upload(companyId, file.name, file.type || 'application/pdf', await fileToBase64(file));
      await load();
    } catch (e: any) {
      setError(e?.message || 'فشل الرفع');
    } finally {
      setUploading(false);
      if (input.current) input.current.value = '';
    }
  };

  const tone = (s: string | null) =>
    s === 'EXPIRED' ? 'text-rose-300' : s && s.startsWith('EXPIRING') ? 'text-amber-300' : 'text-emerald-300';

  return (
    <div className="space-y-3" dir="rtl">
      <div className="flex items-center justify-between">
        <h3 className="font-bold">ملف الشركة والوثائق</h3>
        <button onClick={() => input.current?.click()} disabled={uploading} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-sm disabled:opacity-50">
          <Upload className="w-4 h-4" /> {uploading ? 'جاري الرفع...' : 'رفع وثيقة'}
        </button>
        <input ref={input} type="file" accept="application/pdf,image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
      </div>
      {error && <div className="p-2 rounded-lg bg-rose-950 text-rose-200 text-sm">{error}</div>}
      {docs.length === 0 && <div className="p-6 text-center text-slate-400 text-sm">لا توجد وثائق بعد</div>}
      {docs.map((d) => (
        <div key={d.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <FileText className="w-5 h-5 text-slate-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate">{d.labelAr} {d.versionNumber > 1 ? `(نسخة ${d.versionNumber})` : ''}</div>
              <div className="text-xs text-slate-400 truncate">{d.docNumber || d.originalFileName}</div>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className={tone(d.expiryStatus)}>{d.hasNoExpiry ? 'بدون انتهاء' : d.expiryDate || 'بدون تاريخ'}</span>
            <a href={d.downloadUrl} className="text-slate-300" aria-label="تحميل"><Download className="w-4 h-4" /></a>
          </div>
        </div>
      ))}
    </div>
  );
};
