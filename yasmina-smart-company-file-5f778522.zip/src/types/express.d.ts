export interface AuthUser {
  userId: number;
  username: string;
  role: string;
  tenantId: string;
  tokenVersion: number;
  typ?: "access" | "refresh";
  jti?: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      id?: string;
    }
  }
}

export {};
