export type NavigationTab = 
  | 'dashboard' 
  | 'companies'
  | 'documents'
  | 'requests' 
  | 'whatsapp' 
  | 'transactions' 
  | 'employees'
  | 'contracts'
  | 'services'
  | 'invoices'
  | 'customers' 
  | 'analytics' 
  | 'settings';

export type RequestStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'converted';
export type RequestPriority = 'high' | 'medium' | 'low';

export interface CustomerRequest {
  id: string;
  customerPhone: string;
  customerName?: string;
  serviceCategory: string;
  serviceSubType?: string;
  extractedIntent: string;
  status: RequestStatus;
  priority: RequestPriority;
  requirementChecklist: string[];
  notes?: string;
  createdAt: string;
  updatedAt: string;
  fullRawConversation?: {
    role: 'customer' | 'assistant' | 'system';
    text: string;
    timestamp: string;
  }[];
}

export interface Transaction {
  id: string;
  title: string;
  customerName: string;
  customerPhone: string;
  serviceType: string;
  portalName: string; // e.g. Invest Easy, Ministry of Labour, Sanad, ROP
  status: 'draft' | 'submitted' | 'under_review' | 'completed' | 'rejected';
  priority: RequestPriority;
  feeOmaR: number;
  createdAt: string;
  referenceNumber?: string;
  description?: string;
  companyName?: string;
  category?: string;
  type?: string;
  amount?: number;
  paymentMethod?: string;
  currency?: string;
  companyId?: string;
  date?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  crNumber?: string; // Commercial Registration Number (سجل تجاري)
  civilId?: string; // الرقم المدني
  email?: string;
  companyName?: string;
  totalTransactions: number;
  notes?: string;
}

export interface WhatsAppMessage {
  id: string;
  phone: string;
  sender: 'customer' | 'assistant';
  text: string;
  timestamp: string;
  isAiGenerated?: boolean;
}

export type CompanyStatus = 'active' | 'pending' | 'compliance_risk' | 'inactive' | 'suspended';

export interface CompanyPhoneItem {
  number: string;
  label?: string;
  isWhatsapp?: boolean;
}

export interface Company {
  id: string;
  name: string;
  companyNameEn?: string | null;
  tradeName: string;
  taxId: string;
  taxCardNumber?: string | null;
  chamberNumber?: string | null;
  sector: string;
  status: CompanyStatus;
  revenueMonthly: number;
  currency: 'OMR' | 'SAR' | 'USD' | 'AED';
  employeesCount: number;
  city: string;
  stateCountry: string;
  whatsappConnected: boolean;
  complianceScore: number;
  createdDate: string;
  contactEmail: string;
  contactPhone: string;
  phone?: string;
  contactPhones?: string[];
  phoneItems?: CompanyPhoneItem[];
  ownerName: string;
  ownerCustomerId?: number | null;
  linkedInstanceId?: string;
  documentsCount: number;
  activeContractsCount: number;
  crExpiryDate?: string;
  crIssueDate?: string;
  licenseExpiryDate?: string;
  licenseNumber?: string;
  crDocumentUrl?: string | null;
  crDocumentName?: string | null;
  capital?: number;
  capitalAmount?: number;
  capitalBaisa?: number;
  legalForm?: string;
  version?: number;
  updatedAt?: string;
}

export type DocumentLifecycleStatus =
  | 'ACTIVE'
  | 'EXPIRING_SOON'
  | 'CRITICAL'
  | 'EXPIRED'
  | 'RENEWAL_REQUESTED'
  | 'RENEWAL_IN_PROGRESS'
  | 'RENEWED'
  | 'ARCHIVED';

export type DocumentNotificationType =
  | 'REMINDER_60'
  | 'REMINDER_30'
  | 'REMINDER_14'
  | 'REMINDER_7'
  | 'EXPIRY_DAY'
  | 'EXPIRED_ALERT'
  | 'MANUAL';

export interface DocumentNotificationRecord {
  id: string;
  companyId: string;
  companyName: string;
  documentId: string;
  documentTitle: string;
  notificationType: DocumentNotificationType | string;
  channel: 'whatsapp' | 'email' | 'sms' | 'system';
  recipient: string;
  message: string;
  status: 'SENT' | 'DELIVERED' | 'FAILED' | 'SKIPPED' | 'PENDING';
  sentAt: string;
  deliveredAt?: string;
  retryCount: number;
  error?: string;
  lastAttemptAt?: string;
  idempotencyKey: string;
  createdBy: string;
  explanationReason?: string;
}

export interface CompanyDocument {
  id: string;
  companyId: string;
  companyName: string;
  taxId?: string;
  title: string;
  type: string;
  fileUrl?: string;
  fileName?: string;
  fileSize?: string;
  issueDate?: string;
  expiryDate?: string;
  lifecycleStatus?: DocumentLifecycleStatus;
  renewalStatus?: string;
  extractedFields?: Record<string, any>;
  aiConfidence?: number;
  uploadedAt?: string;
  source?: string;
  lastNotificationAt?: string;
  lastNotificationType?: string;
  lastAuditAt?: string;
}

export interface DocumentRenewalRequest {
  id: string;
  companyId?: string;
  companyName?: string;
  documentId: string;
  documentTitle?: string;
  requestedBy: string;
  requestedAt: string;
  status: string;
  assignedTo?: string;
  priority?: string;
  customerPhone?: string;
  notes?: string;
  feeEstimatedOMR?: number;
  completedAt?: string;
  newDocumentId?: string;
  timeline?: {
    step: string;
    timestamp: string;
    actor: string;
    note?: string;
  }[];
}

export interface DocumentTimelineEvent {
  id: string;
  documentId?: string;
  companyId?: string;
  event?: string;
  title: string;
  description?: string;
  timestamp: string;
  type?: string;
  actor?: string;
  metadata?: Record<string, any>;
}

export interface DocumentExpiryAuditConfig {
  warningDays?: number;
  criticalDays?: number;
  upcomingDaysThreshold?: number;
  urgentDaysThreshold?: number;
  criticalDaysThreshold?: number;
  autonomousEnabled?: boolean;
  whatsappEnabled?: boolean;
  autoCreateRenewalTask?: boolean;
  defaultLanguage?: 'ar' | 'en' | 'bilingual';
  notificationScheduleDays?: number[];
}

export interface WhatsAppInstance {
  id: string;
  name: string;
  companyId?: string;
  phone?: string;
  phoneNumber?: string;
  profileName?: string;
  status: 'connected' | 'disconnected' | 'connecting';
  qrCode?: string;
  messagesSent24h?: number;
}

export interface WhatsAppChat {
  id: string;
  instanceId?: string;
  name?: string;
  contactName?: string;
  phone?: string;
  contactPhone?: string;
  contactNumber?: string;
  unreadCount: number;
  lastMessage?: string;
  lastMessageTime?: string;
  status?: string;
  tags?: string[];
  avatarUrl?: string;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderName: string;
  senderNumber: string;
  fromMe: boolean;
  text: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
  aiGenerated?: boolean;
}

export interface Employee {
  id: string;
  companyId: string;
  name: string;
  civilId?: string;
  nationalId?: string;
  jobTitle?: string;
  companyName?: string;
  department?: string;
  role?: string;
  contractType?: string;
  currency?: string;
  nationality?: string;
  salary?: number;
  overtimeHoursMonth?: number;
  riskStatus?: string;
  residenceExpiry?: string;
  passportExpiry?: string;
  laborCardNo?: string;
  licenseNumber?: string;
  licenseExpiryDate?: string;
  licenseFileUrl?: string;
  licenseFileName?: string;
  active: boolean;
}

export interface Contract {
  id: string;
  companyId: string;
  companyName?: string;
  partyBName?: string;
  currency?: string;
  title: string;
  type: string;
  startDate?: string;
  endDate?: string;
  value?: number;
  status: string;
  fileUrl?: string;
  fileName?: string;
}

export interface ServiceItem {
  id: string;
  code: string;
  nameAr: string;
  nameEn?: string;
  authority: string;
  govFeeOmaR: number;
  officeFeeOmaR: number;
  active: boolean;
  category?: string;
  name?: string;
  description?: string;
  priceMonthly?: number;
  activeSubscriptions?: number;
}

export interface SystemAlert {
  id: string;
  title: string;
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical' | 'warning' | 'info';
  timestamp: string;
  read: boolean;
  category?: string;
  actionPath?: string;
}

export interface UserUser {
  id: string;
  username: string;
  email: string;
  displayName?: string;
  role: string;
  active?: boolean;
  tenantId?: string;
  name?: string;
  avatarUrl?: string;
  status?: string;
  lastLogin?: string;
  permissions?: string[];
}

export interface CrewAgent {
  id: string;
  name: string;
  role: string;
  goal: string;
  backstory: string;
  status: 'idle' | 'working' | 'offline';
}

export interface AgentTask {
  id: string;
  title?: string;
  agentId: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  result?: string;
  executionTimeMs?: number;
  timestamp?: string;
}

export interface SystemMetrics {
  totalCompanies?: number;
  totalTransactions?: number;
  totalRevenueOMR?: number;
  activeContracts?: number;
  systemUptime?: string;
  activeWhatsAppConnections?: number;
  totalRevenueMonthly?: number;
  activeCompanies?: number;
  pendingComplianceIssues?: number;
  aiAgentsCount?: number;
  messagesSentToday?: number;
  cpuUsagePct?: number;
  memoryUsagePct?: number;
  apiLatencyMs?: number;
}

