declare module 'qrcode' {
  export function toDataURL(text: string, options?: any): Promise<string>;
  export function toString(text: string, options?: any): Promise<string>;
  const QRCode: {
    toDataURL: typeof toDataURL;
    toString: typeof toString;
  };
  export default QRCode;
}

declare module 'cookie-parser' {
  function cookieParser(secret?: string | string[], options?: any): any;
  export default cookieParser;
}
