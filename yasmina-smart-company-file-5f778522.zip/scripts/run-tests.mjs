// Runs every standalone test script in tests/ (they are tsx scripts, not vitest suites).
// Each script needs DATABASE_URL pointing at a PostgreSQL database (use a scratch DB, not production).
import { readdirSync } from "node:fs";
import { spawnSync } from "node:child_process";

if (!process.env.DATABASE_URL && !process.env.SQL_HOST) {
  console.error("DATABASE_URL is not set. Point it at a scratch PostgreSQL database and retry.");
  process.exit(2);
}
const files = readdirSync("tests").filter((f) => f.endsWith(".ts")).sort();
const failed = [];
for (const f of files) {
  console.log(`\n=== tests/${f} ===`);
  const r = spawnSync("npx", ["tsx", `tests/${f}`], { stdio: "inherit", env: process.env });
  if (r.status !== 0) failed.push(f);
}
console.log(failed.length ? `\nFAILED: ${failed.join(", ")}` : "\nAll test scripts passed.");
process.exit(failed.length ? 1 : 0);
